"""Resource support and escalations sharing the transactional project ledger.

All mutations are called inside DomainStore.command's SQLite transaction. No
external messages, dispatch services, tracking feeds, or live staffing are used.
"""


class CoordinationMixin:
    def support_create(self, c, p, actor):
        from domain import require, text, quantity, timestamp
        fields = self.common(c, p)
        require(bool(fields['project_id']), 'حدد مشروع طلب الدعم')
        project_id = fields['project_id']
        source = self.get(c, 'zones', p.get('from_zone_id'))
        destination = self.get(c, 'zones', p.get('to_zone_id'))
        require(source['id'] != destination['id'], 'اختر منطقتين مختلفتين للدعم')
        require(source['project_id'] == destination['project_id'] == project_id,
                'منطقتا الدعم يجب أن تتبعا المشروع نفسه', 'project_mismatch')
        responsible_id = text(p.get('responsible_id'), 'مسؤول الدعم', True, 100)
        responsible = self.get(c, 'stakeholders', responsible_id)
        require(responsible['project_id'] == project_id, 'المسؤول يتبع مشروعًا آخر', 'project_mismatch')
        incident_id = text(p.get('incident_id'), 'البلاغ المرتبط', limit=100)
        if incident_id:
            incident = self.get(c, 'incidents', incident_id)
            require(incident.get('project_id') == project_id, 'البلاغ يتبع مشروعًا آخر', 'project_mismatch')
            require(incident['status'] != 'closed', 'لا يُنشأ دعم جديد لبلاغ مقفل')
        item_id = text(p.get('item_id'), 'المورد المطلوب', limit=100)
        requested_quantity = None
        if item_id:
            item = self.get(c, 'items', item_id)
            require(item.get('project_id') == project_id, 'الصنف يتبع مشروعًا آخر', 'project_mismatch')
            requested_quantity = quantity(p.get('qty'))
        needed = timestamp(p.get('needed_by'), 'الموعد المطلوب')
        fields.update(title=text(p.get('title'), 'عنوان طلب الدعم', True, 240),
                      from_zone_id=source['id'], to_zone_id=destination['id'],
                      zone_id=destination['id'], responsible_id=responsible_id,
                      incident_id=incident_id, item_id=item_id, qty=requested_quantity,
                      needed_by=needed.isoformat(), reason=text(p.get('reason'), 'سبب الدعم', True, 2000),
                      status='requested', history=[], stock_reference='', movement_ids=[])
        return self.new(c, 'support_requests', fields, actor)

    def support_transition(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'support_requests', p.get('id'))
        current, target = row['status'], p.get('status')
        transitions = {'requested': {'approved', 'rejected', 'cancelled'},
                       'approved': {'dispatched', 'cancelled'},
                       'dispatched': {'received'}, 'received': set(),
                       'cancelled': set(), 'rejected': set()}
        require(target in transitions.get(current, set()), 'انتقال حالة الدعم غير مسموح', 'invalid_transition', 409)
        if target in {'approved', 'rejected'}:
            require(actor['role'] in {'admin', 'manager'}, 'اعتماد الدعم أو رفضه يتطلب مدير المشروع', 'forbidden', 403)
        evidence = text(p.get('evidence'), 'إثبات الدعم', True, 4000)
        reason = text(p.get('reason'), 'سبب القرار', target in {'rejected', 'cancelled'}, 2000)
        reference = 'support:' + row['id']
        if row['item_id']:
            base = {'item_id': row['item_id'], 'qty': row['qty'], 'reference': reference,
                    'phase_id': row['phase_id'], 'responsible_id': row['responsible_id'],
                    'custodian_id': row['responsible_id'], 'evidence': evidence,
                    'reason': reason or row['reason']}
            action = None
            if target == 'approved':
                action = 'reserve'
            elif target == 'dispatched':
                action = 'issue'
            elif target == 'received':
                action = 'return'
            elif target == 'cancelled' and current == 'approved':
                action = 'release'
            if action:
                move = self.stock_move(c, {**base, 'action': action,
                                          'zone_id': row['to_zone_id'] if target == 'received' else row['from_zone_id']}, actor, True)
                row['movement_ids'].append(move['id'])
        row['history'].append({'from': current, 'to': target, 'at': now(),
                               'actor_id': actor['id'], 'evidence': evidence, 'reason': reason})
        row.update(status=target, stock_reference=reference, updated_at=now())
        return self.put(c, 'support_requests', row)

    def incident_escalate(self, c, p, actor):
        from domain import require, text, timestamp, now
        row = self.get(c, 'incidents', p.get('id'))
        require(row['status'] not in {'resolved', 'closed'}, 'صعّد بلاغًا مفتوحًا أو مسندًا فقط', 'invalid_transition', 409)
        responsible_id = text(p.get('to_responsible_id'), 'مسؤول التصعيد', True, 100)
        responsible = self.get(c, 'stakeholders', responsible_id)
        require(responsible['project_id'] == row['project_id'], 'مسؤول التصعيد يتبع مشروعًا آخر', 'project_mismatch')
        deadline = timestamp(p.get('due_at'), 'مهلة التصعيد')
        reason = text(p.get('reason'), 'سبب التصعيد', True, 2000)
        evidence = text(p.get('evidence'), 'إثبات التصعيد', True, 4000)
        previous = row.get('responsible_id', '')
        previous_status = row['status']
        row.update(responsible_id=responsible_id, status='assigned',
                   escalation_level=row.get('escalation_level', 0) + 1,
                   escalation_due_at=deadline.isoformat(), escalation_reason=reason,
                   escalated_at=now(), updated_at=now())
        row['history'].append({'event': 'escalated', 'from': previous_status, 'to': 'assigned',
                               'from_responsible_id': previous, 'responsible_id': responsible_id,
                               'due_at': deadline.isoformat(), 'reason': reason, 'evidence': evidence,
                               'actor_id': actor['id'], 'at': now()})
        return self.put(c, 'incidents', row)

"""Daily zone readiness and documented handover; no external integrations.

Both commands run inside DomainStore.command's transaction, revision check and
project authorization. Closing a daily report never closes operational records.
"""
import datetime as dt
import re


class OperationsMixin:
    def daily_open(self, c, p, actor):
        from domain import require, text, now
        fields = self.common(c, p)
        for key, label in [('project_id', 'المشروع'), ('zone_id', 'المنطقة'),
                           ('phase_id', 'المرحلة'), ('responsible_id', 'مسؤول اليوم')]:
            require(bool(fields[key]), f'حدد {label} لافتتاح اليوم')
        require(bool(fields['evidence']), 'محضر افتتاح اليوم مطلوب')
        date_value = text(p.get('operational_date'), 'تاريخ التشغيل', True, 10)
        require(bool(re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', date_value)),
                'تاريخ التشغيل يجب أن يكون YYYY-MM-DD', 'invalid_operational_date')
        try:
            dt.date.fromisoformat(date_value)
        except ValueError:
            require(False, 'تاريخ التشغيل غير صالح', 'invalid_operational_date')
        raw = p.get('readiness')
        require(isinstance(raw, list) and 1 <= len(raw) <= 20,
                'سجل من بند واحد إلى 20 بندًا لجاهزية اليوم')
        readiness, seen = [], set()
        for entry in raw:
            require(isinstance(entry, dict), 'بند الجاهزية غير صالح')
            identifier = text(entry.get('id'), 'معرف بند الجاهزية', True, 80)
            require(identifier not in seen, 'معرفات بنود الجاهزية مكررة')
            seen.add(identifier)
            status = entry.get('status')
            require(isinstance(status, str) and status in {'ready', 'issue'},
                    'حالة بند الجاهزية يجب أن تكون ready أو issue')
            readiness.append({'id': identifier,
                              'label': text(entry.get('label'), 'بند الجاهزية', True, 300),
                              'status': status,
                              'notes': text(entry.get('notes'), 'تفاصيل ملاحظة الجاهزية', status == 'issue', 2000)})
        require(not any(row['zone_id'] == fields['zone_id'] and row['operational_date'] == date_value
                        and row['status'] == 'open' for row in self.all(c, 'daily_reports')),
                'يوجد تقرير يومي مفتوح لهذه المنطقة والتاريخ', 'daily_already_open', 409)
        fields.update(operational_date=date_value, readiness=readiness, status='open',
                      opening_evidence=fields['evidence'], opened_at=now(), opened_by=actor['id'],
                      closure_snapshot=None, readiness_followup=[], closed_at='', closed_by='', closing_evidence='', summary='',
                      handover_responsible_id='', handover_due_at='', handover_notes='')
        return self.new(c, 'daily_reports', fields, actor)

    def daily_snapshot(self, c, project_id, zone_id):
        from domain import now
        def in_zone(row):
            return row.get('project_id') == project_id and row.get('zone_id') == zone_id
        def brief(row):
            return {key: row[key] for key in ('id', 'title', 'status', 'priority', 'responsible_id',
                                              'from_zone_id', 'to_zone_id') if key in row}
        tasks = [brief(row) for row in self.all(c, 'tasks') if in_zone(row) and row['status'] != 'completed']
        incidents = [brief(row) for row in self.all(c, 'incidents') if in_zone(row) and row['status'] != 'closed']
        support = [brief(row) for row in self.all(c, 'support_requests')
                   if row.get('project_id') == project_id
                   and zone_id in {row.get('zone_id'), row.get('from_zone_id'), row.get('to_zone_id')}
                   and row['status'] not in {'received', 'cancelled', 'rejected'}]
        critical = [row for row in incidents if row.get('priority') == 'critical' and row['status'] in {'open', 'assigned'}]
        return {'captured_at': now(), 'tasks': tasks, 'incidents': incidents, 'support_requests': support, 'readiness_issues': [],
                'counts': {'tasks': len(tasks), 'incidents': len(incidents), 'support_requests': len(support),
                           'total': len(tasks) + len(incidents) + len(support), 'critical_incidents': len(critical), 'readiness_issues': 0}}

    def daily_close(self, c, p, actor):
        from domain import require, text, timestamp, now
        require(actor.get('role') in {'admin', 'manager'}, 'إقفال اليوم يتطلب مدير المشروع', 'forbidden', 403)
        row = self.get(c, 'daily_reports', p.get('id'))
        require(row['status'] == 'open', 'التقرير اليومي مقفل بالفعل', 'invalid_transition', 409)
        evidence = text(p.get('evidence'), 'محضر إقفال اليوم', True, 4000)
        summary = text(p.get('summary'), 'ملخص اليوم', True, 4000)
        snapshot = self.daily_snapshot(c, row['project_id'], row['zone_id'])
        require(snapshot['counts']['critical_incidents'] == 0,
                'لا يمكن إقفال اليوم مع بلاغ حرج مفتوح أو مسند في المنطقة', 'critical_incident_open', 409)
        opening_issues = {item['id']: item for item in row['readiness'] if item['status'] == 'issue'}
        raw_followup = p.get('readiness_followup', [])
        require(isinstance(raw_followup, list) and len(raw_followup) <= 20, 'متابعة ملاحظات الافتتاح غير صالحة')
        require(not opening_issues or bool(raw_followup),
                'سجل معالجة أو ترحيل كل ملاحظة من محضر افتتاح اليوم', 'readiness_followup_required', 409)
        followup, seen = [], set()
        for entry in raw_followup:
            require(isinstance(entry, dict), 'متابعة بند الجاهزية غير صالحة')
            identifier = text(entry.get('id'), 'معرف ملاحظة الافتتاح', True, 80)
            require(identifier in opening_issues and identifier not in seen,
                    'ملاحظة افتتاح غير معروفة أو مكررة', 'invalid_readiness_followup')
            seen.add(identifier)
            status = entry.get('status')
            require(isinstance(status, str) and status in {'resolved', 'carryover'},
                    'حدد معالجة الملاحظة أو ترحيلها')
            followup.append({'id': identifier, 'label': opening_issues[identifier]['label'], 'status': status,
                             'notes': text(entry.get('notes'), 'نتيجة معالجة أو ترحيل الملاحظة', True, 2000),
                             'evidence': evidence if status == 'resolved' else ''})
        require(seen == set(opening_issues), 'سجل معالجة أو ترحيل كل ملاحظة افتتاح', 'readiness_followup_required', 409)
        snapshot['readiness_issues'] = [dict(entry) for entry in followup if entry['status'] == 'carryover']
        snapshot['counts']['readiness_issues'] = len(snapshot['readiness_issues'])
        snapshot['counts']['total'] += len(snapshot['readiness_issues'])
        outstanding = snapshot['counts']['total'] > 0
        provided = any(p.get(key) for key in ('handover_responsible_id', 'handover_due_at', 'handover_notes'))
        require(not outstanding or all(p.get(key) for key in ('handover_responsible_id', 'handover_due_at', 'handover_notes')),
                'الأعمال المتبقية تحتاج مسؤول تسليم وموعدًا وملاحظات متابعة', 'handover_required', 409)
        responsible_id = due_at = handover_notes = ''
        if outstanding or provided:
            responsible_id = text(p.get('handover_responsible_id'), 'مسؤول متابعة المتبقي', True, 100)
            responsible = self.get(c, 'stakeholders', responsible_id)
            require(responsible['project_id'] == row['project_id'], 'مسؤول التسليم يتبع مشروعًا آخر', 'project_mismatch')
            due_at = timestamp(p.get('handover_due_at'), 'موعد متابعة المتبقي').isoformat()
            handover_notes = text(p.get('handover_notes'), 'ملاحظات تسليم المتبقي', True, 4000)
        row.update(status='closed', closed_at=now(), closed_by=actor['id'], closing_evidence=evidence,
                   summary=summary, closure_snapshot=snapshot, readiness_followup=followup, handover_responsible_id=responsible_id,
                   handover_due_at=due_at, handover_notes=handover_notes)
        return self.put(c, 'daily_reports', row)

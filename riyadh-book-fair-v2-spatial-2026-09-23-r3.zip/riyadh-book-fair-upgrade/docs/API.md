# عقد API — إدارة معرض الرياض الدولي للكتاب

تنفيذ Python stdlib + SQLite. البيانات في الخادم؛ لا يعتمد السماح بالإجراء على إخفاء أزرار الواجهة. كل أمر، وحركات المخزون الناتجة عنه، وتحديث رقم النسخة، وسجل التدقيق تنفذ في معاملة واحدة. فشل أي شرط يلغي المعاملة كلها.

## الاتصال والجلسة

- `GET /api/health`: حالة الخدمة والإصدار ووضع التشغيل فقط.
- `GET /api/session` أو `/api/session/me`: `{authenticated,user,mode,data_mode,review,roles}`.
- `POST /api/session/login`: `{username,password}`. يعيد Cookie تحمل `HttpOnly; SameSite=Strict` و`Secure` مع أصل HTTPS. صلاحية الجلسة ثماني ساعات.
- `POST /api/session/logout`: `{}`؛ يلغي الجلسة من الخادم.
- `POST /api/session`: يقبل أيضًا `{action:'login',username,password}` أو `{action:'logout'}`.
- يجب أن يحمل كل POST ترويسة `Content-Type: application/json` و`Origin` معتمدًا. لا توجد CORS مفتوحة.
- `--review` هوية مدير مراجعة تلقائية على loopback فقط. ليس آلية دخول إنتاجية.

## قراءة الحالة والتزامن

`GET /api/state` يتطلب جلسة، ويعيد:

```text
revision, mode, data_mode, user, permissions, capabilities,
provenance_notice, integrations,
projects, phases, zones, stakeholders, items, stock, stock_moves,
reservations, custody, stock_counts, orders, tasks, permits, access_logs,
incidents, decisions, procurements, observations, spatial_jobs, spatial_plans, support_requests, attachments, daily_reports, closeout, audit
```

- `mode`: `demo` أو `review` أو `production`. `data_mode`: `demo` أو `manual`.
- `permissions`: أسماء الأوامر المسموحة للدور؛ تطبق الصلاحيات مرة أخرى على الخادم.
- جميع السجلات الجديدة تحمل `id,created_at,created_by,provenance`، ومعرّفات الربط حيث تنطبق.
- `provenance` يحدده نوع قاعدة البيانات؛ لا يمكن للمتصفح تحويله إلى `live`.
- السجلات الحساسة للزائر (`customer_name,customer_phone,address`) محجوبة عن `viewer,field,security`؛ يرى المدير والمستودع البيانات اللازمة لتنفيذ التسليم.
- الحساب الذي يحدد `project_ids` يرى بيانات تلك المشاريع فقط. لا توجد صلاحيات دقيقة مستقلة لكل منطقة في هذا الإصدار.
- `audit` يعرض آخر 200 حدث؛ النسخة الاحتياطية تحتوي كامل السجل.
- `GET /api/backup` أو `/api/export`: تنزيل JSON كاملة بالسجلات وسجل التدقيق، دون كلمات المرور أو الجلسات. تتطلب `admin/manager` غير مقيد بنطاق مشاريع. لا يوجد API للاستيراد أو الحذف الشامل.

## إرسال أمر

```json
{
  "type": "stock.move",
  "expected_revision": 42,
  "payload": {
    "action": "receipt",
    "item_id": "ITM-...",
    "zone_id": "ZON-...",
    "qty": 10,
    "evidence": "محضر الاستلام رقم ..."
  }
}
```

النجاح: `{ok:true,revision,result}`. الخطأ: `{error,code}` برسالة عربية. يلزم أخذ `revision` من آخر حالة؛ `428 revision_required` عند غيابه، و`409 revision_conflict` إذا سبق تعديل آخر. لا تعد الطلب تلقائيًا دون تحديث الحالة ومراجعة النتيجة.

حقول مشتركة: `project_id,phase_id,zone_id,responsible_id,evidence,notes`. تُفحص المراجع ويُرفض ربط سجلات مشاريع مختلفة. جميع الكميات أعداد صحيحة؛ التواريخ ذات الوقت ISO 8601 مع منطقة زمنية مثل `2026-09-23T14:00:00+03:00`.

## السجلات والمخزون

| الأمر | الحقول الأساسية |
|---|---|
| `shared.create` | `collection: projects/phases/zones/stakeholders`, `name`؛ يلزم `project_id` عدا إنشاء المشروع |
| `item.create` | `kind: equipment/book/consumable`, `name`, `project_id`, `owner_id`, `title?`, `edition?`, `isbn?`, `unit?`؛ الناشر/المالك إلزامي للكتاب |
| `stock.move` | `action,item_id,zone_id,qty,reference?,to_zone_id?,custodian_id?,evidence?,reason?` |
| `stock.settle` | `item_id,reference,qty,disposition,reason,evidence`؛ مدير أو admin فقط |
| `stock.count` | `item_id,zone_id,counted_qty,evidence` مع الحقول المشتركة الاختيارية |
| `stock.count.review` | `id,status: approved/rejected,reason,evidence` |

`phases.kind`: `foundation/planning/procurement/build/operations/dismantling/closeout` ومعه `order` عدد صحيح. `zones.capacity` سعة مرجعية. `stakeholders` يقبل `role,organization,contact`؛ هذه سجلات الجهات، وليست حسابات تسجيل الدخول.

حركات `stock.move`:

- `receipt`: استلام؛ إثبات إلزامي.
- `reserve/release`: حجز وتحرير مرتبطان بـ `reference`؛ لا يمكن تحرير حجز مرجع مختلف.
- `issue`: صرف بعهدة؛ يلزم `reference,custodian_id,evidence`. يستهلك حجز المرجع نفسه أولًا ثم المتاح.
- `return`: استرجاع؛ يلزم `reference,evidence`، ولا يتجاوز العهدة القائمة. يمكن الاسترجاع إلى موقع مختلف داخل المشروع.
- `transfer`: نقل متاح غير محجوز؛ يلزم `to_zone_id,evidence`.
- `consume`: استهلاك مواد استهلاكية من المتاح دون إنشاء عهدة؛ يلزم `reference,responsible_id,evidence`. لا يستهلك المحجوز.
- `maintenance/restore`: إخراج معدات للصيانة وإعادتها؛ إثبات إلزامي، وتنفصل كمية الصيانة عن المتاح.
- `ship`: شحن نهائي من المخزون، كإعادة المتبقي إلى الناشر؛ إثبات إلزامي. متابعة الناقل إدخال يدوي، ولا توجد شركة شحن متصلة.

الأرصدة `stock`: `{id,item_id,zone_id,on_hand,reserved,available,maintenance}`. المتاح = الموجود − المحجوز. لا يسمح بأي رصيد سالب. `custody` تتتبع `issued,returned,outstanding,custodian_id,reference,kind,project_id`. `kind:order` يمثل كتب الزائر التي خرجت، ولا يحسب عهدة معدات معلقة للإقفال.

تسوية العهدة `stock.settle` تقلل العهدة القائمة دون إضافة مخزون. `consumed` للمواد الاستهلاكية، و`publisher_sold` للكتب التي يثبت الناشر بيعها، و`final_delivery/loss_damage` للمعدات أو الكتب أو المواد بمحضر مدير. لا يمكن تسوية مرجع طلب زائر من هذا الأمر. تحفظ حركة `settlement` وكمية `custody.settled`؛ مجموع المصروف يساوي المرتجع + التسوية + العهدة المتبقية. لحركة التسوية `zone_id` فارغ لأنها لا تحرك مخزون موقع، و`balance_after:null`.

الجرد مطابقًا للرصد الحالي ينتج `matched`. الفرق ينتج `pending` ولا يعدّل الرصيد. اعتماد مدير ينتج حركة `adjustment` محفوظة، بعد التحقق أن المخزون لم يتحرك منذ الجرد وألا يقل الرصيد المعدل عن المحجوز. المخزون المتحرك بعد الجرد يتطلب جردًا جديدًا.

## مشتريات الزوار

`order.create`:

```json
{
  "project_id": "PRJ-...",
  "customer_name": "اسم المستلم",
  "customer_phone": "...",
  "address": "عنوان التسليم",
  "lines": [
    {"item_id":"ITM-...","zone_id":"ZON-...","qty":2},
    {"item_id":"ITM-...","zone_id":"ZON-...","qty":1}
  ]
}
```

يحجز جميع البنود أو لا يحجز شيئًا عند العجز. قد تختلف جهات النشر. `order.transition {id,status,evidence?,reason?,tracking_number?,carrier?}`:

`ordered → picking → packed → shipped → delivered`.

- الإثبات مطلوب للتغليف والشحن والتسليم والإلغاء والاسترجاع.
- الشحن يتطلب عنوانًا مسجلًا، `carrier` و`tracking_number`؛ يصرف الرصيد مرة واحدة.
- `cancelled` قبل الشحن فقط، مع سبب؛ يحرر جميع الحجوزات.
- `exception` يتطلب سببًا، ثم العودة إلى الحالة السابقة بإثبات أو إلغاء/مرتجع وفق حالة الشحن.
- `returned` يعيد كامل بنود طلب مشحون إلى المخزون، مع سبب وإثبات. لا توجد مرتجعات جزئية أو إلغاء جزئي في هذا الإصدار.
- لا توجد بوابة دفع أو حساب ضرائب أو تسويات ناشرين؛ `payment_status=not_integrated` دائمًا.

## المهام والتصاريح

`task.create {title,project_id,phase_id?,zone_id?,responsible_id?,dependencies:[],start_date?,due_date?,inspection_required:true,inspection_checklist?:[{id,label,required:true}],permit_id?}`. التاريخ المجرد `YYYY-MM-DD`.

`task.transition {id,status,evidence?,inspection_result?,reason?}`:

- `planned → active → inspection → completed`، مع `blocked` والعودة إلى العمل.
- لا يبدأ العمل أو يكتمل قبل اكتمال الاعتماديات.
- إذا رُبط تصريح، يلزم تطابق المشروع والمنطقة وصلاحية التصريح عند البدء والإكمال.
- `task.inspect {id,results:[{item_id,status:passed/failed,notes?}],evidence,attachment_ids?:[]}` ينشئ تقرير فحص للمدير أو admin في مرحلة `inspection`. كل بند إلزامي يحتاج نتيجة، والفشل يحتاج ملاحظة. القائمة من بند إلى20، والافتراضية: `scope` نطاق العمل، `quality` الجودة والوظيفة، `handover` التسليم.
- الإكمال بعد فحص مطلوب يحتاج أحدث تقرير بنود ناجح للدورة الحالية؛ لا يكفي إرسال `inspection_result:passed`. تحفظ التقارير في `task.inspections` مع المفتش والوقت والإثبات والنتائج.
- العودة إلى `active` تزيد `inspection_cycle` وتبطل نتيجة الفحص السابقة. المرفقات، إن حددت، يجب أن تتبع المشروع نفسه.

`permit.create {title,holder_name,holder_id?,kind:person/vehicle/team/supplier,vehicle_plate?,authority,approval_role:security/manager,valid_from,valid_until,project_id?,phase_id?,zone_id,responsible_id?}`.

يمكن إضافة `approval_steps:[{id,authority,role:security/manager,stakeholder_id?}]` من خطوة إلى ثلاث خطوات بدل `authority/approval_role` المفردتين. جهة stakeholder مرتبطة بالمشروع نفسه. الحقول المفردة ما زالت مقبولة وتنتج خطوة واحدة.

`permit.transition {id,status,evidence?,reason?}`: `proposed → submitted → approved/rejected`، و`approved → revoked`. كل طلب `status:approved` يعتمد الخطوة الحالية فقط، ويبقى التصريح `submitted` حتى اكتمال كل الخطوات. `current_step_index` يبدأ صفرًا ويصبح عدد الخطوات عند الإكمال. الاعتماد/الرفض للدور المحدد في الخطوة الحالية أو admin، والسحب لدور آخر خطوة أو admin. الإثبات مطلوب، والرفض/السحب يحتاج سببًا. لا يسمح بالدخول قبل اكتمال جميع الخطوات.

`permit.access {id,action:checkin/checkout,zone_id?,evidence}` للأمن أو admin. لا دخول خارج الصلاحية، أو إلى منطقة مختلفة، أو دخول مكرر. يمكن تسجيل الخروج بعد انتهاء/سحب التصريح.

## غرفة القيادة والشراء

- `incident.create {title,description,priority:critical/high/medium/low,source:manual/field/prediction,category?,observed_at?,...common}`.
- `incident.transition {id,status:assigned/resolved/closed,responsible_id?,evidence?}`. الإسناد يلزم مسؤولًا؛ الحل يحتاج قرارًا مسجلًا وإثباتًا؛ الإقفال لمسؤول قيادة.
- `incident.decision {incident_id,decision,action,impact,impact_type:expected/observed,responsible_id?,evidence}`. القرار/الإجراء/الأثر أجزاء مستقلة موثقة.
- `observation.create {zone_id,responsible_id,observed_at?,people_count,capacity,wait_minutes?,satisfaction_score?,sample_size?,evidence,...common}`. أعداد موجبة أو صفر، السعة موجبة، الرضا 0–5 ومعه حجم عينة. رصد يدوي دائمًا، ولا يقبل `source:live`.
- `procurement.create {title?,item_id,qty,supplier_id,zone_id,...common}`.
- `procurement.transition {id,status:approved/ordered/received,evidence}`. الاعتماد وإصدار الطلب للمدير؛ الاستلام يولّد حركة استلام مرة واحدة. لا استلام جزئي في هذا الإصدار.

## التشغيل اليومي

- `daily.open {project_id,phase_id,zone_id,responsible_id,operational_date,readiness,evidence,notes?}` يفتح سجل المنطقة لليوم. التاريخ `YYYY-MM-DD`؛ جميع الروابط المشتركة موجودة وفي المشروع نفسه.
- `readiness` من1 إلى20 بندًا: `{id,label,status:ready/issue,notes?}`. المعرفات فريدة، و`issue` يحتاج وصفًا. الإثبات محضر افتتاح؛ بيانات الجاهزية مدخلة يدويًا وليست حالة حساسات متصلة.
- أدوار الافتتاح: `admin/manager/warehouse/security/field`. لا يسمح بأكثر من تقرير مفتوح للمنطقة والتاريخ نفسيهما، حتى عند طلبين متزامنين. يمكن فتح وردية أخرى للتاريخ نفسه بعد إقفال التقرير السابق.
- `daily.close {id,evidence,summary,readiness_followup?,handover_responsible_id?,handover_due_at?,handover_notes?}` للمدير أو admin فقط. يرفض مع بلاغ `critical` في `open/assigned` داخل المشروع والمنطقة الحاليين، مهما كان تاريخ إنشائه أو رصده؛ مرور الوقت لا يسقط خطرًا قائمًا. بلاغ مشروع آخر أو منطقة أخرى أو بلاغ `closed` لا يمنع إقفال هذه المنطقة.
- لكل بند افتتاح حالته `issue` يلزم عنصر واحد في `readiness_followup:[{id,status:resolved/carryover,notes}]`، دون إغفال أو تكرار. الملاحظات إلزامية؛ `resolved` يسجل نتيجة المعالجة ومحضر الإقفال إثباتًا لها، و`carryover` يدخل المتبقي ويفرض التسليم. تحفظ المتابعة كاملة في التقرير.
- يحسب الخادم وقت الإقفال الأعمال المتبقية: مهام غير مكتملة، بلاغات غير مقفلة، وطلبات دعم غير منتهية تستخدم المنطقة مصدرًا أو وجهة. إذا بقي أي منها، تلزم حقول التسليم الثلاثة؛ مسؤول التسليم من المشروع نفسه، وموعده ISO مع منطقة زمنية.
- يحفظ `closure_snapshot` قوائم مختصرة ومعها `counts:{tasks,incidents,support_requests,readiness_issues,total,critical_incidents}` ووقت الالتقاط، وتدخل ملاحظات الافتتاح المرحلة في `closure_snapshot.readiness_issues`. يحفظ `closed_at,closed_by,closing_evidence,summary` وبيانات التسليم.
- إقفال التقرير لا يغلق مهمة أو بلاغًا أو طلب دعم تلقائيًا. تظل اللقطة ثابتة ولو تغيرت الأعمال لاحقًا، والتقارير المفتوحة تمنع إقفال المشروع.
- نطاق التقرير المشروع والمنطقة معًا، ولا يرشّح المتبقي حسب تاريخ إنشائه؛ البلاغات في مناطق أو مشاريع أخرى لا تدخل لقطته. البلاغ `resolved` لم يقفل بعد يدخل التسليم، دون أن يعاد إقفاله تلقائيًا. التقرير اليومي يقبل مرفقات خاصة عبر `record_collection:daily_reports`.

## الإثباتات والمرفقات الخاصة

- `attachment.create {project_id,filename,content_type,data_base64,label?,record_collection?,record_id?,phase_id?,zone_id?,responsible_id?}`. إذا رُبط المرفق بسجل، يلزم نوع السجل ومعرّفه معًا وفي المشروع نفسه.
- يقبل PNG/JPEG/WebP/PDF فقط، بحد 5 MiB للملف. يطابق الامتداد والنوع والتوقيع الأساسي للملف، ويفحص Base64 واسم الملف. لا يقبل مسارات من اسم الملف أو ملفات HTML/SVG/JavaScript تنفيذية.
- `state.attachments` معلومات مرجعية وحجم وSHA-256، دون بايتات الملفات. لا يحتفظ الخادم بالملف تحت مسار static؛ البايتات BLOB في SQLite وتُحفظ في المعاملة نفسها.
- `GET /api/attachments/ATT-...` يتطلب جلسة ودور تشغيل ونطاق مشروع صالحًا. دور `viewer` يرى metadata فقط ولا ينزّل الملف. المرفق المرتبط بطلب زائر متاح لـ`admin/manager/warehouse` فقط؛ يُحجب اسمه التفصيلي عن بقية الأدوار.
- كل تنزيل `application/octet-stream` و`Content-Disposition: attachment`، مع التحقق من SHA-256 قبل إعادته.
- حد POST العادي 1 MiB؛ أمر رفع المرفق فقط يسمح حتى 8 MiB لحاوية Base64.
- التصدير JSON يتضمن `attachment_contents` مع Base64/الحجم/SHA-256؛ نسخة SQLite تتضمن جدول البايتات تلقائيًا.
- التحقق من التوقيع ليس فحصًا لمكافحة البرمجيات الخبيثة؛ لا توجد خدمة فحص ملفات متصلة.

## الدعم بين المناطق والتصعيد

- `support.create {title,project_id,from_zone_id,to_zone_id,responsible_id,needed_by,reason,item_id?,qty?,incident_id?,phase_id?}`. المشروع والمنطقتان والمسؤول متطابقون؛ المورد اختياري لطلبات فرق العمل غير المخزنية.
- `support.transition {id,status,evidence,reason?}`: `requested → approved → dispatched → received`، مع `rejected/cancelled` قبل الإرسال. اعتماد/رفض المدير فقط. الطلب المخزني يحجز عند الاعتماد، ويصرف عهدة مؤقتة أثناء النقل، ثم يسترجع إلى رصيد موقع الوجهة عند إثبات الاستلام. الإلغاء يحرر حجزه وحده. لا تُستعمل مراجع `support:` في حركات يدوية أو تسوية عهدة خارج هذه الدورة.
- `incident.escalate {id,to_responsible_id,due_at,reason,evidence}`. ينقل مسؤولية بلاغ غير محلول إلى المسؤول المحدد ويزيد مستوى التصعيد ويحفظ المهلة والسبب والتدقيق. لا يرسل بريدًا أو رسالة خارجية.
- طلبات الدعم غير المنتهية تمنع إقفال المشروع.

## المسار المكاني

- `spatial.create {title,input_type:svg/dxf/image,source_file,...common}`.
- `spatial.transition {id,status:calibrated/reviewed/exported,evidence,...}`.
- المعايرة تحتاج `scale_meters,reference_pixels,height_meters` موجبة.
- التصدير يحتاج `output_file` ينتهي بـ `.glb` أو `.gltf` بعد مراجعة بشرية.
- يسجل هذا API مراجع العمل والاعتماد. لا ينفذ أوامر Blender أو يحمل ملفات من روابط غير موثوقة داخل الخادم. الأدوات المحلية الخاصة بالمخططات موثقة في مسارها المنفصل.

### نسخ المخططات الفعلية

`spatial_plan.create {project_id,title,source_reference,source_version,source_units,source_crs?,plan}` يحفظ **نسخة مستقلة** في `state.spatial_plans`. يجب أن يكون `plan` مستند JSON بصيغة `scripts/spatial/plan_schema.py`: `schema_version:1`، الإحداثيات المحلية بالمتر و`right-handed-z-up`، مصدر ومعايرة صالحان، وعناصر ذات مضلعات سليمة. يجب أن يشير كل `element.zone_id` إلى منطقة موجودة في المشروع نفسه. لا يقبل خادم الأوامر مخططًا يتجاوز 900 KiB بعد تسلسله، أو 5,000 رأس إجمالًا، أو عبئًا يتجاوز 500,000 زوج ضلع محتمل لفحص التقاطع؛ يُرفض المخطط المعقد قبل الفحص المكلف، ويمكن تقسيمه إلى مناطق أصغر. حد الحجم يترك حيزًا لبيانات الأمر تحت حد طلب HTTP البالغ 1 MiB. لا توجد عملية تعديل للنسخة بعد التسجيل؛ إذا تغيّر المصدر أو الرسم، سجّل نسخة جديدة.

حقول مصدر النسخة إلزامية ما عدا `source_crs` الاختياري. `source_reference` قد يكون رقم رسم أو محضرًا أو رابطًا مرجعيًا، و`source_version` نسخة ذلك المصدر، و`source_units` وحدة إحداثياته الأصلية؛ `plan.units` يظل مترًا بعد المعايرة. يحفظ الخادم `plan` و`plan_json` المتسلسل ترتيبًا ثابتًا و`plan_sha256` لبصمة البايتات المسلسلة، مع `status:draft` واسم منشئ السجل. يزيل الخادم أي `plan.review` مزعوم في ملف الإدخال ويعيده إلى غير معتمد.

`spatial_plan.review {id,evidence}` متاح لـ`admin/manager` فقط. يفحص سلامة النسخة المسجلة والمنطقة/المشروع ومعلومات المصدر؛ يشترط `plan.provenance.source_file` و`source_type` وبصمة `source_sha256` من 64 رقمًا سداسيًا، ويرفض `data_class:demo` وقاعدة البيانات التجريبية. بعد محضر مراجعة غير فارغ، يسجل هوية المراجع المصدق ووقته ورقم `review_revision` المتزايد في السجل و`plan.review`، ويعيد حساب `plan_json` وبصمته، ويغير الحالة إلى `reviewed`. يحدد رقم المراجعة أحدث نسخة حتى لو حدث قراران في الثانية نفسها. لا تتكرر المراجعة على النسخة نفسها؛ أنشئ نسخة جديدة عند التصحيح. كل إنشاء أو مراجعة يزيد رقم النسخة ويظهر في سجل التدقيق والتصدير الاحتياطي. الحساب المقيد بمشاريع لا يرى ولا يعتمد مخططات خارج نطاقه.

المراجعة تؤكد أن شخصًا مخولًا فحص الربط والمعايرة والسند المسجل؛ لا تثبت وحدها دقة مساحية، أو تطابق الموقع الفعلي، أو صحة ملف المصدر المشار إليه. بصمة المصدر يرفعها المستخدم مع المخطط ولا يقارنها الخادم ببايتات ملف أصل مستقل. لا يوجد GIS أو حساسات أو تصدير Blender متصل بالخادم في هذا الأمر.

## الإقفال

`state.closeout` يحتوي تقريرًا لكل مشروع: `{project_id,status,ready,blockers:[{code,label,count,ids}]}`.

`project.close {id,evidence,summary}` للمدير؛ يمنع عند وجود مهام أو بلاغات أو طلبات أو مشتريات معلقة، دخول قائم، عهد تشغيلية، حجوزات، معدات بالصيانة، أو مواقع مخزون بلا جرد نهائي حديث. بعدها يمنع الخادم معاملات المشروع. `project.reopen {id,reason,evidence}` يعيد فتحه باعتماد موثق؛ لا يحذف سجل الإقفال.

## حدود الإصدار

الإثباتات مراجع نصية أو ملفات خاصة محفوظة في SQLite؛ لا توجد خدمة لمكافحة البرمجيات الخبيثة. لا بوابات خارجية للأمن، ولا بريد أو SMS، ولا حساسات حشود أو تنبؤ معتمد. المصادقة حسابات محلية مجزأة؛ لا SSO/MFA. النسخة الحالية للتشغيل المحدود بعد مراجعة الموقع والنسخ الاحتياطي والاختبار؛ لا تدّعي اختبارات تحمل على مستوى معرض كامل.

#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
source scripts/select-runtime.sh
print 'مراجعة محلية تجريبية: http://127.0.0.1:8765'
print 'البيانات تُحفظ في data/review-demo.sqlite؛ لا تُحذف عند إغلاق النافذة.'
exec "$rbf_python" server.py --review --demo --db data/review-demo.sqlite --port "${RBF_PORT:-8765}"

#!/usr/bin/env python3
"""Extract inert, privacy-redacted reference pages; never execute legacy JavaScript.

Run from any directory. The trusted byte-for-byte source stays under baseline/ and
is never copied into the public application. This uses the Python standard library.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_SHA = "28336aa3fcb741fb34ecfd9bb6bce7e5aebfe0f8f166bc67a23bb51cc11dc221"
SOURCE_URL = "https://riyadh-book-fair.onrender.com"
COMMIT = "29e836d4ec1164e524150377ec1b9c8cf3deaf20"
CSP = ("default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; "
       "img-src data:; font-src 'none'; connect-src 'none'; object-src 'none'; "
       "base-uri 'none'; form-action 'none'; frame-src about:; "
       "worker-src 'none'; media-src 'none'")
PHONE = re.compile(r"(?<![\d\w])(?:\+?966|00966|05)(?:[\s-]?\d){7,10}(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
BLOCKED = {"script", "object", "embed", "applet", "audio", "video", "source", "track", "foreignobject"}
BANNER = ('<aside role="note" style="position:relative;z-index:2147483647;'
          'padding:12px 18px;background:#fff5d6;color:#563d00;border-bottom:2px solid #d7ae44;'
          'font:600 14px/1.8 Tahoma,Arial,sans-serif;text-align:right" dir="rtl">'
          'مرجع تصميم · بيانات محاكاة وليست بيانات تشغيل حية · '
          'الأسماء وبيانات الاتصال محجوبة · الأزرار والروابط الخارجية معطّلة</aside>')


def parse_assignment(source: str, marker: str):
    return json.JSONDecoder().raw_decode(source[source.index(marker) + len(marker):])[0]


def scrub_css(css: str) -> str:
    css = re.sub(r"@import\s+[^;]+;?", "", css, flags=re.I)
    css = re.sub(r"url\(\s*(['\"]?)(.*?)\1\s*\)",
                 lambda m: m.group(0) if m.group(2).startswith(("#", "data:image/")) else "none", css, flags=re.I)
    return re.sub(r"expression\s*\([^)]*\)", "", css, flags=re.I)


class InertHTML(HTMLParser):
    def __init__(self, redactions: dict[str, str], depth: int = 0):
        super().__init__(convert_charrefs=True)
        self.redactions = redactions
        self.depth = depth
        self.out: list[str] = []
        self.skip: list[str] = []
        self.in_style = False

    def redact(self, value: str) -> str:
        for private, replacement in self.redactions.items():
            value = value.replace(private, replacement)
        return EMAIL.sub("[بريد محجوب]", PHONE.sub("[رقم محجوب]", value))

    def handle_decl(self, decl):
        if not self.skip and decl.lower() == "doctype html":
            self.out.append("<!doctype html>")

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if self.skip:
            if tag not in VOID:
                self.skip.append(tag)
            return
        if tag in BLOCKED:
            if tag not in VOID:
                self.skip.append(tag)
            return
        if tag == "iframe":
            # The executive dashboard contains an embedded map design. Preserve
            # only its sanitized srcdoc, never a remote iframe or active script.
            if attrs.get("srcdoc") and self.depth < 2:
                nested = sanitize(attrs["srcdoc"], self.redactions, self.depth + 1)
                self.out.append('<iframe sandbox="" referrerpolicy="no-referrer" '
                                'title="مخطط مرجعي ثابت" srcdoc="' + html.escape(nested, quote=True) + '"></iframe>')
            else:
                self.out.append('<div role="note" style="padding:32px;text-align:center;background:#122b35;color:#e7c77b">'
                                'مرجع خريطة خارجية — الاتصال الخارجي معطّل في الأرشيف</div>')
            self.skip.append(tag)
            return
        if tag in {"base", "link"}:
            return
        if tag == "meta" and not ("charset" in attrs or attrs.get("name", "").lower() == "viewport"):
            return
        tag = "div" if tag == "form" else tag
        safe = []
        for key, value in attrs.items():
            value = value or ""
            if key.startswith("on") or key in {"srcdoc", "srcset", "action", "formaction", "target", "ping", "download", "contenteditable", "autofocus", "value", "nonce", "integrity"}:
                continue
            if key in {"src", "href", "xlink:href", "poster", "background", "data", "codebase"}:
                if not (value.startswith("#") or (tag == "img" and value.startswith(("data:image/png;", "data:image/jpeg;", "data:image/webp;")))):
                    continue
            if key == "type" and value.lower() == "password":
                value = "text"
            if key == "style":
                value = scrub_css(value)
            safe.append((key, self.redact(value)))
        if tag in {"input", "button", "select", "textarea"}:
            safe += [("disabled", ""), ("aria-disabled", "true")]
        attr_text = "".join(' ' + k + '="' + html.escape(v, quote=True) + '"' for k, v in safe)
        self.out.append("<" + tag + attr_text + ">")
        if tag == "head":
            self.out.append('<meta http-equiv="Content-Security-Policy" content="' + html.escape(CSP, quote=True) + '">')
        if tag == "body":
            self.out.append(BANNER)
        if tag == "style":
            self.in_style = True

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if self.skip:
            if tag in self.skip:
                while self.skip:
                    if self.skip.pop() == tag:
                        break
            return
        if tag in BLOCKED or tag in VOID or tag == "iframe":
            return
        self.out.append("</" + ("div" if tag == "form" else tag) + ">")
        if tag == "style":
            self.in_style = False

    def handle_data(self, data):
        if self.skip:
            return
        self.out.append(scrub_css(data) if self.in_style else html.escape(self.redact(data), quote=False))


def sanitize(source: str, redactions: dict[str, str], depth: int = 0) -> str:
    # Original srcdoc strings deliberately escape closers to fit the outer script.
    source = source.replace("<\\/script>", "</script>").replace("<\\/style>", "</style>")
    parser = InertHTML(redactions, depth)
    parser.feed(source)
    parser.close()
    result = "".join(parser.out)
    if "Content-Security-Policy" not in result:
        result = '<meta http-equiv="Content-Security-Policy" content="' + html.escape(CSP, quote=True) + '">' + result
    return result


def extract(source: Path, output: Path) -> dict:
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != EXPECTED_SHA:
        raise ValueError("Baseline hash mismatch. Review source before extracting.")
    text = raw.decode("utf-8")
    pages = parse_assignment(text, "const pages=")
    if len(pages) != 22:
        raise ValueError("Expected exactly 22 legacy pages.")
    team = parse_assignment(pages[-1]["html"], "const TEAM_DATA=")
    redactions: dict[str, str] = {}
    for row in team.values():
        for key, replacement in [("name", "عضو فريق محجوب"), ("phone", "[رقم محجوب]")]:
            if row.get(key):
                redactions[str(row[key])] = replacement
    # Defensive: detect these values without logging them or copying the login gate.
    for match in re.finditer(r"\b(?:USERNAME|PASSWORD)\s*=\s*(['\"])(.*?)\1", text):
        if match.group(2):
            redactions[match.group(2)] = "[بيانات دخول محجوبة]"
    redactions = dict(sorted(redactions.items(), key=lambda pair: -len(pair[0])))
    result = {
        "schemaVersion": 1,
        "classification": "reference/simulation",
        "source": {"url": SOURCE_URL, "repository": "https://github.com/aalamoudi-sudo/riyadh-book-fair", "commit": COMMIT, "sha256": digest},
        "security": {"sandbox": "", "referrerPolicy": "no-referrer", "scripts": False, "network": False, "personalContacts": "redacted", "storage": False},
        "pages": [{"id": "legacy-" + p["num"], "num": p["num"], "title": p["title"], "classification": "reference/simulation", "html": sanitize(p["html"], redactions)} for p in pages],
    }
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    # Fail closed, without printing the sensitive match, if any known value remains.
    if any(private in serialized for private in redactions):
        raise ValueError("Privacy validation failed: a known private value remains.")
    for p in result["pages"]:
        decoded = html.unescape(p["html"])
        if re.search(r"<script\b|\bon\w+\s*=|(?:local|session)Storage|javascript:", decoded, re.I):
            raise ValueError("Active content validation failed for " + p["id"])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(serialized, encoding="utf-8")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", type=Path, default=ROOT / "baseline/index.html")
    ap.add_argument("--output", type=Path, default=ROOT / "app/legacy/pages.json")
    args = ap.parse_args()
    result = extract(args.source, args.output)
    print(json.dumps({"pages": len(result["pages"]), "classification": result["classification"], "sha256": result["source"]["sha256"], "output": str(args.output)}, ensure_ascii=False))

"""Consistent SQLite backup and verified restore into a NEW file; never overwrite.

python scripts/database_backup.py backup data/operations.sqlite /safe/backup.sqlite
python scripts/database_backup.py verify /safe/backup.sqlite
python scripts/database_backup.py restore /safe/backup.sqlite data/restored.sqlite
"""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys


def verify(path):
    path = Path(path).resolve()
    if not path.is_file():
        raise ValueError('ملف قاعدة البيانات غير موجود')
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        check = db.execute('PRAGMA integrity_check').fetchone()[0]
        if check != 'ok':
            raise ValueError('فشل فحص سلامة قاعدة البيانات')
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'metadata', 'records', 'audit', 'sessions'}.issubset(tables):
            raise ValueError('الملف ليس قاعدة بيانات المنصة')
        mode = db.execute("SELECT value FROM metadata WHERE key='mode'").fetchone()
        revision = db.execute("SELECT value FROM metadata WHERE key='revision'").fetchone()
        if not mode or mode[0] not in {'demo', 'manual'} or not revision:
            raise ValueError('بيانات وصفية غير صالحة')
        return {'integrity': check, 'mode': mode[0], 'revision': int(revision[0]),
                'records': db.execute('SELECT count(*) FROM records').fetchone()[0],
                'audit_entries': db.execute('SELECT count(*) FROM audit').fetchone()[0]}


def copy_database(source, destination, restore=False):
    src, dest = Path(source).resolve(), Path(destination).resolve()
    info = verify(src)
    if src == dest or dest.exists():
        raise ValueError('اختر ملف وجهة جديدًا؛ لا تستبدل قاعدة قائمة')
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents concurrent invocations from overwriting a target.
    fd = os.open(dest, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    try:
        with closing(sqlite3.connect(src.as_uri() + '?mode=ro', uri=True)) as reader, closing(sqlite3.connect(dest)) as writer:
            reader.backup(writer)
            if restore:
                writer.execute('DELETE FROM sessions')
            writer.commit()
        verified = verify(dest)
        info.update(verified)
        info['sha256'] = hashlib.sha256(dest.read_bytes()).hexdigest()
        info['sessions_cleared'] = restore
        info['destination'] = str(dest)
        return info
    except Exception:
        # Remove only the brand new incomplete backup created by this invocation.
        dest.unlink(missing_ok=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['backup', 'verify', 'restore'])
    parser.add_argument('source')
    parser.add_argument('destination', nargs='?')
    args = parser.parse_args()
    try:
        if args.action == 'verify':
            result = verify(args.source)
        else:
            if not args.destination:
                parser.error('destination is required')
            result = copy_database(args.source, args.destination, args.action == 'restore')
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, OSError, sqlite3.Error) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

"""Fail early with a useful message when the selected Python cannot run this app."""
import hashlib
from contextlib import closing
from pathlib import Path
import sqlite3
import sys
import tempfile


def check_runtime():
    if sys.version_info < (3, 11):
        raise RuntimeError('يلزم Python 3.11 أو أحدث؛ Python المحدد هو ' + sys.version.split()[0])
    if not hasattr(hashlib, 'scrypt'):
        raise RuntimeError('Python المحدد لا يوفر hashlib.scrypt؛ اختر نسخة مبنية مع OpenSSL')
    hashlib.scrypt(b'runtime-check', salt=b'local-preflight', n=1024, r=8, p=1)
    # Exercise the exact read-only SQLite URI + backup features used by this app.
    with tempfile.TemporaryDirectory(prefix='rbf runtime ') as folder:
        source = Path(folder) / 'source with spaces.sqlite'
        with closing(sqlite3.connect(source)) as db:
            db.execute('CREATE TABLE probe(value INTEGER)')
            db.execute('INSERT INTO probe VALUES(1)')
            db.commit()
        reader = sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)
        writer = sqlite3.connect(Path(folder) / 'copy.sqlite')
        try:
            reader.backup(writer)
            if writer.execute('SELECT value FROM probe').fetchone() != (1,):
                raise RuntimeError('فشل فحص SQLite backup')
        finally:
            writer.close()
            reader.close()


if __name__ == '__main__':
    try:
        check_runtime()
    except (RuntimeError, OSError, ValueError, sqlite3.Error) as error:
        print(str(error) + '\nعلى جهاز المراجعة استخدم ./run-tests.command أو ./run-review.command، أو حدد RBF_PYTHON بمسار مفسر مدعوم.', file=sys.stderr)
        raise SystemExit(1)
    print('Python ' + sys.version.split()[0] + ' | scrypt + SQLite backup: OK | ' + sys.executable)

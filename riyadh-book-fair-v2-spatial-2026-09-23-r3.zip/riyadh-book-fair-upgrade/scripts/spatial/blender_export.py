"""Run with: blender --background --factory-startup --python this.py -- plan.json out.glb"""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plan_schema import area, validate_plan


def export(plan_path, output_path):
    # Validate before touching Blender state or overwriting any output.
    source = Path(plan_path)
    output = Path(output_path)
    if output.suffix.lower() != ".glb" or output.exists():
        raise ValueError("اختر مسار GLB جديدًا؛ لا تتم الكتابة فوق ملفات قائمة")
    if source.stat().st_size > 20 * 1024 * 1024:
        raise ValueError("ملف المخطط أكبر من 20 MB")
    content = source.read_bytes()
    plan = validate_plan(json.loads(content), require_review=True)
    import bpy
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1
    scene["plan_sha256"] = hashlib.sha256(content).hexdigest()
    scene["data_class"] = plan["provenance"]["data_class"]
    scene["source_file"] = plan["provenance"]["source_file"]
    scene["reviewer"] = plan["review"]["reviewer"]
    scene["reviewed_at"] = plan["review"]["reviewed_at"]
    scene["source_coordinate_system"] = plan["coordinate_system"]
    scene["units"] = "m"
    material = bpy.data.materials.new("مناطق المخطط")
    material.diffuse_color = (0.12, 0.43, 0.39, 1)
    for element in plan["elements"]:
        points = element["polygon"]
        if area(points) < 0:
            points = list(reversed(points))
        n, base, height = len(points), element.get("base_m", 0), element["height_m"]
        vertices = [(x, y, base) for x, y in points] + [(x, y, base + height) for x, y in points]
        # Blender's glTF exporter triangulates planar ngons, including concave outlines.
        faces = [tuple(reversed(range(n))), tuple(range(n, 2 * n))]
        faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
        mesh = bpy.data.meshes.new(element["id"])
        mesh.from_pydata(vertices, [], faces)
        mesh.validate(verbose=False)
        mesh.update()
        obj = bpy.data.objects.new(element["name"], mesh)
        scene.collection.objects.link(obj)
        obj.data.materials.append(material)
        for key in ("id", "zone_id", "asset_id", "type", "height_m", "base_m"):
            obj[key] = element.get(key, "" if key in ("asset_id", "type") else 0)
        obj["data_class"] = plan["provenance"]["data_class"]
        obj["units"] = "m"
    result = bpy.ops.export_scene.gltf(filepath=str(output.resolve()), export_format="GLB", export_extras=True, export_yup=True)
    if "FINISHED" not in result or not output.is_file():
        raise RuntimeError("لم يكتمل تصدير GLB")
    print(f"GLB: {output} | elements={len(plan['elements'])} | source={scene['plan_sha256']}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(args) != 2:
        raise SystemExit("usage: blender --background --factory-startup --python blender_export.py -- reviewed-plan.json new-model.glb")
    export(*args)

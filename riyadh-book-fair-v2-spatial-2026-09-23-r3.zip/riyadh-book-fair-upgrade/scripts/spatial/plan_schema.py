"""Shared, dependency-free geometry validation for reviewed spatial plans."""
import math
from datetime import datetime, timezone

EPSILON = 1e-8
MAX_ELEMENTS = 2000
MAX_VERTICES = 500
MAX_PLAN_VERTICES = 5000
MAX_EDGE_PAIR_CHECKS = 500000


def number(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name}: يلزم عدد محدود")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False  # math.isfinite converts enormous Python ints to float.
    if not finite:
        raise ValueError(f"{name}: يلزم عدد محدود")
    if positive and value <= 0:
        raise ValueError(f"{name}: يلزم عدد أكبر من صفر")
    return value


def calibrate(a, b, distance_m):
    """Metres per source unit. Caller preserves origin and flips image Y once."""
    number(distance_m, "المسافة", positive=True)
    if not isinstance(a, (list, tuple)) or not isinstance(b, (list, tuple)) or len(a) != 2 or len(b) != 2:
        raise ValueError("نقطتا المعايرة يجب أن تحتوي كل منهما إحداثيين")
    for value in list(a) + list(b):
        number(value, "نقطة المعايرة")
    try:
        distance = math.hypot(b[0] - a[0], b[1] - a[1])
    except OverflowError as error:
        raise ValueError("المعايرة خارج المجال العددي") from error
    if not math.isfinite(distance):
        raise ValueError("المعايرة خارج المجال العددي")
    if distance < EPSILON:
        raise ValueError("نقطتا المعايرة متطابقتان")
    try:
        scale = distance_m / distance
    except OverflowError as error:
        raise ValueError("مقياس المعايرة خارج المجال العددي") from error
    return number(scale, "مقياس المعايرة", positive=True)


def area(points):
    return sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(points, points[1:] + points[:1])) / 2


def _cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _on_segment(a, b, p):
    return abs(_cross(a, b, p)) < EPSILON and all(min(a[i], b[i]) - EPSILON <= p[i] <= max(a[i], b[i]) + EPSILON for i in (0, 1))


def _intersects(a, b, c, d):
    ab_c, ab_d, cd_a, cd_b = _cross(a, b, c), _cross(a, b, d), _cross(c, d, a), _cross(c, d, b)
    return (ab_c * ab_d < -EPSILON and cd_a * cd_b < -EPSILON) or any((
        _on_segment(a, b, c), _on_segment(a, b, d), _on_segment(c, d, a), _on_segment(c, d, b)))


def validate_polygon(points):
    if not isinstance(points, list) or not 3 <= len(points) <= MAX_VERTICES:
        raise ValueError("المضلع يحتاج من 3 إلى 500 نقطة")
    for point in points:
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            raise ValueError("كل نقطة يجب أن تحتوي x وy")
        for value in point:
            number(value, "الإحداثيات")
            if abs(value) > 100000:
                raise ValueError("إحداثيات خارج المجال المحلي؛ انقل الأصل إلى المشروع")
    n = len(points)
    for i in range(n):
        if math.dist(points[i], points[(i + 1) % n]) < EPSILON:
            raise ValueError("المضلع يحتوي ضلعًا صفريًا أو نقطة إغلاق مكررة")
        for j in range(i + 1, n):
            if j == i + 1 or (i == 0 and j == n - 1):
                continue
            if _intersects(points[i], points[(i + 1) % n], points[j], points[(j + 1) % n]):
                raise ValueError("حدود المضلع تتقاطع أو تتلامس مع نفسها")
    if abs(area(points)) < EPSILON:
        raise ValueError("مساحة المضلع صفر")
    return points


def validate_review(review):
    if not isinstance(review, dict):
        raise ValueError("بيانات مراجعة المخطط غير صالحة")
    if review.get("approved") is not True or not str(review.get("reviewer", "")).strip() or not review.get("reviewed_at"):
        raise ValueError("يلزم اعتماد بشري باسم المراجع وتاريخ المراجعة قبل تصدير GLB")
    try:
        datetime.fromisoformat(review["reviewed_at"].replace("Z", "+00:00"))
    except (ValueError, TypeError, AttributeError):
        raise ValueError("تاريخ المراجعة غير صالح")
    return review


def validate_plan(plan, require_review=False):
    if not isinstance(plan, dict) or plan.get("schema_version") != 1 or plan.get("units") != "m":
        raise ValueError("صيغة المخطط غير مدعومة؛ schema_version=1 وunits=m مطلوبان")
    if plan.get("coordinate_system") != "right-handed-z-up":
        raise ValueError("نظام الإحداثيات يجب أن يكون right-handed-z-up")
    provenance = plan.get("provenance", {})
    if not isinstance(provenance, dict):
        raise ValueError("بيانات مصدر المخطط غير صالحة")
    if provenance.get("data_class") not in ("manual", "expected", "demo") or not provenance.get("source_file"):
        raise ValueError("اسم المصدر وتصنيف البيانات مطلوبان")
    calibration = plan.get("calibration", {})
    if not isinstance(calibration, dict):
        raise ValueError("بيانات المعايرة غير صالحة")
    number(calibration.get("meters_per_unit"), "مقياس المعايرة", positive=True)
    if calibration.get("method") not in ("known-distance", "declared-unit-scale"):
        raise ValueError("طريقة المعايرة غير معروفة")
    if calibration.get("method") == "known-distance":
        points = calibration.get("points", [])
        if len(points) != 2:
            raise ValueError("نقطتا المعايرة مطلوبتان")
        measured = calibrate(points[0], points[1], calibration.get("distance_m"))
        if not math.isclose(measured, calibration["meters_per_unit"], rel_tol=1e-6):
            raise ValueError("مقياس المعايرة لا يطابق المسافة والنقطتين")
    elements = plan.get("elements")
    if not isinstance(elements, list) or not 1 <= len(elements) <= MAX_ELEMENTS:
        raise ValueError("يلزم من 1 إلى 2000 عنصر")
    # Polygon intersection testing is quadratic. Reject over-budget plans
    # before testing any edges, including when validation holds a DB write lock.
    total_vertices = 0
    edge_pairs = 0
    for element in elements:
        if not isinstance(element, dict):
            raise ValueError("عنصر غير صالح")
        points = element.get("polygon")
        if not isinstance(points, list) or not 3 <= len(points) <= MAX_VERTICES:
            raise ValueError("المضلع يحتاج من 3 إلى 500 نقطة")
        count = len(points)
        total_vertices += count
        edge_pairs += count * (count - 3) // 2
        if total_vertices > MAX_PLAN_VERTICES or edge_pairs > MAX_EDGE_PAIR_CHECKS:
            raise ValueError("المخطط مفصل جدًا؛ قسّمه إلى مناطق أصغر (5000 رأس و500000 فحص تقاطع كحد أقصى)")
    identifiers = set()
    for element in elements:
        if not isinstance(element, dict):
            raise ValueError("عنصر غير صالح")
        for key in ("id", "name", "zone_id"):
            if not isinstance(element.get(key), str) or not element[key].strip() or len(element[key]) > 200:
                raise ValueError(f"العنصر يحتاج {key} صالحًا")
        if element["id"] in identifiers:
            raise ValueError("معرف عنصر مكرر")
        identifiers.add(element["id"])
        if not isinstance(element.get("asset_id", ""), str):
            raise ValueError("asset_id يجب أن يكون نصًا")
        validate_polygon(element.get("polygon"))
        height = number(element.get("height_m"), "الارتفاع", positive=True)
        base = number(element.get("base_m", 0), "مستوى القاعدة")
        if height > 200 or abs(base) > 1000:
            raise ValueError("الارتفاع أو مستوى القاعدة خارج النطاق المقبول")
    review = plan.get("review", {})
    if not isinstance(review, dict):
        raise ValueError("بيانات مراجعة المخطط غير صالحة")
    if require_review:
        validate_review(review)
    return plan


def utc_now():
    return datetime.now(timezone.utc).isoformat()

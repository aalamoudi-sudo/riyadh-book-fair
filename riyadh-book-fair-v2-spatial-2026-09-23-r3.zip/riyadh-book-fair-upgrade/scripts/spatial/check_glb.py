#!/usr/bin/env python3
"""Validate metadata, vertical scale and closed-mesh volume of our Blender export."""
import argparse
import json
import math
from pathlib import Path
import struct
from plan_schema import area, validate_plan


def check(plan_path, glb_path):
    plan=validate_plan(json.loads(Path(plan_path).read_text()))
    content=Path(glb_path).read_bytes()
    magic,version,total=struct.unpack_from('<III',content)
    if (magic,version,total)!=(0x46546c67,2,len(content)):
        raise ValueError('Invalid GLB header')
    json_length,kind=struct.unpack_from('<II',content,12)
    if kind!=0x4e4f534a: raise ValueError('Missing JSON chunk')
    document=json.loads(content[20:20+json_length])
    bin_length,kind=struct.unpack_from('<II',content,20+json_length)
    if kind!=0x004e4942: raise ValueError('Missing binary chunk')
    binary=content[28+json_length:28+json_length+bin_length]
    def values(index):
        accessor=document['accessors'][index]
        view=document['bufferViews'][accessor['bufferView']]
        fmt,size={5126:('f',4),5125:('I',4),5123:('H',2),5121:('B',1)}[accessor['componentType']]
        width={'SCALAR':1,'VEC3':3}[accessor['type']]
        offset=view.get('byteOffset',0)+accessor.get('byteOffset',0)
        stride=view.get('byteStride',size*width)
        return [struct.unpack_from('<'+fmt*width,binary,offset+i*stride) for i in range(accessor['count'])]
    elements={e['id']:e for e in plan['elements']}
    results=[]
    for node in document['nodes']:
        if 'mesh' not in node: continue
        if any(key in node for key in ('matrix','translation','rotation','scale')):
            raise ValueError('This check expects the direct-coordinate export made by blender_export.py')
        element=elements[node['extras']['id']]
        primitive=document['meshes'][node['mesh']]['primitives'][0]
        positions=values(primitive['attributes']['POSITION'])
        indices=[i[0] for i in values(primitive['indices'])]
        volume=0
        for i in range(0,len(indices),3):
            a,b,c=[positions[j] for j in indices[i:i+3]]
            cross=(b[1]*c[2]-b[2]*c[1],b[2]*c[0]-b[0]*c[2],b[0]*c[1]-b[1]*c[0])
            volume+=sum(a[j]*cross[j] for j in range(3))/6
        expected=abs(area(element['polygon']))*element['height_m']
        if not math.isclose(abs(volume),expected,rel_tol=1e-5): raise ValueError(f'Volume mismatch: {element["id"]}')
        for key in ('zone_id','asset_id'):
            if node['extras'].get(key,'')!=element.get(key,''): raise ValueError(f'Metadata mismatch: {key}')
        heights=[p[1] for p in positions]
        if not math.isclose(max(heights)-min(heights),element['height_m'],rel_tol=1e-5): raise ValueError('Y-up height mismatch')
        results.append({'id':element['id'],'zone_id':element['zone_id'],'asset_id':element.get('asset_id',''),'volume_m3':round(abs(volume),6),'expected_volume_m3':round(expected,6),'height_m':round(max(heights)-min(heights),6),'triangles':len(indices)//3})
    if len(results)!=len(elements): raise ValueError('Element count mismatch')
    return {'status':'passed','source':'synthetic demo only' if plan['provenance']['data_class']=='demo' else plan['provenance']['source_file'],'file_bytes':len(content),'data_class':document['scenes'][0]['extras']['data_class'],'elements':results}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan');parser.add_argument('glb');parser.add_argument('--report')
    args=parser.parse_args()
    report=json.dumps(check(args.plan,args.glb),ensure_ascii=False,indent=2)
    if args.report: Path(args.report).write_text(report,encoding='utf-8')
    print(report)

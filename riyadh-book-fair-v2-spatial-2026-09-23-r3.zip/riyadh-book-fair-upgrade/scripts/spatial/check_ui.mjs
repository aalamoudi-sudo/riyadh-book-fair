// Local browser smoke test. PLAYWRIGHT_MODULE may point to a bundled index.mjs.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
const {chromium} = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const browser = await chromium.launch({headless:true, ...(process.env.CHROME_CHANNEL ? {channel:process.env.CHROME_CHANNEL} : {})});
const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'bookfair-spatial-ui-'));
try {
  const page = await browser.newPage({viewport:{width:1440,height:1000}}), errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(`${process.env.SPATIAL_BASE_URL || 'http://127.0.0.1:8892'}/scripts/spatial/review.html`);
  await page.waitForLoadState('networkidle');
  await page.getByRole('heading', {name:'المخطط المكاني · من 2D إلى Blender'}).waitFor();
  assert.equal(await page.locator('#sp-calibrate').isDisabled(), true);
  // Synthetic test image. No real project drawings or personal files are used.
  const png = await page.evaluate(() => {const c=document.createElement('canvas');c.width=800;c.height=500;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,800,500);x.strokeStyle='#222';x.strokeRect(100,100,100,50);return c.toDataURL('image/png').split(',')[1];});
  await page.locator('#sp-image').setInputFiles({name:'synthetic-10m-reference.png',mimeType:'image/png',buffer:Buffer.from(png,'base64')});
  await page.locator('#sp-status').filter({hasText:'اختر نقطتين'}).waitFor();
  await page.getByText('إضافة نقطة بالإحداثيات بدل النقر', {exact:true}).click();
  const point = async (x,y) => {await page.locator('#sp-x').fill(String(x));await page.locator('#sp-y').fill(String(y));await page.locator('#sp-point').click();};
  await point(100,100);await point(200,100);await page.locator('#sp-distance').fill('10');await page.locator('#sp-calibrate').click();
  await page.locator('#sp-scale').filter({hasText:'0.100000'}).waitFor();
  await point(100,100);await point(200,100);await point(200,150);await point(100,150);
  await page.locator('#sp-name').fill('جناح اختبار');await page.locator('#sp-zone').fill('Z-TEST');await page.locator('#sp-asset').fill('ASSET-TEST');
  // Missing height must be rejected, then corrected without losing the trace.
  await page.locator('#sp-add').click();assert.equal(await page.locator('#sp-status').getAttribute('data-error'),'true');
  await page.locator('#sp-height').fill('2.5');await page.locator('#sp-add').click();
  assert.equal(await page.locator('#sp-elements tr').count(),1);
  assert.match(await page.locator('#sp-elements').innerText(),/50\.00/);
  await page.locator('#sp-export').click();assert.match(await page.locator('#sp-status').innerText(),/مربع الاعتماد/);
  await page.locator('#sp-reviewer').fill('مراجع اختبار آلي — بيانات تجريبية');await page.locator('#sp-class').selectOption('demo');await page.locator('#sp-review').check();
  const downloadEvent = page.waitForEvent('download');await page.locator('#sp-export').click();const download=await downloadEvent;
  const jsonPath=path.join(temp,'reviewed.json');await download.saveAs(jsonPath);const plan=JSON.parse(await fs.readFile(jsonPath,'utf8'));
  assert.equal(plan.review.approved,true);assert.equal(plan.provenance.data_class,'demo');assert.equal(plan.calibration.meters_per_unit,.1);assert.deepEqual(plan.elements[0].polygon,[[0,0],[10,0],[10,-5],[0,-5]]);assert.equal(plan.elements[0].height_m,2.5);assert.equal(plan.elements[0].asset_id,'ASSET-TEST');
  await page.locator('#sp-class').selectOption('expected');assert.equal(await page.locator('#sp-review').isChecked(),false);assert.match(await page.locator('#sp-review-state').innerText(),/تحتاج مراجعة/);
  await page.locator('#sp-json').setInputFiles(path.join(root,'scripts/spatial/samples/zone-demo.plan.json'));
  await page.locator('#sp-status').filter({hasText:'تم تحميل المخطط'}).waitFor();assert.equal(await page.locator('#sp-elements tr').count(),3);assert.equal(await page.locator('#sp-review').isChecked(),false);
  await page.screenshot({path:path.join(temp,'desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(temp,'mobile.png'),fullPage:true});
  const overflow = await page.evaluate(() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,items:[...document.querySelectorAll('.spatial-tool *')].map(e=>({tag:e.tagName,id:e.id,class:e.className,left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width,minWidth:getComputedStyle(e).minWidth})).filter(r=>r.width>innerWidth).slice(0,12)}));
  assert.equal(overflow.scroll <= overflow.width,true,`mobile page must not overflow horizontally: ${JSON.stringify(overflow)}`);
  assert.deepEqual(errors,[]);
  console.log(JSON.stringify({status:'passed',flows:['image calibration','manual polygon','height validation','explicit review gate','reviewed JSON download','approval invalidation','vector JSON import','mobile layout'],artifacts:temp}));
} finally {await browser.close();}

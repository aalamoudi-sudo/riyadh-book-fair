#!/usr/bin/env python3
"""Strict SVG / optional DXF import. Never claims arbitrary images are geometry."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

from plan_schema import MAX_ELEMENTS, number, utc_now, validate_plan


def numeric(text, default=None):
    if text is None and default is not None:
        return default
    if not isinstance(text, str) or not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?:px)?", text.strip()):
        raise ValueError(f"قيمة SVG ليست عددًا أو px: {text}")
    return number(float(text.strip().removesuffix("px")), "SVG")


def line_polygon(a, b, width):
    number(width, "عرض الجدار", positive=True)
    length = math.dist(a, b)
    if length < 1e-8:
        raise ValueError("خط صفري الطول")
    dx, dy = -(b[1] - a[1]) * width / (2 * length), (b[0] - a[0]) * width / (2 * length)
    return [[a[0] + dx, a[1] + dy], [a[0] - dx, a[1] - dy], [b[0] - dx, b[1] - dy], [b[0] + dx, b[1] + dy]]


def import_svg(content, scale, height, zone, line_width):
    if b"<!DOCTYPE" in content.upper() or b"<!ENTITY" in content.upper():
        raise ValueError("SVG ذو DTD أو كيانات خارجية غير مدعوم")
    root = ET.fromstring(content)
    if root.tag.split("}")[-1] != "svg":
        raise ValueError("ليس ملف SVG")
    elements = []
    for node in root.iter():
        tag = node.tag.split("}")[-1]
        if tag not in ("svg", "g", "rect", "polygon", "line", "title", "desc", "metadata"):
            raise ValueError(f"SVG يحتوي عنصرًا غير مدعوم: {tag}. بسّط الملف إلى rect/polygon/line")
        if node is not root and tag == "svg":
            raise ValueError("SVG المتداخل غير مدعوم؛ افرد الإحداثيات أولًا")
        if any(key in node.attrib for key in ("transform", "clip-path", "mask", "filter", "style")):
            raise ValueError("تحويلات/قص/أنماط SVG غير مدعومة؛ افرد الإحداثيات وأزل الأنماط أولًا")
        if node.get("display") == "none" or node.get("visibility") == "hidden" or node.get("opacity") == "0":
            raise ValueError("عناصر SVG المخفية غير مدعومة؛ احذفها من نسخة الاستيراد")
        if tag not in ("rect", "polygon", "line"):
            continue
        if tag == "rect":
            if numeric(node.get("rx"), 0) or numeric(node.get("ry"), 0):
                raise ValueError("المستطيل المدور غير مدعوم؛ حوّله إلى مضلع")
            x, y = numeric(node.get("x"), 0), numeric(node.get("y"), 0)
            w, h = numeric(node.get("width")), numeric(node.get("height"))
            number(w, "عرض المستطيل", positive=True)
            number(h, "طول المستطيل", positive=True)
            points = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]]
        elif tag == "polygon":
            values = [numeric(p) for p in re.split(r"[\s,]+", node.get("points", "").strip()) if p]
            if len(values) % 2:
                raise ValueError("عدد إحداثيات SVG غير زوجي")
            points = [[values[i], values[i + 1]] for i in range(0, len(values), 2)]
            if points and points[0] == points[-1]:
                points.pop()
        else:
            points = [[numeric(node.get("x1"), 0), numeric(node.get("y1"), 0)], [numeric(node.get("x2"), 0), numeric(node.get("y2"), 0)]]
        points = [[p[0] * scale, -p[1] * scale] for p in points]
        if tag == "line":
            points = line_polygon(points[0], points[1], line_width)
        idx = len(elements) + 1
        elements.append({"id": f"element-{idx}", "name": node.get("id") or f"عنصر {idx}", "zone_id": zone, "asset_id": "", "type": "wall" if tag == "line" else "space", "polygon": points, "height_m": height, "base_m": 0})
        if len(elements) > MAX_ELEMENTS:
            raise ValueError("عدد العناصر أكبر من الحد المدعوم")
    return elements


def import_dxf(path, scale, height, zone, line_width):
    try:
        import ezdxf
    except ImportError as error:
        raise ValueError("استيراد DXF يحتاج المكتبة الاختيارية ezdxf. ثبّتها في بيئة Python منفصلة أو صدّر SVG مبسّطًا. DWG غير مدعوم.") from error
    document = ezdxf.readfile(path)
    elements = []
    for entity in document.modelspace():
        kind = entity.dxftype()
        if kind in ("TEXT", "MTEXT", "POINT"):
            continue
        if kind == "LINE":
            raw_points = [entity.dxf.start, entity.dxf.end]
        elif kind == "LWPOLYLINE":
            if not entity.closed or entity.has_arc or entity.has_width:
                raise ValueError("DXF يدعم LWPOLYLINE مغلقًا بلا أقواس أو عرض فقط")
            raw_points = list(entity.vertices_in_wcs())
        else:
            raise ValueError(f"كيان DXF غير مدعوم: {kind}. حوّله إلى LINE أو LWPOLYLINE مغلق بلا أقواس")
        if any(abs(p[2]) > 1e-8 for p in raw_points):
            raise ValueError("DXF يحتاج مخططًا مسطحًا على Z=0")
        points = [[p[0] * scale, p[1] * scale] for p in raw_points]
        if kind == "LINE":
            points = line_polygon(points[0], points[1], line_width)
        elif points and points[0] == points[-1]:
            points.pop()
        idx = len(elements) + 1
        elements.append({"id": f"element-{idx}", "name": f"{entity.dxf.layer} / {entity.dxf.handle}", "zone_id": zone, "asset_id": "", "type": "wall" if kind == "LINE" else "space", "polygon": points, "height_m": height, "base_m": 0})
        if len(elements) > MAX_ELEMENTS:
            raise ValueError("عدد العناصر أكبر من الحد المدعوم")
    return elements


def build_plan(path, scale, height, zone, line_width=0.12, data_class="manual"):
    number(scale, "المتر لكل وحدة", positive=True)
    number(height, "الارتفاع", positive=True)
    path = Path(path)
    if path.stat().st_size > 20 * 1024 * 1024:
        raise ValueError("الملف أكبر من 20 MB؛ صدّر منطقة واحدة أولًا")
    content = path.read_bytes()
    suffix = path.suffix.lower()
    if suffix == ".svg":
        elements = import_svg(content, scale, height, zone, line_width)
    elif suffix == ".dxf":
        elements = import_dxf(path, scale, height, zone, line_width)
    else:
        raise ValueError("يُقبل SVG أو DXF فقط؛ الصور تحتاج تتبعًا يدويًا عبر الواجهة")
    plan = {"schema_version": 1, "units": "m", "coordinate_system": "right-handed-z-up", "created_at": utc_now(), "provenance": {"data_class": data_class, "source_file": path.name, "source_type": suffix[1:], "source_sha256": hashlib.sha256(content).hexdigest(), "method": "restricted-vector-import", "notes": "ارتفاع وعرض جدار مدخلان يدويًا؛ يلزم تحقق بشري من المقياس والحدود والمعرفات"}, "calibration": {"method": "declared-unit-scale", "meters_per_unit": scale, "origin": [0, 0], "source_y_down": suffix == ".svg"}, "review": {"approved": False, "reviewer": "", "reviewed_at": None}, "elements": elements}
    return validate_plan(plan)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("--output", required=True)
    parser.add_argument("--meters-per-unit", type=float, required=True)
    parser.add_argument("--height", type=float, required=True, help="الارتفاع بالمتر؛ ليس مستنتجًا من المخطط")
    parser.add_argument("--zone", required=True)
    parser.add_argument("--line-width", type=float, default=0.12, help="عرض تمثيل LINE بالمتر")
    parser.add_argument("--data-class", choices=["manual", "expected", "demo"], default="manual")
    args = parser.parse_args()
    try:
        plan = build_plan(args.source, args.meters_per_unit, args.height, args.zone, args.line_width, args.data_class)
        output = Path(args.output)
        if output.resolve() == Path(args.source).resolve():
            raise ValueError("يجب أن يختلف ملف الناتج عن المصدر")
        with output.open("x", encoding="utf-8") as stream:
            json.dump(plan, stream, ensure_ascii=False, indent=2)
        print(f"أُنشئ {len(plan['elements'])} عنصرًا في {output}. المخطط غير معتمد؛ راجعه عبر الواجهة قبل GLB.")
    except (ValueError, OSError, ET.ParseError) as error:
        parser.exit(2, f"خطأ: {error}\n")


if __name__ == "__main__":
    main()

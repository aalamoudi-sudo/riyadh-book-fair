# Source from a launcher after changing to the repository root.
rbf_python="${RBF_PYTHON:-}"
if [[ -n "$rbf_python" ]]; then
  if [[ ! -x "$rbf_python" ]] || ! "$rbf_python" scripts/check_runtime.py; then
    printf '%s\n' 'RBF_PYTHON لا يشير إلى مفسر مدعوم. صحح المسار ثم أعد المحاولة.' >&2
    exit 1
  fi
else
  for rbf_candidate in "${HOME}/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3" /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
    if [[ -x "$rbf_candidate" ]] && "$rbf_candidate" scripts/check_runtime.py >/dev/null 2>&1; then
      rbf_python="$rbf_candidate"
      break
    fi
  done
  if [[ -z "$rbf_python" ]]; then
    printf '%s\n' 'لم يُعثر على Python 3.11+ يدعم scrypt وSQLite backup. حدد مساره في RBF_PYTHON.' >&2
    exit 1
  fi
  "$rbf_python" scripts/check_runtime.py
fi

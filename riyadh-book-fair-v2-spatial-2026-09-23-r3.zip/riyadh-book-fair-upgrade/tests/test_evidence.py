import base64
import hashlib
import http.client
import importlib.util
import json
from pathlib import Path
import sqlite3
import struct
import sys
import tempfile
import threading
import unittest
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore, DomainError
from evidence import MAX_ATTACHMENT_BYTES, validate_file
from server import Application, Handler, Server

ADMIN = {'id': 'proof-admin', 'role': 'admin', 'name': 'Evidence QA'}


def png():
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(b'\x00\xff\xff\xff')) + chunk(b'IEND', b'')


PNG = png()
PDF = b'%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n'


class EvidenceFixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'evidence.sqlite'
        self.store = DomainStore(self.path)
        self.project = self.command('shared.create', collection='projects', name='Evidence project')
        self.other = self.command('shared.create', collection='projects', name='Other project')
        self.zone = self.command('shared.create', collection='zones', project_id=self.project['id'], name='Warehouse')
        self.person = self.command('shared.create', collection='stakeholders', project_id=self.project['id'], name='Responsible')
        self.task = self.command('task.create', project_id=self.project['id'], zone_id=self.zone['id'], title='Inspection task')

    def tearDown(self):
        self.tmp.cleanup()

    def command(self, command, actor=ADMIN, **payload):
        return self.store.command(command, payload, actor)['result']

    def payload(self, content=PNG, filename='محضر.png', content_type='image/png', **extra):
        return {'project_id': self.project['id'], 'label': 'إثبات فعلي', 'filename': filename,
                'content_type': content_type, 'data_base64': base64.b64encode(content).decode('ascii'), **extra}

    def upload(self, actor=ADMIN, **extra):
        return self.command('attachment.create', actor=actor, **self.payload(**extra))

    def assert_code(self, code, callback):
        with self.assertRaises(DomainError) as error:
            callback()
        self.assertEqual(error.exception.code, code)

    def order(self):
        book = self.command('item.create', project_id=self.project['id'], kind='book', name='Book', owner_id=self.person['id'])
        self.command('stock.move', item_id=book['id'], zone_id=self.zone['id'], action='receipt', qty=3, evidence='Receipt')
        return self.command('order.create', project_id=self.project['id'], customer_name='Test recipient', address='Test address',
                            lines=[{'item_id': book['id'], 'zone_id': self.zone['id'], 'qty': 1}])

class EvidenceTests(EvidenceFixture):
    def test_actual_blob_and_hash_survive_restart_without_paths(self):
        meta = self.upload(zone_id=self.zone['id'], responsible_id=self.person['id'], record_collection='tasks', record_id=self.task['id'])
        self.assertRegex(meta['id'], r'^ATT-[0-9A-F]{32}$')
        self.assertEqual(meta['sha256'], hashlib.sha256(PNG).hexdigest())
        self.assertEqual(meta['size_bytes'], len(PNG))
        self.assertNotIn('data_base64', meta)
        self.assertNotIn('path', meta)
        self.assertNotIn(str(self.tmp.name), json.dumps(meta))
        with self.store.connect() as c:
            blob = c.execute('SELECT content FROM attachment_blobs WHERE id=?', (meta['id'],)).fetchone()['content']
            self.assertEqual(blob, PNG)
        reopened = DomainStore(self.path)
        self.assertEqual(reopened.attachment_read(ADMIN, meta['id'])['content'], PNG)

    def test_state_metadata_and_audit_do_not_include_binary(self):
        meta = self.upload()
        state = self.store.state(ADMIN)
        self.assertEqual(state['attachments'][0]['id'], meta['id'])
        self.assertNotIn('data_base64', json.dumps(state))
        self.assertNotIn(base64.b64encode(PNG).decode(), json.dumps(state))
        with self.store.connect() as c:
            audit = c.execute("SELECT payload FROM audit WHERE command='attachment.create'").fetchone()['payload']
            self.assertNotIn('data_base64', audit)
            self.assertNotIn(meta['filename'], audit)

    def test_no_public_filename_or_path_is_used_for_storage(self):
        for filename in ['../proof.png', '/tmp/proof.png', r'C:\proof.png', 'x:y.png', '.hidden.png', 'proof\x00.png', 'proof\r\nX-Test:evil.png', 'x\u202epng.png']:
            with self.subTest(filename=repr(filename)):
                self.assert_code('invalid_filename', lambda: self.upload(filename=filename))
        self.assertEqual(self.store.state()['attachments'], [])
        self.assertFalse((Path(self.tmp.name) / 'proof.png').exists())

    def test_filename_length_and_label_length_are_bounded(self):
        self.assert_code('validation', lambda: self.upload(filename='a' * 161 + '.png'))
        self.assert_code('validation', lambda: self.upload(label='x' * 201))

    def test_magic_and_mime_extension_must_agree(self):
        for content, name, mime, code in [
            (b'<script>alert(1)</script>', 'fake.png', 'image/png', 'attachment_magic_mismatch'),
            (PNG, 'file.pdf', 'application/pdf', 'attachment_magic_mismatch'),
            (PDF, 'file.png', 'image/png', 'attachment_magic_mismatch'),
            (PNG, 'file.html', 'image/png', 'attachment_type_mismatch'),
            (b'<svg/>', 'file.svg', 'image/svg+xml', 'unsupported_attachment_type'),
            (PNG[:-12], 'broken.png', 'image/png', 'attachment_magic_mismatch'),
        ]:
            with self.subTest(name=name, mime=mime):
                self.assert_code(code, lambda: self.upload(content=content, filename=name, content_type=mime))

    def test_basic_signatures_for_allowed_types(self):
        jpeg = b'\xff\xd8\xff\xe0\x00\x06JFIF\x00\xff\xd9'
        webp = b'RIFF' + struct.pack('<I', 12) + b'WEBPVP8 ' + b'\x00\x00\x00\x00'
        for data, name, mime in [(PNG, 'a.png', 'image/png'), (jpeg, 'a.jpeg', 'image/jpeg'), (webp, 'a.webp', 'image/webp'), (PDF, 'a.pdf', 'application/pdf')]:
            with self.subTest(mime=mime):
                self.assertEqual(validate_file(name, mime, base64.b64encode(data).decode())[2], data)

    def test_strict_base64_and_nonempty_content(self):
        for value in ['!', 'data:image/png;base64,' + base64.b64encode(PNG).decode(), 'غيرصالح', '', 1, base64.b64encode(PNG).decode() + '\n']:
            with self.subTest(value=str(value)[:15]):
                self.assert_code('invalid_attachment_encoding', lambda: self.command('attachment.create', **{**self.payload(), 'data_base64': value}))

    def test_five_megabyte_boundary(self):
        header, tail = b'%PDF-1.4\n', b'\n%%EOF'
        content = header + b' ' * (MAX_ATTACHMENT_BYTES - len(header) - len(tail)) + tail
        accepted = self.upload(content=content, filename='limit.pdf', content_type='application/pdf')
        self.assertEqual(accepted['size_bytes'], MAX_ATTACHMENT_BYTES)
        self.assert_code('attachment_too_large', lambda: self.upload(content=content + b' ', filename='large.pdf', content_type='application/pdf'))

    def test_record_link_requires_allowed_collection_pair_and_same_project(self):
        self.assert_code('attachment_reference_required', lambda: self.upload(record_collection='tasks'))
        self.assert_code('attachment_reference_required', lambda: self.upload(record_id=self.task['id']))
        self.assert_code('attachment_record_type', lambda: self.upload(record_collection='sessions', record_id='private'))
        self.assert_code('project_mismatch', lambda: self.upload(record_collection='projects', record_id=self.other['id']))
        other_task = self.command('task.create', project_id=self.other['id'], title='Other task')
        self.assert_code('project_mismatch', lambda: self.upload(record_collection='tasks', record_id=other_task['id']))
        self.assertEqual(self.store.state()['attachments'], [])

    def test_project_scope_applies_to_upload_read_and_state(self):
        actor = {'id': 'scoped', 'role': 'field', 'project_ids': [self.project['id']]}
        meta = self.upload(actor=actor)
        self.assertEqual(self.store.attachment_read(actor, meta['id'])['content'], PNG)
        blocked = {'id': 'blocked', 'role': 'admin', 'project_ids': [self.other['id']]}
        before = self.store.state()['revision']
        self.assert_code('project_scope_required', lambda: self.upload(actor=blocked))
        self.assert_code('project_scope_required', lambda: self.store.attachment_read(blocked, meta['id']))
        self.assertEqual(self.store.state(blocked)['attachments'], [])
        self.assertEqual(self.store.state()['revision'], before)
        empty_scope = {'id': 'none', 'role': 'manager', 'project_ids': []}
        self.assert_code('project_scope_required', lambda: self.store.attachment_read(empty_scope, meta['id']))

    def test_viewer_has_metadata_only_and_all_operating_roles_can_read_general(self):
        meta = self.upload()
        viewer = {'id': 'viewer', 'role': 'viewer', 'project_ids': [self.project['id']]}
        self.assertEqual(len(self.store.state(viewer)['attachments']), 1)
        self.assert_code('forbidden', lambda: self.upload(actor=viewer))
        self.assert_code('forbidden', lambda: self.store.attachment_read(viewer, meta['id']))
        for role in ['admin', 'manager', 'warehouse', 'field', 'security']:
            actor = {'id': role, 'role': role, 'project_ids': [self.project['id']]}
            own = self.upload(actor=actor)
            self.assertEqual(self.store.attachment_read(actor, own['id'])['content'], PNG)

    def test_order_attachments_restrict_binary_and_redact_private_metadata(self):
        order = self.order()
        meta = self.upload(record_collection='orders', record_id=order['id'], filename='recipient-proof.png', notes='Private recipient note')
        for role in ['field', 'security']:
            actor = {'id': role, 'role': role}
            self.assert_code('attachment_order_restricted', lambda: self.store.attachment_read(actor, meta['id']))
            self.assert_code('attachment_order_restricted', lambda: self.upload(actor=actor, record_collection='orders', record_id=order['id']))
        for role in ['field', 'security', 'viewer']:
            row = self.store.state({'id': role, 'role': role})['attachments'][0]
            self.assertNotIn('filename', row)
            self.assertNotIn('notes', row)
        for role in ['admin', 'manager', 'warehouse']:
            self.assertEqual(self.store.attachment_read({'id': role, 'role': role}, meta['id'])['content'], PNG)

    def test_invalid_upload_rolls_back_metadata_blob_audit_and_revision(self):
        before = self.store.state()
        self.assert_code('attachment_magic_mismatch', lambda: self.upload(content=b'bad content'))
        after = self.store.state()
        self.assertEqual(after['revision'], before['revision'])
        self.assertEqual(after['audit'], before['audit'])
        self.assertEqual(after['attachments'], [])
        with self.store.connect() as c:
            self.assertEqual(c.execute('SELECT count(*) FROM attachment_blobs').fetchone()[0], 0)

    def test_corruption_is_not_downloaded_or_silently_backed_up(self):
        meta = self.upload()
        with self.store.connect() as c:
            c.execute('UPDATE attachment_blobs SET content=? WHERE id=?', (b'corrupt', meta['id']))
        self.assert_code('attachment_integrity_error', lambda: self.store.attachment_read(ADMIN, meta['id']))
        self.assert_code('attachment_integrity_error', lambda: self.store.export(ADMIN))

    def test_json_backup_includes_bytes_and_verifiable_metadata(self):
        first = self.upload()
        second = self.upload(content=PDF, filename='proof.pdf', content_type='application/pdf')
        exported = self.store.export(ADMIN)
        payloads = {x['id']: x for x in exported['attachment_contents']}
        self.assertEqual(set(payloads), {first['id'], second['id']})
        for row in exported['records']['attachments']:
            content = base64.b64decode(payloads[row['id']]['data_base64'], validate=True)
            self.assertEqual(hashlib.sha256(content).hexdigest(), row['sha256'])
            self.assertEqual(len(content), row['size_bytes'])
        self.assertEqual(base64.b64decode(payloads[first['id']]['data_base64']), PNG)

    def test_sqlite_backup_and_restore_preserve_blob_integrity(self):
        meta = self.upload()
        spec = importlib.util.spec_from_file_location('evidence_backup', Path(__file__).resolve().parents[1] / 'scripts/database_backup.py')
        backup = importlib.util.module_from_spec(spec); spec.loader.exec_module(backup)
        snapshot = Path(self.tmp.name) / 'snapshot.sqlite'
        restored = Path(self.tmp.name) / 'restored.sqlite'
        backup.copy_database(self.path, snapshot)
        backup.copy_database(snapshot, restored, restore=True)
        recovered = DomainStore(restored)
        self.assertEqual(recovered.attachment_read(ADMIN, meta['id'])['content'], PNG)


class EvidenceHTTPTests(EvidenceFixture):
    def setUp(self):
        super().setUp()
        self.server = Server(('127.0.0.1', 0), Handler)
        self.port = self.server.server_address[1]
        self.app = Application(self.store, {}, True, '127.0.0.1', self.port)
        self.server.app = self.app
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join()
        super().tearDown()

    def request(self, method, path, body=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        headers = {'Origin': f'http://127.0.0.1:{self.port}'}
        encoded = None
        if body is not None:
            encoded = json.dumps(body).encode(); headers['Content-Type'] = 'application/json'
        conn.request(method, path, encoded, headers)
        response = conn.getresponse(); data = response.read(); result = (response.status, dict(response.getheaders()), data)
        conn.close(); return result

    def test_http_download_requires_auth_and_uses_attachment_headers(self):
        meta = self.upload(content=PDF, filename='محضر.pdf', content_type='application/pdf')
        status, headers, content = self.request('GET', '/api/attachments/' + meta['id'])
        self.assertEqual(status, 200); self.assertEqual(content, PDF)
        self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')
        self.assertTrue(headers['Content-Disposition'].startswith('attachment;'))
        self.assertIn("filename*=UTF-8''", headers['Content-Disposition'])
        self.assertEqual(headers['Content-Type'], 'application/octet-stream')
        self.assertEqual(headers['Cache-Control'], 'no-store')
        self.assertEqual(headers['Cross-Origin-Resource-Policy'], 'same-origin')
        self.app.review = False
        self.assertEqual(self.request('GET', '/api/attachments/' + meta['id'])[0], 401)

    def test_http_scope_and_viewer_cannot_read_binary(self):
        meta = self.upload()
        self.app.actor = lambda handler: {'id': 'viewer', 'role': 'viewer'}
        self.assertEqual(self.request('GET', '/api/attachments/' + meta['id'])[0], 403)
        self.app.actor = lambda handler: {'id': 'other', 'role': 'admin', 'project_ids': [self.other['id']]}
        self.assertEqual(self.request('GET', '/api/attachments/' + meta['id'])[0], 403)

    def test_http_large_attachment_is_allowed_but_other_large_commands_are_not(self):
        content = b'%PDF-1.4\n' + b' ' * (1024 * 1024) + b'\n%%EOF'
        body = {'type': 'attachment.create', 'payload': self.payload(content=content, filename='large.pdf', content_type='application/pdf'), 'expected_revision': self.store.state()['revision']}
        status, _, response = self.request('POST', '/api/commands', body)
        self.assertEqual(status, 200, response[:200])
        meta = json.loads(response)['result']
        self.assertEqual(meta['size_bytes'], len(content))
        status, _, _ = self.request('POST', '/api/commands', {'type':'shared.create', 'payload':{'padding':'x' * (1024 * 1024)}, 'expected_revision': self.store.state()['revision']})
        self.assertEqual(status, 413)

    def test_http_attachment_path_is_not_a_filesystem_path(self):
        status, _, response = self.request('GET', '/api/attachments/..%2F..%2Fdomain.py')
        self.assertEqual(status, 404)
        self.assertNotIn(b'class DomainStore', response)


if __name__ == '__main__':
    unittest.main()

import datetime as dt
import base64
import http.client
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from domain import DomainStore, DomainError
from server import Application, Handler, Server, hash_password, verify_password, create_account_file, load_accounts

ADMIN={'id':'admin','name':'Admin','role':'admin'}
WAREHOUSE={'id':'warehouse','name':'Warehouse','role':'warehouse'}
SECURITY={'id':'security','name':'Security','role':'security'}
FIELD={'id':'field','name':'Field','role':'field'}
VIEWER={'id':'viewer','name':'Viewer','role':'viewer'}

class DomainTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=DomainStore(Path(self.tmp.name)/'db.sqlite')
        self.project=self.cmd('shared.create',collection='projects',name='Test project')
        self.zone=self.cmd('shared.create',collection='zones',name='Warehouse',project_id=self.project['id'])
        self.zone2=self.cmd('shared.create',collection='zones',name='Hall',project_id=self.project['id'])
        self.owner=self.cmd('shared.create',collection='stakeholders',name='Owner',project_id=self.project['id'])
        self.item=self.cmd('item.create',kind='equipment',name='Radio',project_id=self.project['id'],owner_id=self.owner['id'])
        self.move('receipt',10)
    def tearDown(self): self.tmp.cleanup()
    def cmd(self,command_type,actor=ADMIN,**payload): return self.store.command(command_type,payload,actor)['result']
    def move(self,action,qty,**extra):
        return self.cmd('stock.move',action=action,item_id=self.item['id'],zone_id=self.zone['id'],qty=qty,evidence='inspection record',**extra)
    def bal(self): return next(s for s in self.store.state()['stock'] if s['item_id']==self.item['id'] and s['zone_id']==self.zone['id'])
    def assert_code(self,code,callback):
        with self.assertRaises(DomainError) as caught: callback()
        self.assertEqual(caught.exception.code,code)
    def make_book(self,name='Book',qty=10):
        item=self.cmd('item.create',kind='book',name=name,owner_id=self.owner['id'],project_id=self.project['id'])
        self.cmd('stock.move',action='receipt',item_id=item['id'],zone_id=self.zone['id'],qty=qty,evidence='receipt')
        return item
    def order(self,books=None):
        books=books or [self.make_book()]
        return self.cmd('order.create',customer_name='Example visitor',address='Example delivery address',project_id=self.project['id'],
                        lines=[{'item_id':b['id'],'zone_id':self.zone['id'],'qty':3} for b in books])
    def transition_order(self,order,status,**extra):
        return self.cmd('order.transition',id=order['id'],status=status,evidence='Evidence',**extra)
    def shipped_order(self):
        order=self.order()
        self.transition_order(order,'picking'); self.transition_order(order,'packed')
        self.transition_order(order,'shipped',carrier='Manual courier',tracking_number='TEST-123')
        return order

    def test_reservations_are_reference_scoped(self):
        self.move('reserve',7,reference='A')
        self.assert_code('insufficient_stock',lambda:self.move('issue',4,reference='B',custodian_id=self.owner['id']))
        self.assert_code('reservation_exceeded',lambda:self.move('release',1,reference='B'))
        self.move('issue',4,reference='A',custodian_id=self.owner['id'])
        self.assertEqual((self.bal()['on_hand'],self.bal()['reserved'],self.bal()['available']),(6,3,3))
        self.move('return',2,reference='A')
        self.assertEqual(self.bal()['on_hand'],8)
        self.assert_code('return_exceeded',lambda:self.move('return',3,reference='A'))
    def test_return_requires_matching_issue_reference(self):
        self.move('issue',3,reference='A',custodian_id=self.owner['id'])
        self.assert_code('return_exceeded',lambda:self.move('return',1,reference='B'))
        self.move('return',3,reference='A')
        self.assert_code('return_exceeded',lambda:self.move('return',1,reference='A'))
    def test_transfer_and_maintenance_preserve_inventory(self):
        self.move('reserve',3,reference='hold')
        self.assert_code('insufficient_stock',lambda:self.move('transfer',8,to_zone_id=self.zone2['id']))
        self.move('transfer',4,to_zone_id=self.zone2['id'])
        self.move('maintenance',3)
        self.assertEqual((self.bal()['on_hand'],self.bal()['reserved'],self.bal()['maintenance']),(3,3,3))
        self.assert_code('maintenance_exceeded',lambda:self.move('restore',4))
        self.move('restore',3)
        self.assertEqual(sum(x['on_hand']+x['maintenance'] for x in self.store.state()['stock']),10)
    def test_negative_fraction_bool_quantity_rejected(self):
        for invalid in [0,-1,1.5,True,'1',1000001]:
            self.assert_code('invalid_quantity',lambda:self.move('receipt',invalid))
        self.assertEqual(self.bal()['on_hand'],10)
    def test_stock_requires_evidence(self):
        with self.assertRaises(DomainError): self.cmd('stock.move',action='receipt',qty=1,item_id=self.item['id'],zone_id=self.zone['id'])
    def test_multi_line_order_rolls_back_all_reservations_on_shortfall(self):
        first=self.make_book('A',10); second=self.make_book('B',1)
        before=self.store.state()
        self.assert_code('insufficient_stock',lambda:self.order([first,second]))
        after=self.store.state()
        self.assertEqual(before['revision'],after['revision'])
        self.assertEqual(before['stock'],after['stock'])
        self.assertEqual(after['orders'],[])
        self.assertEqual(after['reservations'],[])
    def test_order_cancel_releases_reservation(self):
        order=self.order()
        self.assertEqual(sum(x['reserved'] for x in self.store.state()['stock']),3)
        self.transition_order(order,'cancelled',reason='Visitor cancellation')
        self.assertEqual(sum(x['reserved'] for x in self.store.state()['stock']),0)
    def test_order_requires_tracking_and_packed_evidence(self):
        order=self.order(); self.transition_order(order,'picking')
        with self.assertRaises(DomainError): self.cmd('order.transition',id=order['id'],status='packed')
        self.transition_order(order,'packed')
        before=self.store.state()
        with self.assertRaises(DomainError): self.transition_order(order,'shipped',carrier='Courier')
        self.assertEqual(self.store.state()['revision'],before['revision'])
        self.assertEqual(self.store.state()['stock'],before['stock'])
    def test_order_shipping_delivery_return_once(self):
        order=self.shipped_order()
        self.transition_order(order,'delivered')
        self.transition_order(order,'returned',reason='Received customer return')
        book_id=order['lines'][0]['item_id']
        stock=next(x for x in self.store.state()['stock'] if x['item_id']==book_id)
        self.assertEqual((stock['on_hand'],stock['reserved']),(10,0))
        self.assert_code('invalid_transition',lambda:self.transition_order(order,'returned',reason='duplicate'))
    def test_exception_resume_does_not_dispatch_twice(self):
        order=self.shipped_order(); before=self.store.state()['stock']
        self.transition_order(order,'exception',reason='Courier delay')
        self.transition_order(order,'shipped')
        self.assertEqual(before,self.store.state()['stock'])
        self.transition_order(order,'exception',reason='Courier delay')
        self.assert_code('already_dispatched',lambda:self.transition_order(order,'cancelled',reason='Try cancel'))
    def test_order_reservation_cannot_be_stolen_via_ledger(self):
        order=self.order()
        self.assert_code('protected_reference',lambda:self.cmd('stock.move',action='release',qty=1,item_id=order['lines'][0]['item_id'],zone_id=self.zone['id'],reference='order:'+order['id']))
    def test_tasks_dependency_and_inspection_gates(self):
        prior=self.cmd('task.create',title='Build',project_id=self.project['id'])
        task=self.cmd('task.create',title='Operate',project_id=self.project['id'],dependencies=[prior['id']])
        self.assert_code('dependencies_incomplete',lambda:self.cmd('task.transition',id=task['id'],status='active'))
        self.cmd('task.transition',id=prior['id'],status='active')
        self.assert_code('inspection_required',lambda:self.cmd('task.transition',id=prior['id'],status='completed',inspection_result='passed',evidence='Record'))
        self.cmd('task.transition',id=prior['id'],status='inspection')
        self.assert_code('forbidden',lambda:self.cmd('task.transition',actor=FIELD,id=prior['id'],status='completed',inspection_result='passed',evidence='Record'))
        self.cmd('task.inspect',id=prior['id'],results=[{'item_id':key,'status':'passed'} for key in ['scope','quality','handover']],evidence='Signed inspection')
        self.cmd('task.transition',id=prior['id'],status='completed',evidence='Record')
        self.cmd('task.transition',id=task['id'],status='active')
    def make_permit(self,start=None,end=None):
        now=dt.datetime.now(dt.timezone.utc)
        return self.cmd('permit.create',title='Vehicle entry',holder_name='Supplier',kind='vehicle',vehicle_plate='TEST',
            authority='Site security',approval_role='security',zone_id=self.zone['id'],project_id=self.project['id'],
            valid_from=(start or now-dt.timedelta(hours=1)).isoformat(),valid_until=(end or now+dt.timedelta(hours=1)).isoformat())
    def test_permit_approval_role_and_access(self):
        permit=self.make_permit()
        self.cmd('permit.transition',id=permit['id'],status='submitted')
        self.assert_code('approval_role_required',lambda:self.cmd('permit.transition',actor={'id':'m','role':'manager'},id=permit['id'],status='approved',evidence='record'))
        self.cmd('permit.transition',actor=SECURITY,id=permit['id'],status='approved',evidence='record')
        self.assert_code('zone_not_permitted',lambda:self.cmd('permit.access',actor=SECURITY,id=permit['id'],action='checkin',zone_id=self.zone2['id'],evidence='scan'))
        self.cmd('permit.access',actor=SECURITY,id=permit['id'],action='checkin',evidence='scan')
        self.assert_code('already_checked_in',lambda:self.cmd('permit.access',actor=SECURITY,id=permit['id'],action='checkin',evidence='scan'))
        self.cmd('permit.transition',id=permit['id'],status='revoked',evidence='withdrawal',reason='Done')
        self.cmd('permit.access',actor=SECURITY,id=permit['id'],action='checkout',evidence='exit scan')
    def test_expired_permit_cannot_approve(self):
        now=dt.datetime.now(dt.timezone.utc)
        permit=self.make_permit(now-dt.timedelta(days=2),now-dt.timedelta(days=1))
        self.cmd('permit.transition',id=permit['id'],status='submitted')
        self.assert_code('permit_expired',lambda:self.cmd('permit.transition',id=permit['id'],status='approved',evidence='record'))
    def test_approved_permit_rechecks_expiry_on_entry(self):
        permit=self.make_permit(); self.cmd('permit.transition',id=permit['id'],status='submitted')
        self.cmd('permit.transition',id=permit['id'],status='approved',evidence='record')
        with self.store.connect() as c:
            row=self.store.get(c,'permits',permit['id']); row['valid_until']=(dt.datetime.now(dt.timezone.utc)-dt.timedelta(seconds=1)).isoformat()
            self.store.put(c,'permits',row)
        self.assert_code('permit_expired',lambda:self.cmd('permit.access',id=permit['id'],action='checkin',evidence='scan'))
    def test_incident_requires_decision_before_resolution(self):
        incident=self.cmd('incident.create',title='Blockage',description='Obstructed entrance',zone_id=self.zone['id'])
        self.cmd('incident.transition',id=incident['id'],status='assigned',responsible_id=self.owner['id'])
        self.assert_code('decision_required',lambda:self.cmd('incident.transition',id=incident['id'],status='resolved',evidence='cleared'))
        self.cmd('incident.decision',incident_id=incident['id'],decision='Clear entry',action='Move crates',impact='Entry available',impact_type='observed',evidence='inspection')
        self.cmd('incident.transition',id=incident['id'],status='resolved',evidence='cleared')
        self.cmd('incident.transition',id=incident['id'],status='closed',evidence='accepted')
    def test_procurement_receipt_updates_stock_once(self):
        proc=self.cmd('procurement.create',item_id=self.item['id'],qty=5,supplier_id=self.owner['id'],zone_id=self.zone['id'])
        self.assert_code('forbidden',lambda:self.cmd('procurement.transition',actor=WAREHOUSE,id=proc['id'],status='approved',evidence='approved'))
        for target in ['approved','ordered','received']: self.cmd('procurement.transition',id=proc['id'],status=target,evidence='doc')
        self.assertEqual(self.bal()['on_hand'],15)
        self.assert_code('invalid_transition',lambda:self.cmd('procurement.transition',id=proc['id'],status='received',evidence='duplicate'))
    def test_rbac_rejects_before_mutation(self):
        before=self.store.state()['revision']
        for actor in [VIEWER,SECURITY,FIELD]:
            self.assert_code('forbidden',lambda:self.cmd('item.create',actor=actor,kind='book',name='Not allowed'))
        self.assertEqual(self.store.state()['revision'],before)
        self.assert_code('forbidden',lambda:self.store.export(VIEWER))
    def test_revision_conflict_is_atomic(self):
        revision=self.store.state()['revision']
        self.store.command('item.create',{'kind':'consumable','name':'Tape','project_id':self.project['id']},ADMIN,revision)
        self.assert_code('revision_conflict',lambda:self.store.command('item.create',{'kind':'consumable','name':'More tape','project_id':self.project['id']},ADMIN,revision))
        self.assertEqual(self.store.state()['revision'],revision+1)
    def test_audit_append_only_and_backup_contains_full_audit(self):
        with self.store.connect() as c:
            with self.assertRaises(sqlite3.IntegrityError): c.execute('DELETE FROM audit')
        export=self.store.export(ADMIN)
        seqs=[r['seq'] for r in export['audit']]
        self.assertEqual(seqs,list(range(1,len(seqs)+1)))
        self.assertNotIn('sessions',export['records'])
    def test_demo_provenance_and_mode_isolation(self):
        path=Path(self.tmp.name)/'demo.sqlite'; demo=DomainStore(path,demo=True)
        state=demo.state()
        self.assertEqual(state['mode'],'demo'); self.assertGreater(len(state['items']),0)
        self.assertTrue(all(x['provenance']=='demo' for x in state['items']))
        rev=state['revision']; self.assertEqual(DomainStore(path,demo=True).state()['revision'],rev)
        self.assert_code('mode_mismatch',lambda:DomainStore(path,demo=False))
    def test_observations_cannot_claim_live_source(self):
        p={'zone_id':self.zone['id'],'responsible_id':self.owner['id'],'evidence':'manual count','people_count':50,'capacity':100}
        with self.assertRaises(DomainError): self.cmd('observation.create',**p,source='live')
        obs=self.cmd('observation.create',**p,satisfaction_score=4.2,sample_size=20)
        self.assertEqual((obs['source'],obs['provenance']),('manual','manual'))
    def test_order_personal_data_is_role_filtered(self):
        order=self.order()
        for role in ['viewer','security','field']:
            row=self.store.state({'id':role,'role':role})['orders'][0]
            self.assertNotIn('customer_phone',row);self.assertNotIn('address',row)
            self.assertNotEqual(row['customer_name'],order['customer_name'])
        self.assertEqual(self.store.state(WAREHOUSE)['orders'][0]['address'],order['address'])
    def test_task_completion_rechecks_linked_permit(self):
        permit=self.make_permit()
        self.cmd('permit.transition',id=permit['id'],status='submitted')
        self.cmd('permit.transition',id=permit['id'],status='approved',evidence='approval')
        task=self.cmd('task.create',title='Permitted task',permit_id=permit['id'],project_id=self.project['id'],zone_id=self.zone['id'])
        self.cmd('task.transition',id=task['id'],status='active')
        self.cmd('task.transition',id=task['id'],status='inspection')
        self.cmd('permit.transition',id=permit['id'],status='revoked',reason='Withdrawn',evidence='withdrawal')
        self.assert_code('permit_not_approved',lambda:self.cmd('task.transition',id=task['id'],status='completed',inspection_result='passed',evidence='inspection'))
    def test_task_rejects_permit_for_different_zone(self):
        permit=self.make_permit()
        self.assert_code('zone_not_permitted',lambda:self.cmd('task.create',title='Wrong zone',project_id=self.project['id'],zone_id=self.zone2['id'],permit_id=permit['id']))
    def test_shared_relationships_reject_cross_project(self):
        project2=self.cmd('shared.create',collection='projects',name='Other')
        zone2=self.cmd('shared.create',collection='zones',name='Other zone',project_id=project2['id'])
        self.assert_code('project_mismatch',lambda:self.cmd('incident.create',title='Wrong',description='Mismatch',project_id=self.project['id'],zone_id=zone2['id']))
        self.assert_code('project_mismatch',lambda:self.cmd('stock.move',action='receipt',item_id=self.item['id'],zone_id=zone2['id'],qty=1,evidence='receipt'))
    def count(self,qty):
        return self.cmd('stock.count',item_id=self.item['id'],zone_id=self.zone['id'],counted_qty=qty,evidence='Count sheet')
    def test_count_variance_requires_manager_approval(self):
        count=self.count(8)
        self.assertEqual((count['status'],count['variance'],self.bal()['on_hand']),('pending',-2,10))
        self.assert_code('forbidden',lambda:self.cmd('stock.count.review',actor=WAREHOUSE,id=count['id'],status='approved',reason='Verified loss',evidence='Approval'))
        self.cmd('stock.count.review',id=count['id'],status='approved',reason='Verified loss',evidence='Approval')
        self.assertEqual(self.bal()['on_hand'],8)
        self.assertEqual(self.store.state()['stock_moves'][-1]['signed_qty'],-2)
    def test_count_stale_and_reserved_conflicts(self):
        count=self.count(8); self.move('receipt',1)
        self.assert_code('stale_count',lambda:self.cmd('stock.count.review',id=count['id'],status='approved',reason='Verified',evidence='Approval'))
        self.move('reserve',9,reference='Hold')
        count=self.count(8)
        self.assert_code('reserved_stock_conflict',lambda:self.cmd('stock.count.review',id=count['id'],status='approved',reason='Verified',evidence='Approval'))
    def test_closeout_requires_current_inventory_and_locks_transactions(self):
        self.assert_code('closeout_blocked',lambda:self.cmd('project.close',id=self.project['id'],evidence='Acceptance',summary='Ready'))
        self.count(10)
        report=self.store.state()['closeout'][0];self.assertTrue(report['ready'])
        self.cmd('project.close',id=self.project['id'],evidence='Acceptance',summary='Accepted final inventory')
        self.assert_code('project_closed',lambda:self.move('receipt',1))
        self.assert_code('project_closed',lambda:self.cmd('item.create',kind='book',name='Late book',owner_id=self.owner['id']))
        self.cmd('project.reopen',id=self.project['id'],reason='Late return',evidence='Manager approval')
        self.move('receipt',1)
        self.assertFalse(self.store.state()['closeout'][0]['ready'])
    def test_closeout_blocks_open_custody_and_customer_orders(self):
        self.move('issue',1,reference='custody',custodian_id=self.owner['id']);self.order();self.count(9)
        codes={b['code'] for b in self.store.state()['closeout'][0]['blockers']}
        self.assertIn('outstanding_custody',codes);self.assertIn('open_orders',codes);self.assertIn('reserved_stock',codes)
    def test_scoped_account_cannot_read_mutate_or_export_other_projects(self):
        other=self.cmd('shared.create',collection='projects',name='Other project')
        actor={**ADMIN,'project_ids':[other['id']]}
        state=self.store.state(actor)
        self.assertEqual([p['id'] for p in state['projects']],[other['id']]);self.assertEqual(state['stock'],[])
        rev=self.store.state()['revision']
        self.assert_code('project_scope_required',lambda:self.cmd('stock.move',actor=actor,action='receipt',item_id=self.item['id'],zone_id=self.zone['id'],qty=1,evidence='Unallowed'))
        self.assertEqual(self.bal()['on_hand'],10);self.assertEqual(self.store.state()['revision'],rev)
        self.assert_code('full_backup_scope_required',lambda:self.store.export(actor))
    def test_consumable_consumption_has_no_returnable_custody(self):
        item=self.cmd('item.create',kind='consumable',name='Packing tape',project_id=self.project['id'])
        self.cmd('stock.move',action='receipt',item_id=item['id'],zone_id=self.zone['id'],qty=10,evidence='Receipt')
        self.cmd('stock.move',action='reserve',item_id=item['id'],zone_id=self.zone['id'],qty=7,reference='Other work')
        self.assert_code('insufficient_stock',lambda:self.cmd('stock.move',action='consume',item_id=item['id'],zone_id=self.zone['id'],qty=4,reference='Work',responsible_id=self.owner['id'],evidence='Usage'))
        self.cmd('stock.move',action='consume',item_id=item['id'],zone_id=self.zone['id'],qty=3,reference='Work',responsible_id=self.owner['id'],evidence='Usage')
        state=self.store.state();b=next(x for x in state['stock'] if x['item_id']==item['id'])
        self.assertEqual((b['on_hand'],b['available']),(7,0))
        self.assertFalse(any(x['item_id']==item['id'] for x in state['custody']))
    def test_settle_books_sold_closes_custody_without_inventing_stock(self):
        book=self.make_book(qty=10)
        move={'item_id':book['id'],'zone_id':self.zone['id'],'reference':'Publisher booth','evidence':'Receipt'}
        self.cmd('stock.move',**move,action='issue',qty=8,custodian_id=self.owner['id'])
        self.cmd('stock.move',**move,action='return',qty=3)
        before=self.store.state()['stock']
        self.cmd('stock.settle',item_id=book['id'],reference='Publisher booth',qty=5,disposition='publisher_sold',reason='Publisher signed sales statement',evidence='Statement')
        self.assertEqual(before,self.store.state()['stock'])
        custody=next(x for x in self.store.state()['custody'] if x['item_id']==book['id'])
        self.assertEqual(custody['issued'],custody['returned']+custody['settled']+custody['outstanding'])
        self.assertEqual(custody['outstanding'],0)
        self.assert_code('settlement_exceeded',lambda:self.cmd('stock.settle',item_id=book['id'],reference='Publisher booth',qty=1,disposition='publisher_sold',reason='Duplicate',evidence='Statement'))
    def test_settlement_roles_kind_and_order_protection(self):
        self.move('issue',2,reference='Equipment',custodian_id=self.owner['id'])
        payload={'item_id':self.item['id'],'reference':'Equipment','qty':1,'disposition':'loss_damage','reason':'Damaged','evidence':'Approved writeoff'}
        self.assert_code('forbidden',lambda:self.cmd('stock.settle',actor=WAREHOUSE,**payload))
        self.assert_code('invalid_disposition',lambda:self.cmd('stock.settle',**{**payload,'disposition':'publisher_sold'}))
        self.cmd('stock.settle',**payload)
        order=self.shipped_order()
        self.assert_code('protected_reference',lambda:self.cmd('stock.settle',**{**payload,'item_id':order['lines'][0]['item_id'],'reference':'order:'+order['id'],'disposition':'publisher_sold'}))
    def test_optional_project_is_inferred_but_cross_project_dependencies_are_rejected(self):
        other=self.cmd('shared.create',collection='projects',name='Other')
        first=self.cmd('task.create',title='One',project_id=self.project['id'])
        second=self.cmd('task.create',title='Two',project_id=other['id'])
        inferred=self.cmd('task.create',title='Inferred',dependencies=[first['id']])
        self.assertEqual(inferred['project_id'],self.project['id'])
        self.assert_code('project_mismatch',lambda:self.cmd('task.create',title='Mixed',dependencies=[first['id'],second['id']]))
        with self.assertRaises(DomainError): self.cmd('item.create',kind='equipment',name='Orphan')
        with self.assertRaises(DomainError): self.cmd('task.create',title='Orphan')
    def test_return_at_other_location_preserves_project_inventory(self):
        self.move('issue',4,reference='Move return',custodian_id=self.owner['id'])
        self.cmd('stock.move',action='return',qty=4,item_id=self.item['id'],zone_id=self.zone2['id'],reference='Move return',evidence='Returned to alternate site')
        self.assertEqual(sum(x['on_hand'] for x in self.store.state()['stock']),10)
        other=self.cmd('shared.create',collection='projects',name='Other')
        zone=self.cmd('shared.create',collection='zones',project_id=other['id'],name='Other zone')
        self.assert_code('project_mismatch',lambda:self.cmd('stock.move',action='return',qty=1,item_id=self.item['id'],zone_id=zone['id'],reference='Move return',evidence='Wrong project'))
    def test_dependencies_cannot_point_forward_or_mutate_into_cycles(self):
        self.assert_code('not_found',lambda:self.cmd('task.create',title='Cycle attempt',project_id=self.project['id'],dependencies=['TSK-FUTURE']))
        task=self.cmd('task.create',title='One',project_id=self.project['id'])
        self.assert_code('unknown_command',lambda:self.cmd('task.update',id=task['id'],dependencies=[task['id']]))
    def test_observation_time_and_measurements_are_bounded_finite(self):
        base={'zone_id':self.zone['id'],'responsible_id':self.owner['id'],'evidence':'Count','people_count':0,'capacity':100}
        for value in ['invalid','2026-01-01T12:00:00',(dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=1)).isoformat()]:
            with self.assertRaises(DomainError): self.cmd('observation.create',**base,observed_at=value)
        for value in [float('nan'),float('inf'),-1,1441]:
            with self.assertRaises(DomainError): self.cmd('observation.create',**base,wait_minutes=value)
        for value in [True,float('inf'),1.5,-1]:
            with self.assertRaises(DomainError): self.cmd('shared.create',collection='zones',project_id=self.project['id'],name='Invalid',capacity=value)
        with self.assertRaises(DomainError): self.cmd('incident.create',title='Bad time',description='Bad',zone_id=self.zone['id'],observed_at='not-date')
    def test_inspection_report_is_required_and_invalidated_by_rework(self):
        task=self.cmd('task.create',title='Inspect',project_id=self.project['id'],inspection_checklist=[{'id':'safety','label':'Safety approved','required':True}])
        self.cmd('task.transition',id=task['id'],status='active');self.cmd('task.transition',id=task['id'],status='inspection')
        self.assert_code('inspection_required',lambda:self.cmd('task.transition',id=task['id'],status='completed',inspection_result='passed',evidence='Shortcut'))
        failed=self.cmd('task.inspect',id=task['id'],results=[{'item_id':'safety','status':'failed','notes':'Needs rework'}],evidence='Inspection')
        self.assertEqual(failed['inspections'][-1]['overall'],'failed')
        self.assert_code('inspection_required',lambda:self.cmd('task.transition',id=task['id'],status='completed',evidence='Unready'))
        self.cmd('task.inspect',id=task['id'],results=[{'item_id':'safety','status':'passed'}],evidence='Corrected inspection')
        self.cmd('task.transition',id=task['id'],status='active');self.cmd('task.transition',id=task['id'],status='inspection')
        self.assert_code('inspection_required',lambda:self.cmd('task.transition',id=task['id'],status='completed',evidence='Old inspection'))
        self.cmd('task.inspect',id=task['id'],results=[{'item_id':'safety','status':'passed'}],evidence='Fresh inspection')
        self.cmd('task.transition',id=task['id'],status='completed',evidence='Handover')
    def test_permit_approvals_follow_order_and_prevent_early_entry(self):
        point=dt.datetime.now(dt.timezone.utc)
        permit=self.cmd('permit.create',title='Two approvals',holder_name='Visitor',zone_id=self.zone['id'],valid_from=(point-dt.timedelta(hours=1)).isoformat(),valid_until=(point+dt.timedelta(hours=1)).isoformat(),approval_steps=[{'id':'manager','authority':'Project management','role':'manager','stakeholder_id':self.owner['id']},{'id':'security','authority':'Site security','role':'security'}])
        self.cmd('permit.transition',id=permit['id'],status='submitted')
        self.assert_code('approval_role_required',lambda:self.cmd('permit.transition',actor=SECURITY,id=permit['id'],status='approved',evidence='Out of order'))
        partial=self.cmd('permit.transition',actor={'id':'m','role':'manager'},id=permit['id'],status='approved',evidence='Manager approval')
        self.assertEqual((partial['status'],partial['current_step_index']),('submitted',1))
        self.assert_code('permit_not_approved',lambda:self.cmd('permit.access',id=permit['id'],action='checkin',evidence='Early entry'))
        complete=self.cmd('permit.transition',actor=SECURITY,id=permit['id'],status='approved',evidence='Security approval')
        self.assertEqual((complete['status'],complete['current_step_index']),('approved',2))
        self.cmd('permit.access',actor=SECURITY,id=permit['id'],action='checkin',evidence='Gate scan')
    def test_permit_rejects_authority_from_other_project(self):
        other=self.cmd('shared.create',collection='projects',name='Other')
        authority=self.cmd('shared.create',collection='stakeholders',project_id=other['id'],name='Unrelated authority')
        point=dt.datetime.now(dt.timezone.utc)
        self.assert_code('project_mismatch',lambda:self.cmd('permit.create',title='Wrong authority',holder_name='Visitor',zone_id=self.zone['id'],valid_from=point.isoformat(),valid_until=(point+dt.timedelta(hours=1)).isoformat(),approval_steps=[{'id':'one','authority':'Authority','role':'security','stakeholder_id':authority['id']}]))
    def test_generated_identifier_collision_never_overwrites_existing_record(self):
        with patch('domain.secrets.token_hex',side_effect=['DUPLICATE','DUPLICATE','UNIQUE']):
            first=self.cmd('item.create',kind='equipment',name='Original',project_id=self.project['id'])
            second=self.cmd('item.create',kind='equipment',name='Second',project_id=self.project['id'])
        self.assertNotEqual(first['id'],second['id'])
        with self.store.connect() as c:
            self.assertEqual(self.store.get(c,'items',first['id'])['name'],'Original')
            self.assertEqual(self.store.get(c,'items',second['id'])['name'],'Second')
    def test_incident_assignment_cannot_link_another_project_stakeholder(self):
        incident=self.cmd('incident.create',title='Incident',description='Needs owner',project_id=self.project['id'])
        other=self.cmd('shared.create',collection='projects',name='Other')
        owner=self.cmd('shared.create',collection='stakeholders',project_id=other['id'],name='Other owner')
        revision=self.store.state()['revision']
        self.assert_code('project_mismatch',lambda:self.cmd('incident.transition',id=incident['id'],status='assigned',responsible_id=owner['id']))
        self.assertEqual(self.store.state()['revision'],revision)
    def test_new_pending_count_invalidates_previous_closeout_count(self):
        self.count(10)
        self.assertTrue(self.store.state()['closeout'][0]['ready'])
        self.count(8)
        self.assertFalse(self.store.state()['closeout'][0]['ready'])
        self.assert_code('closeout_blocked',lambda:self.cmd('project.close',id=self.project['id'],summary='Pending discrepancy',evidence='Incomplete'))
    def test_older_count_cannot_overwrite_a_newer_physical_count(self):
        old=self.count(8);self.count(10)
        self.assert_code('superseded_count',lambda:self.cmd('stock.count.review',id=old['id'],status='approved',reason='Obsolete',evidence='Old count'))
        self.assertEqual(self.bal()['on_hand'],10)
    def test_exhausted_ledger_id_collision_rolls_back_balance_and_revision(self):
        state=self.store.state();existing=state['stock_moves'][0]
        suffix=existing['id'].split('-',1)[1]
        with patch('domain.secrets.token_hex',return_value=suffix):
            self.assert_code('identifier_collision',lambda:self.move('receipt',1))
        self.assertEqual(self.bal()['on_hand'],10)
        self.assertEqual(self.store.state()['revision'],state['revision'])
        self.assertEqual(self.store.state()['stock_moves'],state['stock_moves'])
    def test_same_revision_race_has_one_winner_and_one_audit_event(self):
        revision=self.store.state()['revision'];barrier=threading.Barrier(2);outcomes=[]
        def change(reference):
            barrier.wait()
            try:
                result=self.store.command('stock.move',{'action':'reserve','qty':1,'item_id':self.item['id'],'zone_id':self.zone['id'],'reference':reference},ADMIN,revision)
                outcomes.append(result['revision'])
            except DomainError as error: outcomes.append(error.code)
        threads=[threading.Thread(target=change,args=(ref,)) for ref in ['A','B']]
        for thread in threads:thread.start()
        for thread in threads:thread.join()
        self.assertCountEqual(outcomes,[revision+1,'revision_conflict'])
        state=self.store.state();self.assertEqual(state['revision'],revision+1)
        self.assertEqual(state['audit'][0]['seq'],revision+1);self.assertEqual(self.bal()['reserved'],1)
    def test_closed_project_rejects_inferred_new_support_and_evidence(self):
        project=self.cmd('shared.create',collection='projects',name='Closed workflow')
        one=self.cmd('shared.create',collection='zones',project_id=project['id'],name='One')
        two=self.cmd('shared.create',collection='zones',project_id=project['id'],name='Two')
        owner=self.cmd('shared.create',collection='stakeholders',project_id=project['id'],name='Owner')
        self.cmd('project.close',id=project['id'],summary='Empty site accepted',evidence='Acceptance')
        self.assert_code('project_closed',lambda:self.cmd('support.create',from_zone_id=one['id'],to_zone_id=two['id'],responsible_id=owner['id'],title='Late support',reason='Test',needed_by='2027-01-01T12:00:00+03:00'))
        self.assert_code('project_closed',lambda:self.cmd('attachment.create',zone_id=one['id'],filename='test.pdf',content_type='application/pdf',data_base64=base64.b64encode(b'%PDF-1.4\n%%EOF').decode()))
    @unittest.skipUnless(os.name=='posix','POSIX file permissions')
    def test_new_database_is_private_without_chmod_of_existing_directories(self):
        new_dir=Path(self.tmp.name)/'private-data'
        new_path=new_dir/'private.sqlite'
        store=DomainStore(new_path)
        self.assertEqual(new_dir.stat().st_mode & 0o777,0o700)
        self.assertEqual(new_path.stat().st_mode & 0o777,0o600)
        with store.connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            connection.execute("INSERT INTO metadata(key,value) VALUES('permissions-check','1')")
            for suffix in ['-wal','-shm']:
                companion=Path(str(new_path)+suffix)
                if companion.exists(): self.assertEqual(companion.stat().st_mode & 0o077,0)
        existing_dir=Path(self.tmp.name)/'existing-data'
        existing_dir.mkdir();existing_dir.chmod(0o755)
        other_path=existing_dir/'new.sqlite'
        DomainStore(other_path)
        self.assertEqual(existing_dir.stat().st_mode & 0o777,0o755)
        self.assertEqual(other_path.stat().st_mode & 0o777,0o600)
    def test_concurrent_reservation_cannot_oversell(self):
        errors=[]; successes=[]
        def reserve(ref):
            try: self.move('reserve',7,reference=ref); successes.append(ref)
            except DomainError as e: errors.append(e.code)
        threads=[threading.Thread(target=reserve,args=(str(i),)) for i in range(2)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertEqual((len(successes),errors),(1,['insufficient_stock']))
        self.assertEqual(self.bal()['reserved'],7)

class HTTPTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(); cls.store=DomainStore(Path(cls.tmp.name)/'api.sqlite')
        cls.password='a-long-test-password'
        cls.accounts={'admin':{'id':'admin','name':'Admin','username':'admin','role':'admin','password_hash':hash_password(cls.password)},
                      'viewer':{'id':'viewer','name':'Viewer','username':'viewer','role':'viewer','password_hash':hash_password(cls.password)}}
        cls.server=Server(('127.0.0.1',0),Handler); cls.port=cls.server.server_address[1]
        cls.origin=f'http://127.0.0.1:{cls.port}'
        cls.server.app=Application(cls.store,cls.accounts,host='127.0.0.1',port=cls.port,static_root=cls.tmp.name)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True); cls.thread.start()
    @classmethod
    def tearDownClass(cls): cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
    def request(self,path,method='GET',data=None,cookie=None,origin=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5)
        headers={}
        if data is not None: headers['Content-Type']='application/json'
        if origin is not None: headers['Origin']=origin
        if cookie: headers['Cookie']=cookie
        conn.request(method,path,body=json.dumps(data) if data is not None else None,headers=headers)
        response=conn.getresponse(); result=response.read()
        output=(response.status,json.loads(result),dict(response.getheaders()));conn.close();return output
    def login(self,username='admin'):
        status,data,headers=self.request('/api/session/login','POST',{'username':username,'password':self.password},origin=self.origin)
        self.assertEqual(status,200); self.assertIn('HttpOnly',headers['Set-Cookie']); self.assertIn('SameSite=Strict',headers['Set-Cookie'])
        return headers['Set-Cookie'].split(';')[0]
    def test_login_required_and_csrf_origin(self):
        self.assertEqual(self.request('/api/state')[0],401)
        self.assertEqual(self.request('/api/session/login','POST',{'username':'admin','password':self.password})[0],403)
        self.assertEqual(self.request('/api/session/login','POST',{'username':'admin','password':self.password},origin='https://evil.example')[0],403)
        cookie=self.login();self.assertEqual(self.request('/api/state',cookie=cookie)[0],200)
    def test_api_revision_required_and_viewer_enforced(self):
        admin=self.login(); viewer=self.login('viewer')
        payload={'type':'shared.create','payload':{'collection':'projects','name':'Project'}}
        self.assertEqual(self.request('/api/commands','POST',payload,cookie=admin,origin=self.origin)[0],428)
        payload['expected_revision']=None
        self.assertEqual(self.request('/api/commands','POST',payload,cookie=admin,origin=self.origin)[0],400)
        payload['expected_revision']=self.store.state()['revision']
        self.assertEqual(self.request('/api/commands','POST',payload,cookie=viewer,origin=self.origin)[0],403)
        self.assertEqual(self.request('/api/backup',cookie=viewer)[0],403)
        self.assertEqual(self.request('/api/commands','POST',payload,cookie=admin,origin=self.origin)[0],200)
        self.assertEqual(self.request('/api/commands','POST',payload,cookie=admin,origin=self.origin)[0],409)
    def test_logout_invalidates_session(self):
        cookie=self.login()
        self.assertEqual(self.request('/api/session/logout','POST',{},cookie=cookie,origin=self.origin)[0],200)
        self.assertEqual(self.request('/api/state',cookie=cookie)[0],401)
    def test_password_hashing(self):
        value=hash_password('a-secure-long-password')
        self.assertTrue(verify_password('a-secure-long-password',value));self.assertFalse(verify_password('incorrect',value))
        self.assertFalse(verify_password('anything','invalid'))
    def test_account_bootstrap_writes_private_scoped_configuration(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'accounts.json'
            create_account_file(target,'operator','Operator','warehouse',self.password,['PRJ-X'])
            self.assertEqual(target.stat().st_mode & 0o777,0o600)
            accounts=load_accounts(target)
            self.assertEqual(accounts['operator']['project_ids'],['PRJ-X'])
            self.assertTrue(verify_password(self.password,accounts['operator']['password_hash']))
            with self.assertRaises(ValueError): create_account_file(target,'operator','Duplicate','admin',self.password)
    def test_overflow_json_numbers_are_rejected_without_a_write(self):
        cookie=self.login();revision=self.store.state()['revision']
        connection=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5)
        connection.request('POST','/api/commands',body='{"type":"shared.create","expected_revision":0,"payload":{"collection":"zones","capacity":1e309}}',headers={'Content-Type':'application/json','Origin':self.origin,'Cookie':cookie})
        response=connection.getresponse();self.assertEqual(response.status,400)
        self.assertEqual(json.loads(response.read())['code'],'invalid_json');connection.close()
        self.assertEqual(self.store.state()['revision'],revision)
    def test_private_attachment_http_download_and_default_body_limit(self):
        admin=self.login();viewer=self.login('viewer')
        project=self.store.command('shared.create',{'collection':'projects','name':'Evidence test'},ADMIN)['result']
        content=b'%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF\n'
        payload={'type':'attachment.create','expected_revision':self.store.state()['revision'],'payload':{'project_id':project['id'],'filename':'evidence.pdf','content_type':'application/pdf','data_base64':base64.b64encode(content).decode()}}
        status,result,_=self.request('/api/commands','POST',payload,cookie=admin,origin=self.origin)
        self.assertEqual(status,200)
        path='/api/attachments/'+result['result']['id']
        self.assertEqual(self.request(path)[0],401);self.assertEqual(self.request(path,cookie=viewer)[0],403)
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5)
        conn.request('GET',path,headers={'Cookie':admin});response=conn.getresponse()
        self.assertEqual(response.status,200);self.assertEqual(response.read(),content)
        self.assertTrue(response.getheader('Content-Disposition').startswith('attachment;'))
        self.assertEqual(response.getheader('Content-Type'),'application/octet-stream');conn.close()
        large={'type':'shared.create','expected_revision':self.store.state()['revision'],'payload':{'collection':'projects','name':'x'*(1024*1024)}}
        self.assertEqual(self.request('/api/commands','POST',large,cookie=admin,origin=self.origin)[0],413)
    def test_host_and_path_traversal(self):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=5)
        conn.request('GET','/api/health',headers={'Host':'malicious.example'})
        res=conn.getresponse();self.assertEqual(res.status,403);res.read();conn.close()
        self.assertEqual(self.request('/%2e%2e/server.py')[0],404)

if __name__=='__main__': unittest.main()

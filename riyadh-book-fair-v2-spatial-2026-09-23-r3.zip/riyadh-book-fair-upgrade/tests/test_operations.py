import base64
import tempfile
import threading
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore, DomainError

ADMIN = {'id': 'operations-manager', 'role': 'manager'}
FIELD = {'id': 'operations-field', 'role': 'field'}


class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = DomainStore(Path(self.temp.name) / 'operations.sqlite')
        self.project = self.cmd('shared.create', collection='projects', name='Daily operations')
        self.phase = self.cmd('shared.create', collection='phases', name='Operations', kind='operations', project_id=self.project['id'])
        self.zone = self.cmd('shared.create', collection='zones', name='Hall A', project_id=self.project['id'])
        self.other_zone = self.cmd('shared.create', collection='zones', name='Hall B', project_id=self.project['id'])
        self.owner = self.cmd('shared.create', collection='stakeholders', name='Zone manager', project_id=self.project['id'])

    def tearDown(self):
        self.temp.cleanup()

    def cmd(self, command_type, actor=ADMIN, **payload):
        return self.store.command(command_type, payload, actor)['result']

    def opening(self, **extra):
        result = {'project_id': self.project['id'], 'phase_id': self.phase['id'], 'zone_id': self.zone['id'],
                  'responsible_id': self.owner['id'], 'operational_date': '2026-09-23',
                  'readiness': [{'id': 'doors', 'label': 'Doors clear', 'status': 'ready'}], 'evidence': 'Opening signed record'}
        result.update(extra)
        return result

    def open_report(self, **extra):
        return self.cmd('daily.open', **self.opening(**extra))

    def close_report(self, report, **extra):
        return self.cmd('daily.close', id=report['id'], evidence='End of day record', summary='Day summary', **extra)

    def handover(self, **extra):
        result = {'handover_responsible_id': self.owner['id'], 'handover_due_at': '2026-09-24T10:00:00+03:00',
                  'handover_notes': 'Follow up the listed work on the next shift'}
        result.update(extra)
        return result

    def assert_code(self, code, callback):
        with self.assertRaises(DomainError) as caught:
            callback()
        self.assertEqual(caught.exception.code, code)

    def incident(self, priority='medium', zone_id=None):
        return self.cmd('incident.create', title='Outstanding incident', description='Requires action',
                        project_id=self.project['id'], zone_id=zone_id or self.zone['id'], priority=priority)

    def test_open_requires_structured_readiness_notes_and_valid_date(self):
        for readiness in [[], [{'id': 'x', 'label': 'Missing', 'status': 'issue'}],
                          [{'id': 'x', 'label': 'One', 'status': 'ready'}, {'id': 'x', 'label': 'Two', 'status': 'ready'}],
                          [{'id': 'x', 'label': 'Invalid', 'status': 'unknown'}]]:
            with self.assertRaises(DomainError): self.open_report(readiness=readiness)
        for date in ['2026-02-30', '20260923', '23/09/2026']:
            self.assert_code('invalid_operational_date', lambda: self.open_report(operational_date=date))
        for missing in ['phase_id', 'zone_id', 'responsible_id', 'evidence']:
            with self.assertRaises(DomainError): self.open_report(**{missing: ''})
        report = self.open_report(readiness=[{'id': 'lighting', 'label': 'Lighting', 'status': 'issue', 'notes': 'Repair request is being recorded'}])
        self.assertEqual(report['status'], 'open')
        self.assertEqual(report['readiness'][0]['notes'], 'Repair request is being recorded')
        self.assertEqual(report['opening_evidence'], 'Opening signed record')

    def test_duplicate_open_is_atomic_even_with_concurrent_requests(self):
        barrier = threading.Barrier(2)
        outcomes = []
        def run():
            barrier.wait()
            try: outcomes.append(self.open_report()['status'])
            except DomainError as error: outcomes.append(error.code)
        threads = [threading.Thread(target=run) for _ in range(2)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertCountEqual(outcomes, ['open', 'daily_already_open'])
        self.assertEqual(len(self.store.state()['daily_reports']), 1)
        self.open_report(zone_id=self.other_zone['id'])
        self.open_report(operational_date='2026-09-24')

    def test_only_manager_closes_and_terminal_close_cannot_repeat(self):
        report = self.cmd('daily.open', actor=FIELD, **self.opening())
        self.assert_code('forbidden', lambda: self.cmd('daily.close', actor=FIELD, id=report['id'], evidence='Attempt', summary='No authority'))
        closed = self.close_report(report)
        self.assertEqual(closed['status'], 'closed')
        self.assertEqual(closed['closed_by'], ADMIN['id'])
        self.assertEqual(closed['closure_snapshot']['counts']['total'], 0)
        self.assert_code('invalid_transition', lambda: self.close_report(report))
        # A second shift for the same operational day is allowed once the first is closed.
        next_report = self.open_report()
        self.assertNotEqual(next_report['id'], report['id'])

    def test_critical_incident_blocks_daily_close_without_partial_changes(self):
        report = self.open_report()
        self.incident(priority='critical')
        revision = self.store.state()['revision']
        self.assert_code('critical_incident_open', lambda: self.close_report(report, **self.handover()))
        state = self.store.state()
        self.assertEqual(state['daily_reports'][0]['status'], 'open')
        self.assertIsNone(state['daily_reports'][0]['closure_snapshot'])
        self.assertEqual(state['revision'], revision)

    def test_snapshot_handover_preserves_open_work_and_is_immutable_after_changes(self):
        report = self.open_report()
        task = self.cmd('task.create', title='Remaining setup', project_id=self.project['id'], zone_id=self.zone['id'], inspection_required=False)
        incident = self.incident()
        support = self.cmd('support.create', project_id=self.project['id'], title='Outgoing support', from_zone_id=self.zone['id'],
                           to_zone_id=self.other_zone['id'], responsible_id=self.owner['id'], needed_by='2026-09-24T12:00:00+03:00', reason='Next hall needs a team')
        self.assert_code('handover_required', lambda: self.close_report(report))
        self.assert_code('handover_required', lambda: self.close_report(report, handover_responsible_id=self.owner['id']))
        closed = self.close_report(report, **self.handover())
        self.assertEqual(closed['closure_snapshot']['counts'], {'tasks': 1, 'incidents': 1, 'support_requests': 1, 'total': 3, 'critical_incidents': 0, 'readiness_issues': 0})
        state = self.store.state()
        self.assertEqual(state['tasks'][0]['status'], 'planned')
        self.assertEqual(state['incidents'][0]['status'], 'open')
        self.assertEqual(state['support_requests'][0]['status'], 'requested')
        self.assertEqual(closed['closure_snapshot']['support_requests'][0]['id'], support['id'])
        self.cmd('task.transition', id=task['id'], status='active')
        self.assertEqual(self.store.state()['daily_reports'][0]['closure_snapshot']['tasks'][0]['status'], 'planned')

    def test_other_zone_critical_incident_is_not_in_this_zone_snapshot(self):
        report = self.open_report()
        self.incident(priority='critical', zone_id=self.other_zone['id'])
        closed = self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['incidents'], [])

    def test_handover_person_must_share_project_and_date_have_timezone(self):
        report = self.open_report()
        self.incident()
        other = self.cmd('shared.create', collection='projects', name='Other project')
        outsider = self.cmd('shared.create', collection='stakeholders', project_id=other['id'], name='Unrelated owner')
        self.assert_code('project_mismatch', lambda: self.close_report(report, **self.handover(handover_responsible_id=outsider['id'])))
        with self.assertRaises(DomainError): self.close_report(report, **self.handover(handover_due_at='2026-09-24T10:00:00'))
        self.assertEqual(self.store.state()['daily_reports'][0]['status'], 'open')

    def test_project_close_requires_daily_closure_and_closed_project_rejects_open(self):
        report = self.open_report()
        blockers = self.store.state()['closeout'][0]['blockers']
        self.assertIn('open_daily_reports', [x['code'] for x in blockers])
        self.assert_code('closeout_blocked', lambda: self.cmd('project.close', id=self.project['id'], evidence='Premature', summary='Not ready'))
        self.close_report(report)
        self.cmd('project.close', id=self.project['id'], evidence='Accepted', summary='Daily report closed')
        self.assert_code('project_closed', lambda: self.open_report(operational_date='2026-09-24'))

    def test_project_scopes_cover_state_open_and_close(self):
        report = self.open_report()
        other = self.cmd('shared.create', collection='projects', name='Other')
        restricted = {**ADMIN, 'project_ids': [other['id']]}
        self.assertEqual(self.store.state(restricted)['daily_reports'], [])
        self.assert_code('project_scope_required', lambda: self.cmd('daily.open', actor=restricted, **self.opening(operational_date='2026-09-24')))
        self.assert_code('project_scope_required', lambda: self.cmd('daily.close', actor=restricted, id=report['id'], evidence='Unallowed', summary='No access'))

    def issue_report(self):
        return self.open_report(readiness=[{'id':'lighting','label':'Lighting check','status':'issue','notes':'One circuit requires repair'}])

    def test_opening_issues_require_exactly_one_followup_each(self):
        report=self.issue_report();revision=self.store.state()['revision']
        self.assert_code('readiness_followup_required',lambda:self.close_report(report))
        self.assertEqual(self.store.state()['revision'],revision)
        for values in [[{'id':'unknown','status':'resolved','notes':'Wrong item'}],
                       [{'id':'lighting','status':'resolved','notes':'Fixed'},{'id':'lighting','status':'resolved','notes':'Duplicate'}],
                       [{'id':'lighting','status':'resolved','notes':''}]]:
            with self.assertRaises(DomainError): self.close_report(report,readiness_followup=values)
        self.assertEqual(self.store.state()['daily_reports'][0]['status'],'open')

    def test_resolved_opening_issue_records_closing_evidence_without_handover(self):
        report=self.issue_report()
        closed=self.close_report(report,readiness_followup=[{'id':'lighting','status':'resolved','notes':'Circuit repaired and retested'}])
        self.assertEqual(closed['readiness_followup'][0]['evidence'],'End of day record')
        self.assertEqual(closed['readiness_followup'][0]['notes'],'Circuit repaired and retested')
        self.assertEqual(closed['closure_snapshot']['readiness_issues'],[])
        self.assertEqual(closed['closure_snapshot']['counts']['total'],0)

    def test_carried_opening_issue_requires_handover_and_appears_in_snapshot(self):
        report=self.issue_report()
        followup=[{'id':'lighting','status':'carryover','notes':'Waiting for a spare circuit'}]
        self.assert_code('handover_required',lambda:self.close_report(report,readiness_followup=followup))
        closed=self.close_report(report,readiness_followup=followup,**self.handover())
        self.assertEqual(closed['closure_snapshot']['counts']['readiness_issues'],1)
        self.assertEqual(closed['closure_snapshot']['counts']['total'],1)
        self.assertEqual(closed['closure_snapshot']['readiness_issues'][0]['id'],'lighting')
        self.assertEqual(closed['handover_responsible_id'],self.owner['id'])

    def test_other_project_critical_incident_does_not_block_zone_closure(self):
        report=self.open_report()
        other=self.cmd('shared.create',collection='projects',name='Other project')
        other_zone=self.cmd('shared.create',collection='zones',project_id=other['id'],name='Other hall')
        self.cmd('incident.create',title='Other project critical',description='Different operational scope',project_id=other['id'],zone_id=other_zone['id'],priority='critical')
        closed=self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['counts']['critical_incidents'],0)
        self.assertEqual(closed['closure_snapshot']['incidents'],[])

    def test_older_open_critical_incident_remains_blocking(self):
        report=self.open_report()
        self.cmd('incident.create',title='Unresolved old danger',description='Age does not resolve a risk',project_id=self.project['id'],zone_id=self.zone['id'],priority='critical',observed_at='2020-01-01T08:00:00+03:00')
        self.assert_code('critical_incident_open',lambda:self.close_report(report,**self.handover()))

    def resolve_incident(self,incident):
        self.cmd('incident.transition',id=incident['id'],status='assigned',responsible_id=self.owner['id'])
        self.cmd('incident.decision',incident_id=incident['id'],decision='Secure the area',action='Remove the danger',impact='Area checked',impact_type='observed',evidence='Safety inspection')
        self.cmd('incident.transition',id=incident['id'],status='resolved',evidence='Resolved risk')

    def test_closed_critical_incident_does_not_block_daily_close(self):
        report=self.open_report();incident=self.incident(priority='critical')
        self.resolve_incident(incident)
        self.cmd('incident.transition',id=incident['id'],status='closed',evidence='Final acceptance')
        closed=self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['counts']['total'],0)
        self.assertEqual(self.store.state()['incidents'][0]['status'],'closed')

    def test_resolved_critical_incident_requires_handover_but_is_not_reclosed(self):
        report=self.open_report();incident=self.incident(priority='critical')
        self.resolve_incident(incident)
        self.assert_code('handover_required',lambda:self.close_report(report))
        closed=self.close_report(report,**self.handover())
        self.assertEqual(closed['closure_snapshot']['counts']['critical_incidents'],0)
        self.assertEqual(closed['closure_snapshot']['counts']['incidents'],1)
        self.assertEqual(self.store.state()['incidents'][0]['status'],'resolved')

    def test_attachment_can_link_to_daily_report(self):
        report = self.open_report()
        attachment = self.cmd('attachment.create', project_id=self.project['id'], record_collection='daily_reports', record_id=report['id'],
                              filename='daily.pdf', content_type='application/pdf', data_base64=base64.b64encode(b'%PDF-1.4\n%%EOF').decode())
        self.assertEqual(attachment['record_id'], report['id'])
        self.assertEqual(self.store.attachment_read(ADMIN, attachment['id'])['content'], b'%PDF-1.4\n%%EOF')


if __name__ == '__main__':
    unittest.main()

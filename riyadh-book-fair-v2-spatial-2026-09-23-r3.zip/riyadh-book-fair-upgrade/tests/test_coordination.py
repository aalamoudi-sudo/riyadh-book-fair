from pathlib import Path
import tempfile
import unittest
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore, DomainError


class CoordinationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = DomainStore(Path(self.temp.name) / 'test.sqlite')
        self.actor = {'id': 'qa-manager', 'role': 'manager'}
        self.project = self.cmd('shared.create', collection='projects', name='اختبار دعم')
        self.source = self.cmd('shared.create', collection='zones', project_id=self.project['id'], name='المصدر')
        self.target = self.cmd('shared.create', collection='zones', project_id=self.project['id'], name='الوجهة')
        self.person = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='مسؤول الموارد')
        self.item = self.cmd('item.create', kind='equipment', name='جهاز', project_id=self.project['id'])
        self.cmd('stock.move', action='receipt', item_id=self.item['id'], zone_id=self.source['id'], qty=10, evidence='محضر')
        self.incident = self.cmd('incident.create', title='حاجة دعم', description='وصف بلاغ اختباري', project_id=self.project['id'], zone_id=self.target['id'], source='manual', priority='medium', category='logistics')

    def tearDown(self):
        self.temp.cleanup()

    def cmd(self, command_type, **p):
        return self.store.command(command_type, p, self.actor)['result']

    def support(self, **extra):
        p = dict(project_id=self.project['id'], title='دعم أجهزة', from_zone_id=self.source['id'],
                 to_zone_id=self.target['id'], item_id=self.item['id'], qty=4,
                 responsible_id=self.person['id'], incident_id=self.incident['id'],
                 needed_by='2026-12-01T18:00:00+03:00', reason='دعم تجربة الاختبار')
        p.update(extra)
        return self.cmd('support.create', **p)

    def transition(self, row, status, **extra):
        return self.cmd('support.transition', id=row['id'], status=status, evidence='إثبات اختبار', **extra)

    def bal(self, zone):
        with self.store.connect() as c:
            return self.store.balance(c, self.item['id'], zone['id'])

    def test_resource_is_reserved_then_in_transit_then_received(self):
        request = self.support()
        self.assertEqual(self.bal(self.source)['available'], 10)
        request = self.transition(request, 'approved')
        self.assertEqual(self.bal(self.source)['reserved'], 4)
        self.assertEqual(self.bal(self.target)['on_hand'], 0)
        request = self.transition(request, 'dispatched')
        self.assertEqual(self.bal(self.source)['on_hand'], 6)
        self.assertEqual(self.bal(self.target)['on_hand'], 0)
        custody = self.store.state(self.actor)['custody'][0]
        self.assertEqual(custody['outstanding'], 4)
        request = self.transition(request, 'received')
        self.assertEqual(self.bal(self.target)['on_hand'], 4)
        self.assertEqual(self.store.state(self.actor)['custody'][0]['outstanding'], 0)
        self.assertEqual(len(request['movement_ids']), 3)
        with self.assertRaises(DomainError):
            self.transition(request, 'received')

    def test_cancel_releases_only_own_reservation(self):
        request = self.transition(self.support(), 'approved')
        self.transition(request, 'cancelled', reason='لم يعد مطلوبًا')
        self.assertEqual(self.bal(self.source)['available'], 10)
        self.assertEqual(self.bal(self.source)['reserved'], 0)

    def test_overcommit_approval_rolls_back_and_no_field_self_approval(self):
        request = self.support(qty=11)
        with self.assertRaises(DomainError):
            self.transition(request, 'approved')
        self.assertEqual(self.bal(self.source)['available'], 10)
        self.assertEqual(self.store.state(self.actor)['support_requests'][0]['status'], 'requested')
        with self.assertRaises(DomainError):
            self.store.command('support.transition', {'id': request['id'], 'status': 'approved', 'evidence': 'فحص'}, {'id': 'field', 'role': 'field'})

    def test_direct_use_of_support_reference_is_blocked(self):
        request = self.transition(self.support(), 'approved')
        with self.assertRaises(DomainError):
            self.cmd('stock.move', action='release', item_id=self.item['id'], zone_id=self.source['id'], qty=4, reference='support:'+request['id'])

    def test_escalation_has_owner_deadline_and_audit(self):
        row = self.cmd('incident.escalate', id=self.incident['id'], to_responsible_id=self.person['id'],
                       due_at='2026-12-01T18:00:00+03:00', reason='مهلة الاستجابة', evidence='محضر تصعيد')
        self.assertEqual(row['status'], 'assigned')
        self.assertEqual(row['responsible_id'], self.person['id'])
        self.assertEqual(row['escalation_level'], 1)
        self.assertEqual(row['history'][-1]['event'], 'escalated')


if __name__ == '__main__':
    unittest.main()

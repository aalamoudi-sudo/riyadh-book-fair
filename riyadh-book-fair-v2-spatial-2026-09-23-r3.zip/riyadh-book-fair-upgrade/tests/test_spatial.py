"""Spatial geometry and approval gates, no Blender or third-party modules needed."""
from copy import deepcopy
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "spatial"))
from import_plan import build_plan, import_svg, line_polygon
from plan_schema import area, calibrate, validate_plan, validate_polygon
from blender_export import export as export_glb


class SpatialTests(unittest.TestCase):
    def setUp(self):
        self.plan = build_plan(ROOT / "scripts/spatial/samples/zone-demo.svg", .02, 3, "Z-DEMO", data_class="demo")

    def test_known_distance_uses_euclidean_length(self):
        self.assertAlmostEqual(calibrate([20, 10], [23, 14], 10), 2)
        self.assertAlmostEqual(calibrate([100, 200], [100, 300], 5), .05)

    def test_invalid_calibration_does_not_become_geometry(self):
        for distance in (0, -1, math.nan, math.inf, True):
            with self.subTest(distance=distance), self.assertRaises(ValueError):
                calibrate([0, 0], [10, 0], distance)
        with self.assertRaises(ValueError):
            calibrate([4, 4], [4, 4], 1)

    def test_rectangle_dimensions_and_svg_axis(self):
        e = self.plan["elements"][0]
        self.assertEqual(e["polygon"], [[2, -2], [6, -2], [6, -5], [2, -5]])
        self.assertAlmostEqual(abs(area(e["polygon"])), 12)
        self.assertEqual(e["height_m"], 3)
        self.assertEqual(e["zone_id"], "Z-DEMO")

    def test_line_width_is_metres_independent_of_source_scale(self):
        e = self.plan["elements"][2]
        self.assertAlmostEqual(abs(area(e["polygon"])), 11 * .12)
        diagonal = line_polygon([0, 0], [3, 4], .2)
        self.assertAlmostEqual(abs(area(diagonal)), 1)

    def test_concave_polygon_is_valid(self):
        self.assertEqual(validate_polygon(self.plan["elements"][1]["polygon"]), self.plan["elements"][1]["polygon"])

    def test_self_intersection_and_touch_are_rejected(self):
        for polygon in ([[0, 0], [4, 4], [0, 4], [4, 0]], [[0, 0], [4, 0], [2, 0], [4, 4], [0, 4]], [[0, 0], [1, 0], [1, 0], [0, 1]]):
            with self.subTest(polygon=polygon), self.assertRaises(ValueError):
                validate_polygon(polygon)

    def test_non_finite_or_degenerate_geometry_rejected(self):
        for polygon in ([[0, 0], [1, math.nan], [2, 0]], [[0, 0], [1, 1], [2, 2]], [[0, 0], [math.inf, 1], [2, 0]]):
            with self.subTest(polygon=polygon), self.assertRaises(ValueError):
                validate_polygon(polygon)

    def test_review_gate_rejects_auto_imported_plan(self):
        self.assertFalse(self.plan["review"]["approved"])
        with self.assertRaisesRegex(ValueError, "اعتماد بشري"):
            validate_plan(self.plan, require_review=True)
        self.plan["review"] = {"approved": True, "reviewer": "مراجع اختبار", "reviewed_at": "2026-09-23T10:00:00+00:00"}
        validate_plan(self.plan, require_review=True)
        self.plan["review"]["reviewer"] = " "
        with self.assertRaises(ValueError):
            validate_plan(self.plan, require_review=True)

    def test_calibration_mismatch_is_rejected(self):
        self.plan["calibration"] = {"method": "known-distance", "points": [[0, 0], [100, 0]], "distance_m": 10, "meters_per_unit": 1}
        with self.assertRaisesRegex(ValueError, "لا يطابق"):
            validate_plan(self.plan)

    def test_repeated_id_and_missing_zone_are_rejected(self):
        self.plan["elements"][1]["id"] = self.plan["elements"][0]["id"]
        with self.assertRaises(ValueError):
            validate_plan(self.plan)
        self.plan["elements"][1]["id"] = "other"
        self.plan["elements"][1]["zone_id"] = ""
        with self.assertRaises(ValueError):
            validate_plan(self.plan)

    def test_unsupported_svg_is_not_silently_partially_imported(self):
        for inner in ('<path d="M 0 0 L 10 0 L 0 10 Z"/>', '<g transform="translate(10 10)"><rect width="10" height="10"/></g>', '<use href="remote.svg"/>', '<rect width="10" height="10" style="display:none"/>', '<svg x="10"><rect width="10" height="10"/></svg>'):
            with self.subTest(inner=inner), self.assertRaises(ValueError):
                import_svg(f'<svg xmlns="http://www.w3.org/2000/svg">{inner}</svg>'.encode(), .01, 2, "Z-A", .1)

    def test_svg_external_entity_is_rejected(self):
        content = b'<!DOCTYPE svg [<!ENTITY x SYSTEM "file:///etc/passwd">]><svg>&x;</svg>'
        with self.assertRaisesRegex(ValueError, "DTD"):
            import_svg(content, .01, 2, "Z-A", .1)

    def test_blender_export_stops_before_loading_blender_on_unreviewed_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, output = Path(tmp) / "plan.json", Path(tmp) / "model.glb"
            source.write_text(json.dumps(self.plan))
            with self.assertRaisesRegex(ValueError, "اعتماد بشري"):
                export_glb(source, output)
            self.assertFalse(output.exists())

    def test_cli_creates_draft_and_refuses_to_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "draft.json"
            command = [sys.executable, str(ROOT / "scripts/spatial/import_plan.py"), str(ROOT / "scripts/spatial/samples/zone-demo.svg"), "--output", str(output), "--meters-per-unit", "0.02", "--height", "3", "--zone", "Z-A", "--data-class", "demo"]
            first = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(first.returncode, 0, first.stderr)
            before = output.read_bytes()
            self.assertEqual(len(json.loads(before)["elements"]), 3)
            second = subprocess.run(command, capture_output=True, text=True)
            self.assertNotEqual(second.returncode, 0)
            self.assertEqual(output.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()

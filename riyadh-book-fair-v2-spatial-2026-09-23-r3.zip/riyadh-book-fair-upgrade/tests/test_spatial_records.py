"""Persistent spatial plan registration and server-side review gates."""
import copy
import hashlib
import json
import math
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from domain import DomainStore, DomainError, MAX_SPATIAL_PLAN_BYTES

ADMIN={'id':'admin','role':'admin'}
MANAGER={'id':'manager','role':'manager'}
FIELD={'id':'field','role':'field'}
VIEWER={'id':'viewer','role':'viewer'}


class SpatialPlanRecordTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)/'site.sqlite'
        self.store=DomainStore(self.path)
        self.project=self.cmd('shared.create',collection='projects',name='Book fair')['id']
        self.zone=self.cmd('shared.create',collection='zones',project_id=self.project,name='Hall')['id']

    def tearDown(self): self.tmp.cleanup()

    def cmd(self,command,actor=ADMIN,**payload):
        return self.store.command(command,payload,actor)['result']

    def assert_code(self,code,callback):
        with self.assertRaises(DomainError) as caught: callback()
        self.assertEqual(caught.exception.code,code)

    def plan(self,zone=None,data_class='manual'):
        source=b'<svg><rect id="hall"/></svg>'
        return {'schema_version':1,'units':'m','coordinate_system':'right-handed-z-up',
                'provenance':{'data_class':data_class,'source_file':'hall-v1.svg',
                              'source_type':'svg','source_sha256':hashlib.sha256(source).hexdigest(),
                              'method':'restricted-vector-import'},
                'calibration':{'method':'declared-unit-scale','meters_per_unit':0.02,
                               'origin':[0,0],'source_y_down':True},
                'review':{'approved':True,'reviewer':'forged','reviewed_at':'2026-01-01T00:00:00Z'},
                'elements':[{'id':'hall-1','name':'Hall','zone_id':zone or self.zone,
                             'asset_id':'','type':'space','polygon':[[0,0],[5,0],[5,5],[0,5]],
                             'height_m':3,'base_m':0}]}

    def payload(self,plan=None,project=None):
        return {'project_id':project or self.project,'title':'Main hall v1',
                'source_reference':'Approved hall drawing / A-101',
                'source_version':'revision 1','source_units':'px','source_crs':'local hall origin',
                'plan':plan if plan is not None else self.plan()}

    def create(self,actor=ADMIN,**changes):
        payload=self.payload(); payload.update(changes)
        return self.cmd('spatial_plan.create',actor=actor,**payload)

    def test_create_strips_forged_approval_and_persists_canonical_hash(self):
        original=self.plan()
        row=self.create(plan=original,actor=FIELD)
        self.assertEqual(row['status'],'draft')
        self.assertEqual(row['provenance'],'manual')
        self.assertEqual(row['plan']['review'],{'approved':False,'reviewer':'','reviewed_at':None})
        self.assertTrue(original['review']['approved'])
        self.assertEqual(row['plan'],json.loads(row['plan_json']))
        self.assertEqual(row['plan_sha256'],hashlib.sha256(row['plan_json'].encode()).hexdigest())
        self.assertEqual(row['plan_json'],json.dumps(row['plan'],ensure_ascii=False,sort_keys=True,separators=(',',':')))
        reopened=DomainStore(self.path)
        self.assertEqual(reopened.state()['spatial_plans'][0],row)
        self.assertEqual(reopened.export(ADMIN)['records']['spatial_plans'][0],row)

    def test_review_requires_manager_and_stamps_authenticated_actor(self):
        row=self.create()
        self.assert_code('forbidden',lambda:self.cmd('spatial_plan.review',actor=FIELD,id=row['id'],evidence='Checked'))
        before=row['plan_sha256']
        reviewed=self.cmd('spatial_plan.review',actor=MANAGER,id=row['id'],evidence='Compared dimensions to drawing A-101')
        self.assertEqual(reviewed['status'],'reviewed')
        self.assertEqual(reviewed['reviewed_by'],'manager')
        self.assertEqual(reviewed['review_evidence'],'Compared dimensions to drawing A-101')
        self.assertEqual(reviewed['plan']['review']['reviewer'],'manager')
        self.assertEqual(reviewed['plan']['review']['reviewed_at'],reviewed['reviewed_at'])
        self.assertNotEqual(before,reviewed['plan_sha256'])
        self.assertEqual(reviewed['plan_sha256'],hashlib.sha256(reviewed['plan_json'].encode()).hexdigest())
        self.assertEqual(reviewed['plan']['elements'],row['plan']['elements'])
        self.assert_code('invalid_transition',lambda:self.cmd('spatial_plan.review',id=row['id'],evidence='again'))

    def test_review_revision_orders_approvals_with_identical_timestamps(self):
        first=self.create(); second=self.create()
        with patch('domain.now',return_value='2026-09-23T10:00:00+00:00'):
            first_review=self.cmd('spatial_plan.review',id=first['id'],evidence='First checked')
            second_review=self.cmd('spatial_plan.review',id=second['id'],evidence='Second checked')
        self.assertEqual(first_review['reviewed_at'],second_review['reviewed_at'])
        self.assertEqual(second_review['review_revision'],first_review['review_revision']+1)
        self.assertEqual(second_review['review_revision'],self.store.state()['revision'])

    def test_demo_or_unverifiable_source_cannot_be_reviewed(self):
        demo=self.create(plan=self.plan(data_class='demo'))
        self.assert_code('demo_spatial_plan',lambda:self.cmd('spatial_plan.review',id=demo['id'],evidence='Attempt'))
        missing=self.plan(); del missing['provenance']['source_sha256']
        draft=self.create(plan=missing)
        self.assert_code('spatial_source_required',lambda:self.cmd('spatial_plan.review',id=draft['id'],evidence='Attempt'))
        self.assertEqual(self.store.state()['spatial_plans'][1]['status'],'draft')
        for field in ('source_reference','source_version','source_units'):
            payload=self.payload(); payload[field]=''
            self.assert_code('validation',lambda:self.cmd('spatial_plan.create',**payload))
        with tempfile.TemporaryDirectory() as folder:
            demo_store=DomainStore(Path(folder)/'demo.sqlite',demo=True)
            demo_project=demo_store.command('shared.create',{'collection':'projects','name':'Demo site'},ADMIN)['result']['id']
            demo_zone=demo_store.command('shared.create',{'collection':'zones','name':'Demo hall','project_id':demo_project},ADMIN)['result']['id']
            demo_plan=self.plan(zone=demo_zone)
            payload=self.payload(plan=demo_plan,project=demo_project)
            draft=demo_store.command('spatial_plan.create',payload,ADMIN)['result']
            self.assert_code('demo_spatial_plan',lambda:demo_store.command('spatial_plan.review',{'id':draft['id'],'evidence':'Attempt'},ADMIN))

    def test_zone_and_project_scope_are_checked_on_create_and_review(self):
        second=self.cmd('shared.create',collection='projects',name='Other project')['id']
        other_zone=self.cmd('shared.create',collection='zones',project_id=second,name='Other hall')['id']
        before=self.store.state()['revision']
        self.assert_code('project_mismatch',lambda:self.create(plan=self.plan(zone=other_zone)))
        self.assert_code('not_found',lambda:self.create(plan=self.plan(zone='ZON-NOT-FOUND')))
        self.assertEqual(self.store.state()['revision'],before)
        other=self.create(project_id=second,plan=self.plan(zone=other_zone))
        scoped={'id':'manager-one','role':'manager','project_ids':[self.project]}
        self.assertEqual(self.store.state(scoped)['spatial_plans'],[])
        self.assert_code('project_scope_required',lambda:self.cmd('spatial_plan.review',actor=scoped,id=other['id'],evidence='No access'))
        self.assert_code('project_scope_required',lambda:self.create(actor=scoped,project_id=second,plan=self.plan(zone=other_zone)))
        self.assert_code('full_backup_scope_required',lambda:self.store.export(scoped))
        self.assert_code('forbidden',lambda:self.create(actor=VIEWER))

    def test_review_detects_database_tampering_and_does_not_advance_revision(self):
        row=self.create(); before=self.store.state()['revision']
        tampered=copy.deepcopy(row); tampered['plan']['elements'][0]['height_m']=6
        with self.store.connect() as db: self.store.put(db,'spatial_plans',tampered)
        self.assert_code('spatial_integrity_error',lambda:self.cmd('spatial_plan.review',id=row['id'],evidence='Inspection'))
        self.assertEqual(self.store.state()['revision'],before)
        self.assertEqual([a['command'] for a in self.store.state()['audit']].count('spatial_plan.review'),0)

    def test_review_rechecks_geometry_and_project_links(self):
        second=self.cmd('shared.create',collection='projects',name='Other project')['id']
        other_zone=self.cmd('shared.create',collection='zones',project_id=second,name='Other hall')['id']
        row=self.create()
        swapped=copy.deepcopy(row)
        swapped['plan']['elements'][0]['zone_id']=other_zone
        swapped['plan_json']=self.store.spatial_plan_json(swapped['plan'])
        swapped['plan_sha256']=hashlib.sha256(swapped['plan_json'].encode()).hexdigest()
        with self.store.connect() as db: self.store.put(db,'spatial_plans',swapped)
        before=self.store.state()['revision']
        self.assert_code('project_mismatch',lambda:self.cmd('spatial_plan.review',id=row['id'],evidence='Inspection'))
        self.assertEqual(self.store.state()['revision'],before)

    def test_size_limit_and_revision_conflict_are_atomic(self):
        oversized=self.plan(); oversized['padding']='x'*(MAX_SPATIAL_PLAN_BYTES+1)
        before=self.store.state()['revision']
        self.assert_code('spatial_plan_too_large',lambda:self.create(plan=oversized))
        self.assertEqual(self.store.state()['revision'],before)
        self.store.command('spatial_plan.create',self.payload(),ADMIN,before)
        self.assert_code('revision_conflict',lambda:self.store.command('spatial_plan.create',self.payload(),ADMIN,before))
        state=self.store.state()
        self.assertEqual(state['revision'],before+1)
        self.assertEqual(len(state['spatial_plans']),1)
        self.assertEqual([a['command'] for a in state['audit']].count('spatial_plan.create'),1)

    def test_enormous_numeric_inputs_fail_validation_without_server_error(self):
        huge=10**1000
        plans=[]
        height=self.plan(); height['elements'][0]['height_m']=huge; plans.append(height)
        coordinate=self.plan(); coordinate['elements'][0]['polygon'][0][0]=huge; plans.append(coordinate)
        scale=self.plan(); scale['calibration']['meters_per_unit']=huge; plans.append(scale)
        reference=self.plan(); reference['calibration']={'method':'known-distance',
            'meters_per_unit':1,'points':[[0,0],[huge,0]],'distance_m':1}; plans.append(reference)
        revision=self.store.state()['revision']
        for bad in plans:
            self.assert_code('invalid_spatial_plan',lambda:self.create(plan=bad))
        self.assertEqual(self.store.state()['revision'],revision)
        self.assertEqual(self.store.state()['spatial_plans'],[])

    def test_detailed_plan_is_accepted_but_quadratic_work_is_bounded(self):
        polygon=[[100*math.cos(2*math.pi*i/500),100*math.sin(2*math.pi*i/500)] for i in range(500)]
        base=self.plan(); template=base['elements'][0]
        base['elements']=[{**template,'id':f'zone-{i}','polygon':polygon} for i in range(4)]
        accepted=self.create(plan=base)
        self.assertEqual(len(accepted['plan']['elements']),4)
        before=self.store.state()['revision']
        too_complex=copy.deepcopy(base)
        too_complex['elements'].append({**template,'id':'zone-4','polygon':polygon})
        self.assert_code('invalid_spatial_plan',lambda:self.create(plan=too_complex))
        self.assertEqual(self.store.state()['revision'],before)
        self.assertEqual(len(self.store.state()['spatial_plans']),1)

        too_many_rectangles=self.plan(); template=too_many_rectangles['elements'][0]
        too_many_rectangles['elements']=[{**template,'id':f'stand-{i}'} for i in range(1251)]
        self.assert_code('invalid_spatial_plan',lambda:self.create(plan=too_many_rectangles))
        self.assertEqual(self.store.state()['revision'],before)


if __name__=='__main__': unittest.main()

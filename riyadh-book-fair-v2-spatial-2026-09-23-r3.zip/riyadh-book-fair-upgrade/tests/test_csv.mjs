import assert from 'node:assert/strict';
import {test} from 'node:test';
import {csv} from '../app/ui.js';

test('CSV neutralizes formula prefixes including whitespace while preserving Arabic quoting and numeric data',async()=>{
  let captured;
  const oldCreate=URL.createObjectURL,oldRevoke=URL.revokeObjectURL,oldDocument=globalThis.document;
  try{
    URL.createObjectURL=blob=>{captured=blob;return 'blob:csv-test'};
    URL.revokeObjectURL=()=>{};
    globalThis.document={createElement:()=>({click(){},remove(){}}),body:{append(){}}};
    csv('review.csv',['اسم'],[[' =1+1'],['\t=1+1'],['\n@cmd'],['نص، عربي "مقتبس"'],[42]]);
    const output=await captured.text();
    for(const value of [' =1+1','\t=1+1','\n@cmd'])assert.ok(output.includes('"\''+value+'"'));
    assert.ok(output.includes('"نص، عربي ""مقتبس"""'));
    assert.ok(output.includes('"42"'));
  }finally{URL.createObjectURL=oldCreate;URL.revokeObjectURL=oldRevoke;globalThis.document=oldDocument;}
});

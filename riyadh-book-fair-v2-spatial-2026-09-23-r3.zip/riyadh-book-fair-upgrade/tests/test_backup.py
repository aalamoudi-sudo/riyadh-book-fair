import importlib.util
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
spec = importlib.util.spec_from_file_location('database_backup', Path(__file__).resolve().parents[1] / 'scripts/database_backup.py')
backup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backup)


class BackupTests(unittest.TestCase):
    def test_snapshot_and_restore_preserve_records_and_clear_sessions(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'source.sqlite'
            store = DomainStore(source)
            actor = {'id': 'qa', 'role': 'admin'}
            store.command('shared.create', {'collection': 'projects', 'name': 'اختبار نسخة'}, actor)
            with store.connect() as db:
                db.execute('INSERT INTO sessions VALUES(?,?,?)', ('test-token', 'qa', 9999999999))
            snapshot = Path(folder) / 'backup.sqlite'
            backup.copy_database(source, snapshot)
            restored = Path(folder) / 'restored.sqlite'
            backup.copy_database(snapshot, restored, restore=True)
            self.assertEqual(backup.verify(restored)['revision'], 1)
            with sqlite3.connect(restored) as db:
                self.assertEqual(db.execute('SELECT count(*) FROM records').fetchone()[0], 1)
                self.assertEqual(db.execute('SELECT count(*) FROM audit').fetchone()[0], 1)
                self.assertEqual(db.execute('SELECT count(*) FROM sessions').fetchone()[0], 0)
            with self.assertRaises(ValueError):
                backup.copy_database(source, restored)

    def test_rejects_non_project_database(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / 'unrelated.sqlite'
            with sqlite3.connect(file) as db:
                db.execute('CREATE TABLE unrelated(id INT)')
            with self.assertRaises(ValueError):
                backup.verify(file)


if __name__ == '__main__':
    unittest.main()

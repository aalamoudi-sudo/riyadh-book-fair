import {esc, n, date, datetime, label, badge, icon, button, field, select, textarea, table, empty, modal, detail} from './ui.js';
import {recordEvidence} from './evidence.js';

const riyadhDay = () => new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const reportTitle = (ctx, report) => `تشغيل ${ctx.name('zones', report.zone_id)} · ${date(report.operational_date)}`;
const info = (title, value) => `<div class="detail-item"><span>${esc(title)}</span><strong>${esc(value || '—')}</strong></div>`;
const kpi = (title, value, description, ico='reports') => `<div class="kpi"><div class="kpi-top"><span>${esc(title)}</span><span class="kpi-icon">${icon(ico)}</span></div><div class="kpi-value">${n(value)}</div><div class="kpi-foot">${esc(description)}</div></div>`;
const canClose = ctx => ctx.can('daily.close') && ['admin','manager'].includes(ctx.state.user?.role);
const roleAttrs = allowed => allowed ? '' : 'disabled title="الإجراء يتطلب الصلاحية المناسبة"';
const closeButton = (ctx, report) => report.status === 'open' ? button('إقفال اليوم', 'operations-close', 'small', 'check', `data-id="${esc(report.id)}" ${roleAttrs(canClose(ctx))}`) : '';
const supportLabel = status => ({requested:'مطلوب',approved:'معتمد',dispatched:'أُرسل الدعم',received:'مستلم',rejected:'مرفوض',cancelled:'ملغى'}[status] || label(status));
const recordName = (ctx, report) => `${report.operational_date} ${ctx.name('zones',report.zone_id)} ${ctx.name('stakeholders',report.responsible_id)} ${report.id} ${report.notes || ''}`;
const getReport = (ctx, id) => {const report=ctx.records('daily_reports').find(x=>x.id===id);if(!report)throw new Error('المحضر غير موجود في المشروع الحالي.');return report;};

function currentWork(ctx, report) {
  const zone = report.zone_id;
  const tasks = ctx.records('tasks').filter(x => x.zone_id === zone && x.status !== 'completed');
  const incidents = ctx.records('incidents').filter(x => x.zone_id === zone && x.status !== 'closed');
  const support = ctx.records('support_requests').filter(x => (x.zone_id === zone || x.from_zone_id === zone || x.to_zone_id === zone) && !['received','cancelled','rejected'].includes(x.status));
  return {tasks, incidents, support_requests:support, counts:{tasks:tasks.length, incidents:incidents.length, support_requests:support.length, total:tasks.length+incidents.length+support.length, critical_incidents:incidents.filter(x=>x.priority==='critical'&&['open','assigned'].includes(x.status)).length}};
}

function workTable(work, withLinks=false) {
  const rows = [
    ...(work.tasks || []).map(x=>({...x,kind:'مهمة',action:'lc-task-detail'})),
    ...(work.incidents || []).map(x=>({...x,kind:'بلاغ',action:'incident-detail'})),
    ...(work.support_requests || []).map(x=>({...x,kind:'طلب دعم',action:'support-detail'})),
    ...(work.readiness_issues || []).map(x=>({...x,title:x.label,kind:'ملاحظة جاهزية',action:''})),
  ];
  return rows.length ? table(['النوع', 'السجل', 'الحالة', 'الأولوية'], rows.map(row => `<tr><td>${esc(row.kind)}</td><td>${withLinks && row.action ? button(row.title || row.id, row.action, 'ghost', '', `data-id="${esc(row.id)}"`) : esc(row.title || row.id)}<span class="cell-sub">${esc(row.kind==='ملاحظة جاهزية'?row.notes:row.id)}</span></td><td>${badge(row.status, row.kind==='طلب دعم'?supportLabel(row.status):row.status==='carryover'?'تحتاج متابعة':label(row.status))}</td><td>${row.priority ? badge(row.priority) : '—'}</td></tr>`)) : '<p class="field-help">لا توجد مهام أو بلاغات أو طلبات دعم مفتوحة لهذه المنطقة في السجلات الحالية.</p>';
}

function followupTable(rows=[]) {
  return table(['ملاحظة الافتتاح', 'نتيجة الإقفال', 'المعالجة / المتابعة'], rows.map(row => `<tr><td>${esc(row.label)}</td><td>${badge(row.status==='resolved'?'approved':'high',row.status==='resolved'?'تمت المعالجة':'رُحّلت للمتابعة')}</td><td>${esc(row.notes)}${row.evidence?`<span class="cell-sub">إثبات المعالجة: ${esc(row.evidence)}</span>`:''}</td></tr>`));
}

function readinessTable(rows=[]) {
  return table(['بند الجاهزية', 'نتيجة الافتتاح', 'الملاحظة'], rows.map(row => `<tr><td>${esc(row.label)}</td><td>${badge(row.status==='ready'?'approved':'high',row.status==='ready'?'جاهز':'ملاحظة تحتاج معالجة')}</td><td><span class="cell-sub" title="${esc(row.notes || '')}">${esc(row.notes || '—')}</span></td></tr>`));
}

export function renderOperations(ctx) {
  const reports = ctx.records('daily_reports'), today = riyadhDay();
  const list = reports.filter(report => {
    const matchesStatus = !ctx.status || ctx.status==='all' || report.status===ctx.status || (ctx.status==='issues'&&(report.readiness||[]).some(r=>r.status==='issue')) || (ctx.status==='handover'&&report.handover_responsible_id);
    return matchesStatus && (!ctx.query || recordName(ctx,report).toLowerCase().includes(String(ctx.query).toLowerCase()));
  }).slice().sort((a,b)=>b.operational_date.localeCompare(a.operational_date)||(b.opened_at||b.created_at).localeCompare(a.opened_at||a.created_at));
  const create = button('فتح محضر تشغيل', 'operations-open', 'primary', 'plus', roleAttrs(ctx.can('daily.open')));
  const issues = reports.filter(r=>r.status==='open').reduce((sum,r)=>sum+(r.readiness||[]).filter(c=>c.status==='issue').length,0);
  return `<div class="page-heading"><div><span class="eyebrow">الجاهزية · التشغيل · تسليم الوردية</span><h1>التشغيل اليومي</h1><p>محضر للمنطقة يثبت جاهزية الافتتاح، ثم يوثق ما أُنجز وما يحتاج تسليمًا لمسؤول آخر عند إقفال اليوم.</p></div><div class="actions">${create}</div></div><div class="kpi-grid">${kpi('محاضر اليوم',reports.filter(r=>r.operational_date===today).length,`تاريخ الرياض: ${date(today)}`,'clock')}${kpi('محاضر مفتوحة',reports.filter(r=>r.status==='open').length,'تحتاج ملخص إقفال واعتمادًا')}${kpi('ملاحظات الافتتاح',issues,'في قوائم المحاضر المفتوحة','alert')}${kpi('محاضر مع تسليم أعمال',reports.filter(r=>r.handover_responsible_id).length,'أعمال مفتوحة أُسند استكمالها','stakeholders')}</div><div class="callout">${icon('check')}<p>إقفال المحضر لا يغلق المهام أو البلاغات أو طلبات الدعم. تبقى الأعمال في سجلاتها، ويُثبت التسليم ومسؤوله وموعده. البلاغ الحرج المفتوح أو المسند يمنع إقفال اليوم.</p></div><div class="filterbar mt"><label class="search-field">${icon('search')}<input data-filter="query" type="search" value="${esc(ctx.query||'')}" placeholder="المنطقة، التاريخ، المسؤول أو رقم المحضر…" aria-label="البحث في محاضر التشغيل"></label><select data-filter="status" aria-label="تصفية محاضر التشغيل"><option value="">جميع المحاضر</option>${[{id:'open',name:'مفتوحة'},{id:'closed',name:'مقفلة'},{id:'issues',name:'بها ملاحظات افتتاح'},{id:'handover',name:'مع تسليم أعمال'}].map(s=>`<option value="${s.id}" ${ctx.status===s.id?'selected':''}>${s.name}</option>`).join('')}</select><span class="filter-count">${n(list.length)} محضر مطابق</span></div><section class="panel"><div class="panel-head"><div><h2>محاضر المناطق</h2><p>قائمة الجاهزية وإثبات الافتتاح محفوظان كما سجلهما المسؤول</p></div></div>${list.length ? table(['اليوم / المنطقة','المرحلة / المسؤول','قائمة الجاهزية','الحالة','تسليم الأعمال','الإجراءات'],list.map(r=>`<tr><td><span class="cell-title">${esc(date(r.operational_date))}</span><span class="cell-sub">${esc(ctx.name('zones',r.zone_id))}</span></td><td>${esc(ctx.name('phases',r.phase_id))}<span class="cell-sub">${esc(ctx.name('stakeholders',r.responsible_id))}</span></td><td>${n((r.readiness||[]).filter(c=>c.status==='ready').length)} جاهز / ${n((r.readiness||[]).length)} بند<span class="cell-sub">${n((r.readiness||[]).filter(c=>c.status==='issue').length)} ملاحظة</span></td><td>${badge(r.status,r.status==='closed'?'مقفل':'مفتوح')}</td><td>${r.handover_responsible_id?`${esc(ctx.name('stakeholders',r.handover_responsible_id))}<span class="cell-sub">${esc(datetime(r.handover_due_at))}</span>`:'—'}</td><td><div class="cell-actions">${button('المحضر','operations-detail','small','',`data-id="${esc(r.id)}"`)}${closeButton(ctx,r)}</div></td></tr>`)) : empty(reports.length?'لا محاضر مطابقة':'لا توجد محاضر تشغيل يومي',reports.length?'عدّل البحث أو التصفية.':'ابدأ باختيار المنطقة والتاريخ ومسؤول الافتتاح، ثم سجّل نتيجة فحص الجاهزية.',reports.length?'':create)}</section>`;
}

let checklistSequence = 0;
function checklistHTML(title='') {
  const id = `READY-${globalThis.crypto?.randomUUID?.() || `${Date.now()}-${++checklistSequence}`}`;
  return `<div class="panel panel-body mt" data-readiness-row data-id="${esc(id)}"><div class="form-grid">${field('readiness_label','بند الفحص','text',title,'required maxlength="200"')}${select('readiness_status','نتيجة الفحص',[{id:'',name:'اختر نتيجة الفحص'},{id:'ready',name:'جاهز'},{id:'issue',name:'ملاحظة تحتاج معالجة'}],'','required')}${textarea('readiness_notes','الملاحظة والإجراء المطلوب','','maxlength="2000"')}</div><div class="actions mt">${button('حذف البند','operations-remove-check','small','close','aria-label="حذف بند الجاهزية"')}</div></div>`;
}

function updateChecklist(form) {
  const rows = [...form.querySelectorAll('[data-readiness-row]')];
  let answered = 0, issues = 0;
  for (const row of rows) {
    const state = row.querySelector('[name=readiness_status]').value;
    row.querySelector('[name=readiness_notes]').required = state === 'issue';
    if (state) answered++;
    if (state === 'issue') issues++;
  }
  form.querySelector('[data-readiness-progress]').textContent = `سُجّلت نتيجة ${n(answered)} من ${n(rows.length)} بند · ${n(issues)} ملاحظة تحتاج وصفًا.`;
}

function addChecklist(form, title='') {
  const container = form.querySelector('[data-readiness-list]');
  if (container.querySelectorAll('[data-readiness-row]').length >= 20) throw new Error('الحد الأعلى 20 بندًا في قائمة الجاهزية.');
  const template = document.createElement('template'); template.innerHTML = checklistHTML(title);
  container.append(template.content); updateChecklist(form);
}

function openDay(ctx) {
  if (!ctx.can('daily.open')) throw new Error('لا تملك صلاحية فتح محضر تشغيل.');
  if (!ctx.projectId || !ctx.records('phases').length || !ctx.records('zones').length || !ctx.records('stakeholders').length) return detail('تهيئة محضر التشغيل', '<p>أضف مشروعًا ومرحلة ومنطقة ومسؤولًا قبل تسجيل محضر الافتتاح.</p>');
  const operationsPhase = ctx.records('phases').find(x=>x.kind==='operations');
  const dialog = modal('فتح محضر تشغيل للمنطقة', `<div class="form-grid">${field('operational_date','تاريخ يوم التشغيل — الرياض','date',riyadhDay(),'required')}${ctx.commonFields({project_id:ctx.projectId,phase_id:operationsPhase?.id||''})}${textarea('evidence','مرجع إثبات الافتتاح / محضر الاستلام','','required maxlength="4000"')}${textarea('notes','ملاحظات افتتاح اليوم','','maxlength="4000"')}</div><h3 class="form-section">فحص الجاهزية — من 1 إلى 20 بندًا</h3><p class="field-help">سمّ البنود وفق المنطقة، وسجّل النتيجة بعد الفحص. لكل ملاحظة وصف وإجراء مطلوب. يمكن رفع صور ومحاضر من تفاصيل السجل بعد حفظه.</p><div data-readiness-list></div><div class="actions mt">${button('إضافة بند فحص','operations-add-check','secondary','plus')}</div><p class="field-help" data-readiness-progress aria-live="polite"></p>`, async(data,form)=>{
    const readiness = [...form.querySelectorAll('[data-readiness-row]')].map(row=>({id:row.dataset.id,label:row.querySelector('[name=readiness_label]').value.trim(),status:row.querySelector('[name=readiness_status]').value,notes:row.querySelector('[name=readiness_notes]').value.trim()}));
    if (!readiness.length || readiness.length > 20) throw new Error('قائمة الجاهزية تحتاج من 1 إلى 20 بندًا.');
    if (readiness.some(r=>r.status==='issue'&&!r.notes)) throw new Error('أضف ملاحظة توضح كل بند يحتاج معالجة.');
    const {readiness_label,readiness_status,readiness_notes,...header}=data;
    await ctx.command('daily.open',{...header,readiness});
  },'حفظ محضر الافتتاح',true);
  const form=dialog.querySelector('form');
  for (const key of ['phase_id','zone_id','responsible_id']) form.elements[key].required=true;
  for (const title of ['جاهزية مخارج ومسارات الحركة','جاهزية الفريق واستلام المواقع','جاهزية المعدات والاتصالات','نظافة المنطقة وخدمة الزائر']) addChecklist(form,title);
  form.addEventListener('change',()=>updateChecklist(form));
}

function dailyDetail(ctx,id) {
  const report=getReport(ctx,id),closed=report.status==='closed';
  const work=closed?report.closure_snapshot:currentWork(ctx,report);
  detail(reportTitle(ctx,report), `<div class="actions">${badge(report.status,closed?'محضر مقفل':'محضر مفتوح')}${badge(report.provenance)}${closeButton(ctx,report)}</div><div class="details-grid mt">${info('المشروع',ctx.name('projects',report.project_id))}${info('المنطقة',ctx.name('zones',report.zone_id))}${info('المرحلة',ctx.name('phases',report.phase_id))}${info('مسؤول الافتتاح',ctx.name('stakeholders',report.responsible_id))}${info('تاريخ التشغيل',date(report.operational_date))}${info('وقت تسجيل الافتتاح',datetime(report.opened_at||report.created_at))}</div><h3 class="form-section">نتيجة جاهزية الافتتاح</h3>${readinessTable(report.readiness)}<h3 class="form-section">إثبات الافتتاح</h3><p>${esc(report.opening_evidence||report.evidence)}</p>${report.notes?`<p class="mt">${esc(report.notes)}</p>`:''}${closed?`<h3 class="form-section">ملخص إقفال اليوم</h3><p>${esc(report.summary)}</p><div class="details-grid mt">${info('وقت الإقفال',datetime(report.closed_at))}${info('إثبات الإقفال',report.closing_evidence)}</div>${report.readiness_followup?.length?`<h3 class="form-section">متابعة ملاحظات الافتتاح</h3>${followupTable(report.readiness_followup)}`:''}`:''}<h3 class="form-section">${closed?'الأعمال المفتوحة وقت إقفال المحضر':'الأعمال المفتوحة حاليًا في المنطقة'}</h3>${workTable(work||{},true)}${closed&&work?.captured_at?`<p class="field-help">لقطة محفوظة في ${esc(datetime(work.captured_at))}؛ الحالة الحالية للسجل قد تكون تغيرت بعد التسليم.</p>`:''}${report.handover_responsible_id?`<h3 class="form-section">تسليم استكمال الأعمال</h3><div class="details-grid">${info('مسؤول التسليم',ctx.name('stakeholders',report.handover_responsible_id))}${info('الموعد',datetime(report.handover_due_at))}</div><p>${esc(report.handover_notes)}</p>`:''}${recordEvidence(ctx,'daily_reports',report.id)}`);
}

function closeDay(ctx,id) {
  if (!canClose(ctx)) throw new Error('إقفال اليوم يتطلب مدير المشروع أو مدير النظام.');
  const report=getReport(ctx,id);
  if (report.status!=='open') throw new Error('المحضر مقفل بالفعل.');
  const work=currentWork(ctx,report);
  if (work.counts.critical_incidents) return detail('تعذر إقفال اليوم لوجود بلاغ حرج', `<div class="callout warning">${icon('alert')}<p>يوجد ${n(work.counts.critical_incidents)} بلاغ حرج مفتوح أو مسند في المنطقة. عالج الحالة وسجّل نتيجتها قبل إقفال المحضر.</p></div>${workTable(work,true)}`);
  const openingIssues=(report.readiness||[]).filter(row=>row.status==='issue');
  const followup=openingIssues.map(row=>`<div class="panel panel-body mt" data-followup-row data-id="${esc(row.id)}"><h4>${esc(row.label)}</h4><p class="field-help">ملاحظة الافتتاح: ${esc(row.notes)}</p><div class="form-grid">${select('followup_status','نتيجة متابعة الملاحظة',[{id:'',name:'اختر نتيجة المتابعة'},{id:'resolved',name:'تمت المعالجة'},{id:'carryover',name:'تُرحّل للمتابعة'}],'','required')}${textarea('followup_notes','تفاصيل المعالجة / المتبقي','','required maxlength="2000"')}</div></div>`).join('');
  const dialog=modal('إقفال محضر التشغيل', `<p>${esc(reportTitle(ctx,report))}</p><h3 class="form-section">الأعمال المفتوحة قبل الإقفال</h3>${workTable(work)}${openingIssues.length?`<h3 class="form-section">متابعة ملاحظات الافتتاح</h3><p class="field-help">يجب توثيق معالجة أو ترحيل كل ملاحظة. يُحفظ مرجع إثبات الإقفال مع البنود المعالجة، وتدخل الملاحظات المرحّلة في تسليم الأعمال.</p>${followup}`:''}<div class="form-grid mt">${textarea('summary','ملخص ما أُنجز وحالة المنطقة','','required maxlength="4000"')}${textarea('evidence','مرجع إثبات الإقفال / محضر التسليم','','required maxlength="4000"')}</div><div data-handover-section><h3 class="form-section" data-handover-title>تسليم الأعمال المتبقية</h3><div class="form-grid">${select('handover_responsible_id','مسؤول استكمال الأعمال',[{id:'',name:'اختر المسؤول'},...ctx.records('stakeholders')],'')}${field('handover_due_at','موعد المتابعة — توقيت الرياض','datetime-local','')}${textarea('handover_notes','تعليمات التسليم وما يحتاج متابعة','','maxlength="4000"')}</div></div><p class="field-help" data-closure-help></p>`, async(data,form)=>{
    const readiness_followup=[...form.querySelectorAll('[data-followup-row]')].map(row=>({id:row.dataset.id,status:row.querySelector('[name=followup_status]').value,notes:row.querySelector('[name=followup_notes]').value.trim()}));
    const {followup_status,followup_notes,...values}=data;
    const payload={id,...values,readiness_followup};
    if(data.handover_due_at){const parsed=new Date(`${data.handover_due_at}+03:00`);if(!Number.isFinite(parsed.getTime()))throw new Error('موعد المتابعة غير صالح.');payload.handover_due_at=parsed.toISOString();}
    await ctx.command('daily.close',payload);
  },'اعتماد إقفال اليوم',true);
  const form=dialog.querySelector('form');
  const updateHandover=()=>{
    const carryover=[...form.querySelectorAll('[name=followup_status]')].filter(el=>el.value==='carryover').length;
    const total=work.counts.total+carryover,needsHandover=total>0;
    const section=form.querySelector('[data-handover-section]');section.hidden=!needsHandover;
    for(const el of section.querySelectorAll('input,select,textarea')){el.required=needsHandover;el.disabled=!needsHandover;}
    form.querySelector('[data-handover-title]').textContent=`تسليم ${n(total)} من الأعمال والملاحظات المتبقية`;
    form.querySelector('[type=submit]').textContent=needsHandover?'اعتماد الإقفال وتسليم المتابعة':'اعتماد إقفال اليوم';
    form.querySelector('[data-closure-help]').textContent=(needsHandover?'تبقى الأعمال والملاحظات المرحّلة ظاهرة في المحضر مع مسؤول المتابعة وموعدها ولقطة الحالات.':'لا توجد أعمال مفتوحة أو ملاحظات مرحّلة تحتاج تسليمًا حسب السجلات الحالية.')+' يتحقق الخادم مجددًا عند الاعتماد.';
  };
  form.addEventListener('change',updateHandover);updateHandover();
}

export function operationsActions(ctx) {
  return {
    'operations-open':async()=>openDay(ctx),
    'operations-detail':async el=>dailyDetail(ctx,el.dataset.id),
    'operations-close':async el=>closeDay(ctx,el.dataset.id),
    'operations-add-check':async el=>addChecklist(el.closest('form')),
    'operations-remove-check':async el=>{const form=el.closest('form');if(form.querySelectorAll('[data-readiness-row]').length===1)throw new Error('احتفظ ببند فحص واحد على الأقل.');el.closest('[data-readiness-row]').remove();updateChecklist(form);},
  };
}

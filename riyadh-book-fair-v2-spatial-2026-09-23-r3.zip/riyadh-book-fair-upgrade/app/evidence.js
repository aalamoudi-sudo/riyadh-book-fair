import {esc, n, date, label, badge, icon, button, field, select, textarea, table, empty, modal, detail} from './ui.js';

const MAX_BYTES = 5 * 1024 * 1024;
const uploadRoles = ['admin', 'manager', 'warehouse', 'field', 'security'];
const orderRoles = ['admin', 'manager', 'warehouse'];
const types = {'image/png': 'PNG', 'image/jpeg': 'JPEG', 'image/webp': 'WebP', 'application/pdf': 'PDF'};
const collections = {
  projects: 'المشروع', phases: 'المرحلة', zones: 'المنطقة', stakeholders: 'الجهة / المسؤول',
  items: 'الصنف', stock_moves: 'حركة المستودع', stock_counts: 'محضر الجرد', orders: 'طلب الزائر',
  tasks: 'المهمة', permits: 'التصريح', access_logs: 'دخول / خروج', incidents: 'البلاغ',
  decisions: 'القرار', procurements: 'طلب الشراء', spatial_jobs: 'المخطط',
  observations: 'الرصد الميداني', support_requests: 'طلب الدعم', daily_reports: 'محضر تشغيل يومي',
};
const recordActions = {items: 'inventory-detail', stock_counts: 'inventory-count-detail', orders: 'order-detail', tasks: 'lc-task-detail', permits: 'permit-detail', incidents: 'incident-detail', procurements: 'procurement-detail', zones: 'zone-overview', support_requests: 'support-detail', daily_reports: 'operations-detail'};
const records = (ctx, collection) => collection === 'projects' ? ctx.records(collection).filter(x => x.id === ctx.projectId) : ctx.records(collection);
const fileSize = bytes => bytes >= 1024 * 1024 ? `${n(Number((bytes / 1024 / 1024).toFixed(2)))} MB` : `${n(Number((bytes / 1024).toFixed(1)))} KB`;
const canDownload = (ctx, meta) => uploadRoles.includes(ctx.state.user?.role) && (meta.record_collection !== 'orders' || orderRoles.includes(ctx.state.user?.role));
const nameOf = (row, collection) => row.label || row.name || row.title || (collection === 'orders' ? `طلب ${row.id}` : collection === 'stock_moves' ? `${label(row.action)} · ${row.id}` : collection === 'decisions' ? row.decision : '') || row.id;
const getAttachment = (ctx, id) => {const meta = ctx.records('attachments').find(x => x.id === id); if (!meta) throw new Error('المرفق غير موجود في المشروع الحالي.'); return meta;};
const info = (title, value) => `<div class="detail-item"><span>${esc(title)}</span><strong>${esc(value || '—')}</strong></div>`;
const kpi = (title, value, subtitle) => `<div class="kpi"><div class="kpi-top"><span>${esc(title)}</span><span class="kpi-icon">${icon('reports')}</span></div><div class="kpi-value">${esc(value)}</div><div class="kpi-foot">${esc(subtitle)}</div></div>`;

function downloadLink(ctx, meta) {
  return canDownload(ctx, meta) ? `<a class="btn small" href="/api/attachments/${encodeURIComponent(meta.id)}" download="${esc(meta.filename)}" aria-label="تنزيل ${esc(meta.filename)}">${icon('download')}تنزيل الملف</a>` : '<span class="badge">بيانات المرفق فقط</span>';
}

function recordLink(ctx, meta) {
  if (!meta.record_collection) return '<span class="muted">إثبات عام للمشروع</span>';
  const row = records(ctx, meta.record_collection).find(x => x.id === meta.record_id);
  const title = row ? nameOf(row, meta.record_collection) : meta.record_id;
  return `<button type="button" class="text-btn" data-action="evidence-record" data-id="${esc(meta.id)}">${esc(collections[meta.record_collection])}<span class="cell-sub">${esc(title)}</span></button>`;
}

// For saved record detail panels. Opening upload replaces the shared modal, so
// do not insert this action in an unsaved create/edit form.
export function recordEvidence(ctx, collection, id) {
  const files = ctx.records('attachments').filter(meta => meta.record_collection === collection && meta.record_id === id);
  const allowed = ctx.can('attachment.create') && (collection !== 'orders' || orderRoles.includes(ctx.state.user?.role));
  return `<h3 class="form-section">ملفات الإثبات المحفوظة</h3>${files.length ? `<ul class="record-list">${files.map(meta => `<li class="record-row"><div class="record-main"><h3>${esc(meta.label)}</h3><p>${esc(meta.filename)} · ${fileSize(meta.size_bytes)}</p></div><div class="record-actions">${button('البيانات', 'evidence-detail', 'small', '', `data-id="${esc(meta.id)}"`)}${downloadLink(ctx, meta)}</div></li>`).join('')}</ul>` : '<p class="field-help">لا ملفات مرفوعة مرتبطة بهذا السجل. مرجع الإثبات النصي وحده لا يتضمن ملفًا.</p>'}<div class="actions mt">${button('إرفاق ملف إثبات', 'evidence-upload', 'secondary', 'plus', `data-collection="${esc(collection)}" data-record="${esc(id)}" ${allowed ? '' : 'disabled'}`)}</div>`;
}

export function renderEvidence(ctx) {
  const files = ctx.records('attachments');
  const rows = files.filter(meta => {
    const search = [meta.label, meta.filename, meta.id, meta.record_id, ctx.name('zones', meta.zone_id), ctx.name('stakeholders', meta.responsible_id)].join(' ').toLowerCase();
    return (!ctx.query || search.includes(String(ctx.query).toLowerCase())) && (!ctx.status || ctx.status === 'all' || (ctx.status === 'pdf' && meta.content_type === 'application/pdf') || (ctx.status === 'images' && meta.content_type.startsWith('image/')) || (ctx.status === 'linked' && meta.record_id) || (ctx.status === 'general' && !meta.record_id));
  }).slice().reverse();
  const create = button('رفع ملف إثبات', 'evidence-upload', 'primary', 'plus', ctx.can('attachment.create') ? '' : 'disabled title="لا تملك صلاحية رفع المرفقات"');
  const totalBytes = files.reduce((sum, f) => sum + f.size_bytes, 0);
  return `<div class="page-heading"><div><span class="eyebrow">المحاضر والصور والمستندات</span><h1>ملفات الإثبات</h1><p>مرفقات فعلية محفوظة في قاعدة بيانات الخادم، مرتبطة بالمشروع والسجل والمسؤول، مع بصمة للتحقق من سلامة كل ملف.</p></div><div class="actions">${create}</div></div><div class="kpi-grid">${kpi('الملفات المحفوظة', n(files.length), 'المحتوى محفوظ على الخادم')}${kpi('الحجم الإجمالي', fileSize(totalBytes), 'حد الملف الواحد 5 MB')}${kpi('مرتبطة بسجل', n(files.filter(x => x.record_id).length), 'طلب أو مهمة أو حركة أو محضر')}${kpi('مستندات PDF', n(files.filter(x => x.content_type === 'application/pdf').length), 'تُنزّل كملفات مستقلة')}</div><div class="callout">${icon('check')}<p>هذه ملفات مرفوعة فعلًا. كتابة اسم محضر أو رابط في حقل «الإثبات» داخل السجلات تبقى مرجعًا نصيًا، ولا ترفع ملفًا تلقائيًا. صلاحية الاطلاع تتيح بيانات المرفق؛ تنزيل المحتوى يحتاج صلاحية تشغيل.</p></div><div class="filterbar mt"><label class="search-field">${icon('search')}<input type="search" data-filter="query" value="${esc(ctx.query || '')}" placeholder="عنوان الإثبات، الملف، السجل أو المسؤول…" aria-label="البحث في المرفقات"></label><select data-filter="status" aria-label="تصفية المرفقات"><option value="">جميع المرفقات</option>${[{id:'images',name:'صور'},{id:'pdf',name:'PDF'},{id:'linked',name:'مرتبطة بسجل'},{id:'general',name:'إثباتات عامة'}].map(o=>`<option value="${o.id}" ${ctx.status===o.id?'selected':''}>${o.name}</option>`).join('')}</select><span class="filter-count">${n(rows.length)} ملف مطابق</span></div><section class="panel"><div class="panel-head"><div><h2>سجل الملفات</h2><p>الملفات ليست منشورة في مجلد عام؛ يتحقق الخادم من الحساب والمشروع عند التنزيل</p></div></div>${rows.length ? table(['عنوان الإثبات / الملف', 'السجل المرتبط', 'المسؤول / المنطقة', 'النوع والحجم', 'التاريخ', 'الإجراءات'], rows.map(meta => `<tr><td><span class="cell-title">${esc(meta.label)}</span><span class="cell-sub">${esc(meta.filename)}</span><span class="mono" title="SHA-256: ${esc(meta.sha256)}">${esc(meta.sha256.slice(0, 12))}…</span></td><td>${recordLink(ctx, meta)}</td><td>${esc(ctx.name('stakeholders', meta.responsible_id))}<span class="cell-sub">${esc(ctx.name('zones', meta.zone_id))}</span></td><td>${esc(types[meta.content_type] || meta.content_type)}<span class="cell-sub">${fileSize(meta.size_bytes)}</span></td><td>${esc(date(meta.created_at))}</td><td><div class="cell-actions">${button('بيانات الملف', 'evidence-detail', 'small', '', `data-id="${esc(meta.id)}"`)}${downloadLink(ctx, meta)}</div></td></tr>`)) : empty(files.length ? 'لا ملفات مطابقة' : 'لا توجد ملفات إثبات مرفوعة', files.length ? 'عدّل البحث أو التصفية.' : 'ارفع صورة أو مستند PDF واربطه بالسجل المناسب.', files.length ? '' : create)}</section>`;
}

function upload(ctx, element) {
  if (!ctx.can('attachment.create')) throw new Error('لا تملك صلاحية رفع ملف إثبات.');
  if (!ctx.projectId) throw new Error('حدد مشروعًا قبل رفع الملف.');
  const supported = Object.entries(collections).filter(([key]) => (key !== 'orders' || orderRoles.includes(ctx.state.user?.role)) && records(ctx, key).length);
  const initialCollection = supported.some(([key]) => key === element?.dataset.collection) ? element.dataset.collection : '';
  const dialog = modal('رفع ملف إثبات محفوظ', `<div class="form-grid">${field('label', 'عنوان الإثبات', 'text', '', 'required maxlength="200"')}<label class="field"><span>الملف — صورة أو PDF حتى 5 MB</span><input type="file" name="file" required accept="image/png,image/jpeg,image/webp,application/pdf,.png,.jpg,.jpeg,.webp,.pdf"></label>${ctx.commonFields({project_id: ctx.projectId})}${select('record_collection', 'نوع السجل المرتبط', [{id:'',name:'إثبات عام للمشروع'}, ...supported.map(([id,name])=>({id,name}))], initialCollection)}${select('record_id', 'السجل المرتبط', [{id:'',name:'اختر نوع السجل أولًا'}])}${textarea('notes', 'وصف الملف وملاحظات المراجعة', '', 'maxlength="4000"')}</div><p class="field-help" data-file-status aria-live="polite">اختر ملفًا من جهازك. يُرسل فقط عند الضغط على «رفع وحفظ الملف».</p><p class="field-help">الملفات المقبولة PNG وJPEG وWebP وPDF فقط. مرفقات طلبات الزوار متاحة للإدارة والمستودع. احتفظ بالمراجع الشخصية اللازمة للعمل فقط.</p>`, async (data, form) => {
    const file = form.elements.file.files[0];
    if (!file) throw new Error('اختر ملف الإثبات.');
    if (!file.size || file.size > MAX_BYTES) throw new Error('حجم الملف يجب أن يكون أكبر من صفر ولا يتجاوز 5 MB.');
    const extension = file.name.split('.').at(-1).toLowerCase();
    const contentType = file.type || ({png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',pdf:'application/pdf'}[extension]);
    if (!types[contentType]) throw new Error('اختر PNG أو JPEG أو WebP أو PDF.');
    const status = dialog.querySelector('[data-file-status]'); status.textContent = 'جارٍ قراءة الملف المختار…';
    const encoded = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {const content = String(reader.result); const comma = content.indexOf(','); if (comma < 0) reject(new Error('تعذرت قراءة الملف.')); else resolve(content.slice(comma + 1));};
      reader.onerror = () => reject(new Error('تعذرت قراءة الملف من الجهاز.'));
      reader.onabort = () => reject(new Error('أُلغيت قراءة الملف.'));
      reader.readAsDataURL(file);
    });
    status.textContent = 'جارٍ رفع الملف وحفظه مع بيانات الإثبات…';
    const {file: ignored, ...metadata} = data;
    await ctx.command('attachment.create', {...metadata, filename: file.name, content_type: contentType, data_base64: encoded});
  }, 'رفع وحفظ الملف', true);
  const form = dialog.querySelector('form');
  const updateRecords = () => {
    const collection = form.elements.record_collection.value;
    const options = collection ? records(ctx, collection).map(row => ({id: row.id, name: `${nameOf(row, collection)} · ${row.id}`})) : [];
    form.elements.record_id.replaceChildren(...[{id:'',name:collection?'اختر السجل':'إثبات عام للمشروع'}, ...options].map(o => {const option = document.createElement('option'); option.value=o.id; option.textContent=o.name; return option;}));
    form.elements.record_id.required = Boolean(collection);
    form.elements.record_id.disabled = !collection;
  };
  form.elements.record_collection.addEventListener('change', updateRecords);
  form.elements.record_id.addEventListener('change', () => {
    const row = records(ctx, form.elements.record_collection.value).find(x => x.id === form.elements.record_id.value);
    if (row) for (const key of ['phase_id','zone_id','responsible_id']) if (!form.elements[key]?.value && row[key] && [...form.elements[key].options].some(o => o.value === row[key])) form.elements[key].value = row[key];
  });
  form.elements.file.addEventListener('change', () => {
    const file = form.elements.file.files[0];
    dialog.querySelector('[data-file-status]').textContent = file ? `${file.name} · ${fileSize(file.size)}${file.size > MAX_BYTES ? ' — يتجاوز الحد المسموح' : ' — لم يُرفع بعد'}` : 'لم يُختر ملف.';
    if (file && !form.elements.label.value) form.elements.label.value = file.name.slice(0, 200);
  });
  updateRecords();
  if (initialCollection && element?.dataset.record) {form.elements.record_id.value = element.dataset.record; form.elements.record_id.dispatchEvent(new Event('change'));}
}

function evidenceDetail(ctx, id) {
  const meta = getAttachment(ctx, id);
  detail(meta.label, `<div class="actions">${badge(meta.provenance)}${downloadLink(ctx, meta)}</div><div class="details-grid mt">${info('اسم الملف', meta.filename)}${info('نوع الملف', types[meta.content_type])}${info('الحجم الفعلي', fileSize(meta.size_bytes))}${info('وقت الرفع', date(meta.created_at))}${info('المشروع', ctx.name('projects', meta.project_id))}${info('المسؤول', ctx.name('stakeholders', meta.responsible_id))}${info('المرحلة', ctx.name('phases', meta.phase_id))}${info('المنطقة', ctx.name('zones', meta.zone_id))}</div><h3 class="form-section">السجل المرتبط</h3>${recordLink(ctx, meta)}<h3 class="form-section">بصمة SHA-256</h3><p class="mono" style="overflow-wrap:anywhere">${esc(meta.sha256)}</p><p class="field-help">يتحقق الخادم من بصمة المحتوى وحجمه قبل التنزيل. الملف محفوظ داخل قاعدة بيانات المشروع.</p>${meta.notes ? `<h3 class="form-section">ملاحظات</h3><p>${esc(meta.notes)}</p>` : ''}`);
}

function linkedRecord(ctx, id) {
  const meta = getAttachment(ctx, id), collection = meta.record_collection;
  const row = records(ctx, collection).find(x => x.id === meta.record_id);
  if (!row) throw new Error('السجل المرتبط غير متاح في المشروع الحالي.');
  const action = recordActions[collection];
  detail(`${collections[collection]} · ${nameOf(row, collection)}`, `<div class="details-grid">${info('المعرف', row.id)}${info('الحالة', label(row.status))}${info('مصدر البيانات', label(row.provenance))}${info('تاريخ السجل', date(row.created_at))}${info('المنطقة', ctx.name('zones', row.zone_id))}${info('المسؤول', ctx.name('stakeholders', row.responsible_id))}</div>${row.evidence ? `<p>مرجع الإثبات النصي: ${esc(row.evidence)}</p>` : ''}${row.notes ? `<p>${esc(row.notes)}</p>` : ''}${action ? `<div class="actions mt">${button('فتح تفاصيل السجل وإجراءاته', action, 'secondary', 'arrow', `data-id="${esc(row.id)}"`)}</div>` : ''}<h3 class="form-section">ملف الإثبات المرتبط</h3><p>${esc(meta.label)} · ${esc(meta.filename)}</p><div class="actions mt">${downloadLink(ctx, meta)}</div>`);
}

export function evidenceActions(ctx) {
  return {
    'evidence-upload': async el => upload(ctx, el),
    'evidence-detail': async el => evidenceDetail(ctx, el.dataset.id),
    'evidence-record': async el => linkedRecord(ctx, el.dataset.id),
  };
}

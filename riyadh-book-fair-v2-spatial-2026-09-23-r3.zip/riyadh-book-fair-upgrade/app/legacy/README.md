# Legacy reference import contract

`pages.json` is generated from the verified source by `python3 scripts/extract_legacy.py`.

```ts
type LegacyReferences = {
  schemaVersion: 1;
  classification: 'reference/simulation';
  source: { url: string; repository: string; commit: string; sha256: string };
  security: {
    sandbox: ''; referrerPolicy: 'no-referrer';
    scripts: false; network: false; personalContacts: 'redacted'; storage: false;
  };
  pages: Array<{
    id: string; // legacy-01 ... legacy-22: stable, unique
    num: string; // 01 ... 22, kept as a string
    title: string; // duplicated titles are intentional; use id as the key
    classification: 'reference/simulation';
    html: string; // inert HTML, NOT trusted operational data
  }>;
};
```

Render `page.html` only in an iframe, for example:

```js
const frame = document.createElement('iframe');
frame.setAttribute('sandbox', ''); // no allow-scripts/same-origin/forms/popups
frame.referrerPolicy = 'no-referrer';
frame.title = `مرجع تصميم: ${page.title}`;
frame.srcdoc = page.html;
```

Never put this HTML in the parent DOM with `innerHTML`; never enable scripts, forms, popups, navigation or same-origin permissions. There is deliberately no `postMessage` bridge and no data import from the legacy application. The HTML includes restrictive CSP and a visible Arabic reference/simulation notice. External Google maps and fonts are disabled. A nested, sanitized map `srcdoc` survives in page 01 under its own empty sandbox. Script-created content is intentionally not executed and may be blank. Native controls are disabled. The original login gate is not part of this artifact; page 19 is only its original static design reference without an active form.

Keep the original baseline out of the app's static server. Do not restore the old login mechanism or expose its embedded contact data. Re-run extraction only against the reviewed SHA-256; source changes fail closed until reviewed.

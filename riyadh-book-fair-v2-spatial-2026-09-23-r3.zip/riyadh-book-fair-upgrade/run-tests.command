#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
source scripts/select-runtime.sh
"$rbf_python" -m unittest discover -s tests -v
rbf_node="${RBF_NODE:-}"
if [[ -z "$rbf_node" ]]; then
  for rbf_candidate in "${HOME}/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do
    if [[ -x "$rbf_candidate" ]] && "$rbf_candidate" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)' >/dev/null 2>&1; then
      rbf_node="$rbf_candidate"
      break
    fi
  done
fi
if [[ -z "$rbf_node" || ! -x "$rbf_node" ]]; then
  printf '%s\n' 'اكتملت اختبارات Python؛ اختبار JavaScript لم يعمل. حدد RBF_NODE بمسار Node 22+ لإتمام التحقق.' >&2
  exit 2
fi
"$rbf_node" --test tests/test_csv.mjs
for rbf_file in app/*.js; do
  "$rbf_node" --check "$rbf_file"
done
printf '%s\n' 'اكتمل تحقق Python وCSV وصياغة JavaScript بنجاح.'

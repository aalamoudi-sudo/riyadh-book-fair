// A read-only route guide for presenting the prototype. It never creates records.
const steps = [
  {route: 'dashboard', title: 'غرفة القيادة', story: 'ابدأ بالمشهد العام: ما الذي يحدث الآن، وأين يلزم قرار؟', proof: 'المؤشرات تُشتق من سجلات النموذج، وقراءات الحشود التجريبية مميزة عن الربط الحي.'},
  {route: 'lifecycle', title: 'دورة المشروع', story: 'اعرض انتقال المنطقة من البناء إلى التشغيل، ثم الفك والإقفال بمحاضر ومسؤوليات.', proof: 'الانتقال والإقفال يخضعان لشروط؛ المسار المفتوح يظهر سبب تعطله.'},
  {route: 'spatial', title: 'التوأم المكاني', story: 'اربط المنطقة بالمخطط، ثم اعرض مسار تحويل المخطط ثنائي الأبعاد إلى نموذج ثلاثي عبر Blender.', proof: 'المجسم المعروض عينة؛ يحتاج مخطط المشروع الفعلي إلى مصدر ومقياس ومراجعة.'},
  {route: 'permits', title: 'التصاريح والدخول', story: 'مرّ على طلب تصريح واعتماده ثم تسجيل الدخول والخروج من البوابة.', proof: 'جهات الاعتماد ممثلة بأدوار وحسابات داخل النموذج؛ لا يوجد ربط مباشر بجهة رسمية.'},
  {route: 'books', title: 'رحلة كتب الناشر', story: 'تتبّع الشحنة من البيان إلى الاستلام والجرد والتوزيع والمرتجع.', proof: 'يعرض السجل الكمية الفعلية والفروق وقرار تسويتها.'},
  {route: 'orders', title: 'طلب الزائر والشحن', story: 'اعرض طلبًا متعدد الكتب من الحجز حتى التجميع والشحن والتسليم.', proof: 'الناقل ورقم التتبع في النموذج يدخلان يدويًا؛ الدفع والناقل غير موصولين.'},
  {route: 'operations', title: 'التشغيل والتسليم', story: 'افتح الوردية، عالج الملاحظات، ثم راجع محضر التسليم بين الفرق.', proof: 'السجلات تبيّن المسؤول والوقت والملاحظات التي تمنع التسليم.'},
  {route: 'incidents', title: 'الأمن والحشود والقرارات', story: 'اختم ببلاغ يبدأ من رصد المنطقة، ثم قرار وتصعيد وإجراء وأثر.', proof: 'الرصد في النموذج يدوي أو تجريبي، ولا يوصف بأنه حساس حي.'},
];

const app = document.getElementById('app');
const guide = document.createElement('dialog');
guide.id = 'presentation-guide';
guide.setAttribute('aria-labelledby', 'presentation-guide-title');
guide.innerHTML = `<div class="presentation-head"><div><span class="presentation-kicker">نموذج مشروع · جولة مقترحة ٨ دقائق</span><h2 id="presentation-guide-title">من أول مخطط إلى آخر محضر</h2><p>افتح الأقسام بالترتيب لشرح الفكرة في اجتماع أو عرض. هذه الجولة للقراءة فقط.</p></div><button type="button" class="presentation-close" data-presentation-close aria-label="إغلاق جولة العرض">×</button></div><div class="presentation-caution"><strong>حدود النموذج:</strong> البيانات التجريبية تمثل سيناريو توضيحيًا. المخطط الثلاثي عينة، والجهات والبوابات والناقلون والحشود غير متصلين بأنظمة خارجية.</div><ol class="presentation-steps">${steps.map((step, index) => `<li><span class="presentation-number">${String(index + 1).padStart(2, '0')}</span><div><h3>${step.title}</h3><p>${step.story}</p><small>${step.proof}</small></div><button type="button" data-presentation-route="${step.route}">فتح القسم</button></li>`).join('')}</ol><div class="presentation-footer"><span>مدة مقترحة: دقيقة لكل محطة، ثم أسئلة الحضور.</span><button type="button" data-presentation-close>إغلاق</button></div>`;
document.body.appendChild(guide);

let focusOnClose = true;
function syncLauncher() {
  const banner = app.querySelector('.source-banner:not(.manual)');
  if (!banner || banner.querySelector('.presentation-launch')) return;
  const launcher = document.createElement('button');
  launcher.type = 'button';
  launcher.className = 'presentation-launch';
  launcher.textContent = 'جولة العرض';
  launcher.setAttribute('aria-haspopup', 'dialog');
  launcher.addEventListener('click', () => {
    focusOnClose = true;
    guide.showModal();
    guide.querySelector('[data-presentation-close]')?.focus();
  });
  banner.appendChild(launcher);
}
new MutationObserver(syncLauncher).observe(app, {childList: true});
syncLauncher();

guide.addEventListener('click', event => {
  if (event.target.matches('[data-presentation-close]')) {
    guide.close();
    return;
  }
  const route = event.target.closest('[data-presentation-route]')?.dataset.presentationRoute;
  if (!route) return;
  focusOnClose = false;
  guide.close();
  if (location.hash !== `#${route}`) location.hash = route;
  else window.scrollTo({top: 0, behavior: 'smooth'});
});
guide.addEventListener('close', () => {
  if (focusOnClose) app.querySelector('.presentation-launch')?.focus();
});

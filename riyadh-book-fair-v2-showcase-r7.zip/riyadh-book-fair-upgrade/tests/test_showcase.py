"""Presentation data must exercise real workflows while staying synthetic."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from domain import DomainStore
from scripts.prepare_showcase import create_showcase


class ShowcaseTests(unittest.TestCase):
    def test_showcase_is_a_coherent_isolated_story(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'showcase.sqlite'
            summary = create_showcase(path)
            store = DomainStore(path, demo=True)
            state = store.state()
            self.assertEqual(state['mode'], 'demo')
            self.assertEqual(state['revision'], summary['revision'])
            self.assertEqual(state['integrations']['shipping'], 'not_connected')
            self.assertEqual(len(state['projects']), 1)
            self.assertEqual(len(state['phase_handoffs']), 3)
            self.assertTrue(all(row['status'] == 'accepted' for row in state['phase_handoffs']))
            self.assertEqual(len({row['zone_id'] for row in state['phase_handoffs']}), 1)
            self.assertEqual([row['status'] for row in state['daily_reports']], ['closed'])

            orders = {row['status'] for row in state['orders']}
            self.assertEqual(orders, {'ordered', 'delivered'})
            self.assertEqual(len([row for row in state['book_shipments']
                                  if row['status'] == 'resolved' and row['difference_reason']]), 1)
            self.assertEqual(len([row for row in state['book_shipments']
                                  if row['direction'] == 'publisher_return' and row['status'] == 'received']), 1)
            self.assertEqual(len([row for row in state['permits']
                                  if row['status'] == 'approved' and len(row['approval_steps']) == 2]), 1)
            self.assertEqual(len([row for row in state['access_logs']
                                  if row['checked_out_at']]), 1)
            self.assertEqual({row['status'] for row in state['incidents']}, {'open', 'closed'})
            self.assertEqual(state['spatial_plans'][0]['status'], 'draft')
            self.assertEqual(state['spatial_plans'][0]['plan']['provenance']['data_class'], 'demo')
            self.assertFalse(state['spatial_plans'][0]['plan']['review']['approved'])
            self.assertEqual(len(state['spatial_plans'][0]['plan']['elements']), len(state['zones']))
            fixture = json.loads((ROOT / 'scripts/spatial/samples/showcase-demo.plan.json').read_text(encoding='utf-8'))
            draft = state['spatial_plans'][0]['plan']
            self.assertEqual([(element['id'], element['polygon'], element['height_m'])
                              for element in draft['elements']],
                             [(element['id'], element['polygon'], element['height_m'])
                              for element in fixture['elements']])
            self.assertTrue(set(element['zone_id'] for element in draft['elements']).isdisjoint(
                element['zone_id'] for element in fixture['elements']))
            self.assertTrue(all(row['provenance'] == 'demo' for collection in
                                ('projects', 'zones', 'items', 'orders', 'permits', 'spatial_plans')
                                for row in state[collection]))
            self.assertTrue(all(row['on_hand'] >= 0 and row['available'] >= 0
                                for row in state['stock']))
            self.assertEqual(len(store.export({'id': 'test', 'role': 'admin'})['audit']), state['revision'])

    def test_existing_database_is_never_replaced(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'existing.sqlite'
            path.write_bytes(b'keep me')
            with self.assertRaises(FileExistsError):
                create_showcase(path)
            self.assertEqual(path.read_bytes(), b'keep me')

    def test_failed_generation_removes_only_new_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'failed.sqlite'
            with patch('scripts.prepare_showcase.seed_story', side_effect=RuntimeError('test failure')):
                with self.assertRaises(RuntimeError):
                    create_showcase(path)
            self.assertFalse(path.exists())
            self.assertFalse(Path(str(path) + '-wal').exists())
            self.assertFalse(Path(str(path) + '-shm').exists())


if __name__ == '__main__':
    unittest.main()

"""Create a disposable, clearly labelled book-fair presentation database.

This script accepts only a NEW file. It never opens or resets an existing
database, and all records remain in the application's isolated ``demo`` mode.
Run ``python3 scripts/prepare_showcase.py --db data/showcase-demo.sqlite`` then
``python3 server.py --review --demo --db data/showcase-demo.sqlite``.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import secrets
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from domain import DomainStore  # noqa: E402


MANAGER = {'id': 'showcase-manager', 'role': 'manager'}
SECURITY = {'id': 'showcase-security', 'role': 'security'}
FIELD = {'id': 'showcase-field', 'role': 'field'}
WAREHOUSE = {'id': 'showcase-warehouse', 'role': 'warehouse'}
REVIEW_ADMIN = {'id': 'review-admin', 'role': 'admin'}


def seed_story(store):
    """Add finished and in-progress paths to DomainStore's standard demo seed."""
    state = store.state()
    project = state['projects'][0]
    project_id = project['id']
    phases = {p['kind']: p for p in state['phases']}
    zones = {z['name']: z for z in state['zones']}
    books = {i['title']: i for i in state['items'] if i['kind'] == 'book'}
    publishers = {s['id']: s for s in state['stakeholders']}

    def do(actor, command, **payload):
        return store.command(command, payload, actor)['result']

    # A full documented phase chain for one clearly fictional zone. The other
    # seeded zones remain active so the audience can also try pending actions.
    showcase_zone = do(MANAGER, 'shared.create', collection='zones', project_id=project_id,
                       name='جناح مسار العرض — بيانات تجريبية', capacity=300,
                       notes='منطقة اصطناعية لشرح البناء ثم التشغيل ثم الفك')
    zones[showcase_zone['name']] = showcase_zone
    receiver = do(MANAGER, 'shared.create', collection='stakeholders', project_id=project_id,
                  name='مستلم المحاضر التجريبي', role='operations',
                  organization='فريق العرض', account_id='review-admin')
    manager_authority = do(MANAGER, 'shared.create', collection='stakeholders', project_id=project_id,
                           name='اعتماد إدارة المشروع التجريبي', role='manager',
                           organization='جهة افتراضية', account_id=MANAGER['id'])
    security_authority = do(MANAGER, 'shared.create', collection='stakeholders', project_id=project_id,
                            name='اعتماد أمن الموقع التجريبي', role='security',
                            organization='جهة افتراضية', account_id=SECURITY['id'])

    build = do(MANAGER, 'task.create', project_id=project_id, phase_id=phases['build']['id'],
               zone_id=showcase_zone['id'], title='تجهيز الجناح التجريبي وفحص تسليمه',
               responsible_id=receiver['id'], inspection_required=False)
    do(FIELD, 'task.transition', id=build['id'], status='active')
    do(MANAGER, 'task.transition', id=build['id'], status='completed',
       evidence='محضر تجريبي: انتهى تجهيز الجناح')

    def handover(source, target):
        row = do(MANAGER, 'phase_handoff.create', project_id=project_id,
                 zone_id=showcase_zone['id'], from_phase_id=phases[source]['id'],
                 to_phase_id=phases[target]['id'], recipient_id=receiver['id'],
                 evidence=f'محضر عرض تجريبي: {source} إلى {target}')
        return do(REVIEW_ADMIN, 'phase_handoff.accept', id=row['id'],
                  evidence='قبول تجريبي بحساب المراجع المحلي')

    handover('build', 'operations')
    operating_day = do(FIELD, 'daily.open', project_id=project_id,
                       phase_id=phases['operations']['id'], zone_id=showcase_zone['id'],
                       responsible_id=receiver['id'],
                       operational_date=datetime.now(timezone.utc).date().isoformat(),
                       readiness=[{'id': 'gate', 'label': 'جاهزية المدخل التجريبي', 'status': 'ready'},
                                  {'id': 'team', 'label': 'حضور فريق التشغيل التجريبي', 'status': 'ready'}],
                       evidence='محضر افتتاح وردية تجريبية')
    do(MANAGER, 'daily.close', id=operating_day['id'],
       evidence='محضر إقفال وردية تجريبية', summary='انتهت وردية العرض بلا أعمال مفتوحة في هذا الجناح')
    handover('operations', 'dismantling')
    dismantle = do(MANAGER, 'task.create', project_id=project_id,
                   phase_id=phases['dismantling']['id'], zone_id=showcase_zone['id'],
                   title='فك الجناح التجريبي وتسليم الموقع', responsible_id=receiver['id'],
                   inspection_required=False)
    do(FIELD, 'task.transition', id=dismantle['id'], status='active')
    do(MANAGER, 'task.transition', id=dismantle['id'], status='completed',
       evidence='محضر فك وتسليم تجريبي')
    handover('dismantling', 'closeout')

    # A separate permission journey remains visible beside the standard demo's
    # submitted permit: two distinct authority accounts, then gate in and out.
    point = datetime.now(timezone.utc)
    permit = do(FIELD, 'permit.create', project_id=project_id,
                phase_id=phases['operations']['id'], zone_id=showcase_zone['id'],
                title='دخول فريق تشغيل الجناح — تجربة', holder_name='فريق افتراضي',
                kind='team', valid_from=(point - timedelta(hours=1)).isoformat(),
                valid_until=(point + timedelta(days=2)).isoformat(),
                approval_steps=[
                    {'id': 'management', 'authority': 'إدارة المشروع التجريبية',
                     'role': 'manager', 'stakeholder_id': manager_authority['id']},
                    {'id': 'security', 'authority': 'أمن الموقع التجريبي',
                     'role': 'security', 'stakeholder_id': security_authority['id']}])
    do(FIELD, 'permit.transition', id=permit['id'], status='submitted')
    do(MANAGER, 'permit.transition', id=permit['id'], status='approved',
       evidence='اعتماد إدارة تجريبي')
    do(SECURITY, 'permit.transition', id=permit['id'], status='approved',
       evidence='اعتماد أمن تجريبي')
    do(SECURITY, 'permit.access', id=permit['id'], action='checkin',
       evidence='تسجيل دخول تجريبي من البوابة')
    do(SECURITY, 'permit.access', id=permit['id'], action='checkout',
       evidence='تسجيل خروج تجريبي من البوابة')

    # The source observation is entered by a human. It is not labelled as a
    # sensor or live feed, even though the command room shows its metrics.
    crowd_start = point - timedelta(minutes=10)
    crowd_source = do(FIELD, 'observation.create', project_id=project_id,
       phase_id=phases['operations']['id'], zone_id=showcase_zone['id'],
       responsible_id=receiver['id'], observed_at=crowd_start.isoformat(),
       people_count=270, capacity=300, wait_minutes=8,
       satisfaction_score=4.4, sample_size=25,
       evidence='رصد يدوي اصطناعي قبل قرار تنظيم الدخول')
    incident = do(SECURITY, 'incident.create', project_id=project_id,
                  phase_id=phases['operations']['id'], zone_id=showcase_zone['id'],
                  title='ازدحام تدريبي عند الجناح', description='بلاغ محاكاة لمراجعة القرار والإجراء والأثر.',
                  priority='medium', source='field', category='crowds',
                  observation_id=crowd_source['id'], observed_at=crowd_start.isoformat())
    do(SECURITY, 'incident.transition', id=incident['id'], status='assigned',
       responsible_id=security_authority['id'])
    do(MANAGER, 'incident.decision', incident_id=incident['id'],
       responsible_id=security_authority['id'], decision='فتح مسار دخول إضافي افتراضي',
       action='توجيه الفريق إلى تنظيم الصف في المحاكاة',
       impact='يتوقع انخفاض الانتظار بعد فتح المسار الإضافي',
       impact_type='expected', evidence='محضر قرار محاكاة')
    crowd_verified = do(FIELD, 'observation.create', project_id=project_id,
       phase_id=phases['operations']['id'], zone_id=showcase_zone['id'],
       responsible_id=receiver['id'], observed_at=datetime.now(timezone.utc).isoformat(),
       people_count=120, capacity=300, wait_minutes=4,
       satisfaction_score=4.4, sample_size=25,
       evidence='رصد متابعة اصطناعي بعد إجراء تنظيم الدخول')
    do(MANAGER, 'incident.decision', incident_id=incident['id'],
       responsible_id=security_authority['id'], decision='التحقق من أثر تنظيم الدخول',
       action='إعادة عدّ الجمهور وزمن الانتظار بعد الإجراء',
       impact='انخفضت القراءة التجريبية من 270 إلى 120 شخصًا والانتظار من 8 إلى 4 دقائق',
       impact_type='observed', verification_observation_id=crowd_verified['id'],
       evidence='محضر رصد متابعة اصطناعي')
    do(SECURITY, 'incident.transition', id=incident['id'], status='resolved',
       evidence='محضر معالجة تجريبي')
    do(MANAGER, 'incident.transition', id=incident['id'], status='closed',
       evidence='مراجعة إقفال بلاغ محاكاة')

    # Publisher ownership, receipt discrepancy, distribution to a hall,
    # visitor delivery and publisher return all use the real stock commands.
    warehouse = zones['المستودع المركزي']
    hall = zones['القاعة أ']
    first = books['رحلات في المعرفة']
    second = books['ذاكرة المدن']
    late_inbound = do(WAREHOUSE, 'book_shipment.create', project_id=project_id,
                      zone_id=warehouse['id'], publisher_id=second['owner_id'],
                      direction='inbound', document_reference='SHOWCASE-LATE-BOOK-12',
                      expected_at=(point - timedelta(hours=2)).isoformat(),
                      impact_zone_id=hall['id'],
                      lines=[{'item_id': second['id'], 'qty': 12}],
                      notes='بيان افتراضي لم يصل في موعد تجهيز جناح القاعة أ؛ الأثر المحتمل يحتاج قرار المستودع والناشر.',
                      evidence='بيان موعد وارد تجريبي غير متصل بالناقل')
    inbound = do(WAREHOUSE, 'book_shipment.create', project_id=project_id,
                 zone_id=warehouse['id'], publisher_id=second['owner_id'],
                 direction='inbound', document_reference='SHOWCASE-IN-20',
                 lines=[{'item_id': second['id'], 'qty': 20}],
                 evidence='بيان وارد افتراضي من الناشر')
    do(WAREHOUSE, 'book_shipment.receive', id=inbound['id'],
       actual_lines=[{'item_id': second['id'], 'received_qty': 18}],
       receiver_name='مستودع العرض', difference_reason='نقص نسختين في سيناريو التدريب',
       evidence='محضر فرق استلام تجريبي')
    do(MANAGER, 'book_shipment.resolve', id=inbound['id'],
       reason='اعتماد فرق الكمية في المحاكاة', evidence='محضر تسوية تجريبي')
    for book, qty in ((first, 12), (second, 10)):
        do(WAREHOUSE, 'stock.move', action='transfer', item_id=book['id'],
           zone_id=warehouse['id'], to_zone_id=hall['id'], qty=qty,
           evidence='محضر توزيع كتب تجريبي إلى القاعة أ')
    visitor_order = do(WAREHOUSE, 'order.create', project_id=project_id,
                       phase_id=phases['operations']['id'],
                       customer_name='زائر تجريبي بلا بيانات شخصية فعلية',
                       address='عنوان عرض افتراضي غير صالح للشحن',
                       lines=[{'item_id': first['id'], 'zone_id': hall['id'], 'qty': 2},
                              {'item_id': second['id'], 'zone_id': hall['id'], 'qty': 1}])
    do(WAREHOUSE, 'order.transition', id=visitor_order['id'], status='picking')
    do(WAREHOUSE, 'order.transition', id=visitor_order['id'], status='packed',
       evidence='تجميع وتغليف افتراضي')
    do(WAREHOUSE, 'order.transition', id=visitor_order['id'], status='shipped',
       carrier='ناقل تجريبي غير متصل', tracking_number='DEMO-VISITOR-001',
       evidence='محضر تسليم للناقل التجريبي')
    do(WAREHOUSE, 'order.transition', id=visitor_order['id'], status='delivered',
       evidence='إثبات استلام زائر افتراضي')
    outgoing = do(WAREHOUSE, 'book_shipment.create', project_id=project_id,
                  zone_id=hall['id'], publisher_id=first['owner_id'],
                  direction='publisher_return', document_reference='SHOWCASE-RETURN-05',
                  lines=[{'item_id': first['id'], 'qty': 5}],
                  evidence='بيان مرتجع ناشر تجريبي')
    do(WAREHOUSE, 'book_shipment.dispatch', id=outgoing['id'],
       carrier='ناقل تجريبي غير متصل', tracking_number='DEMO-PUBLISHER-001',
       evidence='تسليم مرتجع افتراضي للناقل')
    do(WAREHOUSE, 'book_shipment.receive', id=outgoing['id'],
       actual_lines=[{'item_id': first['id'], 'received_qty': 5}],
       receiver_name=publishers[first['owner_id']]['name'],
       evidence='محضر استلام ناشر تجريبي')

    # The draft and bundled GLB share one fictional geometry source. Runtime
    # zone IDs differ from the GLB's DEMO-* placeholders so the preview cannot
    # pass the reviewed-plan linkage gate or acquire operational authority.
    fixture = json.loads((ROOT / 'scripts/spatial/samples/showcase-demo.plan.json').read_text(encoding='utf-8'))
    demo_zones = {
        'DEMO-WAREHOUSE': warehouse, 'DEMO-HALL-A': hall,
        'DEMO-HALL-B': zones['القاعة ب'],
        'DEMO-LOADING': zones['منطقة التحميل'],
        'DEMO-VISITOR': zones['مركز خدمة الزائر'],
        'DEMO-JOURNEY': showcase_zone,
    }
    elements = [{**element, 'name': demo_zones[element['zone_id']]['name'],
                 'zone_id': demo_zones[element['zone_id']]['id']}
                for element in fixture['elements']]
    plan = {**fixture,
            'created_at': datetime.now(timezone.utc).isoformat(),
            'provenance': {**fixture['provenance'],
                           'notes': 'رسم اصطناعي مطابق بصريًا للمثال الثلاثي؛ معرفات المناطق خاصة بقاعدة العرض ولا تمنح المجسم ربطًا تشغيليًا.'},
            'review': {'approved': False, 'reviewer': '', 'reviewed_at': None},
            'elements': elements}
    do(FIELD, 'spatial_plan.create', project_id=project_id,
       title='مخطط توضيحي لمناطق العرض — غير معتمد',
       source_reference='رسم مولد آليًا لأغراض العرض فقط', source_version='DEMO-1',
       source_units='m', source_crs='local synthetic coordinates', plan=plan)

    result = store.state()
    return {'project_id': project_id, 'showcase_zone_id': showcase_zone['id'],
            'visitor_order_id': visitor_order['id'], 'approved_permit_id': permit['id'],
            'late_book_shipment_id': late_inbound['id'],
            'crowd_source_observation_id': crowd_source['id'],
            'crowd_verification_observation_id': crowd_verified['id'],
            'spatial_plan_id': result['spatial_plans'][-1]['id'],
            'revision': result['revision'],
            'counts': {name: len(result[name]) for name in
                       ('phase_handoffs', 'book_shipments', 'orders', 'permits',
                        'incidents', 'observations', 'spatial_plans')}}


def create_showcase(path):
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(descriptor)
    try:
        store = DomainStore(target, demo=True)
        summary = seed_story(store)
        summary['database'] = str(target)
        return summary
    except BaseException:
        # These paths belong only to the file that this invocation created.
        for suffix in ('', '-wal', '-shm'):
            Path(str(target) + suffix).unlink(missing_ok=True)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, default=None,
                        help='A new private SQLite path; existing files are never modified')
    args = parser.parse_args(argv)
    path = args.db or ROOT / 'data' / (
        'showcase-demo-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        + '-' + secrets.token_hex(3) + '.sqlite')
    try:
        summary = create_showcase(path)
    except FileExistsError:
        parser.exit(2, 'الملف موجود مسبقًا؛ اختر مسارًا جديدًا. لم تتغير قاعدة البيانات.\n')
    except Exception as error:
        parser.exit(1, f'تعذر تجهيز عرض تجريبي: {type(error).__name__}: {error}\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nللعرض المحلي: python3 server.py --review --demo --db '{summary['database']}' --port 8765")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

"""Run with: blender --background --factory-startup --python this.py -- plan.json out.glb"""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plan_schema import area, validate_plan


def export(plan_path, output_path):
    # Validate before touching Blender state or overwriting any output.
    source = Path(plan_path)
    output = Path(output_path)
    if output.suffix.lower() != ".glb" or output.exists():
        raise ValueError("اختر مسار GLB جديدًا؛ لا تتم الكتابة فوق ملفات قائمة")
    if source.stat().st_size > 20 * 1024 * 1024:
        raise ValueError("ملف المخطط أكبر من 20 MB")
    content = source.read_bytes()
    plan = validate_plan(json.loads(content), require_review=True)
    import bpy
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1
    scene["plan_sha256"] = hashlib.sha256(content).hexdigest()
    scene["data_class"] = plan["provenance"]["data_class"]
    scene["source_file"] = plan["provenance"]["source_file"]
    scene["reviewer"] = plan["review"]["reviewer"]
    scene["reviewed_at"] = plan["review"]["reviewed_at"]
    scene["source_coordinate_system"] = plan["coordinate_system"]
    scene["units"] = "m"
    # Node colors survive glTF export; viewport diffuse_color alone does not.
    colors = {
        "space": (0.035, 0.54, 0.45, 1),
        "wall": (0.74, 0.39, 0.11, 1),
        "asset": (0.31, 0.22, 0.62, 1),
    }
    def make_material(name, color):
        material = bpy.data.materials.new(name)
        material.diffuse_color = color
        material.use_nodes = True
        shader = material.node_tree.nodes.get("Principled BSDF")
        shader.inputs["Base Color"].default_value = color
        shader.inputs["Roughness"].default_value = 0.82
        return material

    materials = {kind: make_material(f"spatial-{kind}", color)
                 for kind, color in colors.items()}
    # Synthetic presentation plans use the same ordered palette as their 2D
    # preview. These colors communicate categories visually, not site status.
    demo_palette = [
        (0.153, 0.639, 0.545, 1), (0.424, 0.392, 0.812, 1),
        (0.247, 0.529, 0.788, 1), (0.882, 0.627, 0.267, 1),
        (0.741, 0.471, 0.682, 1), (0.349, 0.651, 0.478, 1),
    ]
    demo_materials = [make_material(f"demo-zone-{i + 1}", color)
                      for i, color in enumerate(demo_palette)] if plan["provenance"]["data_class"] == "demo" else []
    for index, element in enumerate(plan["elements"]):
        points = element["polygon"]
        if area(points) < 0:
            points = list(reversed(points))
        n, base, height = len(points), element.get("base_m", 0), element["height_m"]
        vertices = [(x, y, base) for x, y in points] + [(x, y, base + height) for x, y in points]
        # Blender's glTF exporter triangulates planar ngons, including concave outlines.
        faces = [tuple(reversed(range(n))), tuple(range(n, 2 * n))]
        faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
        mesh = bpy.data.meshes.new(element["id"])
        mesh.from_pydata(vertices, [], faces)
        mesh.validate(verbose=False)
        mesh.update()
        obj = bpy.data.objects.new(element["name"], mesh)
        scene.collection.objects.link(obj)
        obj.data.materials.append(demo_materials[index % len(demo_materials)] if demo_materials else materials.get(element.get("type"), materials["space"]))
        for key in ("id", "zone_id", "asset_id", "type", "height_m", "base_m"):
            obj[key] = element.get(key, "" if key in ("asset_id", "type") else 0)
        obj["data_class"] = plan["provenance"]["data_class"]
        obj["units"] = "m"
    result = bpy.ops.export_scene.gltf(filepath=str(output.resolve()), export_format="GLB", export_extras=True, export_yup=True)
    if "FINISHED" not in result or not output.is_file():
        raise RuntimeError("لم يكتمل تصدير GLB")
    print(f"GLB: {output} | elements={len(plan['elements'])} | source={scene['plan_sha256']}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(args) != 2:
        raise SystemExit("usage: blender --background --factory-startup --python blender_export.py -- reviewed-plan.json new-model.glb")
    export(*args)

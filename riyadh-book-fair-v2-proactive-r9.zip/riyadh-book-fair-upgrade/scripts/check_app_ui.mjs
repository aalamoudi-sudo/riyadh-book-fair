// Browser smoke test for the main application, using an isolated local demo DB.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const {chromium} = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.env.APP_BASE_URL || 'http://127.0.0.1:8893';
const browser = await chromium.launch({headless:true, ...(process.env.CHROME_CHANNEL ? {channel:process.env.CHROME_CHANNEL} : {})});
const output = await fs.mkdtemp(path.join(os.tmpdir(), 'rbf-app-ui-'));
try {
  const page = await browser.newPage({viewport:{width:1440,height:960}});
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(base);
  await page.waitForLoadState('networkidle');
  await page.locator('#main').waitFor();

  await page.getByRole('button', {name:'جولة العرض'}).click();
  await page.getByRole('heading', {name:'من أول مخطط إلى آخر محضر'}).waitFor();
  assert.equal(await page.locator('#presentation-guide [data-presentation-route]').count(), 8);
  await page.screenshot({path:path.join(output,'presentation-guide.png')});
  await page.locator('#presentation-guide [data-presentation-route="spatial"]').click();
  await page.getByRole('heading', {name:'التوأم المكاني للمعرض'}).waitFor();
  assert.equal(await page.locator('#presentation-guide').evaluate(node => node.open), false);

  await page.locator('.nav a[data-route="books"]').click();
  await page.getByRole('heading', {name:'مستودع الكتب'}).waitFor();
  await page.getByRole('heading', {name:'شحنات الناشرين ومحاضر الاستلام'}).waitFor();
  await page.getByRole('button', {name:'بيان شحنة واردة'}).click();
  await page.getByRole('heading', {name:'بيان شحنة واردة من الناشر'}).waitFor();
  assert.equal(await page.locator('#dialog [data-shipment-line]').count(), 1);
  await page.locator('#dialog [data-close]').first().click();

  await page.locator('.nav a[data-route="operations"]').click();
  await page.getByRole('heading', {name:'تسليم المراحل بين الفرق'}).waitFor();
  await page.getByRole('button', {name:'طلب تسليم مرحلة'}).first().click();
  await page.getByRole('heading', {name:'طلب تسليم مرحلة'}).waitFor();
  assert.equal(await page.locator('#dialog [name="recipient_account_id"]').count(), 0);
  await page.locator('#dialog [data-close]').first().click();

  await page.locator('.nav a[data-route="spatial"]').click();
  await page.getByRole('heading', {name:'التوأم المكاني للمعرض'}).waitFor();
  assert.equal(await page.locator('.spatial-jumps button').count(), 5);
  await page.locator('[data-action="spatial-jump"][data-target="spatial-workspace"]').click();
  assert.equal(await page.evaluate(() => document.activeElement?.id), 'spatial-workspace');
  await page.screenshot({path:path.join(output,'desktop.png'),fullPage:true});

  await page.setViewportSize({width:390,height:844});
  await page.locator('[data-action="spatial-jump"][data-target="spatial-source"]').click();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({path:path.join(output,'mobile.png'),fullPage:true});
  await page.getByRole('button', {name:'فتح القائمة'}).click();
  await page.locator('.nav a[data-route="books"]').click();
  await page.getByRole('heading', {name:'مستودع الكتب'}).waitFor();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.getByRole('button', {name:'جولة العرض'}).click();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({path:path.join(output,'presentation-guide-mobile.png')});
  await page.locator('#presentation-guide [data-presentation-close]').first().click();
  assert.deepEqual(errors, []);
  console.log(JSON.stringify({status:'passed',flows:['presentation guide','main navigation','book manifest dialog','phase handoff dialog','spatial jump focus','mobile navigation and width'],artifacts:output}));
} finally {
  await browser.close();
}

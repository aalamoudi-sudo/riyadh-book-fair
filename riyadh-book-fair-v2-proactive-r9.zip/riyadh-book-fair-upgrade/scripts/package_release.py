#!/usr/bin/env python3
"""Build an allow-listed source release without databases, accounts or originals."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ('README.md', 'index.html', '.gitignore', 'run-review.command', 'run-showcase.command',
         'run-tests.command', 'server.py',
         'domain.py', 'coordination.py', 'evidence.py', 'operations.py', 'decision_signals.py',
         'backup_service.py')
TREES = ('app', 'docs', 'scripts', 'tests')
FORBIDDEN_SUFFIXES = {'.sqlite', '.sqlite3', '.db', '.pyc', '.zip', '.dmg'}


def release_files():
    result = [ROOT / item for item in FILES]
    for tree in TREES:
        result.extend(p for p in (ROOT / tree).rglob('*') if p.is_file())
    result.extend(p for p in (ROOT / 'review').glob('*.md') if p.is_file())
    result.extend(p for p in (ROOT / 'review').glob('*.json') if p.is_file())
    result.extend(p for p in (ROOT / 'review/screenshots').glob('*.png') if p.is_file())
    for path in sorted(set(result)):
        relative = path.relative_to(ROOT)
        if path.is_symlink() or (path.suffix.lower() in FORBIDDEN_SUFFIXES
                                and relative.as_posix() != 'app/assets/spatial-converter.zip'):
            continue
        if any(x.startswith('.') or x == '__pycache__' for x in relative.parts) and relative.name != '.gitignore':
            continue
        if not path.is_file():
            raise ValueError(f'Required file is missing: {relative}')
        yield path, relative.as_posix()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path, help='New zip path; existing files are never replaced')
    args = parser.parse_args()
    inventory = []
    with zipfile.ZipFile(args.output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path, relative in release_files():
            content = path.read_bytes()
            inventory.append({'path': relative, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
            archive.write(path, 'riyadh-book-fair-upgrade/' + relative)
        archive.writestr('riyadh-book-fair-upgrade/RELEASE-MANIFEST.json', json.dumps(
            {'format': 1, 'files': inventory, 'excluded': ['original private backups', 'databases', 'accounts',
             'environment secrets', 'git history', 'downloaded tools']}, ensure_ascii=False, indent=2))
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    print(json.dumps({'archive': str(args.output.resolve()), 'files': len(inventory),
                      'bytes': args.output.stat().st_size, 'sha256': digest}, indent=2))


if __name__ == '__main__':
    main()

import {recordEvidence} from './evidence.js';
import {modal, detail, esc, table, badge, button, select, field, textarea, n, date, datetime, label, empty, icon} from './ui.js';

const all = (ctx, collection) => ctx.state[collection] || [];
const itemSet = (ctx, kind) => ctx.records('items').filter(x => kind === 'book' ? x.kind === 'book' : x.kind !== 'book');
const byId = (ctx, collection, id) => all(ctx, collection).find(x => x.id === id);
const blank = (name = 'اختر…') => ({id: '', name});
const attrs = values => Object.entries(values).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ');
const permission = (ctx, type) => ctx.can(type) ? '' : 'disabled title="لا تملك صلاحية هذا الإجراء"';
const actionButton = (ctx, text, action, type, data = {}, style = 'small', ico = '') => button(text, action, style, ico, `${attrs(data)} ${permission(ctx, type)}`);
const heading = (eyebrow, title, description, actions = '') => `<div class="page-heading"><div><span class="eyebrow">${esc(eyebrow)}</span><h1>${esc(title)}</h1><p>${esc(description)}</p></div><div class="actions">${actions}</div></div>`;
const kpi = (title, value, note, ico = 'warehouse') => `<div class="kpi"><div class="kpi-top"><span>${esc(title)}</span><span class="kpi-icon">${icon(ico)}</span></div><div class="kpi-value">${esc(value)}</div><div class="kpi-foot">${esc(note)}</div></div>`;
const info = (title, value) => `<div class="detail-item"><span>${esc(title)}</span><strong>${esc(value || '—')}</strong></div>`;
const note = text => `<p class="field-help">${esc(text)}</p>`;
const includes = (ctx, values) => !ctx.query || values.join(' ').toLocaleLowerCase().includes(String(ctx.query).toLocaleLowerCase());
const statusMatch = (ctx, value) => !ctx.status || ctx.status === 'all' || ctx.status === value;
const balance = (ctx, itemId, zoneId) => all(ctx, 'stock').find(x => x.item_id === itemId && x.zone_id === zoneId) || {on_hand: 0, available: 0, reserved: 0, maintenance: 0};
const qty = (name = 'qty', value = 1) => field(name, 'الكمية', 'number', value, 'required min="1" max="1000000" step="1" inputmode="numeric"');

function filterbar(ctx, statuses, count, placeholder) {
  return `<div class="filterbar"><label class="search-field">${icon('search')}<input id="search" data-filter="query" type="search" value="${esc(ctx.query || '')}" aria-label="بحث في السجلات" placeholder="${esc(placeholder)}"></label><select id="status-filter" data-filter="status" aria-label="تصفية الحالة"><option value="">جميع الحالات</option>${statuses.map(s => `<option value="${esc(s.id || s)}" ${(s.id || s) === ctx.status ? 'selected' : ''}>${esc(s.name || label(s))}</option>`).join('')}</select><span class="filter-count">${n(count)} سجل مطابق</span></div>`;
}

function quantities(ctx, items, key) {
  const groups = new Map();
  for (const item of items) {
    const value = all(ctx, 'stock').filter(x => x.item_id === item.id).reduce((sum, row) => sum + Number(row[key] || 0), 0);
    const unit = item.unit || (item.kind === 'book' ? 'نسخة' : 'قطعة');
    groups.set(unit, (groups.get(unit) || 0) + value);
  }
  return [...groups.entries()].map(([unit, value]) => `${n(value)} ${unit}`).join(' · ') || '٠';
}

function itemRows(ctx, items) {
  return items.flatMap(item => {
    const rows = all(ctx, 'stock').filter(row => row.item_id === item.id);
    return (rows.length ? rows : [{zone_id: '', on_hand: 0, available: 0, reserved: 0, maintenance: 0}]).map(stock => ({item, stock}));
  });
}

function movementTable(ctx, moves) {
  return moves.length ? table(['التاريخ', 'الحركة', 'الصنف / الموقع', 'الكمية', 'المرجع', 'الإثبات'], moves.map(m => `<tr><td>${esc(date(m.created_at))}</td><td>${badge(m.action, ({adjustment: 'تسوية جرد', settlement: 'تسوية عهدة', consume: 'استهلاك مباشر'}[m.action]))}</td><td>${esc(ctx.name('items', m.item_id))}<span class="cell-sub">${esc(ctx.name('zones', m.zone_id))}${m.to_zone_id ? ` ← ${esc(ctx.name('zones', m.to_zone_id))}` : ''}</span></td><td>${m.action === 'adjustment' ? `${m.signed_qty > 0 ? '+' : ''}${n(m.signed_qty)}` : n(m.qty)}</td><td><span class="mono">${esc(m.reference || '—')}</span></td><td><span class="cell-sub" title="${esc(m.evidence || '')}">${esc(m.evidence || m.reason || '—')}</span></td></tr>`)) : empty('لم تسجل حركات بعد', 'يظهر هنا كل استلام وحجز وصرف ونقل واسترجاع مسجل.');
}

const countLabel = status => ({matched: 'مطابق', pending: 'فرق ينتظر الاعتماد', approved: 'فرق معتمد', rejected: 'فرق مرفوض'}[status] || label(status));
function countCurrent(ctx, row) {
  const moves = all(ctx, 'stock_moves').filter(m => m.item_id === row.item_id && (m.zone_id === row.zone_id || m.to_zone_id === row.zone_id));
  return row.movement_marker === (moves.at(-1)?.id || '');
}
function countTable(ctx, counts) {
  return counts.length ? table(['الصنف / الموقع', 'التاريخ', 'الدفتري', 'العد الفعلي', 'الفرق', 'الحالة', 'الإجراء'], counts.map(c => `<tr><td>${esc(ctx.name('items', c.item_id))}<span class="cell-sub">${esc(ctx.name('zones', c.zone_id))}</span></td><td>${esc(date(c.created_at))}</td><td>${n(c.expected_qty)}</td><td>${n(c.counted_qty)}</td><td>${c.variance > 0 ? '+' : ''}${n(c.variance)}</td><td>${badge(c.status, countLabel(c.status))}${!countCurrent(ctx, c) ? '<span class="cell-sub">تحرك المخزون بعد هذا الجرد</span>' : ''}</td><td><div class="cell-actions">${button('المحضر', 'inventory-count-detail', 'small', '', attrs({id: c.id}))}${c.status === 'pending' ? actionButton(ctx, 'مراجعة الفرق', 'inventory-count-review', 'stock.count.review', {id: c.id}) : ''}</div></td></tr>`)) : empty('لا توجد محاضر جرد', 'العد الفعلي يقارن بالموجود الدفتري. اختلاف الكمية ينتظر اعتماد المدير قبل التسوية.');
}

const shipmentStatus = status => ({announced:'معلنة تنتظر الاستلام',prepared:'مرتجع مجهز',shipped:'لدى الناقل',received:'مستلمة بالكامل',discrepancy:'فرق استلام ينتظر القرار',resolved:'فرق تمت تسويته بمحضر',cancelled:'ملغاة بمحضر'}[status]||status);
const shipmentDirection = direction => direction==='inbound'?'وارد من الناشر':'مرتجع إلى الناشر';
function shipmentAction(ctx, row) {
  if(row.status==='prepared')return actionButton(ctx,'تسليم للناقل','inventory-shipment-dispatch','book_shipment.dispatch',{id:row.id});
  if(['announced','shipped'].includes(row.status))return actionButton(ctx,'تسجيل الاستلام','inventory-shipment-receive','book_shipment.receive',{id:row.id});
  if(row.status==='discrepancy')return actionButton(ctx,'معالجة الفرق','inventory-shipment-resolve','book_shipment.resolve',{id:row.id});
  return '';
}
const shipmentCancelAction = (ctx,row) => ['announced','prepared'].includes(row.status)?actionButton(ctx,'إلغاء البيان','inventory-shipment-cancel','book_shipment.cancel',{id:row.id}):'';
function shipmentPanel(ctx) {
  const shipments=ctx.records('book_shipments').slice().reverse();
  const inbound=actionButton(ctx,'بيان شحنة واردة','inventory-shipment-new','book_shipment.create',{direction:'inbound'},'secondary','plus');
  const outbound=actionButton(ctx,'بيان مرتجع للناشر','inventory-shipment-new','book_shipment.create',{direction:'publisher_return'},'secondary','warehouse');
  return `<section class="panel mt"><div class="panel-head"><div><h2>شحنات الناشرين ومحاضر الاستلام</h2><p>بيان موحد لعناوين الناشر، مع كميات مرسلة ومستلمة وفروق موثقة.</p></div><div class="actions">${inbound}${outbound}</div></div>${shipments.length?table(['البيان / الاتجاه','الناشر والموقع','النسخ','الحالة','الإجراء'],shipments.map(row=>`<tr><td><span class="cell-title">${esc(row.document_reference)}</span><span class="cell-sub">${esc(shipmentDirection(row.direction))} · ${esc(row.id)}</span></td><td>${esc(ctx.name('stakeholders',row.publisher_id))}<span class="cell-sub">${esc(ctx.name('zones',row.zone_id))}</span></td><td>${n(row.lines.reduce((sum,line)=>sum+line.qty,0))} في البيان<span class="cell-sub">${row.received_at?`${n(row.lines.reduce((sum,line)=>sum+(line.received_qty||0),0))} مثبتة بالاستلام`:'لم يُسجل الاستلام'}</span></td><td>${badge(row.status,shipmentStatus(row.status))}</td><td><div class="cell-actions">${button('المحضر','inventory-shipment-detail','small','',attrs({id:row.id}))}${shipmentAction(ctx,row)}${shipmentCancelAction(ctx,row)}</div></td></tr>`)):empty('لا توجد شحنات ناشرين','أنشئ بيانًا من عنوان أو أكثر للناشر نفسه، ثم سجّل التسليم والاستلام الفعلي.',inbound)}<div class="panel-body"><p class="field-help">الوارد يضيف إلى الرصيد ما استُلم فعليًا فقط. المرتجع يخصم الرصيد عند تسليمه للناقل. اسم المستلم ورقم التتبع ومرجع الإثبات تُدخل يدويًا؛ لا يوجد توقيع إلكتروني أو اتصال مباشر بالناشر والناقل.</p></div></section>`;
}

function shipmentLineHTML(ctx) {
  return `<div class="line-editor" data-shipment-line>${select('shipment_item_id','عنوان الكتاب',[blank(),...itemSet(ctx,'book')],'','required')}${qty('shipment_qty')}${button('حذف العنوان','inventory-shipment-remove-line','small','close','aria-label="حذف عنوان من البيان"')}<p class="field-help wide" data-shipment-stock></p></div>`;
}
function addShipmentLine(ctx,container) {
  if(container.querySelectorAll('[data-shipment-line]').length>=100)throw new Error('الحد الأعلى 100 عنوان في البيان.');
  const template=document.createElement('template');template.innerHTML=shipmentLineHTML(ctx);container.append(template.content);
}
function updateShipmentLines(ctx,form) {
  const publisher=form.elements.publisher_id.value,zone=form.elements.zone_id.value;
  for(const row of form.querySelectorAll('[data-shipment-line]')){
    const item=byId(ctx,'items',row.querySelector('[name=shipment_item_id]').value);
    const stock=balance(ctx,item?.id,zone);
    row.querySelector('[data-shipment-stock]').textContent=item?`الناشر: ${ctx.name('stakeholders',item.owner_id)} · المتاح في الموقع: ${n(stock.available)} نسخة${publisher&&item.owner_id!==publisher?' · هذا العنوان لغير الناشر المحدد':''}`:'اختر عنوانًا تابعًا للناشر المحدد.';
  }
}
function newShipment(ctx,direction) {
  if(!ctx.can('book_shipment.create'))throw new Error('إنشاء البيان يتطلب صلاحية المستودع.');
  if(!itemSet(ctx,'book').length||!ctx.records('zones').length||!ctx.records('stakeholders').length)return detail('تهيئة شحنات الناشرين',note('أضف ناشرًا وعنوان كتاب ومنطقة قبل إنشاء بيان الشحنة.'));
  const returning=direction==='publisher_return';
  const timingFields=returning?'':`${field('expected_at','موعد الوصول المتوقع','datetime-local','','')}${select('impact_zone_id','المنطقة التي تتأثر بالتأخير',[blank(),...ctx.records('zones')])}`;
  const dialog=modal(returning?'بيان مرتجع إلى الناشر':'بيان شحنة واردة من الناشر',`<div class="form-grid">${select('publisher_id','الناشر',[blank(),...ctx.records('stakeholders')],'','required')}${select('zone_id',returning?'موقع سحب المرتجع':'منطقة استلام الوارد',[blank(),...ctx.records('zones')],'','required')}${field('document_reference','رقم بيان الشحنة / المرجع','text','','required maxlength="160"')}${timingFields}${textarea('evidence','مرجع بيان الشحنة ومصدره','','required maxlength="4000"')}${textarea('notes','تعليمات الشحن أو فحص الاستلام','','maxlength="4000"')}</div><h3 class="form-section">عناوين وكمية البيان</h3><div data-shipment-lines></div>${button('إضافة عنوان','inventory-shipment-add-line','secondary','plus')}<p class="field-help">${returning?'يُتحقق من الرصيد المتاح الآن وعند تسليم المرتجع للناقل.':'لا يزيد الرصيد حتى تسجيل الكمية المستلمة فعليًا. الموعد والمنطقة المتأثرة اختياريان، ويُستخدمان لتفسير إشارة التأخير.'} يجب أن تكون كل العناوين للناشر المحدد.</p>`,async(data,form)=>{
    const seen=new Set();
    const lines=[...form.querySelectorAll('[data-shipment-line]')].map(row=>{
      const item_id=row.querySelector('[name=shipment_item_id]').value,qtyValue=Number(row.querySelector('[name=shipment_qty]').value),item=byId(ctx,'items',item_id);
      if(!item||item.kind!=='book'||item.owner_id!==data.publisher_id)throw new Error('كل عنوان يجب أن يكون كتابًا للناشر المحدد.');
      if(seen.has(item_id))throw new Error('ادمج السطور المتكررة للعنوان نفسه.');seen.add(item_id);
      if(!Number.isInteger(qtyValue)||qtyValue<1)throw new Error('أدخل كمية صحيحة موجبة لكل عنوان.');
      if(returning&&balance(ctx,item_id,data.zone_id).available<qtyValue)throw new Error(`الرصيد المتاح لا يكفي للعنوان ${item.name}.`);
      return {item_id,qty:qtyValue};
    });
    const timing=returning?{}:{expected_at:data.expected_at?new Date(data.expected_at).toISOString():null,impact_zone_id:data.impact_zone_id||null};
    await ctx.command('book_shipment.create',{project_id:ctx.projectId,direction,publisher_id:data.publisher_id,zone_id:data.zone_id,document_reference:data.document_reference,evidence:data.evidence,notes:data.notes,lines,...timing});
  },'حفظ بيان الشحنة',true);
  const form=dialog.querySelector('form');addShipmentLine(ctx,dialog.querySelector('[data-shipment-lines]'));
  form.addEventListener('change',()=>updateShipmentLines(ctx,form));updateShipmentLines(ctx,form);
}
function shipmentDetail(ctx,id) {
  const row=requireRecord(ctx,'book_shipments',id);
  detail(`شحنة ${row.document_reference}`,`<div class="actions">${badge(row.status,shipmentStatus(row.status))}${shipmentAction(ctx,row)}${shipmentCancelAction(ctx,row)}</div><div class="details-grid mt">${info('اتجاه الشحنة',shipmentDirection(row.direction))}${info('الناشر',ctx.name('stakeholders',row.publisher_id))}${info('موقع الاستلام',ctx.name('zones',row.zone_id))}${row.expected_at?info('موعد الوصول المتوقع',datetime(row.expected_at)):''}${row.impact_zone_id?info('المنطقة المتأثرة',ctx.name('zones',row.impact_zone_id)):''}${info('مرجع البيان',row.document_reference)}${info('الناقل — إدخال يدوي',row.carrier)}${info('التتبع — إدخال يدوي',row.tracking_number)}${info('اسم المستلم المسجل',row.receiver_name)}${info('وقت الإرسال',row.dispatched_at?date(row.dispatched_at):'')}${info('وقت الاستلام',row.received_at?date(row.received_at):'')}</div>${table(['العنوان','كمية البيان','المستلم فعليًا','حركة الرصيد'],row.lines.map(line=>`<tr><td>${esc(line.title||ctx.name('items',line.item_id))}</td><td>${n(line.qty)}</td><td>${line.received_qty===null?'لم يسجل':n(line.received_qty)}</td><td>${esc(line.stock_move_id||'بانتظار الحركة')}</td></tr>`))}<h3 class="form-section">مراجع المحاضر</h3><p>بيان الشحنة: ${esc(row.created_evidence)}</p>${row.dispatch_evidence?`<p>تسليم الناقل: ${esc(row.dispatch_evidence)}</p>`:''}${row.receipt_evidence?`<p>إثبات الاستلام: ${esc(row.receipt_evidence)}</p>`:''}${row.difference_reason?`<p>فرق الاستلام: ${esc(row.difference_reason)}</p>`:''}${row.resolution_reason?`<p>قرار معالجة الفرق: ${esc(row.resolution_reason)} · ${esc(row.resolution_evidence)}</p>`:''}${row.cancellation_reason?`<p>إلغاء البيان: ${esc(row.cancellation_reason)} · ${esc(row.cancellation_evidence)}</p>`:''}${row.notes?`<p>${esc(row.notes)}</p>`:''}${recordEvidence(ctx,'book_shipments',row.id)}`);
}
function dispatchShipment(ctx,id) {
  const row=requireRecord(ctx,'book_shipments',id);
  if(row.status!=='prepared')throw new Error('المرتجع لم يعد في حالة التجهيز.');
  modal('تسليم المرتجع للناقل',`<p>${esc(row.document_reference)} · ${esc(ctx.name('stakeholders',row.publisher_id))}</p><div class="form-grid">${field('carrier','اسم الناقل','text','','required maxlength="200"')}${field('tracking_number','رقم التتبع أو بوليصة الشحن','text','','required maxlength="160"')}${textarea('evidence','مرجع محضر خروج الشحنة وتسليمها للناقل','','required maxlength="4000"')}</div>${note('عند الحفظ سيُخصم كامل بيان المرتجع من الموقع في معاملة واحدة. سيتحقق الخادم من الرصيد مرة أخرى.')}`,async data=>ctx.command('book_shipment.dispatch',{id:row.id,...data}),'تأكيد التسليم وخصم الرصيد');
}
function receiveShipment(ctx,id) {
  const row=requireRecord(ctx,'book_shipments',id);
  if(!['announced','shipped'].includes(row.status))throw new Error('الشحنة ليست بانتظار الاستلام.');
  const inbound=row.direction==='inbound';
  const inputs=row.lines.map(line=>`<div class="line-editor" data-receipt-line data-id="${esc(line.item_id)}"><div><strong>${esc(line.title||ctx.name('items',line.item_id))}</strong><span class="cell-sub">في البيان: ${n(line.qty)} نسخة</span></div>${field('received_qty','المستلم فعليًا','number',line.qty,`required min="0" max="${line.qty}" step="1" inputmode="numeric"`)}</div>`).join('');
  const dialog=modal(inbound?'استلام شحنة ناشر وإضافة الرصيد':'تأكيد استلام الناشر للمرتجع',`<p>${esc(row.document_reference)} · ${esc(ctx.name('zones',row.zone_id))}</p><h3 class="form-section">مطابقة العناوين والكميات</h3>${inputs}<div class="form-grid mt">${field('receiver_name','اسم المستلم وفق المحضر','text','','required maxlength="200"')}${textarea('evidence','مرجع محضر الاستلام الفعلي','','required maxlength="4000"')}${textarea('difference_reason','سبب النقص أو التلف عند اختلاف الكمية','','maxlength="2000"')}</div>${note(inbound?'سيُضاف إلى المخزون ما ثبت استلامه فقط. أي فرق يبقى مفتوحًا حتى توثيق قرار معالجته.':'هذا إقرار استلام يدوي؛ رصيد المرتجع خُصم عند تسليم الناقل. الفرق يبقى مفتوحًا حتى قرار موثق.')}`,async(data,form)=>{
    const actual_lines=[...form.querySelectorAll('[data-receipt-line]')].map(element=>({item_id:element.dataset.id,received_qty:Number(element.querySelector('[name=received_qty]').value)}));
    if(actual_lines.some((line,index)=>!Number.isInteger(line.received_qty)||line.received_qty<0||line.received_qty>row.lines[index].qty))throw new Error('الكمية المستلمة يجب أن تكون بين صفر وكمية البيان.');
    if(actual_lines.some((line,index)=>line.received_qty!==row.lines[index].qty)&&!data.difference_reason.trim())throw new Error('اكتب سبب فرق الاستلام.');
    await ctx.command('book_shipment.receive',{id:row.id,actual_lines,receiver_name:data.receiver_name,evidence:data.evidence,difference_reason:data.difference_reason});
  },'حفظ محضر الاستلام',true);
  const form=dialog.querySelector('form');const update=()=>{const differs=[...form.querySelectorAll('[data-receipt-line]')].some((line,index)=>Number(line.querySelector('[name=received_qty]').value)!==row.lines[index].qty);form.elements.difference_reason.required=differs;};form.addEventListener('input',update);update();
}
function resolveShipment(ctx,id) {
  const row=requireRecord(ctx,'book_shipments',id);
  if(row.status!=='discrepancy')throw new Error('لا يوجد فرق استلام ينتظر قرارًا.');
  modal('معالجة فرق استلام الشحنة',`<p>${esc(row.document_reference)} · ${esc(row.difference_reason)}</p><div class="form-grid">${textarea('reason','قرار معالجة النقص أو التلف','','required maxlength="2000"')}${textarea('evidence','مرجع محضر اعتماد معالجة الفرق','','required maxlength="4000"')}</div>${note('توثيق القرار لا ينشئ حركة رصيد إضافية. إذا وصلت نسخ لاحقة، سجّل بيان شحنة واردة جديدًا ومستقلًا.')}`,async data=>ctx.command('book_shipment.resolve',{id:row.id,...data}),'اعتماد معالجة الفرق');
}
function cancelShipment(ctx,id) {
  const row=requireRecord(ctx,'book_shipments',id);
  if(!['announced','prepared'].includes(row.status))throw new Error('لا يمكن إلغاء شحنة تغير رصيدها أو أرسلت للناقل.');
  modal('إلغاء بيان الشحنة',`<p>${esc(row.document_reference)} · ${esc(shipmentDirection(row.direction))}</p><div class="form-grid">${textarea('reason','سبب إلغاء البيان','','required maxlength="2000"')}${textarea('evidence','مرجع اعتماد الإلغاء','','required maxlength="4000"')}</div>${note('الإلغاء قبل أي حركة رصيد فقط؛ يبقى المحضر في السجل للتدقيق.')}`,async data=>ctx.command('book_shipment.cancel',{id:row.id,...data}),'تأكيد إلغاء البيان');
}

export function renderInventory(ctx, kind = 'equipment') {
  const books = kind === 'book', items = itemSet(ctx, kind), ids = new Set(items.map(x => x.id));
  const rows = itemRows(ctx, items).filter(({item, stock}) => includes(ctx, [item.name, item.title, item.isbn, item.edition, item.id, ctx.name('stakeholders', item.owner_id), ctx.name('zones', stock.zone_id)]) && (!ctx.status || ctx.status === 'all' || (ctx.status === 'empty' ? stock.on_hand === 0 && stock.maintenance === 0 : stock[ctx.status] > 0)));
  const moves = all(ctx, 'stock_moves').filter(x => ids.has(x.item_id)).slice().reverse();
  const create = actionButton(ctx, books ? 'إضافة عنوان كتاب' : 'إضافة صنف', 'inventory-new-item', 'item.create', {kind}, 'primary', 'plus');
  const move = actionButton(ctx, books ? 'نقل أو صرف كتب' : 'تسجيل حركة', 'inventory-move', 'stock.move', {kind}, 'secondary', 'warehouse');
  const count = actionButton(ctx, 'جرد جديد', 'inventory-count', 'stock.count', {kind}, 'secondary', 'check');
  const counts = all(ctx, 'stock_counts').filter(c => ids.has(c.item_id)).slice().reverse();
  const reservations = all(ctx, 'reservations').filter(x => ids.has(x.item_id) && x.qty > 0);
  const custody = all(ctx, 'custody').filter(x => ids.has(x.item_id) && x.outstanding > 0 && x.kind !== 'order');
  return heading('المخزون والعهد', books ? 'مستودع الكتب' : 'مستودع التشغيل', books ? 'رصيد مستقل لكل ناشر وعنوان وطبعة وموقع، من استلام الشحنة حتى تسليم الجناح وإرجاع المتبقي.' : 'المعدات والأثاث والأجهزة والمواد الاستهلاكية، مع الحجز والعهد والنقل والاسترجاع والصيانة.', create + move + count) +
    `<div class="kpi-grid">${kpi('الموجود في المستودع', quantities(ctx, items, 'on_hand'), 'يشمل الكمية المحجوزة؛ يستبعد العهد والصيانة')}${kpi('المتاح للصرف', quantities(ctx, items, 'available'), 'الموجود ناقص المحجوز')}${kpi('المحجوز', quantities(ctx, items, 'reserved'), `${n(reservations.length)} حجز نشط`)}${kpi('في الصيانة', quantities(ctx, items, 'maintenance'), `${n(custody.length)} عهدة تشغيلية مفتوحة`)}</div>` +
    filterbar(ctx, [{id: 'available', name: 'له رصيد متاح'}, {id: 'reserved', name: 'له حجز'}, {id: 'maintenance', name: 'في الصيانة'}, {id: 'empty', name: 'دون رصيد بالموقع'}], rows.length, books ? 'العنوان، الناشر، ISBN أو الموقع…' : 'الصنف، المالك أو الموقع…') +
    `<section class="panel"><div class="panel-head"><div><h2>${books ? 'عناوين الكتب وأرصدتها' : 'الأصناف وأرصدتها'}</h2><p>${n(items.length)} صنف · كل سطر يمثل موقعًا؛ الأرصدة من دفتر الحركات</p></div></div>${rows.length ? table([books ? 'العنوان / الطبعة' : 'الصنف', 'المالك / الناشر', 'الموقع', 'الموجود', 'المتاح', 'المحجوز', 'الصيانة', 'الإجراءات'], rows.map(({item, stock}) => `<tr><td><span class="cell-title">${esc(item.name)}</span><span class="cell-sub">${books ? `${esc(item.edition || 'طبعة غير محددة')} · ISBN: ${esc(item.isbn || 'غير متوفر')}` : esc(label(item.kind))}</span></td><td>${esc(ctx.name('stakeholders', item.owner_id))}</td><td>${esc(stock.zone_id ? ctx.name('zones', stock.zone_id) : 'لم يُستلم بعد')}</td><td><span class="quantity">${n(stock.on_hand)}</span> <small>${esc(item.unit)}</small></td><td>${n(stock.available)}</td><td>${n(stock.reserved)}</td><td>${n(stock.maintenance)}</td><td><div class="cell-actions">${button('التفاصيل', 'inventory-detail', 'small', '', attrs({id: item.id}))}${actionButton(ctx, books ? 'نقل / صرف' : 'حركة', 'inventory-move', 'stock.move', {id: item.id, zone: stock.zone_id, kind})}</div></td></tr>`)) : empty(items.length ? 'لا نتائج مطابقة' : books ? 'لا توجد كتب مسجلة' : 'لا توجد أصناف مسجلة', items.length ? 'عدّل البحث أو تصفية الرصيد.' : books ? 'أضف العنوان، ثم سجّل بيان شحنة الناشر واستلامه الفعلي.' : 'أضف الصنف ثم سجّل محضر الاستلام لبناء الرصيد.', items.length ? '' : create)}</section>` +
    `<section class="panel"><div class="panel-head"><div><h2>الجرد وفروقات الرصيد</h2><p>${n(counts.filter(c => c.status === 'pending').length)} فرق ينتظر المراجعة · الإقفال يحتاج جردًا مطابقًا أو معتمدًا بعد آخر حركة لكل موقع</p></div>${count}</div>${countTable(ctx, counts)}</section>` +
    `<section class="panel"><div class="panel-head"><div><h2>آخر حركات المستودع</h2><p>آخر ${n(Math.min(12, moves.length))} حركة؛ تفاصيل كل صنف تعرض سجله كاملًا</p></div></div>${movementTable(ctx, moves.slice(0, 12))}</section>${books?shipmentPanel(ctx):''}`;
}

function stockCount(ctx, element) {
  const selected = byId(ctx, 'items', element.dataset.id);
  const items = selected ? ctx.records('items') : itemSet(ctx, element.dataset.kind || 'equipment');
  if (!items.length || !ctx.records('zones').length) return detail('تهيئة الجرد', note('أضف صنفًا ومنطقة قبل تسجيل محضر الجرد.'));
  const dialog = modal('محضر جرد فعلي', `<div class="form-grid">${select('item_id', 'الصنف الجاري جرده', items, selected?.id || items[0].id, 'required')}${field('counted_qty', 'الكمية المعدودة فعليًا', 'number', '', 'required min="0" max="1000000" step="1" inputmode="numeric"')}${ctx.commonFields({project_id: ctx.projectId, zone_id: element.dataset.zone || ''})}${textarea('evidence', 'مرجع محضر الجرد / إثبات العد', '', 'required maxlength="4000"')}${textarea('notes', 'ملاحظات حالة الصنف', '', 'maxlength="4000"')}</div><p class="field-help" data-count-balance aria-live="polite"></p>${note('عُد الموجود في الموقع بما فيه المحجوز، واستبعد المعدات المسلّمة بعهدة أو المحالة للصيانة. المطابق يوثق الجرد؛ الفرق لا يغير الرصيد حتى يعتمد المدير تسويته.')}`, data => ctx.command('stock.count', {...data, counted_qty: Number(data.counted_qty)}), 'تسجيل الجرد', true);
  const form = dialog.querySelector('form');
  const update = () => {
    form.elements.zone_id.required = true;
    const b = balance(ctx, form.elements.item_id.value, form.elements.zone_id.value);
    dialog.querySelector('[data-count-balance]').textContent = `الموجود الدفتري في الموقع: ${n(b.on_hand)} · المحجوز ضمنه: ${n(b.reserved)} · خارج الرصيد بالصيانة: ${n(b.maintenance)}.`;
  };
  form.addEventListener('change', update); update();
}
function countDetail(ctx, id) {
  const c = requireRecord(ctx, 'stock_counts', id);
  detail(`محضر جرد ${c.id}`, `<div class="actions">${badge(c.status, countLabel(c.status))}${c.status === 'pending' ? actionButton(ctx, 'مراجعة فرق الجرد', 'inventory-count-review', 'stock.count.review', {id}) : ''}${actionButton(ctx, 'تسجيل جرد جديد', 'inventory-count', 'stock.count', {id: c.item_id, zone: c.zone_id})}</div><div class="details-grid mt">${info('الصنف', ctx.name('items', c.item_id))}${info('الموقع', ctx.name('zones', c.zone_id))}${info('الرصيد الدفتري عند الجرد', n(c.expected_qty))}${info('العد الفعلي', n(c.counted_qty))}${info('الفرق', `${c.variance > 0 ? '+' : ''}${n(c.variance)}`)}${info('المسؤول', ctx.name('stakeholders', c.responsible_id))}${info('التاريخ', date(c.created_at))}${info('صلاحية الجرد للإقفال', countCurrent(ctx, c) && ['matched', 'approved'].includes(c.status) ? 'يعكس آخر حركة لهذا الصنف والموقع' : 'يحتاج معالجة الفرق أو جردًا جديدًا بعد الحركة')}</div><h3 class="form-section">إثبات العد</h3><p>${esc(c.evidence)}</p>${c.review_evidence ? `<h3 class="form-section">مراجعة الفرق</h3><p>${esc(c.review_evidence)}</p><p>${esc(c.reason)}</p>` : ''}${c.notes ? `<p class="mt">${esc(c.notes)}</p>` : ''}${recordEvidence(ctx, 'stock_counts', c.id)}`);
}
function reviewCount(ctx, id) {
  const c = requireRecord(ctx, 'stock_counts', id), current = countCurrent(ctx, c);
  if (c.status !== 'pending') throw new Error('هذا الجرد لا ينتظر مراجعة فرق.');
  modal('مراجعة فرق الجرد', `<div class="details-grid">${info('الصنف', ctx.name('items', c.item_id))}${info('الموقع', ctx.name('zones', c.zone_id))}${info('الدفتري وقت الجرد', n(c.expected_qty))}${info('المعدود', n(c.counted_qty))}</div>${!current ? note('تحرك المخزون بعد هذا الجرد؛ لا يمكن اعتماد تسويته. ارفض المحضر بسبب موثق ثم سجّل جردًا جديدًا.') : note('الاعتماد يعدّل الموجود إلى الكمية المعدودة، ويسجل قيد تسوية مستقلًا. لا يجوز أن تقل النتيجة عن المحجوز.')}<div class="form-grid mt">${select('status', 'قرار المراجعة', current ? [{id: 'approved', name: 'اعتماد الفرق وتسوية الرصيد'}, {id: 'rejected', name: 'رفض الفرق وطلب إعادة الجرد'}] : [{id: 'rejected', name: 'رفض المحضر المتقادم'}], '', 'required')}${textarea('reason', 'سبب اعتماد أو رفض الفرق', '', 'required maxlength="2000"')}${textarea('evidence', 'محضر معالجة الفرق / مرجع الاعتماد', '', 'required maxlength="4000"')}</div>`, data => ctx.command('stock.count.review', {id, ...data}), 'تسجيل قرار المراجعة');
}

function requireRecord(ctx, collection, id) {
  const row = byId(ctx, collection, id);
  if (!row) throw new Error('السجل غير موجود. حدّث الصفحة ثم أعد المحاولة.');
  return row;
}

function itemDetail(ctx, id) {
  const item = requireRecord(ctx, 'items', id), stocks = all(ctx, 'stock').filter(x => x.item_id === id);
  const reservations = all(ctx, 'reservations').filter(x => x.item_id === id && x.qty > 0);
  const custody = all(ctx, 'custody').filter(x => x.item_id === id && x.outstanding > 0);
  const itemMoves = all(ctx, 'stock_moves').filter(x => x.item_id === id).slice().reverse();
  detail(item.name, `<div class="details-grid">${info('النوع', label(item.kind))}${info('المالك / الناشر', ctx.name('stakeholders', item.owner_id))}${info('الطبعة', item.edition)}${info('ISBN', item.isbn)}${info('الوحدة', item.unit)}${info('مصدر البيانات', label(item.provenance))}</div><div class="actions">${actionButton(ctx, item.kind === 'book' ? 'نقل أو صرف كتب' : 'تسجيل حركة', 'inventory-move', 'stock.move', {id, kind: item.kind === 'book' ? 'book' : 'equipment'}, 'primary', 'plus')}</div><h3 class="form-section">الأرصدة حسب الموقع</h3>${stocks.length ? table(['الموقع', 'الموجود', 'المتاح', 'المحجوز', 'الصيانة'], stocks.map(s => `<tr><td>${esc(ctx.name('zones', s.zone_id))}</td><td>${n(s.on_hand)}</td><td>${n(s.available)}</td><td>${n(s.reserved)}</td><td>${n(s.maintenance)}</td></tr>`)) : note('لم يسجل استلام لهذا الصنف بعد.')}<h3 class="form-section">الحجوزات النشطة</h3>${reservations.length ? table(['المرجع', 'الموقع', 'الكمية', 'الإجراء'], reservations.map(r => `<tr><td>${esc(r.reference)}</td><td>${esc(ctx.name('zones', r.zone_id))}</td><td>${n(r.qty)}</td><td>${r.reference.startsWith('order:') ? 'يدار من طلب الزائر' : actionButton(ctx, 'تحرير الحجز', 'inventory-move', 'stock.move', {id, zone: r.zone_id, operation: 'release', reference: r.reference, qty: r.qty})}</td></tr>`)) : note('لا حجوزات نشطة.')}<h3 class="form-section">العهد المفتوحة</h3>${custody.length ? table(['المرجع', 'صاحب العهدة', 'المتبقي', 'الإجراء'], custody.map(c => `<tr><td>${esc(c.reference)}</td><td>${esc(c.kind === 'order' ? 'طلب زائر' : ctx.name('stakeholders', c.custodian_id))}</td><td>${n(c.outstanding)}</td><td>${c.kind === 'order' ? 'يدار من طلب الزائر' : custodyButtons(ctx, id, c)}</td></tr>`)) : note('لا عهد مفتوحة.')}<h3 class="form-section">دفتر الحركة</h3>${movementTable(ctx, itemMoves)}${item.notes ? `<h3 class="form-section">ملاحظات</h3><p>${esc(item.notes)}</p>` : ''}${recordEvidence(ctx, 'items', id)}`);
}

function newItem(ctx, kind) {
  const book = kind === 'book';
  modal(book ? 'إضافة عنوان إلى مستودع الكتب' : 'إضافة صنف تشغيلي', `<div class="form-grid">${field('name', book ? 'عنوان الكتاب' : 'اسم الصنف', 'text', '', 'required maxlength="240"')}${select('kind', 'نوع الصنف', book ? ['book'] : ['equipment', 'consumable'], book ? 'book' : 'equipment', 'required')}${select('owner_id', book ? 'الناشر / مالك النسخ' : 'مالك الصنف', [blank(), ...ctx.records('stakeholders')], '', book ? 'required' : '')}${field('unit', 'وحدة القياس', 'text', book ? 'نسخة' : 'قطعة', 'required maxlength="40"')}${book ? field('edition', 'الطبعة', 'text', '', 'maxlength="120"') + field('isbn', 'ISBN إن وجد', 'text', '', 'maxlength="40" dir="ltr"') : ''}${ctx.commonFields({project_id: ctx.projectId})}${textarea('notes', 'ملاحظات', '', 'maxlength="4000"')}</div>${note(book ? 'تعريف الكتاب لا يضيف رصيدًا. أنشئ بيان شحنة واردة ثم أثبت الكمية المستلمة.' : 'تعريف الصنف لا يضيف رصيدًا. سجّل حركة استلام مستقلة مع إثباتها بعد الحفظ.') }`, async data => ctx.command('item.create', {...data, title: data.name}), 'حفظ الصنف', true);
}

function custodyButtons(ctx, id, custody) {
  return `<div class="cell-actions">${actionButton(ctx, 'استرجاع', 'inventory-move', 'stock.move', {id, operation: 'return', reference: custody.reference, qty: custody.outstanding})}${actionButton(ctx, 'تسوية عهدة', 'inventory-settle', 'stock.settle', {id, reference: custody.reference, qty: custody.outstanding})}</div>`;
}
function settleCustody(ctx, element) {
  const item = requireRecord(ctx, 'items', element.dataset.id), reference = element.dataset.reference;
  const custody = all(ctx, 'custody').find(c => c.item_id === item.id && c.reference === reference);
  if (!custody || custody.kind === 'order' || custody.outstanding <= 0) throw new Error('لا توجد عهدة تشغيلية مفتوحة لهذا المرجع.');
  const options = [{id: 'final_delivery', name: 'تسليم نهائي موثق'}, {id: 'loss_damage', name: 'فقد أو تلف معتمد'}];
  if (item.kind === 'book') options.unshift({id: 'publisher_sold', name: 'مبيعات ناشر مثبتة'});
  if (item.kind === 'consumable') options.unshift({id: 'consumed', name: 'مواد استُهلكت بعد الصرف'});
  modal('تسوية عهدة مصروفة', `<div class="details-grid">${info('الصنف', item.name)}${info('صاحب العهدة', ctx.name('stakeholders', custody.custodian_id))}${info('مرجع العهدة', reference)}${info('المتبقي المفتوح', `${n(custody.outstanding)} ${item.unit}`)}</div><div class="form-grid">${field('qty', 'الكمية المراد تسويتها', 'number', custody.outstanding, `required min="1" max="${custody.outstanding}" step="1"`)}${select('disposition', 'سبب انتهاء العهدة', options, '', 'required')}${textarea('reason', 'تفاصيل التسوية وسببها', '', 'required maxlength="2000"')}${textarea('evidence', 'محضر اعتماد التسوية', '', 'required maxlength="4000"')}</div>${note('تخفض هذه الخطوة العهدة المفتوحة وتسجل أثرها، ولا تعيد الكمية إلى المستودع. لاسترجاع كمية فعلية استخدم «استرجاع». مبيعات الناشر هنا إقرار كميات موثق، ولا تثبت دفعًا أو تسوية مالية.')}`, data => ctx.command('stock.settle', {item_id: item.id, reference, ...data, qty: Number(data.qty)}), 'اعتماد تسوية العهدة');
}

const movementNames = ['receipt', 'reserve', 'release', 'issue', 'return', 'transfer', 'maintenance', 'restore', 'ship', 'consume'];
function movement(ctx, element) {
  const selected = byId(ctx, 'items', element.dataset.id);
  const items = selected ? ctx.records('items') : itemSet(ctx, element.dataset.kind || 'equipment');
  if (!items.length || !ctx.records('zones').length) return detail('لا يمكن تسجيل الحركة بعد', note('أضف صنفًا ومنطقة إلى المشروع أولًا.'));
  const operation = element.dataset.operation || (items[0]?.kind === 'book' ? 'transfer' : 'receipt');
  const dialog = modal('تسجيل حركة مستودع', `<div class="form-grid">${select('item_id', 'الصنف', items, selected?.id || items[0].id, 'required')}${select('action', 'نوع الحركة', movementNames.map(id => ({id, name: id === 'consume' ? 'استهلاك مواد مباشر' : label(id)})), operation, 'required')}${qty('qty', element.dataset.qty || 1)}${field('reference', 'مرجع الحجز / الطلب / العهدة', 'text', element.dataset.reference || '', 'maxlength="160"')}${ctx.commonFields({project_id: ctx.projectId, zone_id: element.dataset.zone || ''})}${select('to_zone_id', 'منطقة الوجهة للنقل', [blank(), ...ctx.records('zones')])}${select('custodian_id', 'صاحب العهدة عند الصرف', [blank(), ...ctx.records('stakeholders')])}${textarea('evidence', 'مرجع محضر الاستلام أو التسليم / الإثبات', '', 'maxlength="4000"')}${textarea('reason', 'سبب الحركة / الاستثناء', '', 'maxlength="2000"')}</div><p class="field-help" data-stock-summary aria-live="polite"></p>${note('استلام كتب الناشر ومرتجعها يتطلبان بيان شحنة؛ هنا تنفذ النقل والصرف والعهد فقط. مراجع order: وprocurement: وbook_shipment: تديرها دوراتها المسجلة. الإثبات هنا مرجع نصي، وليس ملفًا مرفوعًا.') }`, async data => ctx.command('stock.move', {...data, qty: Number(data.qty)}), 'تسجيل الحركة', true);
  const form = dialog.querySelector('form');
  const update = () => {
    const item = byId(ctx, 'items', form.elements.item_id.value), action = form.elements.action.value;
    const b = balance(ctx, item?.id, form.elements.zone_id?.value);
    dialog.querySelector('[data-stock-summary]').textContent = `الموقع المختار: موجود ${n(b.on_hand)} · متاح ${n(b.available)} · محجوز ${n(b.reserved)} · صيانة ${n(b.maintenance)} ${item?.unit || ''}. يتحقق الخادم من الرصيد والعهدة عند التسجيل.`;
    form.elements.reference.required = ['reserve', 'release', 'issue', 'return', 'consume'].includes(action);
    form.elements.evidence.required = !['reserve', 'release'].includes(action);
    form.elements.to_zone_id.required = action === 'transfer';
    form.elements.to_zone_id.disabled = action !== 'transfer';
    form.elements.custodian_id.required = action === 'issue';
    form.elements.custodian_id.disabled = action !== 'issue';
    if (form.elements.zone_id) form.elements.zone_id.required = true;
    if (form.elements.responsible_id) form.elements.responsible_id.required = action === 'consume';
    for (const option of form.elements.action.options) option.disabled = (['maintenance', 'restore'].includes(option.value) && item?.kind !== 'equipment') || (option.value === 'consume' && item?.kind !== 'consumable') || (item?.kind === 'book' && ['receipt','ship'].includes(option.value));
    if (form.elements.action.selectedOptions[0]?.disabled) {form.elements.action.value = item?.kind === 'book' ? 'transfer' : 'receipt'; update();}
  };
  form.addEventListener('change', update); update();
}

const orderStatusNames = ['ordered', 'picking', 'packed', 'shipped', 'delivered', 'exception', 'returned', 'cancelled'];
const orderActionNames = {picking: 'بدء التجميع', packed: 'تأكيد التغليف', shipped: 'تسليم للناقل', delivered: 'تأكيد التسليم', returned: 'استلام مرتجع', cancelled: 'إلغاء الطلب', exception: 'تسجيل استثناء'};
function orderTargets(order) {
  const map = {ordered: ['picking', 'exception', 'cancelled'], picking: ['packed', 'exception', 'cancelled'], packed: ['shipped', 'exception', 'cancelled'], shipped: ['delivered', 'exception', 'returned'], delivered: ['returned'], exception: [order.previous_status || 'ordered', order.dispatched ? 'returned' : 'cancelled'], returned: [], cancelled: []};
  return map[order.status] || [];
}
const transitionText = (order, target) => order.status === 'exception' && target === order.previous_status ? `معالجة الاستثناء والعودة إلى ${label(target)}` : (orderActionNames[target] || label(target));
function orderButtons(ctx, order, allTargets = false) {
  return (allTargets ? orderTargets(order) : orderTargets(order).slice(0, 1)).map(target => actionButton(ctx, transitionText(order, target), 'order-transition', 'order.transition', {id: order.id, status: target}, ['exception', 'cancelled', 'returned'].includes(target) ? 'danger' : 'small')).join('');
}
function historyTable(history = []) {
  return history.length ? table(['التاريخ', 'الانتقال', 'الإثبات', 'السبب'], history.slice().reverse().map(h => `<tr><td>${esc(date(h.at))}</td><td>${esc(label(h.from))} ← ${esc(label(h.to))}</td><td><span class="cell-sub" title="${esc(h.evidence)}">${esc(h.evidence || '—')}</span></td><td><span class="cell-sub" title="${esc(h.reason)}">${esc(h.reason || '—')}</span></td></tr>`)) : note('لم تسجل انتقالات بعد.');
}

export function renderOrders(ctx) {
  const allOrders = ctx.records('orders'), orders = allOrders.filter(o => statusMatch(ctx, o.status) && includes(ctx, [o.id, o.customer_name, o.tracking_number, o.carrier, ...(o.lines || []).map(l => l.title)]));
  const active = allOrders.filter(x => !['delivered', 'returned', 'cancelled'].includes(x.status));
  const create = actionButton(ctx, 'طلب زائر جديد', 'order-new', 'order.create', {}, 'primary', 'plus');
  return heading('خدمة الزائر والشحن', 'مشتريات الزوار', 'طلب واحد يجمع كتب عدة ناشرين، ويحجزها حتى التجميع والتغليف والشحن وإثبات التسليم.', create) +
    `<div class="kpi-grid">${kpi('الطلبات النشطة', n(active.length), 'الطلبات التي لم تقفل', 'orders')}${kpi('التجميع والتغليف', n(allOrders.filter(x => ['picking', 'packed'].includes(x.status)).length), 'قيد التجهيز قبل تسليم الناقل', 'books')}${kpi('لدى الناقل', n(allOrders.filter(x => x.status === 'shipped').length), 'حالة يسجلها المسؤول يدويًا', 'orders')}${kpi('استثناءات مفتوحة', n(allOrders.filter(x => x.status === 'exception').length), 'تحتاج سببًا وإجراء معالجة', 'alert')}</div>` +
    filterbar(ctx, orderStatusNames, orders.length, 'رقم الطلب، المستلم، عنوان الكتاب أو التتبع…') +
    `<div class="source-card no-margin"><p>الدفع وتسويات الناشرين غير مدمجة. بيانات الناقل ورقم التتبع وتأكيد التسليم تُدخل يدويًا مع الإثبات؛ لا يوجد تتبع حي متصل.</p></div><div class="order-grid mt">${orders.length ? orders.slice().reverse().map(o => {
      const total = (o.lines || []).reduce((sum, l) => sum + l.qty, 0);
      return `<article class="order-card"><div class="order-card-top"><span class="mono">${esc(o.id)}</span>${badge(o.status)}</div><h3>${esc(o.customer_name)}</h3><p>${esc(date(o.created_at))} · ${n(o.lines.length)} بند · ${n(total)} نسخة</p><div class="order-items">${o.lines.slice(0, 3).map(l => `<div class="order-item"><span>${esc(l.title || ctx.name('items', l.item_id))}</span><strong>× ${n(l.qty)}</strong></div>`).join('')}${o.lines.length > 3 ? `<small>و${n(o.lines.length - 3)} بنود أخرى</small>` : ''}</div><p>${o.tracking_number ? `تتبع يدوي: ${esc(o.carrier)} · <span class="mono">${esc(o.tracking_number)}</span>` : 'لم يسجل تسليم للناقل بعد'}</p><div class="order-card-foot mt">${button('تفاصيل الطلب', 'order-detail', 'small', '', attrs({id: o.id}))}${orderButtons(ctx, o)}</div></article>`;
    }).join('') : `<div class="wide">${empty(allOrders.length ? 'لا طلبات مطابقة' : 'لا توجد طلبات زوار بعد', allOrders.length ? 'عدّل البحث أو الحالة.' : 'أضف طلبًا من الكتب المتاحة، وسيحجز المخزون عند الحفظ.', allOrders.length ? '' : create)}</div>`}</div>`;
}

function orderDetail(ctx, id) {
  const o = requireRecord(ctx, 'orders', id);
  detail(`طلب ${o.id}`, `<div class="actions">${badge(o.status)}${badge(o.provenance)}${orderButtons(ctx, o, true)}</div><div class="details-grid mt">${info('المستلم', o.customer_name)}${info('هاتف المستلم', o.customer_phone)}${info('عنوان التسليم', o.address)}${info('المسؤول', ctx.name('stakeholders', o.responsible_id))}${info('شركة الشحن — إدخال يدوي', o.carrier)}${info('رقم التتبع — إدخال يدوي', o.tracking_number)}${info('المشروع', ctx.name('projects', o.project_id))}${info('المرحلة', ctx.name('phases', o.phase_id))}</div>${table(['الكتاب', 'الناشر / المالك', 'موقع المصدر', 'الكمية'], o.lines.map(l => `<tr><td>${esc(l.title || ctx.name('items', l.item_id))}</td><td>${esc(ctx.name('stakeholders', l.owner_id))}</td><td>${esc(ctx.name('zones', l.zone_id))}</td><td>${n(l.qty)}</td></tr>`))}${note(`مرجع المخزون: order:${o.id}. الإلغاء قبل الشحن يحرر الحجز؛ المرتجع بعد الشحن يعيد الكمية إلى مواقع المصدر. لا توجد دفعات مالية أو مزامنة ناقل مدمجة.`)}<h3 class="form-section">سجل الطلب</h3>${historyTable(o.history)}${o.evidence ? `<h3 class="form-section">إثبات الطلب</h3><p>${esc(o.evidence)}</p>` : ''}${o.notes ? `<h3 class="form-section">ملاحظات</h3><p>${esc(o.notes)}</p>` : ''}${recordEvidence(ctx, 'orders', id)}`);
}

function lineHTML(ctx) {
  return `<div class="line-editor" data-order-line>${select('line_item_id', 'الكتاب', itemSet(ctx, 'book'), '', 'required')}${select('line_zone_id', 'موقع السحب', ctx.records('zones'), '', 'required')}${qty('line_qty')}${button('حذف', 'order-remove-line', 'small', 'close', 'aria-label="حذف بند الكتاب"')}<p class="field-help wide" data-line-stock></p></div>`;
}
function updateLine(ctx, row) {
  const item = byId(ctx, 'items', row.querySelector('[name=line_item_id]').value), zone = row.querySelector('[name=line_zone_id]').value;
  const stock = balance(ctx, item?.id, zone);
  row.querySelector('[data-line-stock]').textContent = `الناشر: ${ctx.name('stakeholders', item?.owner_id)} · المتاح في الموقع: ${n(stock.available)} ${item?.unit || 'نسخة'} · الطبعة: ${item?.edition || 'غير محددة'}`;
}
function addLine(ctx, container) {
  if (container.querySelectorAll('[data-order-line]').length >= 100) throw new Error('الحد الأعلى 100 بند في الطلب.');
  const template = document.createElement('template'); template.innerHTML = lineHTML(ctx);
  const row = template.content.firstElementChild; container.append(row); updateLine(ctx, row);
}
function newOrder(ctx) {
  if (!itemSet(ctx, 'book').length || !ctx.records('zones').length) return detail('تهيئة طلبات الزوار', note('أضف كتابًا ومنطقة، ثم سجّل استلام نسخ متاحة قبل إنشاء الطلب.'));
  const dialog = modal('طلب مشتريات زائر', `<div class="form-grid">${field('customer_name', 'اسم المستلم', 'text', '', 'required maxlength="200"')}${field('customer_phone', 'هاتف المستلم', 'tel', '', 'maxlength="60" dir="ltr"')}${textarea('address', 'عنوان التسليم للشحن', '', 'required maxlength="1000"')}${ctx.commonFields({project_id: ctx.projectId})}</div><h3 class="form-section">بنود الطلب</h3><div data-order-lines></div>${button('إضافة كتاب', 'order-add-line', 'secondary', 'plus')}${note('يحجز الطلب جميع البنود عند الحفظ في عملية واحدة. اختر موقعًا يملك رصيدًا متاحًا، وادمج الكتاب المكرر في الموقع نفسه.')}<div class="form-grid mt">${textarea('evidence', 'مرجع طلب الزائر / الإثبات', '', 'maxlength="4000"')}${textarea('notes', 'تعليمات التجميع والتغليف', '', 'maxlength="4000"')}</div>${note('هذا سجل تجهيز وشحن؛ لا يسجل دفعًا أو تسوية مالية.')}`, async (data, form) => {
    const seen = new Set();
    const lines = [...form.querySelectorAll('[data-order-line]')].map(row => {
      const line = {item_id: row.querySelector('[name=line_item_id]').value, zone_id: row.querySelector('[name=line_zone_id]').value, qty: Number(row.querySelector('[name=line_qty]').value)};
      const key = `${line.item_id}@${line.zone_id}`;
      if (seen.has(key)) throw new Error('ادمج البنود المتكررة للكتاب والموقع نفسيهما.'); seen.add(key);
      if (!Number.isInteger(line.qty) || line.qty <= 0) throw new Error('أدخل كمية صحيحة موجبة لكل بند.');
      if (line.qty > balance(ctx, line.item_id, line.zone_id).available) throw new Error(`الكمية المطلوبة تتجاوز المتاح للكتاب: ${ctx.name('items', line.item_id)}`);
      return line;
    });
    const {line_item_id, line_zone_id, line_qty, ...header} = data;
    await ctx.command('order.create', {...header, lines});
  }, 'حفظ الطلب وحجز الكتب', true);
  addLine(ctx, dialog.querySelector('[data-order-lines]'));
  dialog.querySelector('form').addEventListener('change', event => {const row = event.target.closest('[data-order-line]'); if (row) updateLine(ctx, row);});
}
function transitionOrder(ctx, element) {
  const order = requireRecord(ctx, 'orders', element.dataset.id), target = element.dataset.status;
  if (!orderTargets(order).includes(target)) throw new Error('تغيرت حالة الطلب. افتح تفاصيله مجددًا.');
  const returning = target === 'returned', cancelling = target === 'cancelled', shipping = target === 'shipped' && order.status !== 'exception';
  const needEvidence = !['picking', 'exception'].includes(target) || order.status === 'exception';
  modal(transitionText(order, target), `${note(`${order.id} · ${order.customer_name}`)}<div class="form-grid mt">${shipping ? field('carrier', 'شركة الشحن', 'text', '', 'required maxlength="200"') + field('tracking_number', 'رقم التتبع من الناقل', 'text', '', 'required maxlength="160" dir="ltr"') : ''}${textarea('evidence', order.status === 'exception' ? 'إثبات معالجة الاستثناء' : 'مرجع إثبات الإجراء', '', `${needEvidence ? 'required' : ''} maxlength="4000"`)}${textarea('reason', returning ? 'سبب المرتجع' : cancelling ? 'سبب الإلغاء' : 'سبب الاستثناء / ملاحظة', '', `${['exception', 'cancelled', 'returned'].includes(target) ? 'required' : ''} maxlength="2000"`)}</div>${note(shipping ? 'التأكيد يصرف الكتب المحجوزة ويسجلها لدى الناقل. رقم التتبع يدوي ولا يشغّل تكاملًا خارجيًا.' : returning ? 'يسجل مرتجعًا كاملًا لبنود الطلب ويعيدها إلى مواقع السحب الأصلية. لا يدعم مرتجعًا جزئيًا في هذه الخطوة.' : cancelling ? 'الإلغاء يحرر كامل حجوزات الطلب. لا يمكن إلغاء طلب سُلّم للناقل.' : 'يسجل الإجراء والوقت في تاريخ الطلب.')}`, data => ctx.command('order.transition', {id: order.id, status: target, ...data}), 'تأكيد الإجراء');
}

const procurementLabel = status => ({planned: 'طلب احتياج', approved: 'معتمد', ordered: 'أمر شراء صادر', received: 'مستلم في المخزون'}[status] || label(status));
const procurementNext = row => ({planned: 'approved', approved: 'ordered', ordered: 'received'}[row.status]);
function procurementCan(ctx, target) {
  return ctx.can('procurement.transition') && (!['approved', 'ordered'].includes(target) || ['admin', 'manager'].includes(ctx.state.user?.role));
}
function procurementButton(ctx, row) {
  const target = procurementNext(row);
  return target ? button(({approved: 'اعتماد الاحتياج', ordered: 'تسجيل أمر الشراء', received: 'تأكيد الاستلام'}[target]), 'procurement-transition', 'small', '', `${attrs({id: row.id, status: target})} ${procurementCan(ctx, target) ? '' : 'disabled title="يتطلب الإجراء صلاحية الاعتماد المناسبة"'}`) : '';
}
export function renderProcurement(ctx) {
  const records = ctx.records('procurements'), rows = records.filter(p => statusMatch(ctx, p.status) && includes(ctx, [p.id, p.title, ctx.name('items', p.item_id), ctx.name('stakeholders', p.supplier_id), ctx.name('zones', p.zone_id)]));
  const create = actionButton(ctx, 'طلب احتياج جديد', 'procurement-new', 'procurement.create', {}, 'primary', 'plus');
  return heading('الاحتياج والتوريد', 'المشتريات', 'يرتبط طلب الاحتياج بالصنف والمورد ومنطقة الاستلام. يُضاف الرصيد عند تأكيد الاستلام الفعلي.', create) +
    `<div class="kpi-grid">${['planned', 'approved', 'ordered', 'received'].map(status => kpi(procurementLabel(status), n(records.filter(x => x.status === status).length), status === 'received' ? 'أضيفت كمياتها بدفتر الاستلام' : 'لا تزيد المخزون قبل الاستلام', 'procurement')).join('')}</div>` +
    filterbar(ctx, ['planned', 'approved', 'ordered', 'received'].map(id => ({id, name: procurementLabel(id)})), rows.length, 'الطلب، الصنف، المورد أو منطقة الاستلام…') +
    `<section class="panel"><div class="panel-head"><div><h2>طلبات الاحتياج والتوريد</h2><p>سجل كميات واعتمادات؛ لا يمثل فاتورة أو عملية دفع أو تسوية ضريبية</p></div></div>${rows.length ? table(['الطلب / الصنف', 'المورد', 'منطقة الاستلام', 'الكمية', 'الحالة', 'الإجراء'], rows.slice().reverse().map(p => `<tr><td><span class="cell-title">${esc(p.title)}</span><span class="cell-sub">${esc(ctx.name('items', p.item_id))} · ${esc(p.id)}</span></td><td>${esc(ctx.name('stakeholders', p.supplier_id))}</td><td>${esc(ctx.name('zones', p.zone_id))}</td><td>${n(p.qty)} <small>${esc(byId(ctx, 'items', p.item_id)?.unit)}</small></td><td>${badge(p.status, procurementLabel(p.status))}</td><td><div class="cell-actions">${button('التفاصيل', 'procurement-detail', 'small', '', attrs({id: p.id}))}${procurementButton(ctx, p)}</div></td></tr>`)) : empty(records.length ? 'لا طلبات مطابقة' : 'لا توجد طلبات احتياج', records.length ? 'عدّل البحث أو الحالة.' : 'حدد الصنف والمورد والكمية ومنطقة الاستلام.', records.length ? '' : create)}</section>`;
}

function newProcurement(ctx) {
  if (!ctx.records('items').some(item=>item.kind!=='book') || !ctx.records('zones').length || !ctx.records('stakeholders').length) return detail('تهيئة المشتريات', note('أضف الصنف ومنطقة الاستلام وجهة المورد إلى المشروع أولًا.'));
  modal('طلب احتياج وتوريد', `<div class="form-grid">${field('title', 'عنوان الاحتياج', 'text', '', 'required maxlength="240"')}${select('item_id', 'الصنف', ctx.records('items').filter(item=>item.kind!=='book'), '', 'required')}${qty()}${select('supplier_id', 'المورد / الجهة الموردة', [blank(), ...ctx.records('stakeholders')], '', 'required')}${ctx.commonFields({project_id: ctx.projectId})}${textarea('evidence', 'مرجع طلب الاحتياج', '', 'maxlength="4000"')}${textarea('notes', 'المواصفات وتعليمات التسليم', '', 'maxlength="4000"')}</div>${note('كل سجل يخص صنفًا واحدًا وكمية كاملة. بعد الاعتماد وإصدار أمر الشراء، يضيف تأكيد الاستلام كامل الكمية إلى الموقع المختار. لا تسجل هذه الخطوة دفعًا أو فاتورة.')}`, data => {
    if (!data.zone_id) throw new Error('حدد منطقة الاستلام.');
    return ctx.command('procurement.create', {...data, qty: Number(data.qty)});
  }, 'حفظ طلب الاحتياج', true);
}
function procurementDetail(ctx, id) {
  const p = requireRecord(ctx, 'procurements', id);
  detail(p.title, `<div class="actions">${badge(p.status, procurementLabel(p.status))}${procurementButton(ctx, p)}</div><div class="details-grid mt">${info('الصنف', ctx.name('items', p.item_id))}${info('الكمية', `${n(p.qty)} ${byId(ctx, 'items', p.item_id)?.unit || ''}`)}${info('المورد', ctx.name('stakeholders', p.supplier_id))}${info('منطقة الاستلام', ctx.name('zones', p.zone_id))}${info('المرحلة', ctx.name('phases', p.phase_id))}${info('المسؤول', ctx.name('stakeholders', p.responsible_id))}${info('مصدر البيانات', label(p.provenance))}${info('حركة الاستلام', p.stock_move_id)}</div>${p.evidence ? `<p>${esc(p.evidence)}</p>` : ''}${p.notes ? `<p>${esc(p.notes)}</p>` : ''}<h3 class="form-section">سجل الاعتماد والتوريد</h3>${historyTable(p.history)}${note('الاستلام مسجل للكميات فقط. التسعير والدفعات والفواتير والتسويات ليست ضمن هذا السجل.')}${recordEvidence(ctx, 'procurements', id)}`);
}
function transitionProcurement(ctx, element) {
  const p = requireRecord(ctx, 'procurements', element.dataset.id), target = element.dataset.status;
  if (procurementNext(p) !== target) throw new Error('تغيرت حالة طلب الشراء. افتح تفاصيله مجددًا.');
  if (!procurementCan(ctx, target)) throw new Error('لا تملك صلاحية الاعتماد المطلوبة.');
  modal(procurementLabel(target), `${note(`${p.title} · ${n(p.qty)} ${byId(ctx, 'items', p.item_id)?.unit || ''}`)}<div class="form-grid mt">${textarea('evidence', target === 'received' ? 'محضر الاستلام والفحص' : 'مرجع مستند الاعتماد / أمر الشراء', '', 'required maxlength="4000"')}</div>${note(target === 'received' ? `سيُضاف كامل الرصيد مرة واحدة إلى ${ctx.name('zones', p.zone_id)}. تأكد من مطابقة الكمية وفحصها قبل تأكيد الاستلام.` : 'يسجل المستند والوقت، دون تغيير رصيد المخزون.')}`, data => ctx.command('procurement.transition', {id: p.id, status: target, ...data}), target === 'received' ? 'تأكيد الاستلام وإضافة الرصيد' : 'تأكيد الإجراء');
}

export function inventoryActions(ctx) {
  return {
    'inventory-shipment-new':async el=>newShipment(ctx,el.dataset.direction),
    'inventory-shipment-detail':async el=>shipmentDetail(ctx,el.dataset.id),
    'book-shipment-detail':async el=>shipmentDetail(ctx,el.dataset.id),
    'inventory-shipment-dispatch':async el=>dispatchShipment(ctx,el.dataset.id),
    'inventory-shipment-receive':async el=>receiveShipment(ctx,el.dataset.id),
    'inventory-shipment-resolve':async el=>resolveShipment(ctx,el.dataset.id),
    'inventory-shipment-cancel':async el=>cancelShipment(ctx,el.dataset.id),
    'inventory-shipment-add-line':async el=>{const form=el.closest('form');addShipmentLine(ctx,form.querySelector('[data-shipment-lines]'));updateShipmentLines(ctx,form);},
    'inventory-shipment-remove-line':async el=>{const row=el.closest('[data-shipment-line]');if(row.parentElement.querySelectorAll('[data-shipment-line]').length<=1)throw new Error('يجب أن يحتوي البيان على عنوان واحد على الأقل.');row.remove();},
    'inventory-new-item': async el => newItem(ctx, el.dataset.kind || 'equipment'),
    'inventory-move': async el => movement(ctx, el),
    'inventory-detail': async el => itemDetail(ctx, el.dataset.id),
    'inventory-count': async el => stockCount(ctx, el),
    'inventory-count-detail': async el => countDetail(ctx, el.dataset.id),
    'inventory-count-review': async el => reviewCount(ctx, el.dataset.id),
    'inventory-settle': async el => settleCustody(ctx, el),
    'order-new': async () => newOrder(ctx),
    'order-detail': async el => orderDetail(ctx, el.dataset.id),
    'order-transition': async el => transitionOrder(ctx, el),
    'order-add-line': async el => addLine(ctx, el.closest('form').querySelector('[data-order-lines]')),
    'order-remove-line': async el => {const row = el.closest('[data-order-line]'); if (row.parentElement.querySelectorAll('[data-order-line]').length === 1) throw new Error('يجب أن يحتوي الطلب على بند واحد على الأقل.'); row.remove();},
    'procurement-new': async () => newProcurement(ctx),
    'procurement-detail': async el => procurementDetail(ctx, el.dataset.id),
    'procurement-transition': async el => transitionProcurement(ctx, el),
  };
}

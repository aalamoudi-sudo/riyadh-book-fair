export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Latin-shaped digits keep zero and dense operational counts legible in Arabic layouts.
export const n = value => new Intl.NumberFormat('ar-SA-u-nu-latn').format(Number(value)||0);
export const date = value => value ? new Intl.DateTimeFormat('ar-SA',{dateStyle:'medium',calendar:'gregory'}).format(new Date(value)) : 'غير محدد';
export const datetime = value => value ? new Intl.DateTimeFormat('ar-SA',{dateStyle:'short',timeStyle:'short',calendar:'gregory'}).format(new Date(value)) : 'غير محدد';
export const today = () => new Date().toISOString().slice(0,10);
export const labels = {
 planned:'مخطط',approved:'معتمد',ordered:'مسجل',received:'مستلم',draft:'مسودة',pending:'بانتظار البدء',active:'قيد التنفيذ',in_progress:'قيد التنفيذ',inspection:'بانتظار الفحص',completed:'مكتمل',blocked:'متعثر',cancelled:'ملغى',matched:'مطابق',
 picking:'قيد التجميع',packed:'مغلّف',shipped:'لدى الناقل',delivered:'تم التسليم',exception:'استثناء',returned:'مرتجع',
 proposed:'مسودة',submitted:'بانتظار الاعتماد',rejected:'مرفوض',revoked:'ملغى',open:'مفتوح',assigned:'مسند',resolved:'تمت المعالجة',closed:'مغلق',
 equipment:'معدات وأثاث',book:'كتب',consumable:'مواد استهلاكية',receipt:'استلام',reserve:'حجز',release:'تحرير حجز',issue:'صرف وعهدة',return:'استرجاع',transfer:'نقل',maintenance:'إحالة للصيانة',restore:'عودة من الصيانة',ship:'شحن للمالك',
 admin:'مدير النظام',manager:'مدير المشروع',warehouse:'أمين المستودع',security:'الأمن والتصاريح',field:'الفريق الميداني',viewer:'اطلاع فقط',publisher:'ناشر',supplier:'مورد',carrier:'ناقل',authority:'جهة اعتماد',
 demo:'بيانات تجريبية',manual:'إدخال ميداني',reference:'مرجع',live:'مصدر حي',forecast:'سيناريو تقديري',critical:'حرج',high:'عالٍ',medium:'متوسط',low:'منخفض',
 crowd:'الحشود',crowds:'الحشود',safety:'السلامة',service:'خدمة الزوار',logistics:'الإمداد',entry:'دخول',exit:'خروج',checkin:'دخول',checkout:'خروج',consume:'صرف للاستهلاك',settle:'تسوية عهدة'
};
export const label = value => labels[value] || value || '—';
export const badge = (value, text) => `<span class="badge ${esc(value)}">${esc(text||label(value))}</span>`;
const paths = {
 dashboard:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
 lifecycle:'M8 4h13M8 12h13M8 20h13M3 4h.01M3 12h.01M3 20h.01',
 warehouse:'m3 8 9-5 9 5v12H3zM3 8h18M7 20v-7h10v7M10 13v7',
 books:'M12 6c-3-3-7-3-10-2v15c3-1 7-1 10 2 3-3 7-3 10-2V4c-3-1-7-1-10 2zm0 0v15',
 orders:'m3 7 9-4 9 4v11l-9 4-9-4zm0 0 9 4 9-4M12 11v11M7 5l10 4',
 permits:'M5 3h14v18H5zM9 8h6M9 12h6M9 16h3',
 procurement:'M3 3h2l3 12h11l3-9H6M8 20h.01M18 20h.01',
 stakeholders:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.9M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
 spatial:'m12 3 10 5-10 5L2 8zm-10 10 10 5 10-5M2 18l10 5 10-5',
 reports:'M4 3h16v18H4zM8 8h8M8 12h8M8 16h5',
 legacy:'M3 4h18v14H3zM8 22h8M12 18v4',
 plus:'M12 5v14M5 12h14',arrow:'m14 7-5 5 5 5',search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',
 alert:'m12 3 10 18H2zm0 6v5M12 17h.01',check:'m5 12 4 4 10-10',close:'m6 6 12 12M18 6 6 18',refresh:'M20 7v5h-5M4 17v-5h5M5 8a8 8 0 0 1 13-3l2 3M4 16l2 3a8 8 0 0 0 13-3',
 download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',clock:'M12 7v5l3 2M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',menu:'M3 6h18M3 12h18M3 18h18',bell:'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4',logout:'M9 3H3v18h6M14 8l5 4-5 4M8 12h11'
};
export const icon = name => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.dashboard}"/></svg>`;
export const empty = (title,detail='أضف أول سجل لبدء العمل.',action='') => `<div class="empty">${icon('reports')}<h3>${esc(title)}</h3><p>${esc(detail)}</p>${action}</div>`;
export const button = (text,action,style='primary',ico='plus',attrs='')=>`<button type="button" class="btn ${style}" data-action="${esc(action)}" ${attrs}>${ico?icon(ico):''}${esc(text)}</button>`;
const requiredMark = extra => /(?:^|\s)required(?:\s|=|$)/i.test(extra) ? '<span class="field-required"> · مطلوب</span>' : '';
export const field = (name,title,type='text',value='',extra='') => `<label class="field"><span>${esc(title)}${requiredMark(extra)}</span><input name="${esc(name)}" type="${esc(type)}" value="${esc(value)}" ${extra}></label>`;
export const textarea = (name,title,value='',extra='') => `<label class="field wide"><span>${esc(title)}${requiredMark(extra)}</span><textarea name="${esc(name)}" rows="3" ${extra}>${esc(value)}</textarea></label>`;
export const select = (name,title,options,value='',extra='')=>`<label class="field"><span>${esc(title)}${requiredMark(extra)}</span><select name="${esc(name)}" ${extra}>${options.map(o=>{const id=typeof o==='string'?o:o.id; const name=typeof o==='string'?label(o):o.name;return `<option value="${esc(id)}" ${id===value?'selected':''}>${esc(name)}</option>`}).join('')}</select></label>`;
export const table = (headers,rows,opts='',caption='')=>{
 const named=/(?:^|\s)aria-(?:label|labelledby)\s*=/.test(opts);
 const title=caption||`جدول: ${headers.slice(0,3).join('، ')}`;
 const labelledRows=rows.map(row=>{
  let column=0;
  return row.replace(/<(tr|td)(?=[\s>])[^>]*>/gi,(tag,kind)=>{
   if(kind.toLowerCase()==='tr'){column=0;return tag;}
   const heading=headers[column++];
   return heading&&!/\bdata-label\s*=/.test(tag)?`${tag.slice(0,-1)} data-label="${esc(heading)}">`:tag;
  });
 });
 return `<div class="table-wrap"><table ${opts}${caption||named?'':` aria-label="${esc(title)}"`}>${caption?`<caption>${esc(caption)}</caption>`:''}<thead><tr>${headers.map(h=>`<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${labelledRows.join('')}</tbody></table></div>`;
};
export const progress = (value,text='')=>`<div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Number(value)||0}" aria-label="${esc(text||'نسبة الإنجاز')}"><span style="width:${Math.max(0,Math.min(100,Number(value)||0))}%"></span></div>`;
export function download(name,content,type='application/json'){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
export function csv(name,headers,rows){const cell=v=>`"${String(v??'').replace(/^(?:\s*[=+@\-]|[\t\r\n])/,"'$&").replace(/"/g,'""')}"`;download(name,'\uFEFF'+[headers,...rows].map(r=>r.map(cell).join(',')).join('\r\n'),'text/csv;charset=utf-8')}
export function toast(text,error=false){
 const el=document.querySelector('#toast');
 clearTimeout(toast.timer);
 const dismiss=()=>{clearTimeout(toast.timer);el.className='';el.hidden=true;el.replaceChildren();el.setAttribute('role','status');el.setAttribute('aria-live','polite')};
 el.hidden=false;
 el.setAttribute('role',error?'alert':'status');
 el.setAttribute('aria-live',error?'assertive':'polite');
 el.textContent=text;
 if(error){
  const close=document.createElement('button');
  close.type='button';close.textContent='إغلاق';close.setAttribute('aria-label','إغلاق رسالة الخطأ');
  close.style.cssText='margin-inline-start:12px;padding:3px 8px;border:1px solid currentColor;border-radius:4px;background:transparent;color:inherit;cursor:pointer';
  close.onclick=dismiss;el.append(close);
 }
 el.className='show'+(error?' error':'');
 toast.timer=setTimeout(dismiss,error?12000:5000);
}
export function modal(title,body,onSubmit,submitText='حفظ السجل',wide=false){
 const d=document.querySelector('#dialog'); d.className=wide?'dialog-wide':'';
 d.innerHTML=`<form id="modal-form"><div class="dialog-head"><div><span class="eyebrow">سجل المشروع</span><h2 id="dialog-title">${esc(title)}</h2></div><button type="button" class="icon-btn" data-close aria-label="إغلاق">${icon('close')}</button></div><div class="dialog-body">${body}</div><p class="form-error" id="form-error" role="alert"></p><div class="dialog-foot"><button class="btn primary" type="submit">${esc(submitText)}</button><button class="btn secondary" type="button" data-close>إلغاء</button></div></form>`;
 d.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>d.close());
 d.querySelector('form').onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;const b=f.querySelector('[type=submit]');b.disabled=true;d.querySelector('#form-error').textContent='';try{await onSubmit(Object.fromEntries(new FormData(f)),f);d.close()}catch(err){d.querySelector('#form-error').textContent=err.message;}finally{b.disabled=false}};
 if(!d.open)d.showModal();return d;
}
export function detail(title,body,wide=true){const d=modal(title,body,()=>{},'إغلاق',wide);d.querySelector('.dialog-foot').innerHTML='<button class="btn secondary" type="button" data-close>إغلاق</button>';d.querySelector('.dialog-foot button').onclick=()=>d.close();return d}

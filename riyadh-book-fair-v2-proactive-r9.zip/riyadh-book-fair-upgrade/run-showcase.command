#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
source scripts/select-runtime.sh
showcase_db="$PWD/data/showcase-demo-$(date -u +%Y%m%dT%H%M%SZ)-$RANDOM.sqlite"
"$rbf_python" scripts/prepare_showcase.py --db "$showcase_db"
showcase_port="${RBF_SHOWCASE_PORT:-8766}"
print "افتح http://127.0.0.1:${showcase_port} لعرض البيانات التجريبية المعزولة."
exec "$rbf_python" server.py --review --demo --db "$showcase_db" --port "$showcase_port"

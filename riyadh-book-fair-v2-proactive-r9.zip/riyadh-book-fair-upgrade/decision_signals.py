"""Explainable, read-only operating signals derived from already scoped state.

Signals are prompts for a human to inspect a record. They neither create incidents
nor claim a live sensor feed, a prediction model, or an external notification.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone


def _instant(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return parsed.astimezone(timezone.utc) if parsed.tzinfo else None
    except (TypeError, ValueError, OverflowError):
        return None


def decision_signals(state, at=None):
    """Return signals from the supplied *already project-scoped* state object.

    ``at`` is injectable for deterministic boundary tests. This function does
    not read the database and must never broaden the caller's project scope.
    """
    current = at or datetime.now(timezone.utc)
    if current.tzinfo is None:
        raise ValueError('at must include a timezone')
    current = current.astimezone(timezone.utc)
    projects = {row['id'] for row in state.get('projects', ())}
    zones = {row['id']: row for row in state.get('zones', ()) if row.get('project_id') in projects}
    items = {row['id']: row for row in state.get('items', ()) if row.get('project_id') in projects}
    incidents = [row for row in state.get('incidents', ()) if row.get('project_id') in projects]
    result = []

    for shipment in state.get('book_shipments', ()):
        project_id = shipment.get('project_id')
        zone_id = shipment.get('impact_zone_id')
        expected = _instant(shipment.get('expected_at'))
        if (project_id not in projects or shipment.get('direction') != 'inbound'
                or shipment.get('status') != 'announced' or not expected or expected >= current
                or zone_id not in zones or zones[zone_id].get('project_id') != project_id):
            continue
        zone_name = zones[zone_id].get('name') or zone_id
        result.append({
            'id': f"shipment:{shipment['id']}", 'kind': 'late_book', 'severity': 'high',
            'title': 'وارد كتب تجاوز موعده',
            'reason': f"بيان {shipment.get('document_reference') or shipment['id']} لم يسجل استلامه حتى موعده المتوقع.",
            'impact': f'قد تتأخر جاهزية {zone_name}؛ راجع توفر العناوين وخطة التوزيع مع الناشر.',
            'source_at': expected.isoformat(), 'project_id': project_id, 'zone_id': zone_id,
            'source_collection': 'book_shipments', 'source_id': shipment['id'],
            'route': 'books', 'related_incident_id': '',
        })

    latest = {}
    for observation in state.get('observations', ()):
        project_id = observation.get('project_id')
        zone_id = observation.get('zone_id')
        observed = _instant(observation.get('observed_at'))
        if (project_id not in projects or zone_id not in zones
                or zones[zone_id].get('project_id') != project_id or observed is None
                or observed > current
                or observation.get('source') not in {'manual', 'field'}):
            continue
        key = (project_id, zone_id)
        # State collections are in insertion order. A later entry wins when
        # two manual readings have the same timestamp precision.
        if key not in latest or observed >= latest[key][0]:
            latest[key] = (observed, observation)
    for (project_id, zone_id), (observed, observation) in latest.items():
        age = current - observed
        if age < timedelta() or age > timedelta(minutes=30):
            continue
        count = observation.get('people_count')
        capacity = observation.get('capacity')
        wait = observation.get('wait_minutes')
        if (not isinstance(count, int) or isinstance(count, bool) or not isinstance(capacity, int)
                or isinstance(capacity, bool) or capacity <= 0):
            continue
        ratio = count / capacity
        wait = wait if isinstance(wait, (int, float)) and not isinstance(wait, bool) else None
        if ratio < .8 and (wait is None or wait < 10):
            continue
        critical = ratio >= 1 or (wait is not None and wait >= 20)
        related = next((incident['id'] for incident in reversed(incidents)
                        if incident.get('observation_id') == observation['id']
                        and incident.get('zone_id') == zone_id
                        and incident.get('status') in {'open', 'assigned'}), '')
        reason = f"رصد يدوي مؤرخ: {count} من سعة {capacity} ({ratio:.1%})"
        if wait is not None:
            reason += f'؛ زمن الانتظار {wait:g} دقيقة'
        result.append({
            'id': f"crowd:{observation['id']}", 'kind': 'crowd_pressure',
            'severity': 'critical' if critical else 'high', 'title': 'ضغط حشود يحتاج تحققًا ميدانيًا',
            'reason': reason + '. القاعدة: إشغال 80٪ أو انتظار 10 دقائق خلال آخر 30 دقيقة.',
            'impact': 'قد يلزم توزيع الدخول أو دعم الأمن والتشغيل؛ لا تُتخذ خطوة سلامة قبل تحقق الفريق.',
            'source_at': observed.isoformat(), 'project_id': project_id, 'zone_id': zone_id,
            'source_collection': 'observations', 'source_id': observation['id'],
            'route': 'incidents', 'related_incident_id': related,
        })

    # An unresolved crowd incident stays actionable after its manual reading
    # expires. This is a request to recheck, never a claim of current pressure.
    crowd_incidents = {}
    incident_rank = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    for incident in incidents:
        project_id, zone_id = incident.get('project_id'), incident.get('zone_id')
        if (incident.get('category') != 'crowds' or incident.get('status') == 'closed'
                or zone_id not in zones or zones[zone_id].get('project_id') != project_id):
            continue
        key = (project_id, zone_id)
        previous = crowd_incidents.get(key)
        if previous is None or incident_rank.get(incident.get('priority'), 4) <= incident_rank.get(previous.get('priority'), 4):
            crowd_incidents[key] = incident
    for (project_id, zone_id), incident in crowd_incidents.items():
        last = latest.get((project_id, zone_id))
        if last and current - last[0] <= timedelta(minutes=30):
            continue
        last_at = last[0] if last else None
        source = last[1] if last else incident
        result.append({
            'id': f"crowd-recheck:{incident['id']}", 'kind': 'crowd_recheck',
            'severity': 'high', 'title': 'بلاغ حشود ينتظر رصدًا حديثًا',
            'reason': ('آخر رصد يدوي تجاوز 30 دقيقة؛ يلزم قياس جديد قبل الحكم على حالة المنطقة.'
                       if last_at else 'لا توجد قراءة حشود يدوية مسجلة لهذه المنطقة.'),
            'impact': 'الحالة الحالية غير معروفة؛ يلزم رصد ميداني جديد قبل تقييم الضغط أو أثر القرار.',
            'source_at': last_at.isoformat() if last_at else incident.get('created_at', ''),
            'project_id': project_id, 'zone_id': zone_id,
            'source_collection': 'observations' if last else 'incidents',
            'source_id': source['id'], 'route': 'incidents',
            'related_incident_id': incident['id'],
        })

    custody = {row['id']: row for row in state.get('custody', ())
               if row.get('item_id') in items
               and (row.get('project_id') or items[row['item_id']]['project_id']) == items[row['item_id']]['project_id']
               and row.get('kind') != 'order'
               and isinstance(row.get('outstanding'), int) and row['outstanding'] > 0}
    latest_move = {}
    for move in state.get('stock_moves', ()):
        reference = move.get('reference')
        item_id = move.get('item_id')
        key = f'{item_id}@{reference}'
        if key in custody and move.get('action') in {'issue', 'return'}:
            instant = _instant(move.get('created_at'))
            if instant and (key not in latest_move or instant > latest_move[key]):
                latest_move[key] = instant
    for report in state.get('closeout', ()):
        project_id = report.get('project_id')
        if project_id not in projects or report.get('status') == 'closed':
            continue
        blocker = next((b for b in report.get('blockers', ())
                        if b.get('code') == 'outstanding_custody'), None)
        if not blocker:
            continue
        for custody_id in blocker.get('ids', ()):
            row = custody.get(custody_id)
            if not row or items[row['item_id']]['project_id'] != project_id:
                continue
            item = items.get(row.get('item_id'))
            if not item:
                continue
            moved = latest_move.get(custody_id)
            result.append({
                'id': f'custody:{custody_id}', 'kind': 'outstanding_custody', 'severity': 'high',
                'title': 'عهدة تشغيل تمنع الإقفال',
                'reason': f"{row['outstanding']} وحدة من {item.get('name') or item['id']} ما زالت بعهدة {row.get('custodian_id') or 'مسؤول غير محدد'}.",
                'impact': 'إقفال المشروع متوقف حتى توثيق الاسترجاع أو التسوية والجرد النهائي.',
                'source_at': moved.isoformat() if moved else row.get('created_at', ''),
                'project_id': project_id, 'zone_id': '',
                'source_collection': 'custody', 'source_id': custody_id,
                'route': 'lifecycle', 'related_incident_id': '',
            })

    priority = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    return sorted(result, key=lambda row: (priority.get(row['severity'], 4), row['kind'], row['id']))

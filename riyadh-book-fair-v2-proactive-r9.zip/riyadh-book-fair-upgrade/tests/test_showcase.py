"""Presentation data must exercise real workflows while staying synthetic."""
import json
from datetime import datetime, timezone
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from domain import DomainStore
from scripts.prepare_showcase import create_showcase


class ShowcaseTests(unittest.TestCase):
    def test_showcase_is_a_coherent_isolated_story(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'showcase.sqlite'
            summary = create_showcase(path)
            store = DomainStore(path, demo=True)
            state = store.state()
            self.assertEqual(state['mode'], 'demo')
            self.assertEqual(state['revision'], summary['revision'])
            self.assertEqual(state['integrations']['shipping'], 'not_connected')
            self.assertEqual(len(state['projects']), 1)
            self.assertEqual(len(state['phase_handoffs']), 3)
            self.assertTrue(all(row['status'] == 'accepted' for row in state['phase_handoffs']))
            self.assertEqual(len({row['zone_id'] for row in state['phase_handoffs']}), 1)
            self.assertEqual([row['status'] for row in state['daily_reports']], ['closed'])

            orders = {row['status'] for row in state['orders']}
            self.assertEqual(orders, {'ordered', 'delivered'})
            self.assertEqual(len([row for row in state['book_shipments']
                                  if row['status'] == 'resolved' and row['difference_reason']]), 1)
            self.assertEqual(len([row for row in state['book_shipments']
                                  if row['direction'] == 'publisher_return' and row['status'] == 'received']), 1)
            late = next(row for row in state['book_shipments']
                        if row['id'] == summary['late_book_shipment_id'])
            self.assertEqual(late['status'], 'announced')
            self.assertTrue(late['expected_at'])
            self.assertEqual(late['impact_zone_id'], next(
                zone['id'] for zone in state['zones'] if zone['name'] == 'القاعة أ'))
            self.assertEqual(len([row for row in state['permits']
                                  if row['status'] == 'approved' and len(row['approval_steps']) == 2]), 1)
            self.assertEqual(len([row for row in state['access_logs']
                                  if row['checked_out_at']]), 1)
            self.assertEqual({row['status'] for row in state['incidents']}, {'open', 'closed'})
            completed_crowd = next(row for row in state['incidents']
                                   if row['title'] == 'ازدحام تدريبي عند الجناح')
            self.assertEqual(completed_crowd['observation_id'], summary['crowd_source_observation_id'])
            self.assertTrue(any(decision['incident_id'] == completed_crowd['id']
                                and decision['impact_type'] == 'observed'
                                and decision['verification_observation_id'] ==
                                summary['crowd_verification_observation_id']
                                for decision in state['decisions']))
            signals = {row['kind'] for row in state['decision_signals']}
            self.assertTrue({'late_book', 'crowd_pressure', 'outstanding_custody'} <= signals)
            blockers = {blocker['code'] for blocker in state['closeout'][0]['blockers']}
            self.assertIn('outstanding_custody', blockers)
            self.assertEqual(state['spatial_plans'][0]['status'], 'draft')
            self.assertEqual(state['spatial_plans'][0]['plan']['provenance']['data_class'], 'demo')
            self.assertFalse(state['spatial_plans'][0]['plan']['review']['approved'])
            self.assertEqual(len(state['spatial_plans'][0]['plan']['elements']), len(state['zones']))
            fixture = json.loads((ROOT / 'scripts/spatial/samples/showcase-demo.plan.json').read_text(encoding='utf-8'))
            draft = state['spatial_plans'][0]['plan']
            self.assertEqual([(element['id'], element['polygon'], element['height_m'])
                              for element in draft['elements']],
                             [(element['id'], element['polygon'], element['height_m'])
                              for element in fixture['elements']])
            self.assertTrue(set(element['zone_id'] for element in draft['elements']).isdisjoint(
                element['zone_id'] for element in fixture['elements']))
            self.assertTrue(all(row['provenance'] == 'demo' for collection in
                                ('projects', 'zones', 'items', 'orders', 'permits', 'spatial_plans')
                                for row in state[collection]))
            self.assertTrue(all(row['on_hand'] >= 0 and row['available'] >= 0
                                for row in state['stock']))
            self.assertEqual(len(store.export({'id': 'test', 'role': 'admin'})['audit']), state['revision'])

    def test_three_signals_clear_only_after_recorded_work(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'showcase.sqlite'
            summary = create_showcase(path)
            store = DomainStore(path, demo=True)
            state = store.state()
            self.assertTrue({'late_book', 'crowd_pressure', 'outstanding_custody'} <=
                            {signal['kind'] for signal in state['decision_signals']})

            late = next(row for row in state['book_shipments']
                        if row['id'] == summary['late_book_shipment_id'])
            store.command('book_shipment.receive', {
                'id': late['id'],
                'actual_lines': [{'item_id': line['item_id'], 'received_qty': line['qty']}
                                 for line in late['lines']],
                'receiver_name': 'مستودع العرض', 'evidence': 'محضر استلام تجريبي لاحق',
            }, {'id': 'showcase-warehouse', 'role': 'warehouse'})
            self.assertNotIn('late_book', {signal['kind'] for signal in store.state()['decision_signals']})

            current = next(observation for observation in state['observations']
                           if any(signal['kind'] == 'crowd_pressure'
                                  and signal['source_id'] == observation['id']
                                  for signal in state['decision_signals']))
            store.command('observation.create', {
                'project_id': current['project_id'], 'phase_id': current['phase_id'],
                'zone_id': current['zone_id'], 'responsible_id': current['responsible_id'],
                'observed_at': datetime.now(timezone.utc).isoformat(),
                'people_count': 200, 'capacity': 500, 'wait_minutes': 5,
                'evidence': 'رصد يدوي تجريبي جديد بعد تنظيم التدفق',
            }, {'id': 'showcase-field', 'role': 'field'})
            self.assertNotIn('crowd_pressure', {signal['kind'] for signal in store.state()['decision_signals']})

            custody = next(row for row in state['custody']
                           if row.get('kind') != 'order' and row['outstanding'] > 0)
            issue = next(row for row in state['stock_moves']
                         if row['action'] == 'issue' and row['item_id'] == custody['item_id']
                         and row['reference'] == custody['reference'])
            store.command('stock.move', {
                'action': 'return', 'item_id': custody['item_id'], 'zone_id': issue['zone_id'],
                'qty': custody['outstanding'], 'reference': custody['reference'],
                'evidence': 'محضر استرجاع عهدة تجريبي',
            }, {'id': 'showcase-warehouse', 'role': 'warehouse'})
            self.assertNotIn('outstanding_custody',
                             {signal['kind'] for signal in store.state()['decision_signals']})

    def test_existing_database_is_never_replaced(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'existing.sqlite'
            path.write_bytes(b'keep me')
            with self.assertRaises(FileExistsError):
                create_showcase(path)
            self.assertEqual(path.read_bytes(), b'keep me')

    def test_failed_generation_removes_only_new_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'failed.sqlite'
            with patch('scripts.prepare_showcase.seed_story', side_effect=RuntimeError('test failure')):
                with self.assertRaises(RuntimeError):
                    create_showcase(path)
            self.assertFalse(path.exists())
            self.assertFalse(Path(str(path) + '-wal').exists())
            self.assertFalse(Path(str(path) + '-shm').exists())


if __name__ == '__main__':
    unittest.main()

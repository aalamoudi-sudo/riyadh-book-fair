"""Proactive signals remain explainable, scoped, and backed by saved records."""
import datetime as dt
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from decision_signals import decision_signals
from domain import DomainError, DomainStore


ACTOR = {'id': 'decision-test-admin', 'role': 'admin'}
NOW = dt.datetime(2026, 9, 24, 12, tzinfo=dt.timezone.utc)


class SignalCalculationTests(unittest.TestCase):
    def base(self):
        return {'projects': [{'id': 'P1'}],
                'zones': [{'id': 'Z1', 'project_id': 'P1', 'name': 'قاعة العرض'}],
                'items': [{'id': 'I1', 'project_id': 'P1', 'name': 'جهاز اتصال'}],
                'book_shipments': [], 'observations': [], 'incidents': [],
                'custody': [], 'stock_moves': [],
                'closeout': [{'project_id': 'P1', 'status': 'active', 'blockers': []}]}

    def test_only_overdue_announced_inbound_with_affected_zone_signals(self):
        state = self.base()
        shipment = {'id': 'S1', 'project_id': 'P1', 'zone_id': 'Z1',
                    'impact_zone_id': 'Z1', 'direction': 'inbound', 'status': 'announced',
                    'expected_at': (NOW - dt.timedelta(hours=1)).isoformat(),
                    'document_reference': 'IN-1'}
        state['book_shipments'] = [shipment]
        signal = decision_signals(state, NOW)[0]
        self.assertEqual((signal['kind'], signal['source_id'], signal['route']),
                         ('late_book', 'S1', 'books'))
        self.assertIn('IN-1', signal['reason'])
        for patch in ({'status': 'received'}, {'direction': 'publisher_return'},
                      {'expected_at': (NOW + dt.timedelta(minutes=1)).isoformat()},
                      {'expected_at': ''}, {'impact_zone_id': ''}):
            state['book_shipments'] = [{**shipment, **patch}]
            self.assertEqual(decision_signals(state, NOW), [], patch)

    def test_crowd_signal_uses_latest_manual_reading_only_within_30_minutes(self):
        state = self.base()
        earlier = {'id': 'O1', 'project_id': 'P1', 'zone_id': 'Z1',
                   'observed_at': (NOW - dt.timedelta(minutes=31)).isoformat(),
                   'source': 'manual', 'people_count': 95, 'capacity': 100,
                   'wait_minutes': 15}
        state['observations'] = [earlier]
        self.assertEqual(decision_signals(state, NOW), [])
        recent = {**earlier, 'id': 'O2',
                  'observed_at': (NOW - dt.timedelta(minutes=30)).isoformat(),
                  'people_count': 81, 'wait_minutes': 3}
        state['observations'].append(recent)
        state['incidents'] = [{'id': 'INC1', 'project_id': 'P1', 'zone_id': 'Z1',
                               'observation_id': 'O2', 'status': 'open'}]
        signal = decision_signals(state, NOW)[0]
        self.assertEqual((signal['kind'], signal['source_id'], signal['related_incident_id']),
                         ('crowd_pressure', 'O2', 'INC1'))
        self.assertIn('81.0%', signal['reason'])
        state['observations'].append({**recent, 'id': 'O-FUTURE',
                                      'observed_at': (NOW + dt.timedelta(minutes=1)).isoformat(),
                                      'people_count': 10, 'wait_minutes': 1})
        self.assertEqual(decision_signals(state, NOW)[0]['source_id'], 'O2')
        state['observations'].append({**recent, 'id': 'O3',
                                      'observed_at': (NOW - dt.timedelta(minutes=2)).isoformat(),
                                      'people_count': 70, 'wait_minutes': 4})
        self.assertEqual(decision_signals(state, NOW), [])
        state['observations'][-1]['wait_minutes'] = 10
        self.assertEqual(decision_signals(state, NOW)[0]['source_id'], 'O3')
        state['observations'].append({**recent, 'id': 'O4',
                                      'observed_at': state['observations'][-1]['observed_at'],
                                      'people_count': 70, 'wait_minutes': 4})
        self.assertEqual(decision_signals(state, NOW), [])

    def test_open_crowd_incident_requests_recheck_after_30_minutes(self):
        state = self.base()
        observed_at = NOW - dt.timedelta(minutes=30)
        state['observations'] = [{'id': 'O1', 'project_id': 'P1', 'zone_id': 'Z1',
                                  'observed_at': observed_at.isoformat(), 'source': 'manual',
                                  'people_count': 85, 'capacity': 100, 'wait_minutes': 11}]
        state['incidents'] = [{'id': 'INC1', 'project_id': 'P1', 'zone_id': 'Z1',
                               'category': 'crowds', 'status': 'open', 'priority': 'high',
                               'observation_id': 'O1', 'created_at': observed_at.isoformat()}]
        signals = decision_signals(state, NOW)
        self.assertEqual([s['kind'] for s in signals], ['crowd_pressure'])
        signals = decision_signals(state, NOW + dt.timedelta(seconds=1))
        self.assertEqual([s['kind'] for s in signals], ['crowd_recheck'])
        recheck = signals[0]
        self.assertEqual((recheck['source_collection'], recheck['source_id'],
                          recheck['related_incident_id'], recheck['route']),
                         ('observations', 'O1', 'INC1', 'incidents'))
        self.assertEqual(recheck['source_at'], observed_at.isoformat())
        self.assertIn('تجاوز 30 دقيقة', recheck['reason'])
        self.assertIn('الحالة الحالية غير معروفة', recheck['impact'])

        state['observations'].append({**state['observations'][0], 'id': 'O2',
                                      'observed_at': (NOW - dt.timedelta(minutes=1)).isoformat()})
        self.assertEqual([s['kind'] for s in decision_signals(state, NOW)], ['crowd_pressure'])
        state['observations'][-1].update(people_count=50, wait_minutes=3)
        self.assertEqual(decision_signals(state, NOW), [])
        state['incidents'][0]['status'] = 'closed'
        self.assertEqual(decision_signals(state, NOW + dt.timedelta(hours=1)), [])

    def test_recheck_without_a_reading_never_uses_another_project(self):
        state = self.base()
        state['incidents'] = [
            {'id': 'INC1', 'project_id': 'P1', 'zone_id': 'Z1',
             'category': 'crowds', 'status': 'assigned', 'priority': 'medium',
             'created_at': (NOW - dt.timedelta(hours=1)).isoformat()},
            {'id': 'INC2', 'project_id': 'P2', 'zone_id': 'Z1',
             'category': 'crowds', 'status': 'open', 'priority': 'critical',
             'created_at': (NOW - dt.timedelta(hours=1)).isoformat()}]
        signals = decision_signals(state, NOW)
        self.assertEqual([(s['kind'], s['related_incident_id'], s['source_collection'])
                          for s in signals], [('crowd_recheck', 'INC1', 'incidents')])
        self.assertIn('لا توجد قراءة', signals[0]['reason'])
        state['incidents'][0]['status'] = 'closed'
        self.assertEqual(decision_signals(state, NOW), [])

    def test_custody_signal_requires_closeout_blocker_and_never_crosses_scope(self):
        state = self.base()
        state['custody'] = [
            {'id': 'I1@A', 'project_id': '', 'item_id': 'I1', 'outstanding': 2,
             'kind': 'operational', 'custodian_id': 'OWNER1'},
            {'id': 'I2@B', 'project_id': 'P2', 'item_id': 'I2', 'outstanding': 3,
             'kind': 'operational', 'custodian_id': 'OWNER2'}]
        state['closeout'][0]['blockers'] = [{'code': 'outstanding_custody',
                                             'ids': ['I1@A', 'I2@B']}]
        state['closeout'].append({'project_id': 'P2', 'status': 'active',
                                  'blockers': [{'code': 'outstanding_custody', 'ids': ['I2@B']}]})
        state['book_shipments'].append({'id': 'S2', 'project_id': 'P2', 'zone_id': 'Z2',
                                        'impact_zone_id': 'Z1', 'direction': 'inbound',
                                        'status': 'announced',
                                        'expected_at': (NOW - dt.timedelta(hours=1)).isoformat()})
        state['observations'].append({'id': 'O2', 'project_id': 'P2', 'zone_id': 'Z1',
                                      'observed_at': NOW.isoformat(), 'source': 'manual',
                                      'people_count': 100, 'capacity': 100})
        signals = decision_signals(state, NOW)
        self.assertEqual([(s['kind'], s['source_id']) for s in signals],
                         [('outstanding_custody', 'I1@A')])
        state['closeout'][0]['blockers'] = []
        self.assertEqual(decision_signals(state, NOW), [])


class LinkedDecisionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = DomainStore(Path(self.temp.name) / 'linked.sqlite')
        self.project = self.cmd('shared.create', collection='projects', name='Project')
        self.zone = self.cmd('shared.create', collection='zones', name='Hall',
                             project_id=self.project['id'])
        self.other_zone = self.cmd('shared.create', collection='zones', name='Warehouse',
                                   project_id=self.project['id'])
        self.owner = self.cmd('shared.create', collection='stakeholders', name='Owner',
                              project_id=self.project['id'])

    def tearDown(self):
        self.temp.cleanup()

    def cmd(self, command_type, **payload):
        return self.store.command(command_type, payload, ACTOR)['result']

    def assert_code(self, code, callback):
        with self.assertRaises(DomainError) as caught:
            callback()
        self.assertEqual(caught.exception.code, code)

    def observation(self, zone=None, minutes_ago=3, at=None):
        when = at or (dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=minutes_ago))
        return self.cmd('observation.create', project_id=self.project['id'],
                        zone_id=(zone or self.zone)['id'], responsible_id=self.owner['id'],
                        observed_at=when.isoformat(), people_count=85, capacity=100,
                        wait_minutes=11, evidence='Dated manual count')

    def incident(self, observation, **overrides):
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'title': 'Crowd at entrance', 'description': 'Manual count requires a decision',
                   'category': 'crowds', 'source': 'field', 'observation_id': observation['id']}
        return self.cmd('incident.create', **{**payload, **overrides})

    def decision(self, incident, impact_type='expected', **extra):
        return self.cmd('incident.decision', incident_id=incident['id'],
                        decision='Open second lane', action='Assign gate team',
                        impact='Wait should fall', impact_type=impact_type,
                        responsible_id=self.owner['id'], evidence='Signed decision log', **extra)

    def test_shipment_metadata_is_validated_and_scoped(self):
        book = self.cmd('item.create', project_id=self.project['id'], kind='book',
                        name='Title', owner_id=self.owner['id'])
        base = {'project_id': self.project['id'], 'zone_id': self.other_zone['id'],
                'publisher_id': self.owner['id'], 'direction': 'inbound',
                'document_reference': 'IN-001', 'evidence': 'Manifest',
                'lines': [{'item_id': book['id'], 'qty': 2}]}
        self.assert_code('validation', lambda: self.cmd('book_shipment.create',
                         **{**base, 'expected_at': 'bad-date'}))
        other_project = self.cmd('shared.create', collection='projects', name='Other')
        wrong_zone = self.cmd('shared.create', collection='zones', name='Elsewhere',
                              project_id=other_project['id'])
        self.assert_code('project_mismatch', lambda: self.cmd('book_shipment.create',
                         **{**base, 'impact_zone_id': wrong_zone['id']}))
        due = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=1)).isoformat()
        shipment = self.cmd('book_shipment.create', **{**base, 'expected_at': due,
                                                       'impact_zone_id': self.zone['id']})
        self.assertEqual(shipment['impact_zone_id'], self.zone['id'])
        self.assertTrue(shipment['expected_at'].endswith('+00:00'))
        signal = next(s for s in self.store.state()['decision_signals']
                      if s['source_id'] == shipment['id'])
        self.assertEqual(signal['kind'], 'late_book')

    def test_state_signals_do_not_expose_another_project(self):
        due = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=1)).isoformat()
        own_book = self.cmd('item.create', project_id=self.project['id'], kind='book',
                            name='Own title', owner_id=self.owner['id'])
        own = self.cmd('book_shipment.create', project_id=self.project['id'],
                       zone_id=self.zone['id'], publisher_id=self.owner['id'],
                       direction='inbound', document_reference='OWN-IN', expected_at=due,
                       impact_zone_id=self.zone['id'],
                       lines=[{'item_id': own_book['id'], 'qty': 1}], evidence='Manifest')
        other_project = self.cmd('shared.create', collection='projects', name='Other')
        other_zone = self.cmd('shared.create', collection='zones', name='Other hall',
                              project_id=other_project['id'])
        other_owner = self.cmd('shared.create', collection='stakeholders', name='Other publisher',
                               project_id=other_project['id'])
        other_book = self.cmd('item.create', project_id=other_project['id'], kind='book',
                              name='Other title', owner_id=other_owner['id'])
        hidden = self.cmd('book_shipment.create', project_id=other_project['id'],
                          zone_id=other_zone['id'], publisher_id=other_owner['id'],
                          direction='inbound', document_reference='HIDDEN-IN', expected_at=due,
                          impact_zone_id=other_zone['id'],
                          lines=[{'item_id': other_book['id'], 'qty': 1}], evidence='Manifest')
        scoped = self.store.state({'id': 'scoped-manager', 'role': 'manager',
                                   'project_ids': [self.project['id']]})
        self.assertEqual({row['source_id'] for row in scoped['decision_signals']},
                         {own['id']})
        self.assertNotIn(hidden['id'], repr(scoped['decision_signals']))

    def test_linked_crowd_closure_requires_newer_verified_observation(self):
        source = self.observation(minutes_ago=4)
        wrong = self.observation(zone=self.other_zone, minutes_ago=3)
        self.assert_code('incident_observation_mismatch',
                         lambda: self.incident(wrong))
        too_early = (dt.datetime.fromisoformat(source['observed_at'])
                     - dt.timedelta(seconds=1)).isoformat()
        self.assert_code('incident_before_observation',
                         lambda: self.incident(source, observed_at=too_early))
        incident = self.incident(source)
        self.assertEqual(incident['observation_id'], source['id'])
        self.cmd('incident.transition', id=incident['id'], status='assigned',
                 responsible_id=self.owner['id'])
        self.decision(incident)
        self.cmd('incident.transition', id=incident['id'], status='resolved', evidence='Work performed')
        self.assert_code('observed_impact_required',
                         lambda: self.cmd('incident.transition', id=incident['id'],
                                          status='closed', evidence='Premature closure'))
        self.assert_code('verification_observation_required',
                         lambda: self.decision(incident, impact_type='observed'))
        self.assert_code('verification_observation_mismatch',
                         lambda: self.decision(incident, impact_type='observed',
                                               verification_observation_id=wrong['id']))
        self.assert_code('verification_not_after_incident',
                         lambda: self.decision(incident, impact_type='observed',
                                               verification_observation_id=source['id']))
        follow_up = self.observation(minutes_ago=0)
        observed = self.decision(incident, impact_type='observed',
                                 verification_observation_id=follow_up['id'])
        self.assertEqual(observed['verification_observation_id'], follow_up['id'])
        self.assertEqual(self.cmd('incident.transition', id=incident['id'],
                                  status='closed', evidence='Validated result')['status'], 'closed')

    def test_latest_decision_must_itself_have_observed_impact(self):
        source = self.observation(minutes_ago=4)
        incident = self.incident(source)
        self.cmd('incident.transition', id=incident['id'], status='assigned',
                 responsible_id=self.owner['id'])
        self.decision(incident)
        follow_up = self.observation(minutes_ago=0)
        self.decision(incident, impact_type='observed',
                      verification_observation_id=follow_up['id'])
        self.decision(incident, impact_type='expected')
        self.cmd('incident.transition', id=incident['id'], status='resolved', evidence='Field work')
        self.assert_code('observed_impact_required',
                         lambda: self.cmd('incident.transition', id=incident['id'],
                                          status='closed', evidence='Old measurement'))

    def test_crowd_followup_must_be_recorded_after_action_and_not_backdated(self):
        source = self.observation(minutes_ago=4)
        incident = self.incident(source)
        self.cmd('incident.transition', id=incident['id'], status='assigned',
                 responsible_id=self.owner['id'])
        preexisting = self.observation(minutes_ago=0,
            at=dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=1))
        self.assert_code('prior_crowd_action_required',
                         lambda: self.decision(incident, impact_type='observed',
                                               verification_observation_id=preexisting['id']))
        action = self.decision(incident)
        self.assert_code('verification_before_action',
                         lambda: self.decision(incident, impact_type='observed',
                                               verification_observation_id=preexisting['id']))
        backdated = self.observation(minutes_ago=1)
        self.assert_code('verification_before_action',
                         lambda: self.decision(incident, impact_type='observed',
                                               verification_observation_id=backdated['id']))
        same_second = self.observation(at=dt.datetime.fromisoformat(action['created_at']))
        verified = self.decision(incident, impact_type='observed',
                                 verification_observation_id=same_second['id'])
        self.assertEqual(verified['verification_observation_id'], same_second['id'])


if __name__ == '__main__':
    unittest.main()

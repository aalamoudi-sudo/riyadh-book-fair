from pathlib import Path
import json
import subprocess
import sys
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.spatial.package_converter import FILES, HERE, TARGET


class SpatialBundleTests(unittest.TestCase):
    def test_downloadable_bundle_contains_current_converter_and_guide(self):
        self.assertTrue(TARGET.is_file(), 'رابط التنزيل يتطلب حزمة منشورة')
        with zipfile.ZipFile(TARGET) as archive:
            self.assertEqual(tuple(archive.namelist()), FILES)
            for name in FILES:
                self.assertEqual(archive.read(name), (HERE / name).read_bytes(), name)
            self.assertIsNone(archive.testzip())

    def test_bundled_demo_glb_matches_shared_six_zone_fixture(self):
        source = HERE / 'samples/showcase-demo.plan.json'
        model = ROOT / 'app/assets/spatial-demo.glb'
        result = subprocess.run([sys.executable, str(HERE / 'check_glb.py'),
                                 str(source), str(model)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report['data_class'], 'demo')
        self.assertEqual(len(report['elements']), 6)


if __name__ == '__main__':
    unittest.main()

"""Offline startup preparation for the existing mobile demo, never a reset.

Run before server.py, with no server using --db. A missing database is restored
only from a hash-pinned domain JSON export. Existing demo databases take priority
over the bootstrap. Training is staged, checked, backed up, then atomically
published. A free host's /tmp still disappears on replacement: the secret export
is a recovery snapshot, not ongoing persistence for later edits.
"""
from __future__ import annotations

import argparse
import base64
import binascii
from contextlib import closing, contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from domain import COLLECTIONS, DomainStore
from evidence import MAX_ATTACHMENT_BYTES, MAX_BASE64_CHARS
from scripts.prepare_readiness_demo import seed_readiness

MARKER = 'r14_readiness_seeded'
SERVICE_COLLECTIONS = ('service_points', 'service_readings', 'service_jobs', 'service_days')
MAX_BOOTSTRAP_BYTES = 64 * 1024 * 1024
MAX_RECORDS = 100000
MAX_AUDIT = 200000
MAX_DEPTH = 40
MAX_STRING = 8 * 1024 * 1024
AUDIT_FIELDS = ('seq', 'at', 'actor_id', 'actor_role', 'command', 'record_id', 'payload')


def check(condition, message):
    if not condition:
        raise ValueError(message)


def _pairs(entries):
    result = {}
    for key, value in entries:
        check(key not in result, 'Duplicate JSON key in bootstrap')
        result[key] = value
    return result


def _constant(_):
    raise ValueError('Non-finite JSON number in bootstrap')


def _bounded(value, depth=0):
    check(depth <= MAX_DEPTH, 'Bootstrap nesting exceeds limit')
    if isinstance(value, dict):
        for key, item in value.items():
            check(len(key) <= 500, 'Bootstrap key exceeds limit')
            _bounded(item, depth + 1)
    elif isinstance(value, list):
        for item in value:
            _bounded(item, depth + 1)
    elif isinstance(value, str):
        check(len(value) <= MAX_STRING, 'Bootstrap string exceeds limit')
    elif isinstance(value, float):
        check(math.isfinite(value), 'Non-finite number in bootstrap')


def _json(raw):
    try:
        value = json.loads(raw, object_pairs_hook=_pairs, parse_constant=_constant)
        _bounded(value)
        return value
    except (RecursionError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError('Invalid bootstrap JSON') from error


def _identifier(value):
    return isinstance(value, str) and 0 < len(value) <= 500 and '\x00' not in value


def load_bootstrap(path, expected_sha256):
    check(isinstance(expected_sha256, str) and re.fullmatch(r'[0-9a-fA-F]{64}', expected_sha256),
          'Bootstrap SHA-256 must be 64 hexadecimal characters')
    with Path(path).open('rb') as source:
        raw = source.read(MAX_BOOTSTRAP_BYTES + 1)
    check(0 < len(raw) <= MAX_BOOTSTRAP_BYTES, 'Bootstrap size exceeds 64 MiB or is empty')
    digest = hashlib.sha256(raw).hexdigest()
    check(hmac.compare_digest(digest, expected_sha256.lower()), 'Bootstrap SHA-256 mismatch')
    data = _json(raw)
    required = {'format', 'schema_version', 'exported_at', 'mode', 'revision', 'records', 'audit', 'attachment_contents'}
    check(isinstance(data, dict) and set(data) == required, 'Unexpected export fields; accounts and sessions are never imported')
    check(data['format'] == 'riyadh-book-fair-backup' and type(data['schema_version']) is int
          and data['schema_version'] == 1 and data['mode'] == 'demo', 'Only schema 1 demo exports are accepted')
    check(isinstance(data['exported_at'], str), 'Export timestamp is missing')
    check(type(data['revision']) is int and 0 <= data['revision'] <= MAX_AUDIT, 'Invalid export revision')
    records = data['records']
    check(isinstance(records, dict) and set(records).issubset(COLLECTIONS), 'Unknown record collection')
    check(all(isinstance(rows, list) for rows in records.values()), 'Collections must be arrays')
    check(sum(map(len, records.values())) <= MAX_RECORDS, 'Too many bootstrap records')
    for collection, rows in records.items():
        seen = set()
        for row in rows:
            check(isinstance(row, dict) and _identifier(row.get('id')), 'Invalid record identifier')
            check(row['id'] not in seen, 'Duplicate record identifier')
            seen.add(row['id'])
            check(row.get('provenance') == 'demo', 'Non-demo record in demo bootstrap')
    audit = data['audit']
    check(isinstance(audit, list) and len(audit) == data['revision'], 'Audit length does not match revision')
    for index, row in enumerate(audit, 1):
        check(isinstance(row, dict) and set(row) == set(AUDIT_FIELDS), 'Invalid audit fields')
        check(type(row['seq']) is int and row['seq'] == index, 'Audit sequence is not contiguous')
        check(all(isinstance(row[key], str) for key in AUDIT_FIELDS[1:]), 'Invalid audit value')
        check(isinstance(_json(row['payload']), dict), 'Audit payload must be a JSON object')
    attachments = {row['id']: row for row in records.get('attachments', [])}
    contents = data['attachment_contents']
    check(isinstance(contents, list) and len(contents) == len(attachments), 'Attachment contents are incomplete')
    blobs = {}
    for entry in contents:
        check(isinstance(entry, dict) and set(entry) == {'id', 'sha256', 'size_bytes', 'data_base64'}, 'Invalid attachment content fields')
        identifier = entry['id']
        check(_identifier(identifier) and identifier in attachments and identifier not in blobs, 'Unknown or duplicate attachment content')
        encoded = entry['data_base64']
        check(isinstance(encoded, str) and 0 < len(encoded) <= MAX_BASE64_CHARS, 'Attachment encoding exceeds limit')
        try:
            blob = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as error:
            raise ValueError('Invalid attachment Base64') from error
        check(base64.b64encode(blob).decode('ascii') == encoded and 0 < len(blob) <= MAX_ATTACHMENT_BYTES,
              'Invalid attachment encoding or size')
        metadata = attachments[identifier]
        actual_hash = hashlib.sha256(blob).hexdigest()
        check(type(entry['size_bytes']) is int and type(metadata.get('size_bytes')) is int
              and entry['size_bytes'] == metadata['size_bytes'] == len(blob)
              and entry['sha256'] == metadata.get('sha256') == actual_hash, 'Attachment integrity mismatch')
        blobs[identifier] = blob
    return data, blobs, digest


def _snapshot(path):
    with closing(sqlite3.connect(Path(path).as_uri() + '?mode=ro', uri=True)) as connection:
        connection.execute('BEGIN')
        check(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'Database integrity check failed')
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        check({'metadata', 'records', 'audit', 'attachment_blobs', 'sessions'}.issubset(tables), 'Not a platform database')
        metadata = dict(connection.execute('SELECT key,value FROM metadata'))
        check(metadata.get('mode') == 'demo', 'Existing manual databases are never modified')
        check(metadata.get('demo_seeded') == '1', 'Existing database has no completed demo seed marker')
        return {'metadata': metadata,
                'records': connection.execute('SELECT collection,id,data FROM records ORDER BY rowid').fetchall(),
                'audit': connection.execute('SELECT * FROM audit ORDER BY seq').fetchall(),
                'blobs': connection.execute('SELECT id,content FROM attachment_blobs ORDER BY id').fetchall(),
                'sessions': connection.execute('SELECT * FROM sessions ORDER BY token_hash').fetchall()}


def _private_file(parent, label):
    descriptor, name = tempfile.mkstemp(prefix=label, suffix='.sqlite', dir=parent)
    os.close(descriptor)
    return Path(name)


def _remove_stage(path):
    for suffix in ('', '-wal', '-shm'):
        Path(str(path) + suffix).unlink(missing_ok=True)


def _copy(source, destination):
    with closing(sqlite3.connect(Path(source).as_uri() + '?mode=ro', uri=True)) as reader:
        with closing(sqlite3.connect(destination)) as writer:
            reader.backup(writer)


def _restore(path, data, blobs, digest):
    # Create only the schema; enabling demo before demo_seeded would seed over the
    # recovered export. This intermediate empty database is private and unpublished.
    store = DomainStore(path)
    with store.connect() as connection:
        connection.execute("UPDATE metadata SET value='demo' WHERE key='mode'")
        connection.execute("UPDATE metadata SET value=? WHERE key='revision'", (str(data['revision']),))
        connection.executemany('INSERT INTO metadata VALUES(?,?)', [('demo_seeded', '1'), ('bootstrap_sha256', digest)])
        for collection, rows in data['records'].items():
            for row in rows:
                connection.execute('INSERT INTO records VALUES(?,?,?)',
                                   (collection, row['id'], json.dumps(row, ensure_ascii=False, separators=(',', ':'), allow_nan=False)))
        connection.executemany('INSERT INTO audit(seq,at,actor_id,actor_role,command,record_id,payload) VALUES(?,?,?,?,?,?,?)',
                               [tuple(row[key] for key in AUDIT_FIELDS) for row in data['audit']])
        connection.executemany('INSERT INTO attachment_blobs VALUES(?,?)', list(blobs.items()))
    check(not _snapshot(path)['sessions'], 'Bootstrap must not restore sessions')


def _preserved(before, after):
    old = {(row[0], row[1]): row[2] for row in before['records']}
    new = {(row[0], row[1]): row[2] for row in after['records']}
    check(all(new.get(key) == value for key, value in old.items()), 'Training changed an existing record')
    check(after['audit'][:len(before['audit'])] == before['audit'], 'Training changed existing audit')
    check(after['blobs'] == before['blobs'], 'Training changed existing attachments')
    check(after['sessions'] == before['sessions'], 'Training changed existing sessions')
    check(all(after['metadata'].get(key) == value for key, value in before['metadata'].items() if key != 'revision'),
          'Training changed existing metadata')


def _preflight(store):
    state = store.state()
    check(bool(state['projects']), 'Training requires an existing demo project')
    pid = state['projects'][0]['id']
    phases = {p.get('kind') for p in state['phases'] if p.get('project_id') == pid}
    check({'operations', 'build'}.issubset(phases), 'Demo phases do not match training fixture')
    names = [z['name'] for z in state['zones'] if z.get('project_id') == pid]
    check(names[:4] == ['المستودع المركزي', 'القاعة أ', 'القاعة ب', 'منطقة التحميل'], 'Demo zones do not match training fixture')
    check(len(state['stakeholders']) >= 2 and all(s.get('project_id') == pid for s in state['stakeholders'][:2]),
          'Demo owners do not match training fixture')
    check(any(i.get('kind') == 'consumable' and i.get('project_id') == pid for i in state['items']),
          'Demo has no consumable for the training fixture')


def _checkpoint(path):
    # Startup-only: refuse active readers/writers instead of replacing a database
    # with an old WAL left next to it. DELETE mode persists safely across cutover.
    with closing(sqlite3.connect(path, timeout=5)) as connection:
        check(connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0] == 0, 'Database is busy; stop the server before preparation')
        check(connection.execute('PRAGMA journal_mode=DELETE').fetchone()[0] == 'delete', 'Database must be offline for cutover')
    with Path(path).open('rb') as stream:
        os.fsync(stream.fileno())


@contextmanager
def _startup_lock(target):
    descriptor = os.open(str(target) + '.r14.lock', os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError('Another r14 preparation is running') from error
        yield
    finally:
        os.close(descriptor)


def prepare_mobile(db, bootstrap, bootstrap_sha256):
    target = Path(db).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with _startup_lock(target):
        exists = target.exists()
        before = _snapshot(target) if exists else None
        if before and MARKER in before['metadata']:
            return {'action': 'already_upgraded', 'restored_bootstrap': False, 'revision': int(before['metadata']['revision'])}
        if before and any(row[0] in SERVICE_COLLECTIONS for row in before['records']):
            return {'action': 'existing_services_preserved', 'restored_bootstrap': False,
                    'revision': int(before['metadata']['revision']), 'training_seeded': False}
        data = blobs = digest = None
        if not exists:
            data, blobs, digest = load_bootstrap(bootstrap, bootstrap_sha256)
        stage = _private_file(target.parent, '.' + target.name + '.r14-stage-')
        baseline = None
        backup = None
        try:
            if exists:
                _copy(target, stage)
                check(_snapshot(stage) == before, 'Database changed while copying; preparation aborted')
            else:
                _restore(stage, data, blobs, digest)
                before = _snapshot(stage)
            baseline = _private_file(target.parent, '.' + target.name + '.r14-baseline-')
            _copy(stage, baseline)
            has_services = any(row[0] in SERVICE_COLLECTIONS for row in before['records'])
            if has_services:
                action = 'existing_services_preserved'
            else:
                store = DomainStore(stage, demo=True)
                _preflight(store)
                summary = seed_readiness(store)
                after_seed = _snapshot(stage)
                _preserved(before, after_seed)
                with store.connect() as connection:
                    connection.execute('INSERT INTO metadata VALUES(?,?)', (MARKER, json.dumps({
                        'version': 14, 'at': datetime.now(timezone.utc).isoformat(),
                        'mission_id': summary['mission_id'], 'baseline_revision': int(before['metadata']['revision'])})))
                action = 'upgraded'
            after = _snapshot(stage)
            _preserved(before, after)
            _checkpoint(stage)
            if exists:
                check(_snapshot(target) == before, 'Database changed before cutover; preparation aborted')
            backup = _private_file(target.parent, target.name + '.pre-r14-')
            _copy(baseline, backup)
            check(_snapshot(backup) == before, 'Original backup verification failed')
            _checkpoint(backup)
            if exists:
                _checkpoint(target)
            else:
                check(not target.exists(), 'Database appeared before cutover; preparation aborted')
            os.replace(stage, target)
            directory = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
            return {'action': action, 'restored_bootstrap': not exists, 'training_seeded': action == 'upgraded',
                    'revision': int(after['metadata']['revision']), 'backup_path': str(backup)}
        finally:
            _remove_stage(stage)
            if baseline:
                _remove_stage(baseline)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', required=True, type=Path)
    parser.add_argument('--bootstrap', required=True, type=Path)
    parser.add_argument('--bootstrap-sha256', required=True)
    args = parser.parse_args(argv)
    try:
        result = prepare_mobile(args.db, args.bootstrap, args.bootstrap_sha256)
    except Exception as error:
        # No bootstrap content or SQL values are included in error output.
        print(f'r14 preparation failed: {type(error).__name__}: {error}', file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

"""Create a NEW private r14 training database; never reuse an existing database."""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from domain import DomainStore
from scripts.prepare_services_demo import seed_services

ADMIN = {'id': 'readiness-demo-manager', 'role': 'admin'}
REPLACEMENT_REASON = 'replaced by measured demo mission'
TARGET_LITERS = 7000


def seed_readiness(store):
    """Extend the existing services fixture through commands, in demo mode only."""
    if store.mode != 'demo':
        raise ValueError('Readiness training must stay in demo mode')
    state = store.state()
    if any(state.get(key) for key in
           ('service_points', 'service_readings', 'service_jobs', 'service_days')):
        raise ValueError('Services records already exist; refusing to reuse this database')

    summary = seed_services(store)
    state = store.state()
    project_id = summary['project_id']
    phase = next(row for row in state['phases']
                 if row['project_id'] == project_id and row['kind'] == 'operations')
    points = {row['name']: row for row in state['service_points']
              if row['project_id'] == project_id}
    water = points['خزان المياه — القاعة أ']
    cleaning = points['نظافة القاعة أ']

    def latest_reading(point_id):
        readings = [row for row in state['service_readings']
                    if row['point_id'] == point_id and row['phase_id'] == phase['id']]
        # The fixture's reads have distinct times. Preserve insertion order on ties.
        return max(enumerate(readings), key=lambda pair:
                   (datetime.fromisoformat(pair[1]['observed_at']), pair[0]))[1]

    def do(command, **payload):
        return store.command(command, payload, ADMIN)['result']

    cleaning_job = next(row for row in state['service_jobs']
                        if row['point_id'] == cleaning['id']
                        and row['phase_id'] == phase['id']
                        and row['status'] == 'awaiting_verification')
    cleaning_reading = latest_reading(cleaning['id'])
    do('service_job.transition', id=cleaning_job['id'], status='completed',
       reading_id=cleaning_reading['id'],
       evidence='اعتماد تدريبي لقراءة النظافة الجاهزة بعد طلب التحقق؛ لا يثبت تنظيف موقع فعلي')

    previous_water_job = next(row for row in state['service_jobs']
                              if row['point_id'] == water['id']
                              and row['phase_id'] == phase['id']
                              and row['status'] == 'scheduled')
    do('service_job.transition', id=previous_water_job['id'], status='cancelled',
       reason=REPLACEMENT_REASON,
       evidence='استبدال مهمة الجدولة الاصطناعية بمهمة تدريب ذات خط أساس وهدف قابلين للتحقق')
    baseline = latest_reading(water['id'])
    if baseline.get('value') != 2100:
        raise ValueError('The services fixture changed; review the r14 water baseline')
    mission = do(
        'service_job.create', point_id=water['id'], phase_id=phase['id'],
        day_id=summary['day_id'], action='fill',
        due_at=(datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(),
        responsible_id=water['responsible_id'],
        provider='مزود مؤهل — اسم تدريبي؛ لا إرسال أو تنفيذ خارجي',
        quantity=TARGET_LITERS-baseline['value'], baseline_reading_id=baseline['id'],
        target_value=TARGET_LITERS,
        evidence='مهمة تدريب: الانتقال من قراءة يدوية اصطناعية 2100 لتر إلى هدف 7000 لتر، ثم قراءة متابعة واعتماد مدير',
        notes='الكمية المخططة لا تغيّر الخزان أو المخزون تلقائيًا. النتيجة تُحسب من قراءة جديدة بعد طلب التحقق.')
    return {
        **summary, 'phase_id': phase['id'], 'zone_id': water['zone_id'],
        'water_point_id': water['id'], 'mission_id': mission['id'],
        'baseline_reading_id': baseline['id'], 'baseline_value': baseline['value'],
        'target_value': TARGET_LITERS, 'unit': 'liters',
        'completed_cleaning_job_id': cleaning_job['id'],
        'replaced_job_id': previous_water_job['id'],
        'provenance': 'demo', 'spatial_location': 'unverified',
    }


def create_readiness_demo(path):
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(descriptor)
    try:
        store = DomainStore(target, demo=True)
        return {'database': str(target), **seed_readiness(store)}
    except BaseException:
        # Only remove files belonging to the database created by this invocation.
        for suffix in ('', '-wal', '-shm'):
            Path(str(target) + suffix).unlink(missing_ok=True)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, required=True,
                        help='A new private SQLite path; existing files are never changed')
    args = parser.parse_args(argv)
    try:
        summary = create_readiness_demo(args.db)
    except FileExistsError:
        parser.exit(2, 'الملف موجود مسبقًا؛ اختر مسارًا جديدًا. لم تتغير قاعدة البيانات.\n')
    except Exception as error:
        parser.exit(1, f'تعذر تجهيز عرض الجاهزية: {type(error).__name__}: {error}\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

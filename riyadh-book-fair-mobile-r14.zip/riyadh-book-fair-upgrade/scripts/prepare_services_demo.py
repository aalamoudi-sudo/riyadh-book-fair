"""Create a NEW isolated r13 demo; never edit an existing database or live system."""
from __future__ import annotations
import argparse
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from domain import DomainStore

RIYADH = timezone(timedelta(hours=3))
ADMIN = {'id': 'services-demo-manager', 'role': 'admin'}
FIELD = {'id': 'services-demo-field', 'role': 'field'}


def seed_services(store):
    if store.mode != 'demo':
        raise ValueError('Synthetic services data must stay in demo mode')
    state = store.state()
    if state.get('service_points') or state.get('service_days'):
        raise ValueError('Services records already exist; refusing to duplicate the scenario')
    pid = state['projects'][0]['id']
    phases = {p['kind']: p['id'] for p in state['phases'] if p['project_id'] == pid}
    zones = [z for z in state['zones'] if z['project_id'] == pid]
    owner = state['stakeholders'][0]['id']
    warehouse_owner = state['stakeholders'][1]['id']
    point = datetime.now(RIYADH)
    current_date = point.date().isoformat()

    def do(command, actor=ADMIN, **payload):
        return store.command(command, payload, actor)['result']

    def service(name, category, zone, **extra):
        return do('service_point.create', project_id=pid, name=name, category=category,
                  zone_id=zone, responsible_id=owner, phase_ids=[], freshness_minutes=60,
                  evidence='نقطة خدمة اصطناعية لعرض النموذج فقط؛ لا تمثل تجهيزًا فعليًا', **extra)

    water = service('خزان المياه — القاعة أ', 'water', zones[1]['id'], capacity=10000,
                    attention_percent=30, policy_reference='قاعدة تدريب اصطناعية؛ ليست حدًا فنيًا أو صحيًا')
    diesel = service('خزان الديزل — التجهيزات', 'diesel', zones[3]['id'], capacity=2000,
                     attention_percent=25, policy_reference='قاعدة تدريب اصطناعية؛ يحدد المختص حدود التشغيل الفعلية')
    sewage = service('خزان الصرف — المرافق', 'sewage', zones[2]['id'], capacity=8000,
                     attention_percent=75, policy_reference='قاعدة تدريب اصطناعية لشرح طلب الشفط فقط')
    clean_a = service('نظافة القاعة أ', 'cleaning', zones[1]['id'])
    clean_b = service('نظافة مرافق القاعة ب', 'cleaning', zones[2]['id'])
    gate_a = service('دخول القاعة أ — عدّ تجريبي', 'visitors', zones[1]['id'])
    gate_b = service('دخول القاعة ب — عدّ تجريبي', 'visitors', zones[2]['id'])
    item = next(i for i in state['items'] if i['kind'] == 'consumable' and i['project_id'] == pid)
    inventory = service('مواد التغليف — المستودع المركزي', 'inventory', zones[0]['id'],
                        item_id=item['id'], minimum_stock=300)
    service('خزان احتياطي — لم يُرصد بعد', 'water', zones[0]['id'], capacity=5000)

    day = do('service_day.open', project_id=pid, phase_id=phases['operations'],
             operational_date=current_date, responsible_id=owner,
             evidence='محضر استلام يوم عرض تجريبي؛ ليس يوم المعرض الفعلي')
    for stage in ['readiness','active']:
        day = do('service_day.advance', id=day['id'], stage=stage,
                 evidence='دليل اصطناعي لانتقال خطوة اليوم: '+stage)
    build_day = do('service_day.open', project_id=pid, phase_id=phases['build'],
                   operational_date=current_date, responsible_id=owner,
                   evidence='يوم بناء تجريبي مستقل لشرح اختلاف المراحل')
    do('service_day.advance', id=build_day['id'], stage='readiness',
       evidence='مراجعة جاهزية فريق البناء وتجهيزاته في المحاكاة')

    def reading(record, minutes=15, **extra):
        return do('service_reading.create', actor=FIELD, point_id=record['id'],
                  phase_id=phases['operations'], observed_at=(datetime.now(RIYADH)-timedelta(minutes=minutes)).isoformat(),
                  source='manual', evidence='قراءة اصطناعية موسومة للعرض؛ لا يوجد حساس متصل', **extra)

    reading(water, value=2100)
    reading(diesel, minutes=180, value=1450)
    reading(sewage, value=6700)
    reading(clean_a, condition='needs_service', notes='مثال اصطناعي: نقطة خدمة تحتاج جولة نظافة')
    reading(clean_b, condition='ready')

    # A measured zero is distinct from an unobserved hour. Future hours are never filled.
    today_start = point.replace(hour=0, minute=0, second=0, microsecond=0)
    periods = [today_start+timedelta(hours=h) for h in range(point.hour)]
    yesterday = today_start-timedelta(days=1)
    periods += [yesterday+timedelta(hours=h) for h in [9,10,11,12,14,16,17,18,19,20,21,22]]
    for start in periods:
        for gate, factor in [(gate_a,1),(gate_b,2)]:
            if gate is gate_b and start.hour in {1,14,19}:
                continue  # Deliberate coverage gap, never interpreted as zero.
            value = 0 if start.hour == 0 else (start.hour+3)*factor*17
            do('service_reading.create', actor=FIELD, point_id=gate['id'], phase_id=phases['operations'],
               observed_at=(start+timedelta(hours=1)).isoformat(), period_start=start.isoformat(),
               period_end=(start+timedelta(hours=1)).isoformat(), source='manual', value=value,
               evidence='عدّ حركات دخول اصطناعي لساعة كاملة، لا يمثل زوارًا فريدين')

    for record, action, offset, quantity in [(water,'fill',-30,4000),(sewage,'pump',45,5000),(inventory,'replenish',90,100)]:
        do('service_job.create', point_id=record['id'], phase_id=phases['operations'], day_id=day['id'],
           action=action, due_at=(point+timedelta(minutes=offset)).isoformat(),
           responsible_id=warehouse_owner if action=='replenish' else owner,
           provider='فريق خدمات تجريبي — لا إرسال خارجي', quantity=quantity,
           evidence='جدولة اصطناعية؛ موعد الخدمة لا يثبت تنفيذها')
    cleaning = do('service_job.create', point_id=clean_a['id'], phase_id=phases['operations'],
                  day_id=day['id'], action='clean', due_at=(point-timedelta(minutes=15)).isoformat(),
                  responsible_id=owner, provider='فريق النظافة التجريبي', evidence='طلب تنظيف اصطناعي')
    do('service_job.transition', actor=FIELD, id=cleaning['id'], status='in_progress',
       evidence='بدء تنفيذ اصطناعي')
    do('service_job.transition', actor=FIELD, id=cleaning['id'], status='awaiting_verification',
       evidence='أفاد الفريق بإتمام الجولة التجريبية؛ ينتظر تحققًا')
    # Follow-up occurs after the verification request and never completes the job implicitly.
    reading(clean_a, minutes=0, condition='ready', notes='قراءة متابعة اصطناعية؛ اعتماد المدير ما زال مطلوبًا')
    return {'project_id':pid,'operational_date':current_date,'point_count':len(store.state()['service_points']),
            'day_id':day['id'],'provenance':'demo'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',type=Path,required=True)
    args=parser.parse_args()
    args.db.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(args.db,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    os.close(fd)
    store=DomainStore(args.db,demo=True)
    result=seed_services(store)
    print(json.dumps({'database':str(args.db.resolve()),**result},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()

import {esc,n,badge,empty} from './ui.js';

export function reviewedPlanForZone(plans,projectId,zoneId) {
  return plans.filter(p=>p.project_id===projectId&&p.status==='reviewed'&&p.provenance!=='demo'&&p.plan?.provenance?.data_class==='manual'&&p.plan.elements?.some(e=>e.zone_id===zoneId))
    .sort((a,b)=>(Number(b.review_revision)||0)-(Number(a.review_revision)||0)||(Date.parse(b.reviewed_at)||0)-(Date.parse(a.reviewed_at)||0))[0]||null;
}
export const readinessLabels={needs_action:'تحتاج متابعة',unknown:'غير متحققة',clear:'الخدمات المسجلة ضمن الشروط'};

export function renderSpatialReadiness(ctx,focus={}) {
  const phases=ctx.records('phases'),phase=phases.find(p=>p.id===focus.phaseId)||phases.find(p=>p.kind==='operations')||phases[0];
  const zones=ctx.records('zones'),summaries=ctx.records('zone_readiness').filter(r=>r.phase_id===phase?.id);
  const cards=zones.map(zone=>{
    const row=summaries.find(r=>r.zone_id===zone.id),status=row?.status||'unknown';
    const plan=reviewedPlanForZone(ctx.records('spatial_plans'),ctx.projectId,zone.id);
    return `<article class="spatial-service-zone ${zone.id===focus.zoneId?'is-selected':''}"><div>${badge(status==='needs_action'?'high':'reference',readinessLabels[status])}<h3>${esc(zone.name)}</h3><p>${row?.points?.length?`${n(row.counts.needs_action)} تحتاج متابعة · ${n(row.counts.unknown)} غير متحققة`:'لا نقاط خدمة محسوبة لهذه المرحلة؛ الحالة غير متحققة'}</p><p class="field-help">${plan?`موضع في مخطط مراجع: ${esc(plan.title)} · ${esc(plan.source_version)}`:'معرّف منطقة مرتبط بالسجلات؛ لا موضع يدوي مراجع'}</p></div><div class="actions"><button type="button" class="btn secondary" data-action="readiness-open" data-zone="${esc(zone.id)}" data-phase="${esc(phase?.id||'')}">فتح الجاهزية والمهمة</button>${plan?`<button type="button" class="btn secondary" data-action="spatial-service-locate" data-zone="${esc(zone.id)}" data-phase="${esc(phase?.id||'')}">عرض موضع المنطقة</button>`:''}</div></article>`;
  }).join('');
  return `<section id="spatial-service-readiness" class="panel spatial-service-board"><div class="panel-head"><div><span class="eyebrow">الرصد ← العمل ← التحقق</span><h2>ارتباط الخدمات بالمناطق</h2><p>${esc(phase?.name||'لم تُعرّف مرحلة')} · الحالة للخدمات المسجلة فقط؛ لا تمنح اعتماد تشغيل المنطقة.</p></div><a class="btn secondary" href="#readiness" data-route="readiness">جاهزية المناطق</a></div><div class="panel-body"><p class="field-help">هذه لوحة ارتباط بالسجلات، وليست خريطة مواقع. يظهر رابط الموضع فقط عند وجود مخطط يدوي مراجع يضم المنطقة. اختيار رسم أو مجسم تجريبي لا يمنح موضعًا معتمدًا.</p><div class="spatial-service-grid">${cards||empty('لم تُعرّف مناطق بعد')}</div></div></section>`;
}

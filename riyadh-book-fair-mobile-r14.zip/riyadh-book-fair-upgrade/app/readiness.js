import {esc,n,badge,icon,button,field,select,textarea,modal,empty} from './ui.js';
import {reviewedPlanForZone} from './spatial-readiness.js';

const scopes=new Map();
const categories={cleaning:'النظافة',water:'المياه',diesel:'الديزل',sewage:'الصرف الصحي',inventory:'المخزون'};
const statusNames={unknown:'حالة غير معروفة',needs_action:'تحتاج إجراء',clear:'لا متابعة مطلوبة في المسجل'};
const jobNames={scheduled:'مجدولة',in_progress:'قيد التنفيذ',awaiting_verification:'بانتظار التحقق',completed:'نتيجة معتمدة',cancelled:'ملغاة'};
const actions={water:'fill',diesel:'fill',sewage:'pump',cleaning:'clean'};
const actionNames={fill:'تعبئة',pump:'شفط',clean:'تنظيف'};
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const rows=(ctx,key)=>ctx.records(key)||[];
const num=value=>finite(value)?n(value):'غير معروف';
const attr=(zone,phase)=>`data-zone="${esc(zone)}" data-phase="${esc(phase)}"`;
const allowed=(ctx,type)=>ctx.can(type)?'':'disabled title="الإجراء غير متاح لصلاحيتك أو لحالة المشروع"';
const isAdmin=ctx=>['manager','admin'].includes(ctx.state.user?.role);
const sourceName=record=>record?.provenance==='demo'?'رصد تجريبي':record?.source==='stock_ledger'?'دفتر المخزون · دون تحقق ميداني':record?.source==='field'?'رصد ميداني يدوي':'إدخال يدوي';
function stamp(value){return value&&Number.isFinite(Date.parse(value))?new Intl.DateTimeFormat('ar-SA-u-nu-latn',{timeZone:'Asia/Riyadh',calendar:'gregory',dateStyle:'medium',timeStyle:'short'}).format(new Date(value)):'غير مسجل';}
function localTime(value=Date.now()){return new Date(new Date(value).getTime()+10800000).toISOString().slice(0,16);}
function localISO(value){if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value||''))throw new Error('أدخل موعدًا صحيحًا بتوقيت الرياض.');const date=new Date(`${value}:00+03:00`);if(!Number.isFinite(date.getTime())||localTime(date)!==value)throw new Error('موعد المهمة غير صالح.');return date.toISOString();}
const stateBadge=state=>badge(state==='needs_action'?'high':'reference',statusNames[state]||statusNames.unknown);
const condition=value=>value==='ready'?'جاهزة':value==='needs_service'?'تحتاج خدمة':'غير معروف';
function valueText(value,category){return category==='cleaning'?condition(value):finite(value)?`${n(value)} لتر`:'غير معروف';}

// Geometry is a reviewed reference, not an engineering or sensor assertion.
export function selectReviewedZonePlan(plans,zoneId,projectId){
  return reviewedPlanForZone(plans,projectId,zoneId);
}
export function zoneReadinessView(row){
  if(!row)return {status:'unknown',unknown:null,needsAction:null,clear:null,points:[],generatedAt:null};
  const points=Array.isArray(row.points)?row.points:[];
  return {status:points.length&&['unknown','needs_action','clear'].includes(row.status)?row.status:'unknown',unknown:finite(row.counts?.unknown)?row.counts.unknown:null,needsAction:finite(row.counts?.needs_action)?row.counts.needs_action:null,clear:finite(row.counts?.clear)?row.counts.clear:null,points,generatedAt:row.generated_at||null};
}
export function missionEligibility(point,readings,phaseId,now=Date.now()){
  if(!point||!actions[point.category])return {eligible:false,baseline:null,reason:'المهمة المقاسة متاحة للخزانات والنظافة. المخزون يتبع دفتر حركاته.'};
  if(point.phase_ids?.length&&!point.phase_ids.includes(phaseId))return {eligible:false,baseline:null,reason:'النقطة لا تخدم المرحلة المختارة.'};
  const baseline=readings.map((reading,index)=>({reading,index})).filter(({reading})=>reading.point_id===point.id&&reading.phase_id===phaseId&&reading.project_id===point.project_id).sort((a,b)=>Date.parse(b.reading.observed_at)-Date.parse(a.reading.observed_at)||b.index-a.index)[0]?.reading;
  if(!baseline)return {eligible:false,baseline:null,reason:'سجّل قراءة أساس للنقطة في هذه المرحلة أولًا.'};
  const age=(new Date(now).getTime()-Date.parse(baseline.observed_at))/60000;
  if(!Number.isFinite(age)||age<0||!finite(point.freshness_minutes)||point.freshness_minutes<=0||age>point.freshness_minutes)return {eligible:false,baseline,reason:'قراءة الأساس متقادمة أو غير صالحة؛ سجّل رصدًا جديدًا.'};
  if(point.category==='cleaning')return {eligible:baseline.condition==='needs_service',baseline,reason:baseline.condition==='needs_service'?'هدف المهمة إثبات الجاهزية بقراءة لاحقة.':'القراءة الحالية لا تسجل حاجة للنظافة؛ يلزم مصدر يثبت الحاجة.'};
  if(!finite(baseline.value)||!finite(point.capacity)||point.capacity<=0||baseline.value<0||baseline.value>point.capacity)return {eligible:false,baseline,reason:'كمية الأساس أو سعة الخزان غير صالحة.'};
  if((point.category==='sewage'&&baseline.value===0)||(point.category!=='sewage'&&baseline.value===point.capacity))return {eligible:false,baseline,reason:'لا يوجد مجال لهدف تحسين في اتجاه الخدمة من هذه القراءة.'};
  return {eligible:true,baseline,reason:'حدّد هدفًا أفضل من قراءة الأساس وضمن السعة.'};
}
export function buildMeasuredMission(point,baseline,data,{projectId,phaseId}){
  if(!point||!baseline||point.project_id!==projectId||baseline.project_id!==projectId||baseline.point_id!==point.id||baseline.phase_id!==phaseId||!actions[point.category])throw new Error('مصدر المهمة لا يطابق النقطة والمشروع والمرحلة.');
  for(const key of ['responsible_id','provider','evidence','due_at'])if(!String(data[key]||'').trim())throw new Error('أكمل المسؤول والمزود والموعد وإثبات التكليف.');
  const payload={project_id:projectId,point_id:point.id,phase_id:phaseId,baseline_reading_id:baseline.id,action:actions[point.category],due_at:localISO(data.due_at),responsible_id:data.responsible_id,provider:data.provider,evidence:data.evidence};
  if(point.category==='cleaning'){
    if(baseline.condition!=='needs_service')throw new Error('مهمة النظافة المقاسة تحتاج قراءة أساس تسجل الحاجة للخدمة.');
    payload.target_condition='ready';
  }else{
    const target=data.target_value===null||data.target_value===undefined||String(data.target_value).trim()===''?NaN:Number(data.target_value);
    if(!Number.isFinite(target)||target<0||!finite(point.capacity)||target>point.capacity||!finite(baseline.value)||(point.category==='sewage'?target>=baseline.value:target<=baseline.value))throw new Error(point.category==='sewage'?'الهدف يجب أن يقل عن كمية الأساس ويبقى غير سالب.':'الهدف يجب أن يزيد عن كمية الأساس ولا يتجاوز السعة.');
    payload.target_value=target;
  }
  return payload;
}
export function missionComparison(job,point){
  const cleaning=point?.category==='cleaning';
  const before=cleaning?job.baseline_snapshot?.condition:job.baseline_snapshot?.value;
  const target=cleaning?job.target_condition:job.target_value;
  const outcome=job.outcome;
  const valid=job.status==='completed'&&outcome?.target_met===true&&Boolean(outcome.reading_id)&&Boolean(outcome.observed_at)&&(cleaning?outcome.after==='ready':finite(outcome.after));
  return {before:cleaning?(before||null):(finite(before)?before:null),target:cleaning?(target||null):(finite(target)?target:null),after:valid?outcome.after:null,delta:valid&&finite(outcome.delta)?outcome.delta:null,verified:valid,outcome:valid?outcome:null};
}
function phaseList(ctx){return rows(ctx,'phases').slice().sort((a,b)=>(a.order||0)-(b.order||0));}
function readinessRows(ctx,phaseId){return rows(ctx,'zone_readiness').filter(row=>row.phase_id===phaseId);}
function defaultZone(ctx,phaseId){
  const rank={needs_action:0,unknown:1,clear:2},zones=rows(ctx,'zones');
  const measuredZones=new Set(rows(ctx,'service_jobs').filter(job=>job.phase_id===phaseId&&job.baseline_snapshot&&!['completed','cancelled'].includes(job.status)).map(job=>job.zone_id||rows(ctx,'service_points').find(point=>point.id===job.point_id)?.zone_id));
  return readinessRows(ctx,phaseId).filter(row=>zones.some(zone=>zone.id===row.zone_id)).sort((a,b)=>{
    const aStatus=zoneReadinessView(a).status,bStatus=zoneReadinessView(b).status;
    return (rank[aStatus]??1)-(rank[bStatus]??1)||(aStatus==='needs_action'&&bStatus==='needs_action'?Number(measuredZones.has(b.zone_id))-Number(measuredZones.has(a.zone_id)):0)||zones.findIndex(zone=>zone.id===a.zone_id)-zones.findIndex(zone=>zone.id===b.zone_id);
  })[0]?.zone_id||zones[0]?.id||'';
}
export function getReadinessScope(ctx){
  if(!scopes.has(ctx.projectId))scopes.set(ctx.projectId,{phaseId:phaseList(ctx).find(p=>p.kind==='operations')?.id||phaseList(ctx)[0]?.id||'',zoneId:'',error:''});
  const scope=scopes.get(ctx.projectId);
  if(!phaseList(ctx).some(p=>p.id===scope.phaseId))scope.phaseId=phaseList(ctx).find(p=>p.kind==='operations')?.id||phaseList(ctx)[0]?.id||'';
  if(!rows(ctx,'zones').some(z=>z.id===scope.zoneId))scope.zoneId=defaultZone(ctx,scope.phaseId);
  return {zoneId:scope.zoneId,phaseId:scope.phaseId};
}
export function setReadinessScope(ctx,{zoneId,phaseId}={}){
  getReadinessScope(ctx);const scope=scopes.get(ctx.projectId);
  if(phaseId!==undefined&&phaseList(ctx).some(p=>p.id===phaseId)){scope.phaseId=phaseId;if(zoneId===undefined)scope.zoneId=defaultZone(ctx,phaseId);}
  if(zoneId!==undefined&&rows(ctx,'zones').some(z=>z.id===zoneId))scope.zoneId=zoneId;
  return getReadinessScope(ctx);
}
function currentRow(ctx){const scope=getReadinessScope(ctx);return readinessRows(ctx,scope.phaseId).find(row=>row.zone_id===scope.zoneId);}
function zoneList(ctx,scope){
  const summary=new Map(readinessRows(ctx,scope.phaseId).map(row=>[row.zone_id,zoneReadinessView(row)]));
  return `<aside class="readiness-zones" aria-label="اختيار منطقة"><div class="readiness-zones-heading"><h2>مناطق المشروع</h2><p>الحالة للخدمات المسجلة فقط</p></div>${rows(ctx,'zones').map(zone=>{const state=summary.get(zone.id)||zoneReadinessView();return `<button type="button" class="readiness-zone ${zone.id===scope.zoneId?'selected':''}" data-action="readiness-select" ${attr(zone.id,scope.phaseId)} ${zone.id===scope.zoneId?'aria-current="true"':''}><span class="readiness-zone-name">${esc(zone.name)}</span><span class="readiness-zone-state ${state.status}">${esc(statusNames[state.status])}</span><span class="readiness-zone-counts">${state.points.length?`${num(state.needsAction)} متابعة <span aria-hidden="true">·</span> ${num(state.unknown)} مجهول`:'لا نقاط خدمة مسجلة'}</span></button>`;}).join('')}</aside>`;
}
function sourceValue(point,entry){
  if(!entry||entry.source_status==='unknown'||(!entry.source_status&&entry.status==='unknown'))return 'غير معروف';
  if(point.category==='cleaning')return condition(entry.condition);
  if(point.category==='inventory')return finite(entry.value)?`${n(entry.value)} متاح دفتريًا`:'رصيد غير معروف';
  return valueText(entry.value,point.category);
}
function sourceAction(ctx,point,phaseId){
  if(point.category==='inventory')return `<a class="btn secondary" href="#${rows(ctx,'items').find(item=>item.id===point.item_id)?.kind==='book'?'books':'warehouse'}" data-route="${rows(ctx,'items').find(item=>item.id===point.item_id)?.kind==='book'?'books':'warehouse'}">فتح دفتر المخزون</a>`;
  return button('تحديث الرصد','services-reading','small','plus',`data-id="${esc(point.id)}" ${attr(point.zone_id,phaseId)} ${allowed(ctx,'service_reading.create')}`);
}
function pointRow(ctx,entry,phaseId){
  const point=rows(ctx,'service_points').find(p=>p.id===entry.point_id);if(!point)return '';
  const eligibility=missionEligibility(point,rows(ctx,'service_readings'),phaseId);
  const measurement=entry.reading_id?rows(ctx,'service_readings').find(reading=>reading.id===entry.reading_id):null;
  const unknown=entry.source_status==='unknown'||(!entry.source_status&&entry.status==='unknown');
  return `<article class="readiness-point"><div class="readiness-point-title"><span>${esc(categories[point.category]||point.category)}</span><h3>${esc(point.name)}</h3><p>${esc(ctx.name('stakeholders',point.responsible_id))}</p></div><div class="readiness-point-source"><strong>${esc(sourceValue(point,entry))}</strong><span>${esc(entry.reason||'لم يسجل تفسير الحالة')}</span><small>${esc(sourceName(entry))}${entry.observed_at?` · ${esc(stamp(entry.observed_at))}`:''}${finite(entry.age_minutes)?` · عمر ${n(Math.floor(entry.age_minutes))} دقيقة`:''}</small>${unknown&&measurement?`<small>آخر قيمة محفوظة: ${esc(valueText(point.category==='cleaning'?measurement.condition:measurement.value,point.category))}؛ لا تمثل الحالة الحالية.</small>`:''}${point.category==='inventory'?'<small>رصيد الحركات؛ لا يُعد إثبات جرد ميداني.</small>':''}${entry.open_job_ids?.length?`<small>${n(entry.open_job_ids.length)} مهمة مفتوحة؛ وجود التكليف لا يزيل فجوة الرصد.</small>`:''}</div><div class="readiness-point-actions">${sourceAction(ctx,point,phaseId)}${actions[point.category]?button('تكليف بهدف مقاس','readiness-mission','secondary','arrow',`data-id="${esc(point.id)}" ${attr(point.zone_id,phaseId)} ${allowed(ctx,'service_job.create')} ${eligibility.eligible?'':`disabled title="${esc(eligibility.reason)}"`}`):''}${actions[point.category]&&!eligibility.eligible?`<small>${esc(eligibility.reason)}</small>`:''}</div></article>`;
}
function jobActions(ctx,job,point){
  const next={scheduled:'in_progress',in_progress:'awaiting_verification',awaiting_verification:'completed'}[job.status];
  return `<div class="actions">${next?button(({in_progress:'بدء التنفيذ',awaiting_verification:'طلب التحقق',completed:'اعتماد النتيجة'})[next],'services-job-transition','primary','check',`data-id="${esc(job.id)}" data-status="${next}" ${allowed(ctx,'service_job.transition')} ${next==='completed'&&!isAdmin(ctx)?'disabled title="اعتماد النتيجة للمدير"':''}`):''}${job.status==='awaiting_verification'?sourceAction(ctx,point,job.phase_id):''}${button('سجل المهمة','services-job-detail','secondary','reports',`data-id="${esc(job.id)}"`)}</div>`;
}
function missionCard(ctx,job){
  const point=rows(ctx,'service_points').find(p=>p.id===job.point_id);if(!point)return '';
  const comparison=missionComparison(job,point),target=point.category==='cleaning'?'جاهزة':`${num(comparison.target)} لتر ${point.category==='sewage'?'أو أقل':'أو أكثر'}`;
  const outcome=comparison.outcome;
  return `<article class="readiness-mission ${comparison.verified?'verified':''}"><div class="readiness-mission-heading"><div><span class="eyebrow">مهمة ميدانية بهدف محفوظ</span><h3>${esc(actionNames[job.action]||'خدمة')} · ${esc(point.name)}</h3><p>${esc(ctx.name('stakeholders',job.responsible_id))} · ${esc(job.provider||'فريق غير مسجل')} · الموعد ${esc(stamp(job.due_at))}</p></div>${badge(comparison.verified?'completed':job.status==='awaiting_verification'?'inspection':job.status,jobNames[job.status]||job.status)}</div><ol class="readiness-comparison"><li><span>01 · قراءة الأساس</span><strong>${esc(valueText(comparison.before,point.category))}</strong><small>${esc(stamp(job.baseline_snapshot?.observed_at))}<br>${esc(sourceName(job.baseline_snapshot))}</small></li><li><span>02 · الهدف المسجل</span><strong><bdi>${esc(target)}</bdi></strong><small>حُدد عند التكليف<br>${point.category==='cleaning'?'يتحقق برصد «جاهزة»':'كمية مرصودة بعد التنفيذ، ضمن سعة الخزان'}</small></li><li class="${comparison.verified?'has-result':''}"><span>03 · القياس اللاحق</span><strong>${comparison.verified?esc(valueText(comparison.after,point.category)):'بانتظار قياس معتمد'}</strong><small>${comparison.verified?`${esc(stamp(outcome.observed_at))}<br>${comparison.delta!==null?`التغير المسجل: <bdi>${comparison.delta>0?'+':''}${n(comparison.delta)} لتر</bdi>`:'الحاجة للخدمة ← جاهزة'}`:'قراءة جديدة بعد طلب التحقق<br>لا تكفي حالة التنفيذ لإثبات النتيجة'}</small></li></ol><div class="readiness-mission-foot">${jobActions(ctx,job,point)}${comparison.verified?`<p>تحقق الهدف وفق القراءتين. المعتمد: ${esc(outcome.verified_by)} · ${esc(stamp(outcome.verified_at))}. هذا تغير مرصود؛ لا يثبت أن المهمة وحدها سببت التغير.</p>`:'<p>تبقى النتيجة غير مثبتة حتى تعتمد قراءة تحقق تحقق الهدف. عند عدم بلوغه، سجل المتابعة واستكمل العمل.</p>'}</div></article>`;
}
function selectedZone(ctx,scope){
  const zone=rows(ctx,'zones').find(z=>z.id===scope.zoneId);if(!zone)return empty('لم تُعرّف مناطق بعد','أضف منطقة ونقاط خدماتها لبدء الربط بالرصد والمهمة.');
  const state=zoneReadinessView(currentRow(ctx)),plan=selectReviewedZonePlan(rows(ctx,'spatial_plans'),zone.id,ctx.projectId);
  const jobs=rows(ctx,'service_jobs').filter(job=>job.phase_id===scope.phaseId&&job.baseline_snapshot&&(job.zone_id===zone.id||rows(ctx,'service_points').some(p=>p.id===job.point_id&&p.zone_id===zone.id))).sort((a,b)=>(Date.parse(b.created_at)||0)-(Date.parse(a.created_at)||0));
  const openOrdinary=rows(ctx,'service_jobs').filter(job=>!job.baseline_snapshot&&job.phase_id===scope.phaseId&&!['completed','cancelled'].includes(job.status)&&(job.zone_id===zone.id||rows(ctx,'service_points').some(p=>p.id===job.point_id&&p.zone_id===zone.id)));
  return `<section class="readiness-zone-detail" aria-labelledby="readiness-zone-title"><div class="readiness-zone-heading"><div><span class="eyebrow">${esc(ctx.name('phases',scope.phaseId))} · حالة الخدمات المسجلة</span><h2 id="readiness-zone-title">${esc(zone.name)}</h2>${stateBadge(state.status)}</div>${button(plan?'موضع في مخطط مراجع':'عرض ارتباط المنطقة','readiness-spatial','secondary','spatial',attr(zone.id,scope.phaseId))}</div><p class="readiness-location-note">${plan?`${esc(plan.title)} · إصدار ${esc(plan.source_version||'غير مسجل')}. ربط بمعرف المنطقة على مخطط مراجع؛ لا يثبت رفعًا مساحيًا أو اعتمادًا هندسيًا.`:'لا موضع يدوي مراجع لهذه المنطقة. عرض الارتباطات يربط السجلات دون إحداثيات أو ادعاء موضع جغرافي.'}</p>${state.points.length?`<div class="readiness-count-strip"><div><strong>${num(state.needsAction)}</strong><span>تحتاج إجراء</span></div><div><strong>${num(state.unknown)}</strong><span>دليلها غير معروف</span></div><div><strong>${num(state.clear)}</strong><span>لا متابعة مطلوبة في المسجل</span></div><p>قد تجتمع المهمة المفتوحة والرصد المجهول في النقطة نفسها؛ الأعداد متداخلة ولا تمثل نسبة جاهزية.</p></div>`:'<p class="readiness-unregistered">لا نقاط خدمة مسجلة في هذه المرحلة؛ الحالة غير معروفة حتى يحدد نطاق الخدمة وتضاف مصادر الرصد.</p>'}<section class="readiness-sources"><div class="readiness-section-heading"><span class="eyebrow">ابدأ بالدليل</span><h3>نقاط الخدمة وسبب الحالة</h3><p>محسوبة على الخادم: ${esc(stamp(state.generatedAt))}. المصادر المتقادمة تبقى مجهولة.</p></div>${state.points.length?state.points.map(point=>pointRow(ctx,point,scope.phaseId)).join(''):empty('لا نقاط خدمة محسوبة لهذه المنطقة والمرحلة','الحالة غير معروفة؛ لا يعادل غياب النقاط اجتياز الجاهزية.')}</section><section class="readiness-missions"><div class="readiness-section-heading"><span class="eyebrow">من التكليف إلى النتيجة</span><h3>المهام المقاسة</h3><p>قراءة الأساس والهدف محفوظان مع المهمة. النتيجة تأتي من قراءة تحقق جديدة.</p></div>${jobs.length?jobs.map(job=>missionCard(ctx,job)).join(''):empty('لم تسجل مهمة بهدف مقاس بعد','اختر نقطة خزانات أو نظافة لها قراءة أساس صالحة، ثم حدّد المطلوب ومسؤول التنفيذ.')}${openOrdinary.length?`<div class="readiness-existing-jobs"><h4>أعمال خدمة قائمة دون هدف مقاس</h4><p>تظل ضمن المتابعة، ولا نضيف إليها نتيجة قبل/بعد غير موثقة.</p><div class="actions">${openOrdinary.map(job=>button(`${ctx.name('service_points',job.point_id)} · ${jobNames[job.status]||job.status}`,'services-job-detail','small','reports',`data-id="${esc(job.id)}"`)).join('')}</div></div>`:''}</section></section>`;
}
export function renderReadiness(ctx){
  const scope=getReadinessScope(ctx),error=scopes.get(ctx.projectId)?.error;
  return `<div class="readiness-workspace" data-readiness-root><div class="page-heading"><div><span class="eyebrow">المنطقة · الرصد · المهمة · النتيجة</span><h1>جاهزية المناطق</h1><p>حدد أين تحتاج الخدمات المسجلة إلى إجراء، ثم تتبع التكليف حتى قياس نتيجته.</p></div><div class="actions">${button('تحديث الحالة','readiness-reload','secondary','refresh')}<a class="btn secondary" href="#services" data-route="services">مراقبة الخدمات</a></div></div><div class="readiness-scope-note">${icon('reports')}<p>حالة الخدمات المسجلة فقط؛ لا تمثل شهادة جاهزية أو سلامة للمنطقة. الرصد يدوي مؤرخ، وحركات الدخول مستبعدة من هذا الحكم.</p></div><div class="readiness-filter">${select('readiness_phase','مرحلة المشروع',phaseList(ctx),scope.phaseId,'data-readiness-phase')}<p data-readiness-connection class="${error?'is-error':''}" role="status">${error?esc(error):`آخر تحميل للسجلات: ${esc(stamp(ctx.lastLoaded))}. يتجدد العرض كل دقيقة أثناء فتحه، ويتوقف أثناء تحرير نموذج.`}</p></div>${!scope.phaseId?empty('حدد مراحل المشروع أولًا','لكل مرحلة نطاق رصد ومهام مستقلة.'):!rows(ctx,'zones').length?empty('لا مناطق مسجلة','عرّف المناطق من الجهات والمسؤوليات ثم أضف نقاط الخدمات.'): `<div class="readiness-layout">${zoneList(ctx,scope)}${selectedZone(ctx,scope)}</div>`}</div>`;
}
function newMission(ctx,el){
  if(!ctx.can('service_job.create'))throw new Error('إنشاء المهمة غير متاح لصلاحيتك أو لحالة المشروع.');
  const scope=setReadinessScope(ctx,{zoneId:el.dataset.zone,phaseId:el.dataset.phase});
  const point=rows(ctx,'service_points').find(p=>p.id===el.dataset.id&&p.zone_id===scope.zoneId);
  const eligibility=missionEligibility(point,rows(ctx,'service_readings'),scope.phaseId);
  if(!eligibility.eligible)throw new Error(eligibility.reason);
  if(!rows(ctx,'stakeholders').length)throw new Error('أضف مسؤول التنفيذ إلى المشروع أولًا.');
  const baseline=eligibility.baseline;
  const relation=point.category==='sewage'?'أقل من':'أعلى من';
  modal(`تكليف بهدف مقاس · ${point.name}`,`<div class="readiness-form-source"><span>قراءة أساس محفوظة عند التكليف</span><strong>${esc(valueText(point.category==='cleaning'?baseline.condition:baseline.value,point.category))}</strong><p>${esc(stamp(baseline.observed_at))} · ${esc(sourceName(baseline))} · ${esc(ctx.name('phases',scope.phaseId))}</p><small>المرجع: ${esc(baseline.evidence||baseline.id)}</small></div><div class="form-grid">${point.category==='cleaning'?'<div class="wide readiness-fixed-goal"><strong>الهدف: جاهزة</strong><p>إثبات الجاهزية بقراءة جديدة بعد طلب التحقق.</p></div>':field('target_value',`الهدف بعد ${point.category==='sewage'?'الشفط':'التعبئة'} · لتر`,'number','',`required min="0" max="${point.capacity}" step="any"`)}${field('due_at','موعد التنفيذ · الرياض','datetime-local',localTime(Date.now()+3600000),'required')}${select('responsible_id','مسؤول التنفيذ',rows(ctx,'stakeholders'),point.responsible_id,'required')}${field('provider','الفريق أو المزود','text','','required maxlength="200"')}${textarea('evidence','مرجع التكليف وسبب اختيار الهدف','','required maxlength="4000"')}</div><p class="readiness-form-note">${point.category==='cleaning'?'النتيجة لا تثبت بمجرد تأشير التنفيذ.':`الهدف ${relation} قراءة الأساس وضمن سعة ${n(point.capacity)} لتر. لا ينفذ النظام تعبئة أو شفطًا آليًا.`} يسجل المدير اعتماد النتيجة بعد قراءة تحقق جديدة تحقق الهدف.</p>`,async data=>{
    const current=missionEligibility(point,rows(ctx,'service_readings'),scope.phaseId);
    if(!current.eligible||current.baseline?.id!==baseline.id)throw new Error('تغيرت قراءة الأساس أو تقادمت؛ حدّث الحالة وافتح التكليف من جديد.');
    await ctx.command('service_job.create',buildMeasuredMission(point,baseline,data,{projectId:ctx.projectId,phaseId:scope.phaseId}));
  },'حفظ التكليف والهدف',true);
}
async function reloadReadiness(ctx,guard=()=>true){
  getReadinessScope(ctx);const projectId=ctx.projectId,scope=scopes.get(projectId),node=document.querySelector('[data-readiness-connection]'),scroll={left:window.scrollX,top:window.scrollY};let rendered=false;
  try{await ctx.reload(()=>{scope.error='';rendered=projectId===ctx.projectId&&Boolean(node?.isConnected)&&guard();return rendered;});if(rendered)window.scrollTo({...scroll,behavior:'instant'});}
  catch(error){scope.error=`تعذر تحديث الحالة؛ راجع تاريخ آخر تحميل قبل الاعتماد على العرض. ${error.message}`;if(node?.isConnected){node.textContent=scope.error;node.classList.add('is-error');}throw error;}
}
export function readinessActions(ctx){return {
  'readiness-open':el=>{setReadinessScope(ctx,{zoneId:el.dataset.zone,phaseId:el.dataset.phase});document.querySelector('#dialog')?.close();ctx.navigate('readiness');},
  'readiness-select':el=>{setReadinessScope(ctx,{zoneId:el.dataset.zone,phaseId:el.dataset.phase});ctx.refresh();document.querySelector('[data-action="readiness-select"][aria-current="true"]')?.focus({preventScroll:true});},
  'readiness-spatial':el=>ctx.openSpatialZone(el.dataset.zone,el.dataset.phase),
  'readiness-mission':el=>newMission(ctx,el),
  'readiness-reload':()=>reloadReadiness(ctx),
};}
export function mountReadiness(ctx){
  const root=document.querySelector('[data-readiness-root]');if(!root)return ()=>{};
  const projectId=ctx.projectId;let disposed=false,busy=false;
  const guard=()=>!disposed&&root.isConnected&&ctx.projectId===projectId&&!document.hidden&&!document.querySelector('#dialog')?.open&&!document.activeElement?.matches('input,select,textarea,[contenteditable="true"]');
  const onChange=event=>{if(!event.target.matches('[data-readiness-phase]'))return;setReadinessScope(ctx,{phaseId:event.target.value});ctx.refresh();document.querySelector('[data-readiness-phase]')?.focus();};
  root.addEventListener('change',onChange);
  const timer=setInterval(async()=>{if(busy||!guard())return;busy=true;try{await reloadReadiness(ctx,guard);}catch{/* Keep the last successful server state with an explicit error. */}finally{busy=false;}},60000);
  return ()=>{disposed=true;clearInterval(timer);root.removeEventListener('change',onChange);};
}

import {esc,n,badge,icon,button,field,select,textarea,table,empty,modal,detail} from './ui.js';
import {SERVICE_DAY_STAGES,SERVICE_PLAYBOOKS} from './service-playbooks.js';

const HOUR=3600000;
const categories={visitors:'حركات الدخول',cleaning:'النظافة',water:'المياه',diesel:'الديزل',sewage:'الصرف الصحي',inventory:'المخزون'};
const actionNames={inspect:'فحص',clean:'تنظيف',fill:'تعبئة',pump:'شفط',replenish:'تعزيز المخزون'};
const jobNames={scheduled:'مجدولة',in_progress:'قيد التنفيذ',awaiting_verification:'بانتظار التحقق',completed:'معتمدة',cancelled:'ملغاة'};
const stageNames={briefing:'الإحاطة',readiness:'الجاهزية',active:'التنفيذ',review:'المراجعة',close:'الإقفال اليومي',handover:'التسليم',completed:'يوم مكتمل'};
const tankCategories=new Set(['water','diesel','sewage']);
const settings=new Map();
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const rows=(ctx,key)=>ctx.records(key)||[];
const phasePoints=(points,phaseId)=>points.filter(p=>!phaseId||!p.phase_ids?.length||p.phase_ids.includes(phaseId));
const pad=value=>String(value).padStart(2,'0');
const permitted=(ctx,command)=>ctx.can(command)?'':'disabled title="الإجراء غير متاح لصلاحيتك أو لحالة المشروع"';
const admin=ctx=>['admin','manager'].includes(ctx.state.user?.role);
const attr=id=>`data-id="${esc(id)}"`;
const note=text=>`<p class="services-note">${esc(text)}</p>`;
const numeric=value=>finite(value)?n(value):'غير معروف';
const sourceLabel=record=>record?.provenance==='demo'?'بيانات تجريبية':record?.source==='field'?'رصد ميداني يدوي':'إدخال يدوي';

export function riyadhDate(value=new Date()) {
  const time=new Date(value).getTime();
  return Number.isFinite(time)?new Date(time+3*HOUR).toISOString().slice(0,10):'';
}
export function riyadhLocal(value=new Date(),seconds=false) {
  const time=new Date(value).getTime();
  return Number.isFinite(time)?new Date(time+3*HOUR).toISOString().slice(0,seconds?19:16):'';
}
export function riyadhHourPeriod(day,hour) {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||!Number.isInteger(hour)||hour<0||hour>23)throw new Error('اختر يومًا وساعة صحيحة بتوقيت الرياض.');
  const start=new Date(`${day}T${pad(hour)}:00:00+03:00`);
  if(!Number.isFinite(start.getTime())||riyadhDate(start)!==day)throw new Error('التاريخ غير صالح.');
  return {period_start:start.toISOString(),period_end:new Date(start.getTime()+HOUR).toISOString()};
}
export function riyadhISO(value) {
  if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(value||''))throw new Error('أدخل التاريخ والوقت بتوقيت الرياض.');
  const result=new Date(`${value}${value.length===16?':00':''}+03:00`);
  if(!Number.isFinite(result.getTime())||riyadhLocal(result,value.length===19)!==value)throw new Error('التاريخ أو الوقت غير صالح.');
  return result.toISOString();
}
function stamp(value) {
  if(!value||!Number.isFinite(new Date(value).getTime()))return 'وقت غير مسجل';
  return new Intl.DateTimeFormat('ar-SA-u-nu-latn',{timeZone:'Asia/Riyadh',calendar:'gregory',dateStyle:'medium',timeStyle:'short'}).format(new Date(value));
}
function timeLabel(value) {
  return new Intl.DateTimeFormat('ar-SA-u-nu-latn',{timeZone:'Asia/Riyadh',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(value));
}
function view(ctx) {
  if(!settings.has(ctx.projectId))settings.set(ctx.projectId,{tab:'now',phaseId:rows(ctx,'phases').find(p=>p.kind==='operations')?.id||rows(ctx,'phases')[0]?.id||'',zoneId:'',day:riyadhDate(),category:'',connectionError:'',lastSuccess:ctx.lastLoaded||''});
  const state=settings.get(ctx.projectId);
  if(state.phaseId&&!rows(ctx,'phases').some(p=>p.id===state.phaseId))state.phaseId='';
  if(state.zoneId&&!rows(ctx,'zones').some(z=>z.id===state.zoneId))state.zoneId='';
  if(ctx.lastLoaded&&ctx.lastLoaded>state.lastSuccess){state.lastSuccess=ctx.lastLoaded;state.connectionError='';}
  return state;
}
function scopedPoints(ctx) {
  const state=view(ctx);
  return phasePoints(rows(ctx,'service_points'),state.phaseId).filter(p=>!state.zoneId||p.zone_id===state.zoneId);
}
function pointReadings(ctx) {
  const state=view(ctx);
  return rows(ctx,'service_readings').filter(r=>!state.phaseId||r.phase_id===state.phaseId);
}

// Historical hourly totals remain observations of their period, never current occupancy.
// Missing, conflicting and future readings cannot manufacture a zero or a complete total.
export function aggregateHourlyEntries(points,readings,day,{now=Date.now(),phaseId=''}={}) {
  const expected=phasePoints(points,phaseId).filter(p=>p.category==='visitors');
  const nowMs=new Date(now).getTime();
  return Array.from({length:24},(_,hour)=>{
    const period=riyadhHourPeriod(day,hour),start=Date.parse(period.period_start),end=Date.parse(period.period_end);
    let covered=0,recordedTotal=0,conflicts=0;
    for(const point of expected){
      const matches=readings.filter(r=>r.point_id===point.id&&(!phaseId||r.phase_id===phaseId)&&Date.parse(r.period_start)===start);
      if(matches.length>1){conflicts++;continue;}
      const reading=matches[0],observed=Date.parse(reading?.observed_at);
      if(reading&&finite(reading.value)&&Number.isInteger(reading.value)&&reading.value>=0&&Date.parse(reading.period_end)===end&&observed>=end&&observed<=nowMs){covered++;recordedTotal+=reading.value;}
    }
    const status=end>nowMs?'pending':!expected.length?'unmonitored':covered===expected.length?'complete':covered?'partial':'missing';
    return {hour,...period,status,expected:expected.length,covered,conflicts,total:status==='complete'?recordedTotal:null,recordedTotal:covered&&status!=='pending'?recordedTotal:null};
  });
}
export function readingState(point,readings,now=Date.now()) {
  const reading=readings.filter(r=>r.point_id===point.id).slice().sort((a,b)=>Date.parse(b.observed_at)-Date.parse(a.observed_at))[0];
  if(!reading)return {status:'missing',reading:null,value:null,ageMinutes:null,attention:null};
  const observed=Date.parse(reading.observed_at),nowMs=new Date(now).getTime();
  const reference=point.category==='visitors'?Math.min(observed,Date.parse(reading.period_end)):observed;
  const ageMinutes=(nowMs-reference)/60000;
  const valid=Number.isFinite(ageMinutes)&&ageMinutes>=0&&observed<=nowMs&&finite(point.freshness_minutes)&&point.freshness_minutes>0&&
    (point.category==='cleaning'?['ready','needs_service'].includes(reading.condition):finite(reading.value)&&reading.value>=0&&(!tankCategories.has(point.category)||(finite(point.capacity)&&point.capacity>0&&reading.value<=point.capacity)));
  if(!valid)return {status:'invalid',reading,value:null,ageMinutes:null,attention:null};
  if(ageMinutes>point.freshness_minutes)return {status:'stale',reading,value:null,ageMinutes,attention:null};
  const percent=tankCategories.has(point.category)?reading.value/point.capacity*100:null;
  const attention=point.category==='cleaning'?reading.condition==='needs_service':percent!==null&&finite(point.attention_percent)?(point.category==='sewage'?percent>=point.attention_percent:percent<=point.attention_percent):null;
  return {status:'fresh',reading,value:point.category==='cleaning'?reading.condition:reading.value,ageMinutes,percent,attention};
}
export function stockBalance(point,stock) {
  const matching=stock.filter(row=>row.item_id===point.item_id&&row.zone_id===point.zone_id);
  const known=matching.length>0&&matching.every(row=>['on_hand','available','reserved','maintenance'].every(key=>finite(row[key])));
  if(!known)return {known:false,on_hand:null,available:null,reserved:null,maintenance:null,attention:null};
  const balance=Object.fromEntries(['on_hand','available','reserved','maintenance'].map(key=>[key,matching.reduce((sum,row)=>sum+row[key],0)]));
  return {known:true,...balance,attention:finite(point.minimum_stock)?balance.available<=point.minimum_stock:null};
}
function statusTag(state) {
  if(state.status==='fresh')return badge(state.attention?'high':'manual',state.attention?'تحتاج متابعة':'رصد ضمن مدة الصلاحية');
  return badge('reference',({missing:'لم تسجل قراءة',stale:'رصد متقادم · الحالة مجهولة',invalid:'قراءة غير صالحة'})[state.status]||'غير معروف');
}
function readingFoot(state,point) {
  return `<p class="services-card-meta">${state.reading?`${esc(sourceLabel(state.reading))} · ${esc(stamp(state.reading.observed_at))}`:'ابدأ بمحضر رصد ميداني'}<br>مدة صلاحية الرصد: ${finite(point.freshness_minutes)?`${n(point.freshness_minutes)} دقيقة`:'غير معتمدة'}${state.ageMinutes!==null?` · عمر الرصد ${n(Math.floor(state.ageMinutes))} دقيقة`:''}</p>`;
}
function pointActions(ctx,point) {
  return `<div class="services-card-actions">${point.category!=='inventory'?button('تسجيل رصد','services-reading','small','plus',`${attr(point.id)} ${permitted(ctx,'service_reading.create')}`):`<a class="btn small" href="#${rows(ctx,'items').find(i=>i.id===point.item_id)?.kind==='book'?'books':'warehouse'}" data-route="${rows(ctx,'items').find(i=>i.id===point.item_id)?.kind==='book'?'books':'warehouse'}">دفتر المخزون</a>`}${button('جدولة خدمة','services-job','small','clock',`${attr(point.id)} ${permitted(ctx,'service_job.create')}`)}${button('السجل','services-point-detail','ghost','reports',attr(point.id))}${button('جاهزية المنطقة','readiness-open','ghost','check',`data-zone="${esc(point.zone_id)}" data-phase="${esc(view(ctx).phaseId)}"`)}</div>`;
}
function pointCard(ctx,point) {
  const readings=pointReadings(ctx),state=readingState(point,readings),stock=point.category==='inventory'?stockBalance(point,rows(ctx,'stock')):null;
  const unit=rows(ctx,'items').find(i=>i.id===point.item_id)?.unit||'وحدة';
  let body='';
  if(stock){
    body=`${badge(stock.known?(stock.attention?'high':'reference'):'reference',stock.known?(stock.attention?'عند حد المتابعة أو دونه':'رصيد دفتري'):'لم يسجل رصيد بالموقع')}<div class="services-reading-value">${numeric(stock.available)}<small>متاح · ${esc(unit)}</small></div><dl class="services-stock-breakdown"><div><dt>الموجود</dt><dd>${numeric(stock.on_hand)}</dd></div><div><dt>المحجوز</dt><dd>${numeric(stock.reserved)}</dd></div><div><dt>خارج الرصيد بالصيانة</dt><dd>${numeric(stock.maintenance)}</dd></div></dl><p class="services-card-meta">${esc(ctx.name('items',point.item_id))}<br>حد المتابعة: ${finite(point.minimum_stock)?`${n(point.minimum_stock)} ${esc(unit)}`:'غير محدد'} · من دفتر الحركات</p>`;
  }else if(tankCategories.has(point.category)){
    body=`${statusTag(state)}<div class="services-reading-value">${state.status==='fresh'?n(Math.round(state.percent))+'%':'غير معروف'}<small>${state.status==='fresh'?`${n(state.value)} / ${n(point.capacity)} لتر`:`السعة ${numeric(point.capacity)} لتر`}</small></div><div class="services-tank-track ${state.status==='fresh'?'':'is-unknown'}" aria-hidden="true">${state.status==='fresh'?`<span style="width:${state.percent}%"></span>`:'<span>لا رصد صالح الآن</span>'}${finite(point.attention_percent)?`<i style="inset-inline-start:${point.attention_percent}%"></i>`:''}</div><p class="services-card-meta">${finite(point.attention_percent)?`حد متابعة داخلي ${n(point.attention_percent)}% ${point.category==='sewage'?'فأعلى':'فأقل'} · ${esc(point.policy_reference)}`:'لم يُحدد حد متابعة داخلي'}</p>${readingFoot(state,point)}`;
  }else if(point.category==='cleaning'){
    body=`${statusTag(state)}<div class="services-reading-value services-condition">${state.status==='fresh'?(state.value==='ready'?'جاهزة':'تحتاج خدمة'):'غير معروف'}</div>${state.status==='fresh'&&state.reading.notes?`<p class="services-card-note">${esc(state.reading.notes)}</p>`:''}${readingFoot(state,point)}`;
  }else{
    body=`${statusTag(state)}<div class="services-reading-value">${state.status==='fresh'?n(state.value):'غير معروف'}<small>حركة دخول في آخر ساعة مرصودة</small></div>${state.reading?.period_start?`<p class="services-card-meta">الفترة: ${esc(stamp(state.reading.period_start))} — ${esc(timeLabel(state.reading.period_end))}</p>`:''}${readingFoot(state,point)}`;
  }
  return `<article class="services-point ${state.attention||stock?.attention?'needs-attention':''}"><div class="services-point-heading"><span class="services-category">${esc(categories[point.category])}</span>${point.provenance==='demo'?badge('demo'):''}</div><h3>${esc(point.name)}</h3><p class="services-point-location">${esc(ctx.name('zones',point.zone_id))} · ${esc(ctx.name('stakeholders',point.responsible_id))}</p><div class="services-point-body">${body}</div>${pointActions(ctx,point)}</article>`;
}
function hourlyPanel(ctx,points) {
  const state=view(ctx),visitors=points.filter(p=>p.category==='visitors');
  const hours=aggregateHourlyEntries(visitors,pointReadings(ctx),state.day,{phaseId:state.phaseId});
  const closed=hours.filter(h=>!['pending','unmonitored'].includes(h.status)),covered=closed.filter(h=>h.status==='complete').length;
  const recorded=hours.filter(h=>h.recordedTotal!==null),total=recorded.length?recorded.reduce((sum,h)=>sum+h.recordedTotal,0):null;
  const max=Math.max(1,...recorded.map(h=>h.recordedTotal));
  const statusText=h=>({pending:'الفترة لم تكتمل',unmonitored:'لا نقاط رصد',missing:'فجوة رصد',partial:'رصد جزئي',complete:'رصد مكتمل'})[h.status];
  return `<section class="panel services-hourly"><div class="panel-head"><div><span class="eyebrow">السجل الزمني · ${esc(state.day)} · الرياض</span><h2>حركات الدخول خلال 24 ساعة</h2><p>جمع فترات ساعة كاملة لكل نقطة؛ حركات متكررة ممكنة ولا تقيس الإشغال أو الزوار الفريدين.</p></div><div class="services-hourly-total"><strong>${numeric(total)}</strong><span>مجموع حركات الدخول المسجلة للنقاط المختارة${covered===closed.length&&closed.length?'':' · تغطية جزئية'}</span></div></div><div class="services-hourly-meta"><span><strong>${n(covered)} / ${n(closed.length)}</strong> ساعة مكتملة التغطية</span><span>${n(visitors.length)} نقطة متوقعة لكل ساعة</span><span>سجل فترات تاريخية؛ ليس قراءة حية</span></div><div class="services-chart-scroll"><div class="services-hourly-chart" role="img" aria-label="رسم حركات الدخول حسب الساعة؛ الجدول التفصيلي التالي يوفر القيم وحالة التغطية.">${hours.map(h=>`<div class="services-hour ${h.status}" title="${pad(h.hour)}:00 · ${esc(statusText(h))} · ${h.recordedTotal===null?'غير معروف':n(h.recordedTotal)}"><div class="services-hour-plot">${h.recordedTotal===null?`<span class="services-hour-gap">${h.status==='pending'?'·':'—'}</span>`:`<span class="services-hour-bar ${h.recordedTotal===0?'is-zero':''}" style="height:${Math.max(2,h.recordedTotal/max*100)}%"></span>`}</div><span class="services-hour-label">${pad(h.hour)}</span></div>`).join('')}</div></div><div class="services-chart-legend"><span><i></i>رصد مكتمل</span><span><i class="partial"></i>مجموع جزئي</span><span><i class="missing"></i>فجوة رصد</span><span>الخط القصير = صفر مسجل</span></div><details class="services-hour-table"><summary>عرض جدول الساعات والقيم والتغطية</summary>${table(['الفترة · الرياض','حركات الدخول المسجلة','التغطية','الحالة'],hours.map(h=>`<tr><td dir="ltr">${pad(h.hour)}:00 — ${h.hour===23?'00:00 (+1)':pad(h.hour+1)+':00'}</td><td>${h.recordedTotal===null?'غير معروف':`${n(h.recordedTotal)}${h.status==='partial'?' · مجموع جزئي':''}`}</td><td>${n(h.covered)} / ${n(h.expected)} نقطة</td><td>${esc(statusText(h))}${h.conflicts?' · تعارض سجلات':''}</td></tr>`),'','حركات الدخول لكل ساعة وتغطية نقاط الرصد')}</details>${note('الفترات غير المرصودة تظل مجهولة. قد تتداخل حركة النقاط ولا تُزال التكرارات بين نقاط مختلفة. الساعات الماضية سجل مؤرخ، وصلاحية الرصد الحالي في بطاقات النقاط.')}</section>`;
}
function nowPanel(ctx) {
  const state=view(ctx),points=scopedPoints(ctx),visible=points.filter(p=>!state.category||p.category===state.category);
  const measured=points.filter(p=>p.category!=='inventory').map(p=>readingState(p,pointReadings(ctx)));
  const attention=measured.filter(r=>r.status==='fresh'&&r.attention).length+points.filter(p=>p.category==='inventory'&&stockBalance(p,rows(ctx,'stock')).attention).length;
  const unknown=measured.filter(r=>r.status!=='fresh').length+points.filter(p=>p.category==='inventory'&&!stockBalance(p,rows(ctx,'stock')).known).length;
  return `<div class="services-status-strip"><div><strong>${n(points.length)}</strong><span>نقطة في النطاق</span></div><div><strong>${n(attention)}</strong><span>تحتاج متابعة بحسب السجل</span></div><div><strong>${n(unknown)}</strong><span>حالتها غير معروفة الآن</span></div><p>الحالة الحالية من آخر رصد يدوي صالح. حدود المتابعة داخلية موثقة، ولا تمثل اعتماد سلامة.</p></div>${hourlyPanel(ctx,points)}<section class="services-points-section"><div class="section-row"><div><span class="eyebrow">الخدمات الآن</span><h2>نقاط الخدمة ومسؤولياتها</h2></div><label class="services-category-filter"><span>الفئة</span><select data-services-filter="category" aria-label="تصفية نقاط الخدمة بالفئة"><option value="">كل الفئات</option>${Object.entries(categories).map(([id,name])=>`<option value="${id}" ${state.category===id?'selected':''}>${name}</option>`).join('')}</select></label></div>${visible.length?`<div class="services-point-grid">${visible.map(p=>pointCard(ctx,p)).join('')}</div>`:empty(points.length?'لا نقاط لهذه الفئة':'لم تُعرّف نقاط خدمة في هذا النطاق',points.length?'اختر فئة أخرى لعرض النقاط.':'أضف نقطة وحدد منطقتها ومسؤولها ومدة صلاحية الرصد.')}</section>`;
}
function scopedJobs(ctx) {
  const state=view(ctx),ids=new Set(scopedPoints(ctx).map(p=>p.id));
  return rows(ctx,'service_jobs').filter(j=>ids.has(j.point_id)&&(!state.phaseId||j.phase_id===state.phaseId)&&riyadhDate(j.due_at)===state.day).sort((a,b)=>Date.parse(a.due_at)-Date.parse(b.due_at));
}
function jobButtons(ctx,job) {
  const next={scheduled:'in_progress',in_progress:'awaiting_verification',awaiting_verification:'completed'}[job.status];
  return `<div class="cell-actions">${button('المحضر','services-job-detail','small','reports',attr(job.id))}${next?button(({in_progress:'بدء العمل',awaiting_verification:'طلب التحقق',completed:'اعتماد التنفيذ'})[next],'services-job-transition','small','check',`${attr(job.id)} data-status="${next}" ${permitted(ctx,'service_job.transition')} ${next==='completed'&&!admin(ctx)?'disabled title="الاعتماد لمدير المشروع أو النظام"':''}`):''}${next?button('إلغاء','services-job-transition','ghost','',`${attr(job.id)} data-status="cancelled" ${permitted(ctx,'service_job.transition')}`):''}</div>`;
}
function schedulePanel(ctx) {
  const jobs=scopedJobs(ctx),now=Date.now();
  return `<section class="panel services-schedule"><div class="panel-head"><div><span class="eyebrow">موعد · تنفيذ · تحقق</span><h2>جدول الخدمة</h2><p>التعبئة والشفط والفحص موثقة بأوامر خدمة. الكميات لا تتغير قبل تسجيل الرصد أو حركة المستودع.</p></div>${button('جدولة خدمة','services-job','secondary','plus',permitted(ctx,'service_job.create'))}</div>${jobs.length?table(['الخدمة / النقطة','الموعد · الرياض','التكليف','الحالة','الإجراء'],jobs.map(j=>{const p=rows(ctx,'service_points').find(p=>p.id===j.point_id);return `<tr><td><span class="cell-title">${esc(actionNames[j.action])} · ${esc(p?.name||j.point_id)}</span><span class="cell-sub">${esc(ctx.name('zones',p?.zone_id))}${finite(j.quantity)?` · ${n(j.quantity)} ${tankCategories.has(p?.category)?'لتر':'وحدة'}`:''}</span></td><td>${esc(stamp(j.due_at))}${Date.parse(j.due_at)<now&&!['completed','cancelled'].includes(j.status)?`<span class="cell-sub">${badge('high','تجاوز الموعد المسجل')}</span>`:''}</td><td>${esc(ctx.name('stakeholders',j.responsible_id))}<span class="cell-sub">${esc(j.provider||'دون مزود مسجل')}${j.day_id?' · مرتبط بيوم خدمة':''}</span></td><td>${badge(j.status==='awaiting_verification'?'inspection':j.status,jobNames[j.status])}${j.provenance==='demo'?badge('demo'):''}</td><td>${jobButtons(ctx,j)}</td></tr>`;})):empty('لا خدمات مجدولة لهذا اليوم والنطاق','اختر يومًا آخر أو سجّل موعدًا ومسؤولًا ومرجع التكليف.')}<div class="panel-body">${note('تسجيل اسم المزود لا يرسل إليه طلبًا. اكتمال العمل يتطلب اعتماد مدير ودليل تحقق؛ أعمال الخزانات والنظافة تتطلب قراءة متابعة جديدة بعد طلب التحقق.')}</div></section>`;
}
export function pendingDayJobs(jobs,day) {
  return jobs.filter(job=>job.project_id===day.project_id&&job.phase_id===day.phase_id&&!['completed','cancelled'].includes(job.status)&&(job.day_id===day.id||(riyadhDate(job.due_at)&&riyadhDate(job.due_at)<=day.operational_date)));
}
function dayPanel(ctx) {
  const state=view(ctx),phases=rows(ctx,'phases').slice().sort((a,b)=>(a.order||0)-(b.order||0)),phase=phases.find(p=>p.id===state.phaseId);
  const day=rows(ctx,'service_days').find(d=>d.phase_id===state.phaseId&&d.operational_date===state.day);
  const playbook=SERVICE_PLAYBOOKS[phase?.kind];
  const strip=`<div class="services-phase-strip" aria-label="مراحل المشروع">${phases.map((p,i)=>`<button type="button" data-action="services-phase" ${attr(p.id)} class="${p.id===state.phaseId?'selected':''}" ${p.id===state.phaseId?'aria-current="step"':''}><span>${pad(i+1)}</span><strong>${esc(p.name)}</strong><small>${n(rows(ctx,'service_days').filter(d=>d.phase_id===p.id&&d.stage==='completed').length)} يوم مكتمل مسجل</small></button>`).join('')}</div>`;
  if(!phase||!playbook)return `${strip}${empty('اختر مرحلة لعرض دورة يومها','خطوات اليوم تتبع نوع المرحلة، ويثبت تقدمها بالتسجيل والحفظ.')}`;
  const history=day?.history||[],current=SERVICE_DAY_STAGES.indexOf(day?.stage);
  const pending=day?pendingDayJobs(rows(ctx,'service_jobs'),day):[];
  const next=day&&day.stage!=='completed'?(SERVICE_DAY_STAGES[current+1]||'completed'):'';
  return `${strip}<section class="panel services-day"><div class="panel-head"><div><span class="eyebrow">${esc(state.day)} · يوم خدمات على مستوى المرحلة</span><h2>${esc(playbook.title)}</h2><p>${esc(playbook.objective)}</p></div><div class="actions">${day?badge(day.stage==='completed'?'completed':'in_progress',stageNames[day.stage]):badge('reference','لم يفتح اليوم')}${!day?button('فتح يوم الخدمة','services-day-open','primary','plus',permitted(ctx,'service_day.open')):next?button(next==='completed'?'اعتماد إكمال اليوم':`الانتقال إلى ${stageNames[next]}`,'services-day-advance','primary','arrow',`${attr(day.id)} data-stage="${next}" ${permitted(ctx,'service_day.advance')} ${next==='completed'&&!admin(ctx)?'disabled title="اعتماد الإكمال لمدير المشروع أو النظام"':''}`):''}</div></div><div class="services-day-context">${day?`<p>المسؤول: <strong>${esc(ctx.name('stakeholders',day.responsible_id))}</strong> · ${n(pending.length)} عمل مستحق أو مرتبط ما زال مفتوحًا${day.provenance==='demo'?` · ${badge('demo')}`:''}</p>`:'<p>الخطة التالية إرشاد للمرحلة. لا يوجد تقدم فعلي قبل فتح سجل اليوم.</p>'}<p>مرشح المنطقة يخص نقاط الخدمة والجدول؛ سجل اليوم يشمل المرحلة كلها.</p></div><ol class="services-day-stages">${playbook.stages.map((stage,i)=>{const entered=day&&(day.stage==='completed'||i<=current),active=day?.stage===stage.key;const entry=history.find(h=>(h.stage||h.to_stage||h.to)===stage.key);return `<li class="${active?'current':entered?'recorded':''}" ${active?'aria-current="step"':''}><div class="services-stage-number">${entered&&!active?'✓':pad(i+1)}</div><div><span class="services-stage-state">${!day?'غير مسجلة':active?'الخطوة الحالية':entered?'انتقال مسجل':'لم تبدأ'}</span><h3>${esc(stage.title)}</h3><p>${esc(stage.description)}</p><small>المخرج: ${esc(stage.output)}</small>${entry?`<time>${esc(stamp(entry.at||entry.created_at))}</time>`:''}</div></li>`;}).join('')}</ol>${pending.length?`<div class="services-day-open-jobs"><h3>الأعمال المفتوحة للتسليم</h3><p>تشمل أعمال اليوم المرتبطة وكل أعمال المرحلة المستحقة حتى هذا التاريخ، ولو لم تربط بيوم.</p>${table(['العمل / النقطة','الموعد · الرياض','الربط','الحالة'],pending.map(job=>`<tr><td>${esc(actionNames[job.action])} · ${esc(ctx.name('service_points',job.point_id))}</td><td>${esc(stamp(job.due_at))}</td><td>${job.day_id===day.id?'مرتبط بهذا اليوم':job.day_id?'مرتبط بيوم آخر':'غير مرتبط بيوم'}</td><td>${badge(job.status,jobNames[job.status])}</td></tr>`))}</div>`:''}<div class="services-day-evidence"><h3>إثبات خروج المرحلة</h3><p>${esc(playbook.exitEvidence)}</p><p>اكتمال يوم الخدمة يحفظ يومه فقط. التسليم يسجل تكليف المتابعة؛ لا يوجد إقرار استلام مستقل أو سجل ورديات مستقل بعد. اعتماد انتقال المرحلة وإقفال المشروع لهما سجلات وشروط مستقلة.</p><div class="actions"><a href="#operations" data-route="operations" class="btn secondary">محاضر التشغيل وتسليم المراحل</a><a href="#lifecycle" data-route="lifecycle" class="btn secondary">مهام دورة المشروع</a>${day?button('سجل انتقالات اليوم','services-day-detail','secondary','reports',attr(day.id)):''}</div></div></section>`;
}

export function renderServices(ctx) {
  const state=view(ctx),phases=rows(ctx,'phases').slice().sort((a,b)=>(a.order||0)-(b.order||0));
  return `<div class="services-workspace" data-services-root><div class="page-heading"><div><span class="eyebrow">الرصد الميداني · الخدمة · دورة اليوم</span><h1>مراقبة الخدمات</h1><p>اقرأ ما رُصد، حدّد العمل المطلوب، ثم وثّق التنفيذ والتحقق في سجل المشروع.</p></div><div class="actions">${button('تعريف نقطة خدمة','services-point-new','primary','plus',permitted(ctx,'service_point.create'))}${button('تحديث السجلات','services-reload','secondary','refresh')}</div></div><div class="services-source-line"><span>${icon('clock')} رصد يدوي مؤرخ</span><span>لا حساسات حية متصلة</span><span>الوقت المعروض بتوقيت الرياض</span></div><div class="services-connection ${state.connectionError?'is-error':''}" data-services-connection role="status">${state.connectionError?esc(state.connectionError)+' · ':''}آخر تحميل ناجح: ${state.lastSuccess?esc(stamp(state.lastSuccess)):'لم يثبت'} · تحديث السجلات كل دقيقة أثناء فتح التبويب؛ يتوقف أثناء تحرير نموذج.</div><div class="services-toolbar"><nav class="services-tabs" aria-label="مساحات مراقبة الخدمات">${[['now','الخدمات الآن'],['schedule','جدول الخدمة'],['day','دورة المشروع واليوم']].map(([id,title])=>`<button type="button" data-action="services-tab" data-tab="${id}" class="${state.tab===id?'active':''}" ${state.tab===id?'aria-current="page"':''}>${title}</button>`).join('')}</nav><div class="services-filters">${select('service_phase','المرحلة',[{id:'',name:'كل المراحل'},...phases],state.phaseId,'data-services-filter="phaseId"')}${select('service_zone','المنطقة',[{id:'',name:'كل المناطق'},...rows(ctx,'zones')],state.zoneId,'data-services-filter="zoneId"')}${field('service_date','يوم السجل · الرياض','date',state.day,'required data-services-filter="day"')}</div></div>${state.tab==='schedule'?schedulePanel(ctx):state.tab==='day'?dayPanel(ctx):nowPanel(ctx)}</div>`;
}

function requireRecord(ctx,key,id) {
  const row=rows(ctx,key).find(r=>r.id===id);
  if(!row)throw new Error('السجل غير موجود في المشروع الحالي.');
  return row;
}
function requireCommand(ctx,command) {
  if(!ctx.can(command))throw new Error('الإجراء غير متاح لصلاحيتك أو لحالة المشروع.');
}
function numberValue(value,title,{optional=false,integer=false,min=0,max=Infinity}={}) {
  if(value===''||value===undefined){if(optional)return undefined;throw new Error(`أدخل ${title}.`);}
  const result=Number(value);
  if(!Number.isFinite(result)||(integer&&!Number.isInteger(result))||result<min||result>max)throw new Error(`قيمة ${title} غير صالحة.`);
  return result;
}
function phasesFor(ctx,point) {
  return rows(ctx,'phases').filter(p=>!point?.phase_ids?.length||point.phase_ids.includes(p.id));
}
const initialPhase=(ctx,point)=>phasesFor(ctx,point).find(p=>p.id===view(ctx).phaseId)?.id||phasesFor(ctx,point)[0]?.id||'';
function pointOptions(ctx,{reading=false}={}) {
  return scopedPoints(ctx).filter(p=>!reading||p.category!=='inventory').map(p=>({id:p.id,name:`${p.name} · ${categories[p.category]}`}));
}
function newPoint(ctx) {
  requireCommand(ctx,'service_point.create');
  if(!rows(ctx,'zones').length||!rows(ctx,'stakeholders').length)throw new Error('أضف منطقة ومسؤولًا في الجهات والمسؤوليات قبل تعريف نقطة الخدمة.');
  const dialog=modal('تعريف نقطة خدمة',`<div class="form-grid">${field('name','اسم النقطة','text','','required maxlength="200"')}${select('category','فئة الخدمة',Object.entries(categories).map(([id,name])=>({id,name})),'visitors','required')}${select('zone_id','المنطقة',rows(ctx,'zones'),view(ctx).zoneId||rows(ctx,'zones')[0]?.id,'required')}${select('responsible_id','المسؤول',rows(ctx,'stakeholders'),rows(ctx,'stakeholders')[0]?.id,'required')}${field('freshness_minutes','مدة صلاحية الرصد بالدقائق','number','','required min="1" step="1" inputmode="numeric"')}<div class="wide services-category-fields" data-category-fields></div><fieldset class="wide services-phase-choices"><legend>المراحل التي تخدمها النقطة</legend>${rows(ctx,'phases').map(p=>`<label><input type="checkbox" name="phase_ids" value="${esc(p.id)}">${esc(p.name)}</label>`).join('')}<p>تركها فارغة يجعل النقطة متاحة لكل مراحل المشروع.</p></fieldset>${textarea('evidence','مرجع تعريف النقطة واعتماد مدة الرصد','','required maxlength="4000"')}</div>`,async(data,form)=>{
    const payload={project_id:ctx.projectId,name:data.name,category:data.category,zone_id:data.zone_id,responsible_id:data.responsible_id,phase_ids:[...form.querySelectorAll('[name="phase_ids"]:checked')].map(el=>el.value),freshness_minutes:numberValue(data.freshness_minutes,'مدة الصلاحية',{integer:true,min:1}),evidence:data.evidence};
    if(tankCategories.has(data.category)){payload.capacity=numberValue(data.capacity,'السعة',{min:0.001});const threshold=numberValue(data.attention_percent,'حد المتابعة',{optional:true,min:0,max:100});if(threshold!==undefined){payload.attention_percent=threshold;payload.policy_reference=data.policy_reference;}}
    if(data.category==='inventory'){payload.item_id=data.item_id;payload.minimum_stock=numberValue(data.minimum_stock,'حد المخزون',{integer:true,min:0});}
    await ctx.command('service_point.create',payload);
  },'حفظ نقطة الخدمة',true);
  const form=dialog.querySelector('form'),fields=dialog.querySelector('[data-category-fields]');
  const update=()=>{
    const category=form.elements.category.value;
    fields.innerHTML=tankCategories.has(category)?`<div class="form-grid">${field('capacity','سعة الخزان · لتر','number','','required min="0.001" step="any"')}${field('attention_percent',`حد متابعة داخلي % · ${category==='sewage'?'فأعلى':'فأقل'} (اختياري)`,'number','','min="0" max="100" step="any"')}${textarea('policy_reference','مرجع اعتماد حد المتابعة','','maxlength="2000"')}</div>${note('لا يمثل الحد الداخلي معيار سلامة. اتركه فارغًا إلى أن يحدده الفريق ويذكر مرجعه.')}`:category==='inventory'?`<div class="form-grid">${select('item_id','صنف المستودع',[{id:'',name:'اختيار الصنف'},...rows(ctx,'items')],'','required')}${field('minimum_stock','حد المتابعة للمتاح','number','','required min="0" step="1"')}</div>${note('الرصيد من الصنف والمنطقة في دفتر الحركات، ولا تسجل قراءة كمية يدوية للمخزون.')}`:note(category==='visitors'?'تسجل حركات الدخول لساعة مكتملة لكل نقطة؛ لا تُستنتج منها أعداد الموجودين.':'تسجل جاهزية النظافة أو الحاجة للخدمة مع ملاحظات المعالجة.');
    const threshold=form.elements.attention_percent;
    if(threshold){const sync=()=>{form.elements.policy_reference.required=threshold.value!=='';};threshold.addEventListener('input',sync);sync();}
  };
  form.elements.category.addEventListener('change',update);update();
}
function newReading(ctx,id) {
  requireCommand(ctx,'service_reading.create');
  const points=pointOptions(ctx,{reading:true});
  if(!points.length)throw new Error('لا توجد نقاط رصد مناسبة للمرشحات. عرّف نقطة خدمة أولًا.');
  const selected=points.some(p=>p.id===id)?id:points[0].id;
  const dialog=modal('تسجيل رصد ميداني',`<div class="form-grid">${select('point_id','نقطة الخدمة',points,selected,'required')}<div data-reading-fields class="wide"></div>${select('observation_time','متى تم الرصد؟',[{id:'now',name:'أرصد الآن · يحفظ وقت الإرسال'},{id:'earlier',name:'رصد سابق · أحدد وقته'}],'now','required')}${field('observed_at','وقت الرصد السابق · الرياض','datetime-local',riyadhLocal(new Date(),true),'disabled step="1"')}${select('source','مصدر السجل',[{id:'manual',name:'إدخال يدوي'},{id:'field',name:'فحص ميداني'}],'field','required')}${textarea('evidence','مرجع محضر الرصد / الإثبات','','required maxlength="4000"')}</div>`,async data=>{
    const point=requireRecord(ctx,'service_points',data.point_id);
    const payload={project_id:ctx.projectId,point_id:point.id,phase_id:data.phase_id,observed_at:data.observation_time==='now'?new Date().toISOString():riyadhISO(data.observed_at),source:data.source,evidence:data.evidence};
    if(point.category==='cleaning'){payload.condition=data.condition;payload.notes=data.notes;}
    else{payload.value=numberValue(data.value,'القراءة',{integer:point.category==='visitors',min:0,max:tankCategories.has(point.category)?point.capacity:Infinity});if(point.category==='visitors')Object.assign(payload,riyadhHourPeriod(data.period_date,Number(data.period_hour)));}
    await ctx.command('service_reading.create',payload);
  },'حفظ الرصد',true);
  const form=dialog.querySelector('form');
  const timeMode=()=>{const earlier=form.elements.observation_time.value==='earlier';form.elements.observed_at.disabled=!earlier;form.elements.observed_at.required=earlier;};
  form.elements.observation_time.addEventListener('change',timeMode);timeMode();
  const update=()=>{
    const point=requireRecord(ctx,'service_points',form.elements.point_id.value);
    dialog.querySelector('[data-reading-fields]').innerHTML=`<div class="form-grid">${select('phase_id','المرحلة',phasesFor(ctx,point),initialPhase(ctx,point),'required')}${point.category==='cleaning'?`${select('condition','حالة النظافة',[{id:'ready',name:'جاهزة'},{id:'needs_service',name:'تحتاج خدمة'}],'ready','required')}${textarea('notes','ملاحظات المعالجة','','maxlength="2000"')}`:field('value',point.category==='visitors'?'حركات الدخول المسجلة خلال الساعة':'الكمية المرصودة · لتر','number','',`required min="0" step="${point.category==='visitors'?'1':'any'}" ${tankCategories.has(point.category)?`max="${point.capacity}"`:''}`)}${point.category==='visitors'?`${field('period_date','يوم الفترة · الرياض','date',view(ctx).day,'required')}${select('period_hour','بداية ساعة الرصد',Array.from({length:24},(_,hour)=>({id:String(hour),name:`${pad(hour)}:00 — ${hour===23?'00:00 اليوم التالي':pad(hour+1)+':00'}`})),String(Math.max(0,Number(riyadhLocal().slice(11,13))-1)),'required')}`:''}</div>${note(point.category==='visitors'?'تقبل ساعة مكتملة فقط، مرة واحدة لكل نقطة. يجب أن يقع وقت الرصد عند نهاية الساعة أو بعدها. سجل الساعة لا يقبل الاستبدال أو التصحيح حاليًا؛ راجع العدد قبل الحفظ.':`المنطقة والمسؤول يرثان من النقطة: ${ctx.name('zones',point.zone_id)} · ${ctx.name('stakeholders',point.responsible_id)}.`)}`;
    if(form.elements.condition){const sync=()=>{form.elements.notes.required=form.elements.condition.value==='needs_service';};form.elements.condition.addEventListener('change',sync);sync();}
  };
  form.elements.point_id.addEventListener('change',update);update();
}
function allowedActions(point) {
  return ['inspect',...({cleaning:['clean'],water:['fill'],diesel:['fill'],sewage:['pump'],inventory:['replenish']}[point.category]||[])].map(id=>({id,name:actionNames[id]}));
}
export function verificationReadings(job,point,readings) {
  return readings.filter(reading=>reading.point_id===point.id&&reading.phase_id===job.phase_id&&Date.parse(reading.observed_at)>Date.parse(job.verification_requested_at)&&(point.category!=='cleaning'||reading.condition==='ready'));
}
function newJob(ctx,id) {
  requireCommand(ctx,'service_job.create');
  const points=pointOptions(ctx);
  if(!points.length||!rows(ctx,'stakeholders').length)throw new Error('يلزم تعريف نقطة خدمة ومسؤول ضمن النطاق أولًا.');
  const selected=points.some(p=>p.id===id)?id:points[0].id;
  const dialog=modal('جدولة خدمة',`<div class="form-grid">${select('point_id','نقطة الخدمة',points,selected,'required')}<div data-job-fields class="wide"></div>${field('due_at','موعد الخدمة · الرياض','datetime-local',`${view(ctx).day}T${riyadhLocal().slice(11,16)}`,'required')}${select('responsible_id','مسؤول التنفيذ',rows(ctx,'stakeholders'),rows(ctx,'service_points').find(p=>p.id===selected)?.responsible_id,'required')}${field('provider','اسم الفريق أو المزود','text','','required maxlength="200"')}${textarea('evidence','مرجع التكليف وجدولة الخدمة','','required maxlength="4000"')}</div>`,async data=>{
    const payload={project_id:ctx.projectId,point_id:data.point_id,phase_id:data.phase_id,action:data.action,due_at:riyadhISO(data.due_at),responsible_id:data.responsible_id,provider:data.provider,evidence:data.evidence};
    if(data.day_id)payload.day_id=data.day_id;
    const quantity=numberValue(data.quantity,'كمية الخدمة',{optional:true,min:0.001});if(quantity!==undefined)payload.quantity=quantity;
    await ctx.command('service_job.create',payload);
  },'حفظ الموعد',true);
  const form=dialog.querySelector('form');
  const updateDays=()=>{
    const current=form.elements.day_id;
    const days=rows(ctx,'service_days').filter(d=>d.phase_id===form.elements.phase_id.value&&d.stage!=='completed');
    current.innerHTML=`<option value="">دون ربط بيوم</option>${days.map(d=>`<option value="${esc(d.id)}">${esc(d.operational_date)} · ${esc(stageNames[d.stage])}</option>`).join('')}`;
    const selectedDay=days.find(d=>d.operational_date===view(ctx).day);if(selectedDay)current.value=selectedDay.id;
  };
  const update=()=>{
    const point=requireRecord(ctx,'service_points',form.elements.point_id.value);
    dialog.querySelector('[data-job-fields]').innerHTML=`<div class="form-grid">${select('phase_id','المرحلة',phasesFor(ctx,point),initialPhase(ctx,point),'required')}${select('action','نوع الخدمة',allowedActions(point),allowedActions(point).at(-1)?.id,'required')}${select('day_id','ربط بدورة يوم (اختياري)',[{id:'',name:'دون ربط بيوم'}])}${tankCategories.has(point.category)||point.category==='inventory'?field('quantity',`الكمية المخططة (اختياري) · ${tankCategories.has(point.category)?'لتر':'وحدة'}`,'number','','min="0.001" step="any"'):''}</div>${note(point.category==='inventory'?'التجديد ينشئ مهمة فقط. سجل الاستلام أو الصرف الفعلي في المستودع ليظهر الرصيد.':'أمر الخدمة لا يغير القراءة. يلزم توثيق التنفيذ والتحقق قبل اعتماده.')}`;
    form.elements.responsible_id.value=point.responsible_id;
    form.elements.phase_id.addEventListener('change',updateDays);updateDays();
  };
  form.elements.point_id.addEventListener('change',update);update();
}
function measuredJobSummary(job,point) {
  if(!job.baseline_snapshot)return '';
  const cleaning=point.category==='cleaning';
  const value=v=>cleaning?(v==='ready'?'جاهزة':v==='needs_service'?'تحتاج خدمة':'غير معروف'):`${numeric(v)} لتر`;
  const target=cleaning?'جاهزة':`${numeric(job.target_value)} لتر أو ${point.category==='sewage'?'أقل':'أكثر'}`;
  const outcome=job.outcome;
  return `<div class="services-note"><strong>تكليف بهدف مقاس</strong><p>الأساس: ${esc(value(cleaning?job.baseline_snapshot.condition:job.baseline_snapshot.value))} · الهدف: <bdi>${esc(target)}</bdi></p>${outcome?`<p>القياس المعتمد: ${esc(value(outcome.after))}${outcome.delta!==null?` · التغير المرصود: <bdi>${outcome.delta>0?'+':''}${numeric(outcome.delta)} لتر</bdi>`:''} · ${esc(stamp(outcome.observed_at))}</p>`:'<p>يعتمد المدير أحدث قراءة فقط، بعد طلب التحقق وضمن مدة صلاحية الرصد، بشرط بلوغ الهدف.</p>'}</div>`;
}
function transitionJob(ctx,el) {
  requireCommand(ctx,'service_job.transition');
  const job=requireRecord(ctx,'service_jobs',el.dataset.id),point=requireRecord(ctx,'service_points',job.point_id),status=el.dataset.status;
  if(status==='completed'&&!admin(ctx))throw new Error('اعتماد التنفيذ لمدير المشروع أو النظام.');
  const readingRequired=status==='completed'&&(tankCategories.has(point.category)||point.category==='cleaning');
  const readings=verificationReadings(job,point,rows(ctx,'service_readings'));
  const dialog=modal(`${({cancelled:'إلغاء الخدمة',completed:'اعتماد التنفيذ',in_progress:'بدء العمل',awaiting_verification:'طلب التحقق'})[status]} · ${point.name}`,`${measuredJobSummary(job,point)}<div class="form-grid">${readingRequired?select('reading_id','قراءة المتابعة بعد طلب التحقق',[{id:'',name:'اختيار قراءة المتابعة'},...readings.map(r=>({id:r.id,name:`${stamp(r.observed_at)} · ${point.category==='cleaning'?(r.condition==='ready'?'جاهزة':'تحتاج خدمة'):numeric(r.value)+' لتر'}`}))],'','required'):''}${status==='cancelled'?textarea('reason','سبب الإلغاء','','required maxlength="2000"'):''}${textarea('evidence',status==='completed'?'مرجع دليل التحقق والاعتماد':'مرجع إثبات الإجراء','','required maxlength="4000"')}</div>${readingRequired&&!readings.length?note('لم تسجل قراءة مناسبة بعد طلب التحقق. أغلق النموذج وسجّل رصدًا جديدًا للنقطة والمرحلة، ثم عد للاعتماد. النظافة تحتاج قراءة «جاهزة».'):''}${point.category==='inventory'?note('اعتماد مهمة التجديد لا يثبت حركة مخزون؛ وثّق الاستلام الفعلي في دفتر المستودع.') : ''}`,data=>ctx.command('service_job.transition',{id:job.id,status,...data}),'حفظ الإجراء');
  if(readingRequired&&!readings.length)dialog.querySelector('[type="submit"]').disabled=true;
}
function openDay(ctx) {
  requireCommand(ctx,'service_day.open');
  const state=view(ctx),phase=rows(ctx,'phases').find(p=>p.id===state.phaseId);
  if(!phase)throw new Error('اختر مرحلة محددة قبل فتح يوم الخدمة.');
  if(!rows(ctx,'stakeholders').length)throw new Error('أضف مسؤولًا في الجهات والمسؤوليات أولًا.');
  modal('فتح يوم الخدمة',`<div class="form-grid">${select('phase_id','المرحلة',[phase],phase.id,'required')}${field('operational_date','يوم التشغيل · الرياض','date',state.day,'required')}${select('responsible_id','مسؤول اليوم',rows(ctx,'stakeholders'),rows(ctx,'stakeholders')[0]?.id,'required')}${textarea('evidence','مرجع إحاطة الفريق وفتح اليوم','','required maxlength="4000"')}</div>${note('يبدأ اليوم بخطوة الإحاطة. التقدم يحفظ بانتقالات موثقة، ولا يتحرك مع مرور الساعة.')}`,async data=>{await ctx.command('service_day.open',{project_id:ctx.projectId,...data});state.day=data.operational_date;ctx.refresh();},'فتح وحفظ اليوم');
}
function advanceDay(ctx,el) {
  requireCommand(ctx,'service_day.advance');
  const day=requireRecord(ctx,'service_days',el.dataset.id),stage=el.dataset.stage;
  if(stage==='completed'&&!admin(ctx))throw new Error('اعتماد إكمال اليوم لمدير المشروع أو النظام.');
  const open=pendingDayJobs(rows(ctx,'service_jobs'),day);
  const handover=stage==='completed'&&open.length>0;
  modal(`${stage==='completed'?'اعتماد إكمال اليوم':'الانتقال إلى '+stageNames[stage]}`,`<div class="form-grid">${textarea('evidence','مرجع إثبات اكتمال الخطوة السابقة والانتقال','','required maxlength="4000"')}${handover?`${select('handover_responsible_id','مسؤول استلام الأعمال المفتوحة',rows(ctx,'stakeholders'),day.responsible_id,'required')}${field('handover_due_at','موعد متابعة التسليم · الرياض','datetime-local','','required')}${textarea('handover_notes','الأعمال المرحلة وخطة متابعتها','','required maxlength="4000"')}`:''}</div>${note(handover?`هناك ${open.length} أعمال مستحقة أو مرتبطة ما زالت مفتوحة، بما فيها غير المرتبطة بيوم. تحفظ مسؤولية متابعة لها وتبقى على حالتها. لا يثبت هذا إقرار المستلم.`:'حفظ هذا الانتقال يخص يوم الخدمة وحده؛ لا يعتمد انتقال مرحلة المشروع.')}`,data=>ctx.command('service_day.advance',{id:day.id,stage,...data,...(handover?{handover_due_at:riyadhISO(data.handover_due_at)}:{})}),'حفظ الانتقال');
}
function historyTable(history=[],day=false) {
  return history.length?table(['الوقت · الرياض','الخطوة','المستخدم','الإثبات'],history.map(h=>`<tr><td>${esc(stamp(h.at||h.created_at))}</td><td>${esc((day?stageNames:jobNames)[h.stage||h.to_stage||h.status||h.to]||h.action||'تسجيل')}</td><td>${esc(h.actor_id||h.by||h.actor||h.created_by||'غير مسجل')}</td><td>${esc(h.evidence||'غير مسجل')}</td></tr>`)):note('لا انتقالات إضافية مسجلة.');
}
function pointDetail(ctx,id) {
  const point=requireRecord(ctx,'service_points',id),readings=rows(ctx,'service_readings').filter(r=>r.point_id===id).sort((a,b)=>Date.parse(b.observed_at)-Date.parse(a.observed_at));
  detail(point.name,`<p>${esc(categories[point.category])} · ${esc(ctx.name('zones',point.zone_id))} · المسؤول ${esc(ctx.name('stakeholders',point.responsible_id))}</p><p class="services-note">مرجع تعريف النقطة: ${esc(point.evidence||'غير مسجل')}</p>${pointActions(ctx,point)}<h3 class="form-section">الرصد المؤرخ</h3>${readings.length?table(['الرصد · الرياض','المرحلة','القيمة عند الرصد','المصدر والإثبات'],readings.map(r=>`<tr><td>${esc(stamp(r.observed_at))}${r.period_start?`<span class="cell-sub">فترة ${esc(stamp(r.period_start))} — ${esc(timeLabel(r.period_end))}</span>`:''}</td><td>${esc(ctx.name('phases',r.phase_id))}</td><td>${point.category==='cleaning'?(r.condition==='ready'?'جاهزة':'تحتاج خدمة'):numeric(r.value)}${tankCategories.has(point.category)?' لتر':point.category==='visitors'?' حركة دخول':''}${r.notes?`<span class="cell-sub">${esc(r.notes)}</span>`:''}</td><td>${esc(sourceLabel(r))}<span class="cell-sub">${esc(r.evidence)}</span></td></tr>`)):note(point.category==='inventory'?'المخزون يقرأ من دفتر الحركات في المستودع.':'لا قراءات محفوظة لهذه النقطة.')}`);
}
function jobDetail(ctx,id) {
  const job=requireRecord(ctx,'service_jobs',id),point=requireRecord(ctx,'service_points',job.point_id);
  detail(`${actionNames[job.action]} · ${point.name}`,`${badge(job.status,jobNames[job.status])}${measuredJobSummary(job,point)}<p class="services-note">الموعد: ${esc(stamp(job.due_at))} · المسؤول: ${esc(ctx.name('stakeholders',job.responsible_id))}</p><p>مرجع التكليف: ${esc(job.evidence||'غير مسجل')}</p>${job.provider?`<p>الفريق أو المزود: ${esc(job.provider)}</p>`:''}${job.verification_evidence?`<p>دليل التحقق: ${esc(job.verification_evidence)}</p>`:''}${job.verification_reading_id?`<p>قراءة المتابعة: ${esc(job.verification_reading_id)}</p>`:''}${job.cancellation_reason?`<p>سبب الإلغاء: ${esc(job.cancellation_reason)}</p>`:''}${jobButtons(ctx,job)}<h3 class="form-section">سجل التنفيذ والتحقق</h3>${historyTable(job.history)}`);
}
function dayDetail(ctx,id) {
  const day=requireRecord(ctx,'service_days',id);
  detail(`انتقالات يوم ${day.operational_date}`,`<p>${esc(ctx.name('phases',day.phase_id))} · ${esc(ctx.name('stakeholders',day.responsible_id))}</p><p class="services-note">مرجع فتح اليوم: ${esc(day.evidence||'غير مسجل')}</p>${historyTable(day.history,true)}${day.handover_responsible_id?`<h3 class="form-section">تسليم الأعمال المفتوحة</h3><p>${esc(ctx.name('stakeholders',day.handover_responsible_id))} · ${esc(stamp(day.handover_due_at))}</p><p>${esc(day.handover_notes)}</p>`:''}`);
}
async function reloadServices(ctx,shouldRender=()=>true) {
  const state=view(ctx),projectId=ctx.projectId,node=document.querySelector('[data-services-connection]');
  const scroll={x:window.scrollX,y:window.scrollY};
  let rendered=false;
  try{await ctx.reload(()=>{rendered=ctx.projectId===projectId&&Boolean(node?.isConnected)&&shouldRender();return rendered;});state.lastSuccess=ctx.lastLoaded||new Date().toISOString();state.connectionError='';if(rendered)window.scrollTo({left:scroll.x,top:scroll.y,behavior:'instant'});}
  catch(error){state.connectionError='تعذر تحديث السجلات؛ الحالة المعروضة قديمة. '+error.message;if(node?.isConnected&&ctx.projectId===projectId){node.textContent=`${state.connectionError} · آخر تحميل ناجح: ${state.lastSuccess?stamp(state.lastSuccess):'لم يثبت'}`;node.classList.add('is-error');}throw error;}
}
export function servicesActions(ctx) {
  return {
    'services-tab':el=>{view(ctx).tab=el.dataset.tab;ctx.refresh();document.querySelector(`[data-action="services-tab"][data-tab="${el.dataset.tab}"]`)?.focus();},
    'services-phase':el=>{view(ctx).phaseId=el.dataset.id;ctx.refresh();},
    'services-reload':()=>reloadServices(ctx),
    'services-point-new':()=>newPoint(ctx),
    'services-reading':el=>{if(el.dataset.phase){view(ctx).phaseId=el.dataset.phase;view(ctx).zoneId=el.dataset.zone||requireRecord(ctx,'service_points',el.dataset.id).zone_id;}return newReading(ctx,el.dataset.id);},
    'services-job':el=>newJob(ctx,el.dataset.id),
    'services-job-transition':el=>transitionJob(ctx,el),
    'services-day-open':()=>openDay(ctx),
    'services-day-advance':el=>advanceDay(ctx,el),
    'services-point-detail':el=>pointDetail(ctx,el.dataset.id),
    'services-job-detail':el=>jobDetail(ctx,el.dataset.id),
    'services-day-detail':el=>dayDetail(ctx,el.dataset.id),
  };
}
export function mountServices(ctx) {
  const root=document.querySelector('[data-services-root]');
  if(!root)return ()=>{};
  const projectId=ctx.projectId;
  let disposed=false,busy=false;
  const canRefresh=()=>!disposed&&root.isConnected&&ctx.projectId===projectId&&!document.hidden&&!document.querySelector('#dialog')?.open&&!document.activeElement?.matches('input,select,textarea,[contenteditable="true"]');
  const onChange=event=>{
    const input=event.target.closest('[data-services-filter]');if(!input)return;
    const key=input.dataset.servicesFilter;
    if(!['phaseId','zoneId','day','category'].includes(key)||!input.checkValidity())return;
    view(ctx)[key]=input.value;ctx.refresh();document.querySelector(`[data-services-filter="${key}"]`)?.focus();
  };
  root.addEventListener('change',onChange);
  const timer=setInterval(async()=>{
    if(busy||!canRefresh())return;
    busy=true;try{await reloadServices(ctx,canRefresh);}catch{/* The in-tab connection message preserves the last successful timestamp. */}finally{busy=false;}
  },60000);
  return ()=>{disposed=true;clearInterval(timer);root.removeEventListener('change',onChange);};
}

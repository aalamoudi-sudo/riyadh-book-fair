"""Manual service monitoring and documented day cycles, inside command transactions.

Readings are observations, not tank controls or stock movements. Visitor readings
represent entry movements in a completed Riyadh hour, never occupancy or people.
Readings are append-only through this command API. Replacing/correcting a recorded
visitor hour requires a future explicit correction workflow; duplicates are rejected.
"""
import datetime as dt
import math
import re


RIYADH = dt.timezone(dt.timedelta(hours=3), 'Asia/Riyadh')
SERVICE_ACTIONS = {
    'visitors': {'inspect'}, 'cleaning': {'inspect', 'clean'},
    'water': {'inspect', 'fill'}, 'diesel': {'inspect', 'fill'},
    'sewage': {'inspect', 'pump'}, 'inventory': {'inspect', 'replenish'},
}
TANKS = {'water', 'diesel', 'sewage'}
DAY_STAGES = ('briefing', 'readiness', 'active', 'review', 'close', 'handover', 'completed')


def service_now():
    # Do not truncate the clock: legitimate observations can carry microseconds,
    # and a verification reading must be strictly after its request.
    return dt.datetime.now(dt.timezone.utc)


def number(value, label, minimum=0, positive=False, integer=False):
    from domain import require
    require(isinstance(value, (int, float)) and not isinstance(value, bool),
            f'{label}: أدخل عددًا صالحًا', 'invalid_service_number')
    try:
        finite = math.isfinite(value)
    except (OverflowError, ValueError):
        finite = False
    require(finite and (value > minimum if positive else value >= minimum)
            and (not integer or isinstance(value, int)),
            f'{label}: القيمة خارج النطاق أو النوع المسموح', 'invalid_service_number')
    return value


class ServicesMixin:
    def _mission_reading(self, c, point, phase_id, reading_id):
        """A measured mission may not select an obsolete or expired observation."""
        from domain import require, timestamp
        from readiness import latest_service_reading
        reading = self._service_ref(c, 'service_readings', reading_id, point['project_id'], 'قراءة المهمة المقاسة')
        require(reading['point_id'] == point['id'] and reading['phase_id'] == phase_id,
                'قراءة المهمة لا تخص نقطة الخدمة ومرحلتها', 'service_context_mismatch')
        at = service_now()
        observed = timestamp(reading['observed_at'], 'وقت قراءة المهمة')
        require(observed <= at and (at - observed).total_seconds() <= point['freshness_minutes'] * 60,
                'المهمة المقاسة تتطلب قراءة حديثة ضمن صلاحية النقطة', 'stale_mission_reading', 409)
        latest = latest_service_reading(self.all(c, 'service_readings'), point['project_id'], point['id'], phase_id)
        require(not latest or timestamp(latest['observed_at'], 'وقت أحدث قراءة') <= at,
                'أحدث قراءة مؤرخة في المستقبل؛ راجع المصدر قبل اعتماد المهمة المقاسة', 'future_mission_reading', 409)
        require(latest and latest['id'] == reading['id'],
                'توجد قراءة أحدث؛ استخدم أحدث قراءة لنقطة الخدمة والمرحلة', 'superseded_mission_reading', 409)
        return reading

    def _service_ref(self, c, collection, identifier, project_id, label):
        from domain import require, text
        identifier = text(identifier, label, True, 100)
        row = self.get(c, collection, identifier)
        require(row.get('project_id') == project_id,
                f'{label}: المرجع يتبع مشروعًا آخر', 'project_mismatch')
        return row

    def _service_context(self, c, p):
        from domain import require, text
        point = self.get(c, 'service_points', text(p.get('point_id'), 'نقطة الخدمة', True, 100))
        phase = self._service_ref(c, 'phases', p.get('phase_id'), point['project_id'], 'المرحلة')
        require(not point['phase_ids'] or phase['id'] in point['phase_ids'],
                'نقطة الخدمة لا تشمل هذه المرحلة', 'service_phase_mismatch')
        require(not p.get('project_id') or p['project_id'] == point['project_id'],
                'نقطة الخدمة تتبع مشروعًا آخر', 'project_mismatch')
        require(not p.get('zone_id') or p['zone_id'] == point['zone_id'],
                'منطقة الخدمة موروثة من النقطة', 'service_context_mismatch')
        return point, phase

    def service_point_create(self, c, p, actor):
        from domain import require, text
        fields = self.common(c, p)
        for key in ('project_id', 'zone_id', 'responsible_id'):
            require(bool(fields[key]), f'الحقل مطلوب: {key}')
        require(bool(fields['evidence']), 'مرجع توثيق نقطة الخدمة مطلوب')
        category = text(p.get('category'), 'نوع الخدمة', True, 30)
        require(category in SERVICE_ACTIONS, 'نوع الخدمة غير صالح', 'invalid_service_category')
        phase_ids = p.get('phase_ids', [])
        require(isinstance(phase_ids, list), 'مراحل النقطة يجب أن تكون قائمة')
        phases = [self._service_ref(c, 'phases', value, fields['project_id'], 'مرحلة النقطة')['id']
                  for value in phase_ids]
        require(len(set(phases)) == len(phases), 'لا تكرر مرحلة النقطة')
        capacity = attention = None
        policy = text(p.get('policy_reference'), 'مرجع حد الانتباه', limit=2000)
        if category in TANKS:
            capacity = number(p.get('capacity'), 'سعة الخزان', positive=True)
            if p.get('attention_percent') not in (None, ''):
                attention = number(p['attention_percent'], 'نسبة الانتباه')
                require(attention <= 100, 'نسبة الانتباه لا تتجاوز 100', 'invalid_service_number')
                require(bool(policy), 'مرجع داخلي موثق مطلوب عند تحديد حد الانتباه')
        else:
            require(p.get('capacity') in (None, '') and p.get('attention_percent') in (None, '')
                    and not policy, 'السعة وحد الانتباه ومرجعه للخزانات فقط')
        item_id, minimum = '', None
        if category == 'inventory':
            item = self._service_ref(c, 'items', p.get('item_id'), fields['project_id'], 'صنف المخزون')
            item_id = item['id']
            minimum = number(p.get('minimum_stock', 0), 'الحد الأدنى للمخزون', integer=True)
        else:
            require(not p.get('item_id') and p.get('minimum_stock') in (None, ''),
                    'الصنف والحد الأدنى خاصان بخدمة المخزون')
        fields.update(name=text(p.get('name'), 'اسم نقطة الخدمة', True, 200), category=category,
                      phase_ids=phases, capacity=capacity, attention_percent=attention,
                      policy_reference=policy, freshness_minutes=number(p.get('freshness_minutes'),
                      'صلاحية القراءة بالدقائق', positive=True), item_id=item_id, minimum_stock=minimum)
        return self.new(c, 'service_points', fields, actor)

    def service_reading_create(self, c, p, actor):
        from domain import require, text, timestamp
        point, phase = self._service_context(c, p)
        require(not p.get('responsible_id') or p['responsible_id'] == point['responsible_id'],
                'مسؤول القراءة موروث من النقطة', 'service_context_mismatch')
        category = point['category']
        require(category != 'inventory', 'المخزون يقرأ من دفتر المستودع؛ لا تسجل رصيدًا موازيًا',
                'inventory_ledger_only')
        source = text(p.get('source'), 'مصدر القراءة', True, 30)
        require(source in {'manual', 'field'}, 'مصدر القراءة يجب أن يكون يدويًا أو ميدانيًا')
        observed = timestamp(p.get('observed_at'), 'وقت الرصد')
        require(observed <= service_now(), 'لا يمكن تسجيل قراءة مستقبلية',
                'future_service_reading')
        fields = {'project_id': point['project_id'], 'point_id': point['id'], 'phase_id': phase['id'],
                  'zone_id': point['zone_id'], 'responsible_id': point['responsible_id'],
                  'source': source, 'observed_at': observed.isoformat(),
                  'evidence': text(p.get('evidence'), 'إثبات القراءة', True, 4000),
                  'notes': text(p.get('notes'), 'ملاحظات القراءة', limit=4000)}
        if category in TANKS:
            value = number(p.get('value'), 'كمية الخزان')
            require(value <= point['capacity'], 'كمية الخزان تتجاوز السعة', 'invalid_service_number')
            fields['value'] = value
        elif category == 'cleaning':
            condition = text(p.get('condition'), 'حالة النظافة', True, 40)
            require(condition in {'ready', 'needs_service'}, 'حالة النظافة غير صالحة')
            require(condition != 'needs_service' or bool(fields['notes']), 'صف حاجة النظافة للخدمة')
            require(p.get('value') in (None, ''), 'قراءة النظافة حالة وليست كمية')
            fields['condition'] = condition
        else:
            value = number(p.get('value'), 'حركات الدخول', integer=True)
            start = timestamp(p.get('period_start'), 'بداية ساعة الرصد')
            end = timestamp(p.get('period_end'), 'نهاية ساعة الرصد')
            local = start.astimezone(RIYADH)
            require(local.minute == local.second == local.microsecond == 0
                    and end == start + dt.timedelta(hours=1) and observed >= end,
                    'قراءة الزوار لساعة تامة بتوقيت الرياض انتهت قبل الرصد', 'invalid_visitor_period')
            require(not any(row.get('point_id') == point['id']
                            and row.get('period_start') == start.isoformat()
                            for row in self.all(c, 'service_readings')),
                    'توجد قراءة لهذه النقطة والساعة؛ لا تجمع الرصد مرتين', 'duplicate_service_reading', 409)
            fields.update(value=value, period_start=start.isoformat(), period_end=end.isoformat(),
                          operational_date=local.date().isoformat())
        return self.new(c, 'service_readings', fields, actor)

    def service_job_create(self, c, p, actor):
        from domain import require, text, timestamp
        point, phase = self._service_context(c, p)
        action = text(p.get('action'), 'إجراء الخدمة', True, 40)
        require(action in SERVICE_ACTIONS[point['category']], 'الإجراء لا يناسب نوع نقطة الخدمة',
                'invalid_service_action')
        responsible = self._service_ref(c, 'stakeholders', p.get('responsible_id'),
                                        point['project_id'], 'مسؤول الخدمة')
        day_id = text(p.get('day_id'), 'يوم الخدمة', limit=100)
        if day_id:
            day = self._service_ref(c, 'service_days', day_id, point['project_id'], 'يوم الخدمة')
            require(day['phase_id'] == phase['id'], 'اليوم يتبع مرحلة أخرى', 'service_phase_mismatch')
            require(day['stage'] != 'completed', 'لا تسند عملًا جديدًا ليوم مكتمل', 'service_day_completed', 409)
        amount = None
        if p.get('quantity') not in (None, ''):
            amount = number(p['quantity'], 'كمية الخدمة', positive=True)
        mission = {}
        require(not any(key in p for key in ('baseline_snapshot', 'outcome')),
                'لقطة الأساس ونتيجة المهمة تُسجلان من القراءات فقط', 'immutable_mission_fields')
        if any(p.get(key) not in (None, '') for key in ('baseline_reading_id', 'target_value', 'target_condition')):
            category = point['category']
            require((category in {'water', 'diesel'} and action == 'fill')
                    or (category == 'sewage' and action == 'pump')
                    or (category == 'cleaning' and action == 'clean'),
                    'القياس قبل وبعد متاح للتعبئة والشفط والنظافة فقط', 'invalid_measured_action')
            baseline_id = text(p.get('baseline_reading_id'), 'قراءة الأساس', True, 100)
            baseline = self._mission_reading(c, point, phase['id'], baseline_id)
            snapshot = {key: baseline.get(key, '') for key in ('observed_at', 'source', 'provenance')}
            snapshot['reading_id'] = baseline_id
            if category in TANKS:
                require(p.get('target_condition') in (None, ''), 'هدف الخزان كمية فقط', 'invalid_mission_target')
                target = number(p.get('target_value'), 'الكمية المستهدفة')
                require(target <= point['capacity'], 'الهدف يتجاوز سعة الخزان', 'invalid_mission_target')
                require(target < baseline['value'] if category == 'sewage' else target > baseline['value'],
                        'هدف الشفط أقل من الأساس وهدف التعبئة أعلى منه', 'invalid_mission_target')
                snapshot['value'] = baseline['value']
                mission['target_value'] = target
            else:
                require(p.get('target_value') in (None, '') and p.get('target_condition') == 'ready'
                        and baseline.get('condition') == 'needs_service',
                        'مهمة النظافة تبدأ بحاجة للخدمة وهدفها حالة جاهزة', 'invalid_mission_target')
                snapshot['condition'] = baseline['condition']
                mission['target_condition'] = 'ready'
            mission.update(baseline_reading_id=baseline_id, baseline_snapshot=snapshot)
        fields = {'project_id': point['project_id'], 'phase_id': phase['id'], 'point_id': point['id'],
                  'zone_id': point['zone_id'], 'day_id': day_id, 'action': action,
                  'responsible_id': responsible['id'], 'provider': text(p.get('provider'), 'فريق أو مزود الخدمة', True, 200),
                  'due_at': timestamp(p.get('due_at'), 'موعد الخدمة').isoformat(), 'quantity': amount,
                  'evidence': text(p.get('evidence'), 'إثبات الجدولة', bool(mission), 4000),
                  'notes': text(p.get('notes'), 'ملاحظات الخدمة', limit=4000),
                  'status': 'scheduled', 'history': [], **mission}
        return self.new(c, 'service_jobs', fields, actor)

    def service_job_transition(self, c, p, actor):
        from domain import require, text, timestamp
        require(not any(key in p for key in ('baseline_reading_id', 'baseline_snapshot', 'target_value',
                                             'target_condition', 'outcome')),
                'قراءة الأساس والهدف ونتيجة المهمة ثابتة ولا تعدل بالانتقال', 'immutable_mission_fields')
        row = self.get(c, 'service_jobs', p.get('id'))
        current, target = row['status'], text(p.get('status'), 'حالة الخدمة', True, 40)
        transitions = {'scheduled': {'in_progress', 'cancelled'},
                       'in_progress': {'awaiting_verification', 'cancelled'},
                       'awaiting_verification': {'completed', 'cancelled'}}
        require(target in transitions.get(current, set()), 'انتقال الخدمة غير مسموح', 'invalid_transition', 409)
        point, _ = self._service_context(c, row)
        evidence = text(p.get('evidence'), 'إثبات انتقال الخدمة', True, 4000)
        reason = text(p.get('reason'), 'سبب إلغاء الخدمة', target == 'cancelled', 2000)
        at = service_now().isoformat()
        if target == 'completed':
            require(actor['role'] in {'admin', 'manager'}, 'التحقق النهائي يتطلب مديرًا', 'forbidden', 403)
            reading_id = text(p.get('reading_id'), 'قراءة التحقق', point['category'] in TANKS | {'cleaning'}, 100)
            if reading_id:
                reading = self._service_ref(c, 'service_readings', reading_id, row['project_id'], 'قراءة التحقق')
                require(reading['point_id'] == row['point_id'] and reading['phase_id'] == row['phase_id'],
                        'قراءة التحقق لا تخص نقطة الخدمة ومرحلتها', 'service_context_mismatch')
                require(timestamp(reading['observed_at'], 'وقت المتابعة') >= timestamp(row['started_at'], 'بدء الخدمة'),
                        'قراءة التحقق أقدم من بدء التنفيذ', 'stale_service_verification', 409)
                require(timestamp(reading['observed_at'], 'وقت المتابعة') > timestamp(row['verification_requested_at'], 'طلب التحقق'),
                        'سجل قراءة متابعة جديدة بعد طلب التحقق', 'stale_service_verification', 409)
                if point['category'] == 'cleaning':
                    require(reading.get('condition') == 'ready', 'قراءة النظافة لا تثبت الجاهزية بعد الخدمة',
                            'service_not_ready', 409)
                if row.get('baseline_snapshot'):
                    reading = self._mission_reading(c, point, row['phase_id'], reading_id)
                    baseline = row['baseline_snapshot']
                    if point['category'] in TANKS:
                        before, after, goal = baseline['value'], reading['value'], row['target_value']
                        met = after <= goal if point['category'] == 'sewage' else after >= goal
                        delta, unit = after - before, 'liters'
                    else:
                        before, after, goal = baseline['condition'], reading['condition'], row['target_condition']
                        met, delta, unit = after == goal, None, 'condition'
                    require(met, 'قراءة المتابعة لم تحقق الهدف المقاس', 'mission_target_not_met', 409)
                    row['outcome'] = {'before': before, 'after': after, 'delta': delta, 'target': goal,
                                      'verified_at': at, 'verified_by': actor['id'], 'reading_id': reading_id,
                                      'observed_at': reading['observed_at'], 'unit': unit, 'target_met': True}
            row.update(completed_at=at, completed_by=actor['id'], verification_evidence=evidence,
                       verification_reading_id=reading_id)
        if target == 'in_progress':
            row.update(started_at=at, started_by=actor['id'])
        if target == 'awaiting_verification':
            row['verification_requested_at'] = at
        if target == 'cancelled':
            row.update(cancelled_at=at, cancelled_by=actor['id'], cancellation_reason=reason)
        row['history'].append({'from': current, 'to': target, 'at': at, 'actor_id': actor['id'],
                               'evidence': evidence, 'reason': reason})
        row.update(status=target, updated_at=at)
        return self.put(c, 'service_jobs', row)

    def service_day_open(self, c, p, actor):
        from domain import require, text, DomainError
        fields = self.common(c, p)
        for key in ('project_id', 'phase_id', 'responsible_id'):
            require(bool(fields[key]), f'الحقل مطلوب: {key}')
        date = text(p.get('operational_date'), 'تاريخ اليوم بتوقيت الرياض', True, 10)
        require(bool(re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', date)),
                'تاريخ التشغيل يجب أن يكون YYYY-MM-DD', 'invalid_operational_date')
        try:
            dt.date.fromisoformat(date)
        except ValueError:
            raise DomainError('تاريخ التشغيل غير صالح', 'invalid_operational_date')
        require(bool(fields['evidence']), 'إثبات افتتاح يوم الخدمة مطلوب')
        require(not any(row['project_id'] == fields['project_id'] and row['phase_id'] == fields['phase_id']
                        and row['operational_date'] == date for row in self.all(c, 'service_days')),
                'يوجد يوم خدمة لهذه المرحلة والتاريخ', 'service_day_exists', 409)
        fields.update(operational_date=date, stage='briefing', history=[{
            'from': None, 'to': 'briefing', 'at': service_now().isoformat(), 'actor_id': actor['id'], 'evidence': fields['evidence']}])
        return self.new(c, 'service_days', fields, actor)

    def service_day_advance(self, c, p, actor):
        from domain import require, text, timestamp
        row = self.get(c, 'service_days', p.get('id'))
        current, target = row['stage'], text(p.get('stage'), 'خطوة اليوم', True, 40)
        index = DAY_STAGES.index(current)
        require(index < len(DAY_STAGES) - 1 and target == DAY_STAGES[index + 1],
                'خطوات اليوم تتقدم بالترتيب دون تجاوز أو تكرار', 'invalid_transition', 409)
        evidence = text(p.get('evidence'), 'إثبات خطوة اليوم', True, 4000)
        at = service_now().isoformat()
        if target == 'completed':
            require(actor['role'] in {'admin', 'manager'}, 'إكمال اليوم يتطلب مديرًا', 'forbidden', 403)
            pending = [job for job in self.all(c, 'service_jobs')
                       if job['project_id'] == row['project_id'] and job['phase_id'] == row['phase_id']
                       and job['status'] not in {'completed', 'cancelled'}
                       and (job.get('day_id') == row['id'] or
                            timestamp(job['due_at'], 'موعد الخدمة').astimezone(RIYADH).date().isoformat()
                            <= row['operational_date'])]
            if pending:
                require(all(p.get(key) for key in ('handover_responsible_id', 'handover_due_at', 'handover_notes')),
                        'الأعمال المفتوحة تتطلب مسؤول متابعة وموعدًا وملاحظات تسليم', 'handover_required', 409)
                owner = self._service_ref(c, 'stakeholders', p['handover_responsible_id'], row['project_id'], 'مستلم المتابعة')
                row.update(handover_responsible_id=owner['id'],
                           handover_due_at=timestamp(p['handover_due_at'], 'موعد متابعة الأعمال').isoformat(),
                           handover_notes=text(p['handover_notes'], 'ملاحظات التسليم', True, 4000))
            row.update(completed_at=at, completed_by=actor['id'],
                       pending_job_ids=[job['id'] for job in pending])
        row['history'].append({'from': current, 'to': target, 'at': at, 'actor_id': actor['id'], 'evidence': evidence})
        row.update(stage=target, updated_at=at)
        return self.put(c, 'service_days', row)

#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
source scripts/select-runtime.sh
rbf_services_db="${RBF_SERVICES_DB:-$PWD/data/services-demo.sqlite}"
rbf_services_port="${RBF_SERVICES_PORT:-8901}"
if [[ ! -e "$rbf_services_db" ]]; then
  "$rbf_python" scripts/prepare_services_demo.py --db "$rbf_services_db"
fi
printf '%s\n' "معاينة محلية: http://127.0.0.1:${rbf_services_port}/#services"
exec "$rbf_python" server.py --review --demo --db "$rbf_services_db" --port "$rbf_services_port"

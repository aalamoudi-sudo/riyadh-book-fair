# r13 — عقد تبويب مراقبة الخدمات

النطاق: إضافة محلية قابلة للتجربة للبروتوتايب، لا نشر أو تغيير خدمة Render أو بيانات اعتماد. لا حساسات متصلة أو تحكم مادي. مصادر القراءات يدوية ومؤرخة، والبيانات التجريبية موسومة. الخريطة تبقى مرجعًا؛ الربط هنا بمعرفات المناطق الموجودة دون ادعاء موضع هندسي معتمد.

## نموذج البيانات

كل سجل يحمل project_id وprovenance/created_at/created_by من DomainStore.new. تستخدم آلية المعاملات والصلاحيات/revision/audit القائمة.

1. `service_points`: name, category (`visitors|cleaning|water|diesel|sewage|inventory`), zone_id, responsible_id, phase_ids (قائمة مراحل المشروع؛ فارغة تعني جميعها), capacity (لتر للخزانات فقط، موجب), attention_percent (اختياري للخزانات فقط؛ حد داخلي موثق وليس معيار سلامة), policy_reference (إلزامي إن حدد حد), freshness_minutes (موجب يقره الفريق)، item_id لصنف inventory من المشروع، minimum_stock (عدد صحيح غير سالب للمخزون فقط)، evidence. الرصيد في المخزون يؤخذ من stock الموجود، ولا ينشأ دفتر رصيد مواز.
2. `service_readings`: point_id, phase_id, zone_id/responsible_id يورثان من النقطة، observed_at (aware، لا مستقبل)، source=manual|field، evidence إلزامي. للخزانات value بين0 وcapacity. للنظافة condition=ready|needs_service، notes عند الحاجة للخدمة. للزوار value=حركات الدخول خلال ساعة تامة، period_start (ساعة صحيحة بتوقيت الرياض)، period_end=بعد ساعة، observed_at>=period_end؛ قراءة واحدة لكل نقطة/ساعة لمنع الجمع المكرر. هذه حركة دخول وليست زوارًا فريدين أو إشغالًا. لا قراءة كمية يدوية للمخزون؛ المصدر دفتر stock.
3. `service_jobs`: point_id, phase_id, optional day_id, action (`inspect|clean|fill|pump|replenish` حسب فئة النقطة)، due_at، responsible_id، provider (اسم فريق/مزود بلا إرسال)، quantity اختياري موجب، evidence، status scheduled→in_progress→awaiting_verification→completed أو cancelled بمبرر. الانتهاء يتطلب دليل تحقق من manager/admin، وللخزانات والنظافة قراءة متابعة تخص النقطة والمرحلة بعد تسليم العمل للتحقق (`verification_requested_at`) وبعد بدء التنفيذ، وحالة ready للنظافة؛ لا تضبط كمية الخزان تلقائيًا من أمر الخدمة. إعادة اعتماد نفس المهمة مرفوضة. replenish لا يحرك الرصيد؛ يوجه إلى مستودع التشغيل وتوثيق حركة هناك.
4. `service_days`: project_id, phase_id, operational_date YYYY-MM-DD (الرياض)، responsible_id، evidence، stage يبدأ briefing ثم readiness→active→review→close→handover→completed، history بمستخدم/وقت/دليل لكل انتقال. واحد لكل مشروع/مرحلة/تاريخ. اكتمال اليوم لا يعتمد مرحلة المشروع ولا يقفلها. إن بقيت jobs غير منتهية مرتبطة day_id أو من المرحلة نفسها ومستحقة في التاريخ التشغيلي أو قبله، يلزم handover_responsible_id وhandover_due_at وhandover_notes عند completed؛ تبقى الأعمال مفتوحة وتتبعها الوردية التالية.

## الأوامر

- service_point.create (admin/manager)
- service_reading.create (admin/manager/field/security/warehouse)
- service_job.create (admin/manager/field/warehouse)
- service_job.transition (admin/manager/field/warehouse؛ completed manager/admin داخل المعالج)
- service_day.open (admin/manager/field)
- service_day.advance (admin/manager/field؛ completed manager/admin)

الرد عبر ctx.command ونفس /api/commands. state يضيف المجموعات الأربعة. ممنوع ربط أي مرجع بمشروع مختلف أو مرحلة لا تتبع المشروع أو لا تشملها النقطة؛ حظر المشروع المقفل، viewer، والأوامر خارج نطاق project_ids. يضم الإقفال أعمال الخدمة والأيام غير المكتملة كمانع جديد، دون تعديل السجلات القديمة.

## الواجهة

route=`services`، عنوان «مراقبة الخدمات». ثلاث واجهات فرعية داخل الصفحة: «الخدمات الآن»، «جدول الخدمة»، «دورة المشروع واليوم». المرشحات: مرحلة، منطقة، تاريخ الرياض؛ اختيار المشروع من الغلاف القائم. تعرض حالة التحديث اليدوي وعمر القراءة، وتعتبر المفقود/القديم مجهولًا لا سليمًا ولا صفرًا. تحديث طلب state كل60 ثانية أثناء عرض التبويب فقط وبلا نافذة تحرير؛ إظهار فشل الاتصال وآخر نجاح دون ادعاء مراقبة خلفية أو تنبيه خارج التطبيق.

لوحة الزوار 24 خانة ساعة للتاريخ المحدد؛ تُظهر ساعات بلا رصد وفراغ التغطية. لا تعرض الحركات المجمعة كعدد زوار فريدين أو حضور آني. المخزون من دفتر المستودع ورابطه. حالات الخزانات نسب من كمية موثقة؛ المياه والديزل انتباه عند<=حد داخلي، الصرف عند>=حد داخلي، ولا تعرض حدًا إن لم يحدد. جدول التعبئة/الشفط ينتهي بتحقق موثق، لا بمجرد موعد مجدول.

دورة المشروع من phases الفعلية (7أنواع قائمة). لكل نوع وصف أهدافه وخطوات اليوم الستة بصياغة مناسبة. التقدم الفعلي يستند إلى service_days وحركة السجل، وليس الساعة أو رسم خطي افتراضي. يستطيع المستخدم فتح يوم وتتبع انتقالاته؛ روابط للتشغيل اليومي ومحاضر تسليم المراحل القائمة.

## ملكية الملفات

- مساعد الخادم: services.py، domain.py، tests/test_services.py فقط.
- مساعد الواجهة: app/services.js، app/services.css، tests/test_services.mjs فقط؛ exports renderServices(ctx), servicesActions(ctx), mountServices(ctx) تُرجع dispose. لا app.js/index.html.
- مساعد دورة الحياة: app/service-playbooks.js، docs/SERVICES-LIFECYCLE.md فقط؛ export SERVICE_DAY_STAGES كقائمة keys بالترتيب أعلاه عدا completed، وexport SERVICE_PLAYBOOKS ككائن أنواع المراحل السبعة، لكل نوع title, objective, stages [{key,title,description,output}]، وexitEvidence نص. لا تحرير بقية الملفات.
- المشرف: التكامل والتهيئة التجريبية والتحقق والتغليف والتوثيق.

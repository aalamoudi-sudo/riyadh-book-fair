#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
source scripts/select-runtime.sh
rbf_readiness_db="${RBF_READINESS_DB:-$PWD/data/readiness-demo.sqlite}"
rbf_readiness_port="${RBF_READINESS_PORT:-8901}"
if [[ ! -e "$rbf_readiness_db" ]]; then
  "$rbf_python" scripts/prepare_readiness_demo.py --db "$rbf_readiness_db"
fi
printf '%s\n' "معاينة محلية: http://127.0.0.1:${rbf_readiness_port}/#readiness"
exec "$rbf_python" server.py --review --demo --db "$rbf_readiness_db" --port "$rbf_readiness_port"

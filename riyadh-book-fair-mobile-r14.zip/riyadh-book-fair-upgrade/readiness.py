"""Read-only status of registered services, never a zone safety approval.

The caller supplies an already project-scoped state. Unknown evidence remains
counted even when an open job also needs action; the counts can therefore overlap.
Inventory is the current stock ledger, not a fresh field observation.
"""
import datetime as dt
import math


def instant(value):
    try:
        parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00')) if isinstance(value, str) else value
        return parsed.astimezone(dt.timezone.utc) if isinstance(parsed, dt.datetime) and parsed.tzinfo else None
    except (ValueError, TypeError, OverflowError):
        return None


def finite(value):
    try:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except (ValueError, OverflowError):
        return False


def latest_service_reading(readings, project_id, point_id, phase_id):
    """Keep future observations visible so callers fail closed, never fall back.

    Observed time wins; append order resolves equal timestamps consistently.
    """
    candidates = []
    for index, reading in enumerate(readings):
        observed = instant(reading.get('observed_at'))
        if (reading.get('project_id') == project_id and reading.get('point_id') == point_id
                and reading.get('phase_id') == phase_id and observed):
            candidates.append((observed, index, reading))
    return max(candidates, key=lambda entry: entry[:2])[2] if candidates else None


def _point_status(state, point, phase_id, at):
    category, pid = point['category'], point['project_id']
    jobs = [job['id'] for job in state.get('service_jobs', [])
            if job.get('project_id') == pid and job.get('point_id') == point['id']
            and job.get('phase_id') == phase_id and job.get('status') not in {'completed', 'cancelled'}]
    result = {'point_id': point['id'], 'category': category, 'status': 'unknown',
              'source_status': 'unknown', 'reason': '', 'reason_codes': [], 'reading_id': '',
              'age_minutes': None, 'observed_at': '', 'open_job_ids': jobs,
              'source': '', 'provenance': point.get('provenance', ''), 'field_verified': False,
              'unit': 'stock_units' if category == 'inventory' else 'condition' if category == 'cleaning' else 'liters'}
    reasons = []

    def reason(code, label):
        result['reason_codes'].append(code)
        reasons.append(label)

    if category == 'inventory':
        result['source'] = 'stock_ledger'
        items = {item['id'] for item in state.get('items', []) if item.get('project_id') == pid}
        balance = next((row for row in state.get('stock', [])
                        if row.get('zone_id') == point['zone_id'] and row.get('item_id') == point.get('item_id')
                        and row.get('project_id', pid) == pid and point.get('item_id') in items), None)
        minimum = point.get('minimum_stock')
        if balance and finite(balance.get('available')) and finite(minimum) and minimum >= 0:
            result.update(value=balance['available'], minimum_stock=minimum, stock_id=balance['id'],
                          provenance=balance.get('provenance', point.get('provenance', '')))
            result['source_status'] = 'needs_action' if balance['available'] < minimum else 'clear'
            reason('stock_below_minimum' if result['source_status'] == 'needs_action' else 'stock_ledger_current',
                   'المتاح في دفتر المخزون دون الحد المسجل' if result['source_status'] == 'needs_action'
                   else 'الرصيد المتاح في الدفتر يحقق الحد المسجل؛ ليس تحققًا ميدانيًا')
        else:
            reason('missing_stock', 'لا يوجد رصيد دفتر صالح لهذه النقطة؛ الحالة مجهولة')
    else:
        reading = latest_service_reading(state.get('service_readings', []), pid, point['id'], phase_id)
        if not reading:
            reason('missing_reading', 'لا توجد قراءة للخدمة في هذه المرحلة؛ الحالة مجهولة')
        else:
            age = (at - instant(reading['observed_at'])).total_seconds() / 60
            result.update(reading_id=reading['id'], age_minutes=age if age >= 0 else None, observed_at=reading['observed_at'],
                          source=reading.get('source', ''), provenance=reading.get('provenance', ''))
            for key in ('value', 'condition'):
                if key in reading:
                    result[key] = reading[key]
            freshness = point.get('freshness_minutes')
            if age < 0:
                reason('future_reading', 'أحدث قراءة مؤرخة في المستقبل؛ الحالة مجهولة حتى مراجعة المصدر')
            elif not finite(freshness) or freshness <= 0 or age > freshness:
                reason('stale_reading', 'القراءة متقادمة؛ يلزم رصد جديد قبل تقييم الحالة')
            elif category == 'cleaning':
                condition = reading.get('condition')
                if condition in {'ready', 'needs_service'}:
                    result['source_status'] = 'clear' if condition == 'ready' else 'needs_action'
                    reason('cleaning_ready' if condition == 'ready' else 'cleaning_needs_service',
                           'قراءة النظافة الحالية جاهزة' if condition == 'ready' else 'قراءة النظافة تتطلب خدمة')
                else:
                    reason('invalid_reading', 'قراءة النظافة لا تتضمن حالة صالحة')
            elif category in {'water', 'diesel', 'sewage'}:
                capacity, value, attention = point.get('capacity'), reading.get('value'), point.get('attention_percent')
                result.update(capacity=capacity, attention_percent=attention, policy_reference=point.get('policy_reference', ''))
                if not finite(capacity) or capacity <= 0 or not finite(value) or not 0 <= value <= capacity:
                    reason('invalid_reading', 'كمية الخزان أو سعته غير صالحة للتقييم')
                elif not finite(attention) or not 0 <= attention <= 100 or not point.get('policy_reference'):
                    reason('missing_criterion', 'حد الانتباه ومرجعه غير محددين؛ معيار التقييم مجهول')
                else:
                    percent = value / capacity * 100
                    needs_action = percent >= attention if category == 'sewage' else percent <= attention
                    result.update(source_status='needs_action' if needs_action else 'clear', percent=percent)
                    reason('attention_threshold' if needs_action else 'within_policy',
                           'الكمية بلغت حد الانتباه الداخلي المسجل' if needs_action
                           else 'القراءة ضمن الحد التشغيلي المسجل؛ ليست اعتماد سلامة')
            else:
                reason('unknown_category', 'نوع الخدمة غير قابل للتقييم')
    result['status'] = 'needs_action' if jobs else result['source_status']
    if jobs:
        reason('open_service_jobs', 'توجد أعمال خدمة لم يكتمل التحقق منها')
    result['reason'] = '؛ '.join(reasons)
    return result


def zone_readiness(state, at=None):
    at = instant(at) if at is not None else dt.datetime.now(dt.timezone.utc)
    if at is None:
        raise ValueError('readiness requires an aware evaluation time')
    project_ids = {project['id'] for project in state.get('projects', [])}
    rows = []
    for zone in state.get('zones', []):
        pid = zone.get('project_id')
        if pid not in project_ids:
            continue
        for phase in state.get('phases', []):
            if phase.get('project_id') != pid:
                continue
            points = [_point_status(state, point, phase['id'], at)
                      for point in state.get('service_points', [])
                      if point.get('project_id') == pid and point.get('zone_id') == zone['id']
                      and point.get('category') != 'visitors'
                      and (not point.get('phase_ids') or phase['id'] in point['phase_ids'])]
            counts = {'unknown': sum(point['source_status'] == 'unknown' for point in points),
                      'needs_action': sum(point['status'] == 'needs_action' for point in points),
                      'clear': sum(point['status'] == 'clear' for point in points)}
            status = 'needs_action' if counts['needs_action'] else 'unknown' if counts['unknown'] or not points else 'clear'
            rows.append({'project_id': pid, 'zone_id': zone['id'], 'phase_id': phase['id'], 'status': status,
                         'counts': counts, 'points': points, 'generated_at': at.isoformat()})
    return rows

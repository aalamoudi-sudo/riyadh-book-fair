import test from 'node:test';
import assert from 'node:assert/strict';
import {riyadhDate,riyadhLocal,riyadhISO,riyadhHourPeriod,aggregateHourlyEntries,readingState,stockBalance,pendingDayJobs,verificationReadings} from '../app/services.js';

const day='2026-09-27';
const points=[{id:'gate-a',category:'visitors',phase_ids:['operations'],freshness_minutes:60},{id:'gate-b',category:'visitors',phase_ids:['operations'],freshness_minutes:60}];
const reading=(id,hour,value,extra={})=>({id:`${id}-${hour}`,point_id:id,phase_id:'operations',...riyadhHourPeriod(day,hour),observed_at:riyadhHourPeriod(day,hour).period_end,value,...extra});
const endOfDay='2026-09-28T00:00:00+03:00';

test('Riyadh date and local input use +03:00 independently of host timezone',()=>{
  assert.equal(riyadhDate('2026-09-26T21:00:00Z'),day);
  assert.equal(riyadhDate('2026-09-26T20:59:59Z'),'2026-09-26');
  assert.equal(riyadhLocal('2026-09-26T21:07:00Z'),'2026-09-27T00:07');
  assert.equal(riyadhISO('2026-09-27T00:07'),'2026-09-26T21:07:00.000Z');
  assert.equal(riyadhISO('2026-09-27T00:07:53'),'2026-09-26T21:07:53.000Z');
  assert.equal(riyadhLocal('2026-09-26T21:07:53Z',true),'2026-09-27T00:07:53');
  assert.deepEqual(riyadhHourPeriod(day,0),{period_start:'2026-09-26T21:00:00.000Z',period_end:'2026-09-26T22:00:00.000Z'});
  assert.equal(riyadhHourPeriod(day,23).period_end,'2026-09-27T21:00:00.000Z');
  assert.throws(()=>riyadhHourPeriod('2026-02-30',0));
  assert.throws(()=>riyadhHourPeriod(day,24));
  assert.throws(()=>riyadhISO('2026-09-27T25:00'));
});

test('24 hourly buckets sum point movements only with complete coverage',()=>{
  const result=aggregateHourlyEntries(points,[reading('gate-a',10,17),reading('gate-b',10,23)],day,{now:endOfDay,phaseId:'operations'});
  assert.equal(result.length,24);
  assert.equal(result[10].status,'complete');
  assert.equal(result[10].total,40);
  assert.equal(result[10].covered,2);
  assert.equal(result[9].total,null);
  assert.equal(result[9].status,'missing');
});

test('zero is a measured value while missing coverage and malformed readings remain unknown',()=>{
  const result=aggregateHourlyEntries(points,[reading('gate-a',3,0),reading('gate-b',3,0),reading('gate-a',4,0),reading('gate-a',5,null),reading('gate-b',5,'0')],day,{now:endOfDay});
  assert.equal(result[3].total,0);
  assert.equal(result[3].status,'complete');
  assert.equal(result[4].total,null);
  assert.equal(result[4].recordedTotal,0);
  assert.equal(result[4].status,'partial');
  assert.equal(result[5].recordedTotal,null);
  assert.equal(result[5].status,'missing');
  assert.equal(result[6].recordedTotal,null);
});

test('duplicate observations cannot be double counted and invalid periods are rejected',()=>{
  const result=aggregateHourlyEntries(points,[reading('gate-a',1,5),reading('gate-a',1,5),reading('gate-b',1,7),reading('gate-a',2,10,{period_end:riyadhHourPeriod(day,3).period_end}),reading('gate-b',2,9,{observed_at:riyadhHourPeriod(day,2).period_start})],day,{now:endOfDay});
  assert.equal(result[1].conflicts,1);
  assert.equal(result[1].total,null);
  assert.equal(result[1].recordedTotal,7);
  assert.equal(result[2].recordedTotal,null);
});

test('unfinished and future hours are pending, not zero; future observations do not count',()=>{
  const now='2026-09-27T10:30:00+03:00';
  const result=aggregateHourlyEntries(points,[reading('gate-a',9,3,{observed_at:'2026-09-27T11:30:00+03:00'}),reading('gate-b',10,6)],day,{now});
  assert.equal(result[9].status,'missing');
  assert.equal(result[10].status,'pending');
  assert.equal(result[10].total,null);
  assert.equal(result[10].recordedTotal,null);
  assert.equal(result[23].status,'pending');
});

test('phase scope includes all-phase points and excludes another phase from readings',()=>{
  const scoped=[...points,{id:'gate-c',category:'visitors',phase_ids:['build']},{id:'gate-d',category:'visitors',phase_ids:[]},{id:'tank',category:'water'}];
  const result=aggregateHourlyEntries(scoped,[reading('gate-a',7,3),reading('gate-b',7,4),reading('gate-d',7,6),reading('gate-c',7,999,{phase_id:'build'}),reading('gate-a',8,777,{phase_id:'build'})],day,{now:endOfDay,phaseId:'operations'});
  assert.equal(result[7].expected,3);
  assert.equal(result[7].total,13);
  assert.equal(result[8].status,'missing');
  assert.equal(aggregateHourlyEntries([],[],day,{now:endOfDay})[0].status,'unmonitored');
});

test('tank and cleaning freshness distinguishes missing, expired, invalid and explicit zero',()=>{
  const point={id:'water',category:'water',capacity:1000,freshness_minutes:60,attention_percent:20};
  const base={point_id:'water',value:0,observed_at:'2026-09-27T09:00:00Z'};
  assert.equal(readingState(point,[],'2026-09-27T09:30:00Z').status,'missing');
  const current=readingState(point,[base],'2026-09-27T09:30:00Z');
  assert.equal(current.value,0);
  assert.equal(current.percent,0);
  assert.equal(current.attention,true);
  const stale=readingState(point,[base],'2026-09-27T10:01:00Z');
  assert.equal(stale.status,'stale');
  assert.equal(stale.value,null);
  assert.equal(stale.attention,null);
  assert.equal(readingState(point,[{...base,value:null}],'2026-09-27T09:30:00Z').status,'invalid');
  assert.equal(readingState(point,[{...base,value:1001}],'2026-09-27T09:30:00Z').status,'invalid');
  assert.equal(readingState(point,[base],'2026-09-27T08:00:00Z').value,null);
  assert.equal(readingState({...point,category:'sewage'},[{...base,value:900}],'2026-09-27T09:30:00Z').attention,true);
  assert.equal(readingState({...point,attention_percent:null},[base],'2026-09-27T09:30:00Z').attention,null);
  assert.equal(readingState({...point,category:'cleaning'},[{...base,condition:'needs_service'}],'2026-09-27T09:30:00Z').attention,true);
});

test('new manual submission of an old entry period does not renew current monitoring',()=>{
  const old=reading('gate-a',3,12,{observed_at:'2026-09-27T10:00:00+03:00'});
  const current=readingState(points[0],[old],'2026-09-27T10:05:00+03:00');
  assert.equal(current.status,'stale');
  assert.equal(current.value,null);
  const historical=aggregateHourlyEntries([points[0]],[old],day,{now:endOfDay});
  assert.equal(historical[3].total,12);
});

test('stock reads server available unchanged and never subtracts maintenance twice',()=>{
  const point={item_id:'gloves',zone_id:'store',minimum_stock:5};
  const stock=[{item_id:'gloves',zone_id:'store',on_hand:10,reserved:2,available:8,maintenance:3},{item_id:'gloves',zone_id:'other',on_hand:200,reserved:0,available:200,maintenance:0}];
  assert.equal(stockBalance(point,stock).available,8);
  assert.equal(stockBalance(point,stock).attention,false);
  assert.equal(stockBalance(point,[]).available,null);
  assert.equal(stockBalance(point,[]).known,false);
  assert.equal(stockBalance(point,[{...stock[0],available:0}]).available,0);
  assert.equal(stockBalance(point,[{...stock[0],available:null}]).known,false);
});

test('day handover includes unlinked overdue work without crossing project or phase',()=>{
  const current={id:'day-1',project_id:'project-a',phase_id:'operations',operational_date:day};
  const base={project_id:'project-a',phase_id:'operations',status:'scheduled',due_at:'2026-09-27T23:50:00+03:00'};
  const jobs=[{...base,id:'due-today'},{...base,id:'overdue',due_at:'2026-09-26T08:00:00+03:00'},{...base,id:'linked-future',day_id:'day-1',due_at:'2026-09-28T08:00:00+03:00'},{...base,id:'other-phase',phase_id:'build'},{...base,id:'other-project',project_id:'project-b'},{...base,id:'done',status:'completed'},{...base,id:'future',due_at:'2026-09-28T08:00:00+03:00'}];
  assert.deepEqual(pendingDayJobs(jobs,current).map(job=>job.id),['due-today','overdue','linked-future']);
});

test('verification selects only same-point, same-phase readings after request and ready cleaning',()=>{
  const point={id:'cleaning-a',category:'cleaning'};
  const job={phase_id:'operations',verification_requested_at:'2026-09-27T10:30:20.300Z'};
  const base={point_id:'cleaning-a',phase_id:'operations',observed_at:'2026-09-27T10:30:20.301Z',condition:'ready'};
  const readings=[{...base,id:'valid'},{...base,id:'same-time',observed_at:job.verification_requested_at},{...base,id:'needs-cleaning',condition:'needs_service'},{...base,id:'other-phase',phase_id:'build'},{...base,id:'other-point',point_id:'cleaning-b'}];
  assert.deepEqual(verificationReadings(job,point,readings).map(reading=>reading.id),['valid']);
  assert.deepEqual(verificationReadings({...job,verification_requested_at:undefined},point,readings),[]);
});

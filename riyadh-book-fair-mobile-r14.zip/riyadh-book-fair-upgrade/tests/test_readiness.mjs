import test from 'node:test';
import assert from 'node:assert/strict';
import {selectReviewedZonePlan,zoneReadinessView,missionEligibility,buildMeasuredMission,missionComparison,getReadinessScope,setReadinessScope,renderReadiness} from '../app/readiness.js';

const now='2026-09-27T12:00:00Z';
const point={id:'water-a',project_id:'project-a',zone_id:'zone-a',category:'water',capacity:10000,freshness_minutes:60,phase_ids:['operations'],responsible_id:'team-a',name:'مياه القاعة أ'};
const baseline={id:'reading-a',project_id:'project-a',phase_id:'operations',point_id:'water-a',observed_at:'2026-09-27T11:45:00Z',value:2100,source:'field',provenance:'manual',evidence:'قراءة معاينة'};
const fields={responsible_id:'team-a',provider:'فريق المياه',evidence:'رفع المخزون التشغيلي وفق التكليف',due_at:'2026-09-27T16:00',target_value:'7000'};
const scope={projectId:'project-a',phaseId:'operations'};
const plan=(id,revision,extra={})=>({id,project_id:'project-a',status:'reviewed',provenance:'manual',review_revision:revision,reviewed_at:'2026-09-26T10:00:00Z',plan:{provenance:{data_class:'manual'},elements:[{zone_id:'zone-a',polygon:[[0,0],[10,0],[10,10]]}]},...extra});

test('spatial label selects the latest reviewed manual plan for the exact project and zone',()=>{
  const old=plan('old',1),latest=plan('latest',2);
  assert.equal(selectReviewedZonePlan([old,latest,plan('unrelated',30,{project_id:'other'})],'zone-a','project-a').id,'latest');
  assert.equal(selectReviewedZonePlan([latest],'zone-b','project-a'),null);
  assert.equal(selectReviewedZonePlan([latest],'zone-a','other'),null);
});

test('demo, expected and draft plans cannot supply operational geometry',()=>{
  const demoRecord=plan('demo-record',100,{provenance:'demo'});
  const demoPlan=plan('demo-plan',101,{plan:{provenance:{data_class:'demo'},elements:[{zone_id:'zone-a'}]}});
  const expected=plan('expected',102,{plan:{provenance:{data_class:'expected'},elements:[{zone_id:'zone-a'}]}});
  const draft=plan('draft',103,{status:'draft'});
  assert.equal(selectReviewedZonePlan([demoRecord,demoPlan,expected,draft],'zone-a','project-a'),null);
  assert.equal(selectReviewedZonePlan([demoRecord,demoPlan,expected,draft,plan('valid',1)],'zone-a','project-a').id,'valid');
});

test('missing readiness is unknown; action and unknown counts remain independent',()=>{
  const absent=zoneReadinessView();
  assert.equal(absent.status,'unknown');
  assert.equal(absent.unknown,null);
  assert.equal(absent.clear,null);
  const derived=zoneReadinessView({status:'needs_action',counts:{unknown:1,needs_action:1,clear:0},points:[{point_id:'water-a',status:'needs_action',source_status:'unknown',open_job_ids:['job-a']}]});
  assert.equal(derived.unknown,1);
  assert.equal(derived.needsAction,1);
  assert.equal(derived.clear,0);
  assert.equal(derived.points[0].source_status,'unknown');
  assert.equal(zoneReadinessView({status:'clear',points:[],counts:{unknown:0,needs_action:0,clear:0}}).status,'unknown');
});

test('mission baseline is latest, fresh and from the same project, point and phase',()=>{
  const readings=[baseline,{...baseline,id:'other-phase',phase_id:'build',observed_at:now},{...baseline,id:'other-project',project_id:'other',observed_at:now},{...baseline,id:'other-point',point_id:'water-b',observed_at:now}];
  const eligible=missionEligibility(point,readings,'operations',now);
  assert.equal(eligible.eligible,true);
  assert.equal(eligible.baseline.id,'reading-a');
  assert.equal(missionEligibility(point,readings,'build',now).eligible,false);
  assert.equal(missionEligibility(point,[baseline,{...baseline,id:'newer',value:2200,observed_at:'2026-09-27T11:50:00Z'}],'operations',now).baseline.id,'newer');
});

test('equal observation times select the last registered reading like the server',()=>{
  const latestRegistered={...baseline,id:'reading-latest-registration',value:2200};
  const eligibility=missionEligibility(point,[baseline,latestRegistered],'operations',now);
  assert.equal(eligibility.eligible,true);
  assert.equal(eligibility.baseline.id,'reading-latest-registration');
  assert.equal(eligibility.baseline.value,2200);
});

test('missing, stale, future and null readings cannot become measured mission baselines',()=>{
  assert.equal(missionEligibility(point,[],'operations',now).eligible,false);
  assert.equal(missionEligibility(point,[{...baseline,observed_at:'2026-09-27T10:00:00Z'}],'operations',now).eligible,false);
  assert.equal(missionEligibility(point,[{...baseline,observed_at:'2026-09-27T13:00:00Z'}],'operations',now).eligible,false);
  assert.equal(missionEligibility(point,[{...baseline,value:null}],'operations',now).eligible,false);
  assert.equal(missionEligibility({...point,freshness_minutes:0},[baseline],'operations',now).eligible,false);
  assert.equal(missionEligibility(point,[{...baseline,value:0}],'operations',now).eligible,true);
  const future={...baseline,id:'future-latest',observed_at:'2026-09-27T13:00:00Z'};
  const blocked=missionEligibility(point,[baseline,future],'operations',now);
  assert.equal(blocked.eligible,false);
  assert.equal(blocked.baseline.id,'future-latest');
});

test('inventory and visitor entries cannot masquerade as tank or cleaning missions',()=>{
  assert.equal(missionEligibility({...point,category:'inventory'},[baseline],'operations',now).eligible,false);
  assert.equal(missionEligibility({...point,category:'visitors'},[baseline],'operations',now).eligible,false);
});

test('numeric target is explicit, improving and within tank capacity',()=>{
  const payload=buildMeasuredMission(point,baseline,fields,scope);
  assert.equal(payload.target_value,7000);
  assert.equal(typeof payload.target_value,'number');
  assert.equal(payload.baseline_reading_id,baseline.id);
  assert.equal(payload.action,'fill');
  assert.equal(payload.due_at,'2026-09-27T13:00:00.000Z');
  assert.throws(()=>buildMeasuredMission(point,baseline,{...fields,target_value:''},scope));
  assert.throws(()=>buildMeasuredMission(point,baseline,{...fields,target_value:'2100'},scope));
  assert.throws(()=>buildMeasuredMission(point,baseline,{...fields,target_value:'11000'},scope));
  assert.throws(()=>buildMeasuredMission(point,baseline,{...fields,provider:''},scope));
  assert.throws(()=>buildMeasuredMission(point,baseline,fields,{...scope,phaseId:'build'}));
});

test('sewage target decreases toward zero without coercing blank to zero',()=>{
  const sewage={...point,category:'sewage'};
  assert.equal(buildMeasuredMission(sewage,baseline,{...fields,target_value:'0'},scope).target_value,0);
  assert.equal(buildMeasuredMission(sewage,baseline,{...fields,target_value:'500'},scope).action,'pump');
  assert.throws(()=>buildMeasuredMission(sewage,baseline,{...fields,target_value:' '},scope));
  assert.throws(()=>buildMeasuredMission(sewage,baseline,{...fields,target_value:2200},scope));
});

test('cleaning uses a condition goal and cannot create a false improvement from ready',()=>{
  const cleaning={...point,category:'cleaning'},source={...baseline,value:undefined,condition:'needs_service'};
  assert.equal(missionEligibility(cleaning,[source],'operations',now).eligible,true);
  const payload=buildMeasuredMission(cleaning,source,fields,scope);
  assert.equal(payload.target_condition,'ready');
  assert.equal(payload.action,'clean');
  assert.equal('target_value' in payload,false);
  assert.equal(missionEligibility(cleaning,[{...source,condition:'ready'}],'operations',now).eligible,false);
  assert.throws(()=>buildMeasuredMission(cleaning,{...source,condition:'ready'},fields,scope));
});

test('comparison shows only server-approved outcome and preserves measured zero',()=>{
  const job={status:'awaiting_verification',baseline_snapshot:{...baseline,value:0},target_value:7000};
  assert.deepEqual(missionComparison(job,point),{before:0,target:7000,after:null,delta:null,verified:false,outcome:null});
  const outcome={before:0,after:7000,delta:7000,target:7000,target_met:true,reading_id:'follow-up',observed_at:now};
  assert.equal(missionComparison({...job,outcome},point).verified,false);
  const verified=missionComparison({...job,status:'completed',outcome},point);
  assert.equal(verified.after,7000);
  assert.equal(verified.delta,7000);
  assert.equal(verified.verified,true);
  assert.equal(missionComparison({...job,status:'completed',outcome:{...outcome,after:null}},point).after,null);
});

function context(projectId='scope-project-a'){
  const collections={phases:[{id:'build',kind:'build',order:1,name:'التجهيز'},{id:'operations',kind:'operations',order:2,name:'التشغيل'}],zones:[{id:'zone-a',name:'القاعة أ'},{id:'zone-b',name:'القاعة ب'}],zone_readiness:[{project_id:projectId,zone_id:'zone-a',phase_id:'operations',status:'clear',counts:{unknown:0,needs_action:0,clear:1},points:[{point_id:'p'}]},{project_id:projectId,zone_id:'zone-b',phase_id:'operations',status:'needs_action',counts:{unknown:1,needs_action:1,clear:0},points:[{point_id:'q',source_status:'unknown'}]}]};
  return {projectId,state:{user:{role:'viewer'}},lastLoaded:now,records:key=>collections[key]||[],name:(key,id)=>collections[key]?.find(row=>row.id===id)?.name||id,can:()=>false};
}
test('readiness scope defaults to operations and first action zone, isolated by project',()=>{
  const first=context(),second=context('scope-project-b');
  assert.deepEqual(getReadinessScope(first),{phaseId:'operations',zoneId:'zone-b'});
  setReadinessScope(first,{zoneId:'zone-a',phaseId:'build'});
  assert.deepEqual(getReadinessScope(first),{phaseId:'build',zoneId:'zone-a'});
  assert.deepEqual(getReadinessScope(second),{phaseId:'operations',zoneId:'zone-b'});
  setReadinessScope(second,{zoneId:'foreign-zone',phaseId:'foreign-phase'});
  assert.deepEqual(getReadinessScope(second),{phaseId:'operations',zoneId:'zone-b'});
});

test('unmapped readiness page offers a relationship board without claiming engineering placement',()=>{
  const html=renderReadiness(context('render-project'));
  assert.match(html,/عرض ارتباط المنطقة/);
  assert.match(html,/دون إحداثيات أو ادعاء موضع جغرافي/);
  assert.match(html,/لا تمثل شهادة جاهزية أو سلامة/);
  assert.doesNotMatch(html,/data-action="spatial-zone-select"/);
});

test('equal action zones prioritize an open measured mission, then original zone order',()=>{
  const base=context('measured-priority-project');
  const summaries=['zone-b','zone-a'].map(zone_id=>({zone_id,phase_id:'operations',status:'needs_action',points:[{point_id:'p'}],counts:{unknown:0,needs_action:1,clear:0}}));
  const jobs=[{id:'mission',phase_id:'operations',zone_id:'zone-b',status:'in_progress',baseline_snapshot:{reading_id:'baseline'}}];
  const ctx={...base,records:key=>key==='zone_readiness'?summaries:key==='service_jobs'?jobs:base.records(key)};
  assert.equal(getReadinessScope(ctx).zoneId,'zone-b');
  const withoutMission={...ctx,projectId:'original-order-project',records:key=>key==='service_jobs'?[]:ctx.records(key)};
  assert.equal(getReadinessScope(withoutMission).zoneId,'zone-a');
});

test('zone with no registered points displays absence instead of zero-pass counters',()=>{
  const base=context('no-points-project');
  const ctx={...base,records:key=>key==='zones'?[{id:'zone-empty',name:'خدمة الزائر'}]:key==='zone_readiness'?[{zone_id:'zone-empty',phase_id:'operations',status:'unknown',points:[],counts:{unknown:0,needs_action:0,clear:0}}]:base.records(key)};
  const html=renderReadiness(ctx);
  assert.match(html,/readiness-zone-counts">لا نقاط خدمة مسجلة/);
  assert.doesNotMatch(html,/0 متابعة <span aria-hidden="true">·<\/span> 0 مجهول/);
});

test('mission target uses RTL-safe words for fill and pump rather than comparison symbols',()=>{
  const base=context('rtl-target-project');
  const jobs=[{id:'fill-job',project_id:base.projectId,zone_id:'zone-b',phase_id:'operations',point_id:'fill-point',action:'fill',status:'scheduled',baseline_snapshot:{...baseline},target_value:7000},{id:'pump-job',project_id:base.projectId,zone_id:'zone-b',phase_id:'operations',point_id:'pump-point',action:'pump',status:'scheduled',baseline_snapshot:{...baseline},target_value:500}];
  const points=[{...point,id:'fill-point',project_id:base.projectId,zone_id:'zone-b'},{...point,id:'pump-point',project_id:base.projectId,zone_id:'zone-b',category:'sewage'}];
  const ctx={...base,records:key=>key==='service_jobs'?jobs:key==='service_points'?points:base.records(key)};
  const html=renderReadiness(ctx);
  assert.match(html,/7,000 لتر أو أكثر/);
  assert.match(html,/500 لتر أو أقل/);
  assert.doesNotMatch(html,/[≥≤]/);
});

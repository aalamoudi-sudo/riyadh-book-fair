import base64
import copy
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import sqlite3
import stat
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
from scripts import prepare_mobile_r14 as mobile

ADMIN = {'id': 'retained-demo-admin', 'role': 'admin'}


class MobileDeployTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.source = self.folder / 'old-r10-demo.sqlite'
        self.store = DomainStore(self.source, demo=True)
        pid = self.store.state()['projects'][0]['id']
        self.store.command('shared.create', {'collection': 'stakeholders', 'project_id': pid,
                           'name': 'Existing operator record', 'notes': 'Preserve this user edit'}, ADMIN)
        self.pdf = b'%PDF-1.4\nPreserved attachment\n%%EOF'
        self.attachment = self.store.command('attachment.create', {
            'project_id': pid, 'filename': 'retained.pdf', 'content_type': 'application/pdf',
            'data_base64': base64.b64encode(self.pdf).decode(), 'evidence': 'Existing document'}, ADMIN)['result']
        with self.store.connect() as connection:
            connection.execute('INSERT INTO sessions VALUES(?,?,?)', ('existing-session', 'retained-demo-admin', 4102444800))
        self.export = self.store.export(ADMIN)
        # The r10 schema-1 export has no service collections. This is the exact
        # old envelope; current records retain their IDs and recorded timestamps.
        for collection in mobile.SERVICE_COLLECTIONS:
            self.export['records'].pop(collection)
        self.bootstrap = self.folder / 'private-bootstrap.json'
        self.digest = self.write_export(self.export)
        self.target = self.folder / 'mobile.sqlite'

    def write_export(self, value):
        raw = json.dumps(value, ensure_ascii=False).encode()
        self.bootstrap.write_bytes(raw)
        return hashlib.sha256(raw).hexdigest()

    def prepare(self, **extra):
        return mobile.prepare_mobile(extra.get('db', self.target), extra.get('bootstrap', self.bootstrap),
                                     extra.get('digest', self.digest))

    def assert_export_preserved(self, path):
        after = DomainStore(path, demo=True).export(ADMIN)
        for collection, old_rows in self.export['records'].items():
            new_rows = {row['id']: row for row in after['records'][collection]}
            for row in old_rows:
                self.assertEqual(new_rows[row['id']], row)
        self.assertEqual(after['audit'][:len(self.export['audit'])], self.export['audit'])
        self.assertEqual(after['attachment_contents'], self.export['attachment_contents'])
        return after

    def test_r10_bootstrap_restores_old_ids_times_audit_blobs_then_adds_training(self):
        result = self.prepare()
        self.assertEqual(result['action'], 'upgraded')
        self.assertTrue(result['restored_bootstrap'])
        self.assertTrue(result['training_seeded'])
        after = self.assert_export_preserved(self.target)
        self.assertEqual(len(after['records']['service_points']), 9)
        self.assertEqual(sum(bool(row.get('baseline_snapshot')) for row in after['records']['service_jobs']), 1)
        self.assertGreater(after['revision'], self.export['revision'])
        backup = mobile._snapshot(Path(result['backup_path']))
        self.assertEqual(int(backup['metadata']['revision']), self.export['revision'])
        self.assertEqual(backup['audit'], [tuple(row[key] for key in mobile.AUDIT_FIELDS) for row in self.export['audit']])
        self.assertEqual(backup['sessions'], [])
        self.assertEqual(backup['blobs'], [(self.attachment['id'], self.pdf)])
        self.assertIn(mobile.MARKER, mobile._snapshot(self.target)['metadata'])
        self.assertEqual(stat.S_IMODE(self.target.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(Path(result['backup_path']).stat().st_mode), 0o600)
        self.assertFalse(list(self.folder.glob('.*r14-stage-*')))
        self.assertFalse(list(self.folder.glob('.*r14-baseline-*')))

    def test_existing_demo_is_authoritative_even_with_invalid_or_missing_bootstrap(self):
        before = mobile._snapshot(self.source)
        result = self.prepare(db=self.source, bootstrap=self.folder / 'missing.json', digest='invalid')
        self.assertFalse(result['restored_bootstrap'])
        self.assertEqual(result['action'], 'upgraded')
        after = mobile._snapshot(self.source)
        mobile._preserved(before, after)
        self.assertEqual(after['sessions'], before['sessions'])
        self.assertEqual(mobile._snapshot(Path(result['backup_path'])), before)

    def test_repeat_is_noop_and_preserves_post_upgrade_user_changes(self):
        self.prepare()
        store = DomainStore(self.target, demo=True)
        store.command('shared.create', {'collection': 'projects', 'name': 'New user work after upgrade'}, ADMIN)
        before = mobile._snapshot(self.target)
        backups = sorted(self.folder.glob('mobile.sqlite.pre-r14-*'))
        with patch.object(mobile, 'load_bootstrap', side_effect=AssertionError('must not read bootstrap')):
            result = self.prepare(digest='invalid')
        self.assertEqual(result['action'], 'already_upgraded')
        self.assertEqual(mobile._snapshot(self.target), before)
        self.assertEqual(sorted(self.folder.glob('mobile.sqlite.pre-r14-*')), backups)

    def test_existing_r13_or_partial_services_without_marker_are_preserved_without_seed(self):
        state = self.store.state()
        self.store.command('service_point.create', dict(project_id=state['projects'][0]['id'],
            zone_id=state['zones'][0]['id'], responsible_id=state['stakeholders'][0]['id'],
            name='Existing service', category='cleaning', freshness_minutes=30, evidence='Existing point'), ADMIN)
        before = mobile._snapshot(self.source)
        with patch.object(mobile, 'seed_readiness', side_effect=AssertionError('must not seed')):
            result = self.prepare(db=self.source, digest='invalid')
        self.assertEqual(result['action'], 'existing_services_preserved')
        self.assertFalse(result['training_seeded'])
        self.assertEqual(mobile._snapshot(self.source), before)
        self.assertNotIn(mobile.MARKER, before['metadata'])

    def test_bootstrap_with_existing_services_restores_without_duplicate_training(self):
        state = self.store.state()
        self.store.command('service_point.create', dict(project_id=state['projects'][0]['id'],
            zone_id=state['zones'][0]['id'], responsible_id=state['stakeholders'][0]['id'],
            name='Existing service', category='cleaning', freshness_minutes=30, evidence='Existing point'), ADMIN)
        self.export = self.store.export(ADMIN)
        self.digest = self.write_export(self.export)
        result = self.prepare()
        self.assertEqual(result['action'], 'existing_services_preserved')
        self.assertTrue(result['restored_bootstrap'])
        after = self.assert_export_preserved(self.target)
        self.assertEqual(after['revision'], self.export['revision'])
        self.assertEqual(len(after['records']['service_points']), 1)

    def test_invalid_hash_is_rejected_before_parse_and_creates_no_database(self):
        self.bootstrap.write_text('not JSON')
        with patch.object(mobile, '_json', side_effect=AssertionError('must not parse')):
            with self.assertRaisesRegex(ValueError, 'SHA-256 mismatch'):
                self.prepare()
        self.assertFalse(self.target.exists())

    def test_invalid_export_content_is_rejected_without_publication(self):
        changes = [lambda value: value.update(mode='manual'),
                   lambda value: value.update(schema_version=True),
                   lambda value: value.update(format='unknown'),
                   lambda value: value.update(sessions=[]),
                   lambda value: value.update(accounts=[]),
                   lambda value: value.update(revision=value['revision'] + 1),
                   lambda value: value['records'].update(unrecognized=[]),
                   lambda value: value['records']['projects'].append(copy.deepcopy(value['records']['projects'][0])),
                   lambda value: value['audit'][0].update(seq=2),
                   lambda value: value['audit'][0].update(payload='[]'),
                   lambda value: value['attachment_contents'][0].update(sha256='0' * 64),
                   lambda value: value['attachment_contents'].clear()]
        for change in changes:
            with self.subTest(change=change):
                value = copy.deepcopy(self.export)
                change(value)
                digest = self.write_export(value)
                with self.assertRaises(ValueError):
                    self.prepare(digest=digest)
                self.assertFalse(self.target.exists())

    def test_json_duplicates_nonfinite_depth_and_size_limits_are_rejected(self):
        for raw in (b'{"format":1,"format":2}', b'{"x":NaN}', b'{"x":1e999}', b'[' * 42 + b'0' + b']' * 42):
            self.bootstrap.write_bytes(raw)
            with self.assertRaises(ValueError):
                self.prepare(digest=hashlib.sha256(raw).hexdigest())
            self.assertFalse(self.target.exists())
        self.digest = self.write_export(self.export)
        with patch.object(mobile, 'MAX_BOOTSTRAP_BYTES', 100):
            with self.assertRaisesRegex(ValueError, 'size'):
                self.prepare()
        self.assertFalse(self.target.exists())

    def test_existing_manual_database_is_rejected_unchanged(self):
        manual = self.folder / 'manual.sqlite'
        DomainStore(manual)
        before = manual.read_bytes()
        with self.assertRaisesRegex(ValueError, 'manual'):
            self.prepare(db=manual)
        self.assertEqual(manual.read_bytes(), before)

    def test_seed_failure_leaves_existing_original_and_its_sessions_unchanged(self):
        before = mobile._snapshot(self.source)
        def fail_after_write(store):
            store.command('shared.create', {'collection': 'projects', 'name': 'Partial staged write'}, ADMIN)
            raise RuntimeError('Injected seed failure')
        with patch.object(mobile, 'seed_readiness', side_effect=fail_after_write):
            with self.assertRaisesRegex(RuntimeError, 'Injected'):
                self.prepare(db=self.source)
        self.assertEqual(mobile._snapshot(self.source), before)
        self.assertFalse(list(self.folder.glob('.*r14-stage-*')))
        self.assertFalse(list(self.folder.glob('.*r14-baseline-*')))
        self.assertFalse(list(self.folder.glob('old-r10-demo.sqlite.pre-r14-*')))

    def test_seed_failure_does_not_publish_a_partially_restored_new_database(self):
        original = self.bootstrap.read_bytes()
        with patch.object(mobile, 'seed_readiness', side_effect=RuntimeError('Injected failure')):
            with self.assertRaises(RuntimeError):
                self.prepare()
        self.assertFalse(self.target.exists())
        self.assertEqual(self.bootstrap.read_bytes(), original)
        self.assertFalse(list(self.folder.glob('.*r14-stage-*')))

    def test_preservation_guard_rejects_seed_that_changes_an_old_record(self):
        before = mobile._snapshot(self.source)
        def bad_seed(store):
            with store.connect() as connection:
                row = store.all(connection, 'projects')[0]
                row['name'] = 'Unwanted legacy change'
                store.put(connection, 'projects', row)
            return {'mission_id': 'unpublished'}
        with patch.object(mobile, 'seed_readiness', side_effect=bad_seed):
            with self.assertRaisesRegex(ValueError, 'existing record'):
                self.prepare(db=self.source)
        self.assertEqual(mobile._snapshot(self.source), before)

    def test_cutover_failure_keeps_original_and_verified_backup(self):
        before = mobile._snapshot(self.source)
        with patch.object(mobile.os, 'replace', side_effect=OSError('Injected cutover failure')):
            with self.assertRaises(OSError):
                self.prepare(db=self.source)
        self.assertEqual(mobile._snapshot(self.source), before)
        backups = list(self.folder.glob('old-r10-demo.sqlite.pre-r14-*'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(mobile._snapshot(backups[0]), before)

    def test_startup_lock_rejects_concurrent_preparation(self):
        with mobile._startup_lock(self.target):
            with self.assertRaisesRegex(ValueError, 'Another'):
                self.prepare()
        self.assertFalse(self.target.exists())

    def test_cli_reports_only_summary_and_existing_database_noop(self):
        output = io.StringIO()
        with redirect_stdout(output), redirect_stderr(io.StringIO()):
            status = mobile.main(['--db', str(self.target), '--bootstrap', str(self.bootstrap),
                                  '--bootstrap-sha256', self.digest])
        self.assertEqual(status, 0)
        summary = json.loads(output.getvalue())
        self.assertEqual(summary['action'], 'upgraded')
        self.assertNotIn('Existing operator record', output.getvalue())
        self.assertNotIn(base64.b64encode(self.pdf).decode(), output.getvalue())


if __name__ == '__main__':
    unittest.main()

from datetime import datetime, timezone
from pathlib import Path
import stat
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
from scripts.prepare_readiness_demo import (
    ADMIN, REPLACEMENT_REASON, create_readiness_demo, seed_readiness,
)

FIELD = {'id': 'readiness-demo-field', 'role': 'field'}


class ReadinessDemoTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / 'readiness.sqlite'

    def test_fixture_preserves_training_sources_stock_and_unapproved_geometry(self):
        store = DomainStore(self.path, demo=True)
        before = store.state()
        summary = seed_readiness(store)
        state = DomainStore(self.path, demo=True).state()
        self.assertEqual(state['mode'], 'demo')
        self.assertEqual(len(state['service_points']), 9)
        self.assertEqual(len(state['service_days']), 2)
        self.assertEqual(len(state['service_jobs']), 5)
        for collection in ('stock', 'stock_moves', 'spatial_plans', 'tasks', 'incidents'):
            self.assertEqual(state[collection], before[collection], collection)
        for collection in ('service_points', 'service_days', 'service_jobs', 'service_readings'):
            self.assertTrue(all(row['provenance'] == 'demo' for row in state[collection]))
        self.assertTrue(all(row['source'] == 'manual' for row in state['service_readings']))
        self.assertFalse(any(row['status'] == 'reviewed' for row in state['spatial_plans']))
        mission = next(row for row in state['service_jobs'] if row['id'] == summary['mission_id'])
        self.assertEqual(mission['status'], 'scheduled')
        self.assertEqual(mission['target_value'], 7000)
        self.assertEqual(mission['baseline_snapshot']['value'], 2100)
        self.assertEqual(mission['baseline_snapshot']['reading_id'], summary['baseline_reading_id'])
        self.assertEqual(mission['baseline_snapshot']['provenance'], 'demo')
        self.assertFalse(mission.get('outcome'))
        replaced = next(row for row in state['service_jobs'] if row['id'] == summary['replaced_job_id'])
        self.assertEqual(replaced['status'], 'cancelled')
        self.assertEqual(replaced['cancellation_reason'], REPLACEMENT_REASON)
        cleaning = next(row for row in state['service_jobs']
                        if row['id'] == summary['completed_cleaning_job_id'])
        self.assertEqual(cleaning['status'], 'completed')
        reading = next(row for row in state['service_readings']
                       if row['id'] == cleaning['verification_reading_id'])
        self.assertEqual(reading['condition'], 'ready')
        self.assertGreater(datetime.fromisoformat(reading['observed_at']),
                           datetime.fromisoformat(cleaning['verification_requested_at']))
        visitor_zone = next(row for row in state['zones'] if row['name'] == 'مركز خدمة الزائر')
        self.assertFalse(any(row['zone_id'] == visitor_zone['id'] for row in state['service_points']))
        readiness = {row['zone_id']: row for row in state['zone_readiness']
                     if row['project_id'] == summary['project_id'] and row['phase_id'] == summary['phase_id']}
        zone_ids = {row['name']: row['id'] for row in state['zones']}
        for name, status in [('القاعة أ', 'needs_action'), ('القاعة ب', 'needs_action'),
                             ('منطقة التحميل', 'unknown'), ('مركز خدمة الزائر', 'unknown')]:
            self.assertEqual(readiness[zone_ids[name]]['status'], status, name)
        diesel = next(row for row in state['service_points'] if row['category'] == 'diesel')
        diesel_reading = next(row for row in state['service_readings'] if row['point_id'] == diesel['id'])
        age_minutes = (datetime.now(timezone.utc)-datetime.fromisoformat(diesel_reading['observed_at'])).total_seconds()/60
        self.assertGreater(age_minutes, diesel['freshness_minutes'])
        sewage = next(row for row in state['service_points'] if row['category'] == 'sewage')
        sewage_reading = next(row for row in state['service_readings'] if row['point_id'] == sewage['id'])
        self.assertGreaterEqual(100*sewage_reading['value']/sewage['capacity'], sewage['attention_percent'])

    def test_mission_ends_only_after_followup_and_manager_verification(self):
        store = DomainStore(self.path, demo=True)
        summary = seed_readiness(store)
        before = store.state()
        for status in ('in_progress', 'awaiting_verification'):
            job = store.command('service_job.transition', {
                'id': summary['mission_id'], 'status': status,
                'evidence': 'إجراء تدريبي موثق؛ لا تنفيذ مادي',
            }, FIELD)['result']
            self.assertFalse(job.get('outcome'))
        reading = store.command('service_reading.create', {
            'point_id': summary['water_point_id'], 'phase_id': summary['phase_id'],
            'observed_at': datetime.now(timezone.utc).isoformat(), 'source': 'manual',
            'value': 7000, 'evidence': 'قراءة متابعة اصطناعية بعد طلب التحقق',
        }, FIELD)['result']
        awaiting = next(row for row in store.state()['service_jobs']
                        if row['id'] == summary['mission_id'])
        self.assertEqual(awaiting['status'], 'awaiting_verification')
        completed = store.command('service_job.transition', {
            'id': summary['mission_id'], 'status': 'completed',
            'reading_id': reading['id'], 'evidence': 'تحقق المدير من نتيجة التدريب',
        }, ADMIN)['result']
        self.assertEqual(completed['status'], 'completed')
        outcome = completed['outcome']
        self.assertEqual((outcome['before'], outcome['target'], outcome['after'], outcome['delta']),
                         (2100, 7000, 7000, 4900))
        self.assertEqual(outcome['reading_id'], reading['id'])
        self.assertEqual(outcome['verified_by'], ADMIN['id'])
        self.assertEqual(outcome['unit'], 'liters')
        self.assertTrue(outcome['target_met'])
        after = store.state()
        self.assertEqual(after['stock'], before['stock'])
        self.assertEqual(after['stock_moves'], before['stock_moves'])
        self.assertEqual(after['spatial_plans'], before['spatial_plans'])
        zone = next(row for row in after['zone_readiness']
                    if row['zone_id'] == summary['zone_id'] and row['phase_id'] == summary['phase_id'])
        self.assertEqual(zone['status'], 'clear')
        self.assertTrue(any(row['status'] != 'closed' for row in after['incidents']))

    def test_repeat_seed_refuses_without_changes(self):
        store = DomainStore(self.path, demo=True)
        seed_readiness(store)
        before = store.state()
        with self.assertRaises(ValueError):
            seed_readiness(store)
        after = store.state()
        for key in ('revision', 'audit', 'service_points', 'service_readings', 'service_jobs', 'service_days'):
            self.assertEqual(after[key], before[key], key)

    def test_manual_database_refused_without_changes(self):
        store = DomainStore(self.path)
        before = store.state()
        with self.assertRaises(ValueError):
            seed_readiness(store)
        after = store.state()
        self.assertEqual(after['revision'], before['revision'])
        self.assertEqual(after['audit'], before['audit'])
        self.assertEqual(after['service_points'], [])

    def test_existing_path_refused_without_reading_or_changing_contents(self):
        self.path.write_bytes(b'Existing database sentinel; must not be opened')
        with self.assertRaises(FileExistsError):
            create_readiness_demo(self.path)
        self.assertEqual(self.path.read_bytes(), b'Existing database sentinel; must not be opened')

    def test_new_database_is_private_and_contains_pending_measured_mission(self):
        summary = create_readiness_demo(self.path)
        self.assertEqual(summary['database'], str(self.path.resolve()))
        self.assertEqual(stat.S_IMODE(self.path.stat().st_mode), 0o600)
        state = DomainStore(self.path, demo=True).state()
        self.assertTrue(any(row['id'] == summary['mission_id'] and row['status'] == 'scheduled'
                            for row in state['service_jobs']))
        self.assertEqual(summary['spatial_location'], 'unverified')


if __name__ == '__main__':
    unittest.main()

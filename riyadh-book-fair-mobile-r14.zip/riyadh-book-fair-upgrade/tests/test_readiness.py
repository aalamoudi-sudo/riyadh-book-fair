import datetime as dt
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainError, DomainStore
from readiness import zone_readiness


MANAGER = {'id': 'readiness-manager', 'role': 'manager'}
FIELD = {'id': 'readiness-field', 'role': 'field'}


class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.at = dt.datetime(2026, 9, 27, 12, tzinfo=dt.timezone.utc)
        for target, clock in [('services.service_now', lambda: self.at), ('domain.now', lambda: self.at.isoformat())]:
            timer = patch(target, side_effect=clock)
            timer.start()
            self.addCleanup(timer.stop)
        self.store = DomainStore(Path(self.temp.name) / 'readiness.sqlite')
        self.project = self.cmd('shared.create', collection='projects', name='Project')
        self.phase = self.cmd('shared.create', collection='phases', name='Operation', project_id=self.project['id'])
        self.phase2 = self.cmd('shared.create', collection='phases', name='Close', project_id=self.project['id'])
        self.zone = self.cmd('shared.create', collection='zones', name='Hall', project_id=self.project['id'])
        self.owner = self.cmd('shared.create', collection='stakeholders', name='Team', project_id=self.project['id'])
        self.item = self.cmd('item.create', kind='consumable', name='Supply', project_id=self.project['id'])

    def cmd(self, command, actor=MANAGER, **payload):
        return self.store.command(command, payload, actor)['result']

    def reject(self, code, command, actor=MANAGER, **payload):
        before = self.store.export(MANAGER)
        with self.assertRaises(DomainError) as caught:
            self.cmd(command, actor=actor, **payload)
        self.assertEqual(caught.exception.code, code)
        after = self.store.export(MANAGER)
        self.assertEqual(after['records'], before['records'])
        self.assertEqual(after['audit'], before['audit'])

    def point(self, category='water', **extra):
        payload = dict(project_id=self.project['id'], zone_id=self.zone['id'], responsible_id=self.owner['id'],
                       name='Point', category=category, phase_ids=[self.phase['id']], freshness_minutes=30,
                       evidence='Point registration')
        if category in {'water', 'diesel', 'sewage'}:
            payload.update(capacity=1000, attention_percent=30 if category != 'sewage' else 70,
                           policy_reference='Team operational criterion; no safety approval')
        if category == 'inventory':
            payload.update(item_id=self.item['id'], minimum_stock=4)
        return self.cmd('service_point.create', **{**payload, **extra})

    def reading(self, point, value=200, minutes=0, **extra):
        payload = dict(point_id=point['id'], phase_id=self.phase['id'],
                       observed_at=(self.at - dt.timedelta(minutes=minutes)).isoformat(), source='field', evidence='Field reading')
        if point['category'] == 'cleaning':
            payload.update(condition='needs_service', notes='Needs cleaning')
        else:
            payload['value'] = value
        return self.cmd('service_reading.create', **{**payload, **extra})

    def job_payload(self, point, **extra):
        action = {'water': 'fill', 'diesel': 'fill', 'sewage': 'pump', 'cleaning': 'clean',
                  'inventory': 'replenish', 'visitors': 'inspect'}[point['category']]
        return dict(point_id=point['id'], phase_id=self.phase['id'], responsible_id=self.owner['id'],
                    action=action, due_at=(self.at + dt.timedelta(hours=1)).isoformat(), provider='Team',
                    evidence='Planned intervention', **extra)

    def transition(self, job, status, actor=MANAGER, **extra):
        return self.cmd('service_job.transition', id=job['id'], status=status, actor=actor,
                        evidence='Work record', **extra)

    def awaiting(self, job):
        self.at += dt.timedelta(minutes=1)
        self.transition(job, 'in_progress', actor=FIELD)
        self.at += dt.timedelta(minutes=1)
        return self.transition(job, 'awaiting_verification', actor=FIELD)

    def readiness(self, phase=None, actor=None):
        rows = zone_readiness(self.store.state(actor), at=self.at)
        return next(row for row in rows if row['phase_id'] == (phase or self.phase)['id'] and row['zone_id'] == self.zone['id'])

    def imported_future(self, reading):
        # Simulate a structurally valid external SQLite restore. The command API
        # itself refuses future observations; no import route is added here.
        with self.store.connect() as connection:
            future = {**reading, 'id': 'external-future-' + reading['id'],
                      'observed_at': (self.at + dt.timedelta(hours=1)).isoformat()}
            return self.store.put(connection, 'service_readings', future)

    def test_no_points_or_visitors_only_is_unknown_and_no_score(self):
        row = self.readiness()
        self.assertEqual(row['status'], 'unknown')
        self.assertEqual(row['counts'], {'unknown': 0, 'needs_action': 0, 'clear': 0})
        self.point('visitors')
        row = self.readiness()
        self.assertEqual(row['points'], [])
        self.assertEqual(row['generated_at'], self.at.isoformat())
        self.assertNotIn('score', row)

    def test_missing_stale_and_missing_criterion_never_clear(self):
        missing = self.point()
        stale = self.point()
        criterion = self.point(attention_percent=None, policy_reference='')
        self.reading(stale, 900, minutes=31)
        self.reading(criterion, 900)
        row = self.readiness()
        self.assertEqual(row['status'], 'unknown')
        self.assertEqual(row['counts']['unknown'], 3)
        points = {point['point_id']: point for point in row['points']}
        self.assertIn('missing_reading', points[missing['id']]['reason_codes'])
        self.assertIn('stale_reading', points[stale['id']]['reason_codes'])
        self.assertIn('missing_criterion', points[criterion['id']]['reason_codes'])

    def test_threshold_direction_and_latest_by_observation_not_append_order(self):
        for category, at_threshold, clear in [('water', 300, 301), ('diesel', 300, 301), ('sewage', 700, 699)]:
            point = self.point(category)
            self.reading(point, at_threshold, minutes=1)
            latest = self.reading(point, clear)
            self.reading(point, at_threshold, minutes=2)
            result = next(p for p in self.readiness()['points'] if p['point_id'] == point['id'])
            self.assertEqual(result['status'], 'clear')
            self.assertEqual(result['reading_id'], latest['id'])
            self.reading(point, at_threshold)  # equal observed_at: later append wins
            result = next(p for p in self.readiness()['points'] if p['point_id'] == point['id'])
            self.assertEqual(result['status'], 'needs_action')

    def test_open_jobs_preserve_unknown_count_and_completed_jobs_do_not_mask_evidence(self):
        point = self.point()
        job = self.cmd('service_job.create', **self.job_payload(point))
        row = self.readiness()
        self.assertEqual(row['status'], 'needs_action')
        self.assertEqual(row['counts'], {'unknown': 1, 'needs_action': 1, 'clear': 0})
        self.assertEqual(row['points'][0]['source_status'], 'unknown')
        self.transition(job, 'cancelled', reason='Replaced by inspection')
        self.assertEqual(self.readiness()['status'], 'unknown')

    def test_cleaning_and_phase_specific_readings_and_jobs(self):
        point = self.point('cleaning', phase_ids=[])
        self.reading(point, condition='ready')
        self.assertEqual(self.readiness()['status'], 'clear')
        self.assertEqual(self.readiness(self.phase2)['status'], 'unknown')
        self.cmd('service_job.create', **{**self.job_payload(point), 'phase_id': self.phase2['id']})
        self.assertEqual(self.readiness()['status'], 'clear')
        self.assertEqual(self.readiness(self.phase2)['status'], 'needs_action')

    def test_inventory_uses_available_ledger_and_is_not_field_verified(self):
        self.point('inventory')
        self.assertEqual(self.readiness()['status'], 'unknown')
        self.cmd('stock.move', action='receipt', item_id=self.item['id'], zone_id=self.zone['id'], qty=6, evidence='Receipt')
        point = self.readiness()['points'][0]
        self.assertEqual(point['status'], 'clear')
        self.assertEqual(point['value'], 6)
        self.assertEqual(point['source'], 'stock_ledger')
        self.assertFalse(point['field_verified'])
        self.assertIsNone(point['age_minutes'])
        self.cmd('stock.move', action='reserve', item_id=self.item['id'], zone_id=self.zone['id'], qty=3, reference='allocated')
        self.assertEqual(self.readiness()['status'], 'needs_action')

    def test_state_derivation_does_not_leak_other_projects_or_mutate_records(self):
        self.point()
        other = self.cmd('shared.create', collection='projects', name='Private')
        self.cmd('shared.create', collection='zones', name='Private zone', project_id=other['id'])
        self.cmd('shared.create', collection='phases', name='Private phase', project_id=other['id'])
        before = self.store.export(MANAGER)
        scoped = self.store.state({**MANAGER, 'project_ids': [self.project['id']]})
        self.assertTrue(scoped['zone_readiness'])
        self.assertTrue(all(row['project_id'] == self.project['id'] for row in scoped['zone_readiness']))
        self.assertEqual(self.store.state({**MANAGER, 'project_ids': []})['zone_readiness'], [])
        self.assertEqual(self.store.export(MANAGER), before)

    def test_future_readings_do_not_establish_readiness(self):
        point = self.point()
        state = self.store.state()
        state['service_readings'].append(dict(id='invalid-future', project_id=self.project['id'],
            point_id=point['id'], phase_id=self.phase['id'], observed_at=(self.at + dt.timedelta(seconds=1)).isoformat(), value=900))
        row = next(row for row in zone_readiness(state, self.at) if row['phase_id'] == self.phase['id'])
        self.assertEqual(row['status'], 'unknown')

    def test_newest_future_reading_blocks_past_clear_and_preserves_unknown_with_open_job(self):
        point = self.point()
        past = self.reading(point, 900)
        self.assertEqual(self.readiness()['status'], 'clear')
        future = self.imported_future(past)
        row = self.readiness()
        self.assertEqual(row['status'], 'unknown')
        self.assertEqual(row['points'][0]['reading_id'], future['id'])
        self.assertIn('future_reading', row['points'][0]['reason_codes'])
        self.assertIsNone(row['points'][0]['age_minutes'])
        self.cmd('service_job.create', **self.job_payload(point))
        row = self.readiness()
        self.assertEqual(row['status'], 'needs_action')
        self.assertEqual(row['points'][0]['source_status'], 'unknown')
        self.assertEqual(row['counts'], {'unknown': 1, 'needs_action': 1, 'clear': 0})

    def test_future_latest_reading_blocks_measured_baseline_creation_atomically(self):
        point = self.point()
        baseline = self.reading(point)
        self.imported_future(baseline)
        self.reject('future_mission_reading', 'service_job.create',
                    **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))

    def test_future_latest_reading_blocks_measured_approval_atomically(self):
        point = self.point()
        baseline = self.reading(point)
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        followup = self.reading(point, 800)
        self.imported_future(followup)
        self.reject('future_mission_reading', 'service_job.transition', id=job['id'], status='completed',
                    evidence='Verification', reading_id=followup['id'])

    def test_measured_fill_freezes_baseline_and_outcome_without_stock_mutation(self):
        point = self.point()
        baseline = self.reading(point, 200)
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))
        self.assertEqual(job['baseline_snapshot'], {'reading_id': baseline['id'], 'observed_at': baseline['observed_at'],
                          'value': 200, 'source': 'field', 'provenance': 'manual'})
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        after = self.reading(point, 720)
        completed = self.transition(job, 'completed', reading_id=after['id'])
        self.assertEqual(completed['outcome'], dict(before=200, after=720, delta=520, target=700, unit='liters',
            verified_at=self.at.isoformat(), verified_by=MANAGER['id'], reading_id=after['id'],
            observed_at=after['observed_at'], target_met=True))
        self.assertEqual(completed['baseline_snapshot'], job['baseline_snapshot'])
        self.reading(point, 400)
        stored = next(row for row in self.store.state()['service_jobs'] if row['id'] == job['id'])
        self.assertEqual(stored['outcome'], completed['outcome'])
        self.assertEqual(self.store.state()['stock_moves'], [])
        self.assertEqual(self.store.state()['stock'], [])

    def test_sewage_pump_requires_lower_target_and_reports_signed_delta(self):
        point = self.point('sewage')
        baseline = self.reading(point, 800)
        for target in (800, 900):
            self.reject('invalid_mission_target', 'service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=target))
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=200))
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        reading = self.reading(point, 250)
        self.reject('mission_target_not_met', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=reading['id'])
        reading = self.reading(point, 150)
        done = self.transition(job, 'completed', reading_id=reading['id'])
        self.assertEqual(done['outcome']['delta'], -650)
        self.assertEqual(done['outcome']['target'], 200)

    def test_cleaning_mission_requires_changed_condition_and_documents_non_numeric_outcome(self):
        point = self.point('cleaning')
        baseline = self.reading(point)
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_condition='ready'))
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        bad = self.reading(point)
        self.reject('service_not_ready', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=bad['id'])
        reading = self.reading(point, condition='ready')
        done = self.transition(job, 'completed', reading_id=reading['id'])
        self.assertEqual((done['outcome']['before'], done['outcome']['after'], done['outcome']['delta']), ('needs_service', 'ready', None))
        self.assertEqual(done['outcome']['unit'], 'condition')
        self.reject('invalid_mission_target', 'service_job.create', **self.job_payload(point, baseline_reading_id=reading['id'], target_condition='ready'))

    def test_measured_payload_is_all_or_none_and_targets_are_bounded_and_finite(self):
        point = self.point()
        baseline = self.reading(point, 200)
        self.reject('validation', 'service_job.create', **self.job_payload(point, target_value=700))
        self.reject('invalid_service_number', 'service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id']))
        for target in (True, float('nan'), float('inf'), -1):
            self.reject('invalid_service_number', 'service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=target))
        for target in (0, 200, 1001):
            self.reject('invalid_mission_target', 'service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=target))
        self.reject('invalid_mission_target', 'service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700, target_condition='ready'))
        self.reject('invalid_measured_action', 'service_job.create', **{**self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700), 'action': 'inspect'})

    def test_measured_creation_requires_evidence_atomically_but_ordinary_does_not(self):
        point = self.point()
        baseline = self.reading(point)
        payload = self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700)
        payload.pop('evidence')
        self.reject('validation', 'service_job.create', **payload)
        for empty in ('', '   '):
            self.reject('validation', 'service_job.create', **{**payload, 'evidence': empty})
        ordinary = self.job_payload(point)
        ordinary.pop('evidence')
        self.assertEqual(self.cmd('service_job.create', **ordinary)['evidence'], '')

    def test_baseline_must_be_latest_fresh_same_point_and_phase(self):
        point = self.point(phase_ids=[])
        old = self.reading(point, minutes=1)
        latest = self.reading(point, 210)
        self.reject('superseded_mission_reading', 'service_job.create', **self.job_payload(point, baseline_reading_id=old['id'], target_value=700))
        self.reject('service_context_mismatch', 'service_job.create', **{**self.job_payload(point, baseline_reading_id=latest['id'], target_value=700), 'phase_id': self.phase2['id']})
        other_point = self.point()
        self.reject('service_context_mismatch', 'service_job.create', **self.job_payload(other_point, baseline_reading_id=latest['id'], target_value=700))
        self.at += dt.timedelta(minutes=31)
        self.reject('stale_mission_reading', 'service_job.create', **self.job_payload(point, baseline_reading_id=latest['id'], target_value=700))

    def test_latest_followup_after_request_and_fresh_at_approval_is_required(self):
        point = self.point()
        baseline = self.reading(point)
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))
        self.awaiting(job)
        equal = self.reading(point, 800)
        self.reject('stale_service_verification', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=equal['id'])
        self.at += dt.timedelta(microseconds=1)
        good = self.reading(point, 800)
        latest = self.reading(point, 500)
        self.reject('superseded_mission_reading', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=good['id'])
        self.reject('mission_target_not_met', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=latest['id'])
        good = self.reading(point, 800)
        self.at += dt.timedelta(minutes=31)
        self.reject('stale_mission_reading', 'service_job.transition', id=job['id'], status='completed', evidence='Verification', reading_id=good['id'])

    def test_measured_completion_requires_manager_and_immutable_baseline_goal(self):
        point = self.point()
        baseline = self.reading(point)
        job = self.cmd('service_job.create', **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))
        for change in ({'target_value': 300}, {'baseline_reading_id': baseline['id']}, {'outcome': {'target_met': True}}):
            self.reject('immutable_mission_fields', 'service_job.transition', id=job['id'], status='in_progress', evidence='Work', **change)
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        reading = self.reading(point, 800)
        self.reject('forbidden', 'service_job.transition', actor=FIELD, id=job['id'], status='completed', evidence='Verification', reading_id=reading['id'])
        done = self.transition(job, 'completed', reading_id=reading['id'])
        self.reject('invalid_transition', 'service_job.transition', id=done['id'], status='completed', evidence='Again', reading_id=reading['id'])

    def test_baseline_project_reference_is_scoped_before_mutation(self):
        point = self.point()
        baseline = self.reading(point)
        other = self.cmd('shared.create', collection='projects', name='Other')
        scoped = {**MANAGER, 'project_ids': [other['id']]}
        self.reject('project_scope_required', 'service_job.create', actor=scoped,
                    **self.job_payload(point, baseline_reading_id=baseline['id'], target_value=700))
        self.reject('project_scope_required', 'service_job.create', actor=scoped,
                    baseline_reading_id=baseline['id'])

    def test_ordinary_job_keeps_existing_behavior_without_measured_fields(self):
        point = self.point()
        job = self.cmd('service_job.create', **self.job_payload(point))
        self.assertNotIn('baseline_snapshot', job)
        self.awaiting(job)
        self.at += dt.timedelta(minutes=1)
        reading = self.reading(point, 100)
        self.at += dt.timedelta(minutes=31)
        done = self.transition(job, 'completed', reading_id=reading['id'])
        self.assertNotIn('outcome', done)
        self.assertEqual(done['status'], 'completed')


if __name__ == '__main__':
    unittest.main()

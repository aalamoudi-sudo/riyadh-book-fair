from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
from scripts.prepare_services_demo import seed_services


class ServicesDemoTests(unittest.TestCase):
    def test_scenario_persists_without_mutating_stock_or_claiming_live_sources(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'demo.sqlite'
            store = DomainStore(path, demo=True)
            stock_before = store.state()['stock']
            result = seed_services(store)
            state = DomainStore(path, demo=True).state()
            self.assertEqual(result['point_count'], 9)
            self.assertEqual(state['stock'], stock_before)
            self.assertEqual(len(state['service_days']), 2)
            self.assertEqual(len(state['service_jobs']), 4)
            self.assertEqual(sum(j['status'] == 'awaiting_verification' for j in state['service_jobs']), 1)
            self.assertTrue(all(r['source'] == 'manual' for r in state['service_readings']))
            for collection in ('service_points', 'service_days', 'service_jobs', 'service_readings'):
                self.assertTrue(all(r['provenance'] == 'demo' for r in state[collection]))
            self.assertTrue(any(p['category'] == 'water' and not any(
                r['point_id'] == p['id'] for r in state['service_readings']) for p in state['service_points']))
            with self.assertRaises(ValueError):
                seed_services(store)

    def test_yesterday_contains_partial_coverage_without_future_readings(self):
        with tempfile.TemporaryDirectory() as folder:
            store = DomainStore(Path(folder) / 'demo.sqlite', demo=True)
            seed_services(store)
            state = store.state()
            now = datetime.now(timezone.utc)
            yesterday = (now.astimezone(timezone(timedelta(hours=3))).date() - timedelta(days=1)).isoformat()
            visitor_ids = {p['id'] for p in state['service_points'] if p['category'] == 'visitors'}
            readings = [r for r in state['service_readings'] if r['point_id'] in visitor_ids]
            self.assertTrue(all(datetime.fromisoformat(r['observed_at']) <= now for r in state['service_readings']))
            local_start = lambda r: datetime.fromisoformat(r['period_start']).astimezone(timezone(timedelta(hours=3)))
            hour_14 = [r for r in readings if local_start(r).date().isoformat() == yesterday and local_start(r).hour == 14]
            hour_12 = [r for r in readings if local_start(r).date().isoformat() == yesterday and local_start(r).hour == 12]
            self.assertEqual(len(hour_14), 1)
            self.assertEqual(len(hour_12), 2)

    def test_synthetic_seed_rejects_manual_database(self):
        with tempfile.TemporaryDirectory() as folder:
            store = DomainStore(Path(folder) / 'manual.sqlite')
            with self.assertRaises(ValueError):
                seed_services(store)
            self.assertEqual(store.state()['service_points'], [])


if __name__ == '__main__':
    unittest.main()

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {reviewedPlanForZone,renderSpatialReadiness} from '../app/spatial-readiness.js';
const plan=(id,extra={})=>({id,project_id:'project',status:'reviewed',provenance:'manual',review_revision:1,reviewed_at:'2026-09-27T00:00:00Z',plan:{provenance:{data_class:'manual'},elements:[{zone_id:'zone'}]},...extra});
test('spatial readiness rejects demo, drafts, expected geometry and other project',()=>{
  const plans=[plan('demo',{provenance:'demo'}),plan('draft',{status:'draft'}),plan('other',{project_id:'other'}),plan('expected',{plan:{provenance:{data_class:'expected'},elements:[{zone_id:'zone'}]}}),plan('demo-geometry',{plan:{provenance:{data_class:'demo'},elements:[{zone_id:'zone'}]}})];
  assert.equal(reviewedPlanForZone(plans,'project','zone'),null);
  assert.equal(reviewedPlanForZone([plan('reviewed')],'project','missing'),null);
});
test('current geometry is selected per zone by revision without mutating source order',()=>{
  const older=plan('old'),newer=plan('new',{review_revision:3}),unrelated=plan('unrelated',{review_revision:8,plan:{provenance:{data_class:'manual'},elements:[{zone_id:'other-zone'}]}});
  const input=[older,newer,unrelated];
  assert.equal(reviewedPlanForZone(input,'project','zone').id,'new');
  assert.deepEqual(input.map(p=>p.id),['old','new','unrelated']);
});
test('unlocated zone remains an honest record link, not a geometry link or clear status',()=>{
  const records={zones:[{id:'zone',name:'منطقة <اختبار>'}],phases:[{id:'phase',kind:'operations',name:'التشغيل'}],spatial_plans:[],zone_readiness:[]};
  const html=renderSpatialReadiness({projectId:'project',records:key=>records[key]||[]});
  assert.match(html,/data-action="readiness-open"/);
  assert.doesNotMatch(html,/data-action="spatial-service-locate"/);
  assert.match(html,/غير متحققة/);
  assert.match(html,/&lt;اختبار&gt;/);
  assert.match(html,/ليست خريطة مواقع/);
});

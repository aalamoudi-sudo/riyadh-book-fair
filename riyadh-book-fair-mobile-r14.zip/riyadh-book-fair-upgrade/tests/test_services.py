import datetime as dt
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainError, DomainStore
from services import DAY_STAGES


MANAGER = {'id': 'service-manager', 'role': 'manager'}
FIELD = {'id': 'service-field', 'role': 'field'}
SECURITY = {'id': 'service-security', 'role': 'security'}
WAREHOUSE = {'id': 'service-warehouse', 'role': 'warehouse'}
NOW = '2026-09-26T12:00:00+00:00'
STARTED = '2026-09-26T10:00:00+00:00'
REQUESTED = '2026-09-26T10:30:00+00:00'
FOLLOWUP = '2026-09-26T11:00:00+00:00'


class ServicesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.clock = patch('domain.now', return_value=NOW)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.service_clock = patch('services.service_now', return_value=dt.datetime.fromisoformat(NOW))
        self.service_clock.start()
        self.addCleanup(self.service_clock.stop)
        self.addCleanup(self.temp.cleanup)
        self.store = DomainStore(Path(self.temp.name) / 'services.sqlite')
        self.project = self.cmd('shared.create', collection='projects', name='Service project')
        self.phase = self.cmd('shared.create', collection='phases', name='Operations', kind='operations', project_id=self.project['id'])
        self.phase2 = self.cmd('shared.create', collection='phases', name='Build', kind='build', project_id=self.project['id'])
        self.zone = self.cmd('shared.create', collection='zones', name='Service zone', project_id=self.project['id'])
        self.owner = self.cmd('shared.create', collection='stakeholders', name='Service owner', project_id=self.project['id'])
        self.item = self.cmd('item.create', name='Operational consumable', kind='consumable', project_id=self.project['id'])

    def cmd(self, command, actor=MANAGER, **payload):
        return self.store.command(command, payload, actor)['result']

    def reject(self, code, command, actor=MANAGER, **payload):
        before = self.store.state()
        with self.assertRaises(DomainError) as error:
            self.cmd(command, actor=actor, **payload)
        if code:
            self.assertEqual(error.exception.code, code)
        after = self.store.state()
        self.assertEqual(after['revision'], before['revision'])
        self.assertEqual(after['audit'], before['audit'])
        for collection in ('service_points', 'service_readings', 'service_jobs', 'service_days', 'stock', 'stock_moves'):
            self.assertEqual(after[collection], before[collection], collection)

    def point_payload(self, category='water', **extra):
        payload = dict(project_id=self.project['id'], zone_id=self.zone['id'], responsible_id=self.owner['id'],
                       name='Manual ' + category, category=category, phase_ids=[self.phase['id']],
                       freshness_minutes=60, evidence='Service point field record')
        if category in {'water', 'diesel', 'sewage'}:
            payload['capacity'] = 1000
        if category == 'inventory':
            payload.update(item_id=self.item['id'], minimum_stock=4)
        payload.update(extra)
        return payload

    def point(self, category='water', **extra):
        return self.cmd('service_point.create', **self.point_payload(category, **extra))

    def reading_payload(self, point, **extra):
        payload = dict(point_id=point['id'], phase_id=self.phase['id'], observed_at=FOLLOWUP,
                       source='manual', evidence='Manual reading record')
        if point['category'] == 'cleaning':
            payload['condition'] = 'ready'
        elif point['category'] == 'visitors':
            payload.update(value=12, period_start='2026-09-26T09:00:00+03:00',
                           period_end='2026-09-26T10:00:00+03:00')
        else:
            payload['value'] = 40
        payload.update(extra)
        return payload

    def reading(self, point, **extra):
        return self.cmd('service_reading.create', **self.reading_payload(point, **extra))

    def job_payload(self, point, **extra):
        action = {'water': 'fill', 'diesel': 'fill', 'sewage': 'pump', 'cleaning': 'clean',
                  'inventory': 'replenish', 'visitors': 'inspect'}[point['category']]
        payload = dict(point_id=point['id'], phase_id=self.phase['id'], responsible_id=self.owner['id'],
                       action=action, due_at='2026-09-26T13:00:00+03:00', provider='Onsite service team',
                       evidence='Schedule record')
        payload.update(extra)
        return payload

    def job(self, point, **extra):
        return self.cmd('service_job.create', **self.job_payload(point, **extra))

    def transition(self, job, status, actor=MANAGER, **extra):
        if status == 'awaiting_verification':
            with patch('services.service_now', return_value=dt.datetime.fromisoformat(REQUESTED)):
                return self.cmd('service_job.transition', actor=actor, id=job['id'], status=status,
                                evidence='Work and verification record', **extra)
        return self.cmd('service_job.transition', actor=actor, id=job['id'], status=status,
                        evidence='Work and verification record', **extra)

    def start_job(self, job):
        with patch('services.service_now', return_value=dt.datetime.fromisoformat(STARTED)):
            return self.transition(job, 'in_progress', actor=FIELD)

    def day_payload(self, **extra):
        payload = dict(project_id=self.project['id'], phase_id=self.phase['id'], responsible_id=self.owner['id'],
                       operational_date='2026-09-26', evidence='Day briefing record')
        payload.update(extra)
        return payload

    def day(self, **extra):
        return self.cmd('service_day.open', **self.day_payload(**extra))

    def advance(self, day, stage, actor=MANAGER, **extra):
        return self.cmd('service_day.advance', actor=actor, id=day['id'], stage=stage,
                        evidence='Stage evidence: ' + stage, **extra)

    def handover(self, day):
        for stage in DAY_STAGES[1:-1]:
            day = self.advance(day, stage, actor=FIELD)
        return day

    def other_project(self):
        project = self.cmd('shared.create', collection='projects', name='Other project')
        pid = project['id']
        return dict(project=project,
                    phase=self.cmd('shared.create', collection='phases', name='Other phase', project_id=pid),
                    zone=self.cmd('shared.create', collection='zones', name='Other zone', project_id=pid),
                    owner=self.cmd('shared.create', collection='stakeholders', name='Other owner', project_id=pid),
                    item=self.cmd('item.create', name='Other stock', kind='consumable', project_id=pid))

    def test_points_validate_category_specific_values_and_provenance(self):
        point = self.point(attention_percent=25, policy_reference='Internal operational policy, not safety capacity')
        self.assertEqual(point['provenance'], 'manual')
        self.assertEqual(point['created_by'], MANAGER['id'])
        self.assertEqual(point['attention_percent'], 25)
        self.assertEqual(point['phase_ids'], [self.phase['id']])
        self.assertIsNone(self.point('sewage')['attention_percent'])
        for value in (0, -1, True, float('nan'), float('inf'), '1000'):
            self.reject('invalid_service_number', 'service_point.create', **self.point_payload(capacity=value))
        for value in (-1, 101, True, float('nan'), float('inf')):
            self.reject('invalid_service_number', 'service_point.create',
                        **self.point_payload(attention_percent=value, policy_reference='Internal'))
        self.reject(None, 'service_point.create', **self.point_payload(attention_percent=10))
        self.reject(None, 'service_point.create', **self.point_payload(evidence=''))
        for value in (0, -1, False, float('inf')):
            self.reject('invalid_service_number', 'service_point.create', **self.point_payload(freshness_minutes=value))
        self.reject(None, 'service_point.create', **self.point_payload('cleaning', capacity=5))
        self.reject(None, 'service_point.create', **self.point_payload('water', minimum_stock=0))
        for value in (-1, 0.5, False, float('nan')):
            self.reject('invalid_service_number', 'service_point.create', **self.point_payload('inventory', minimum_stock=value))

    def test_point_phase_scope_and_all_project_references(self):
        other = self.other_project()
        for change in ({'zone_id': other['zone']['id']}, {'responsible_id': other['owner']['id']},
                       {'phase_ids': [other['phase']['id']]}):
            self.reject('project_mismatch', 'service_point.create', **self.point_payload(**change))
        self.reject('project_mismatch', 'service_point.create', **self.point_payload('inventory', item_id=other['item']['id']))
        self.reject(None, 'service_point.create', **self.point_payload(phase_ids=[self.phase['id'], self.phase['id']]))
        self.reject(None, 'service_point.create', **self.point_payload(phase_ids='not a list'))
        point = self.point()
        self.reject('service_phase_mismatch', 'service_reading.create', **self.reading_payload(point, phase_id=self.phase2['id']))
        self.reject('project_mismatch', 'service_reading.create', **self.reading_payload(point, phase_id=other['phase']['id']))
        universal = self.point(phase_ids=[])
        self.assertEqual(self.reading(universal, phase_id=self.phase2['id'])['phase_id'], self.phase2['id'])

    def test_readings_are_bounded_finite_evidenced_and_not_future(self):
        point = self.point()
        for value in (-1, 1001, True, float('inf'), float('-inf'), float('nan'), '10'):
            self.reject('invalid_service_number', 'service_reading.create', **self.reading_payload(point, value=value))
        self.assertEqual(self.reading(point, value=0)['value'], 0)
        record = self.reading(point, value=1000, observed_at='2020-01-01T00:00:00Z')
        self.assertEqual(record['zone_id'], point['zone_id'])
        self.assertEqual(record['responsible_id'], point['responsible_id'])
        self.reject('future_service_reading', 'service_reading.create',
                    **self.reading_payload(point, observed_at='2026-09-26T12:00:01Z'))
        for observed in ('2026-09-26T11:00:00', 'not a date'):
            self.reject(None, 'service_reading.create', **self.reading_payload(point, observed_at=observed))
        self.reject(None, 'service_reading.create', **self.reading_payload(point, evidence=''))
        self.reject(None, 'service_reading.create', **self.reading_payload(point, source='sensor'))
        owner2 = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Different owner')
        self.reject('service_context_mismatch', 'service_reading.create',
                    **self.reading_payload(point, responsible_id=owner2['id']))

    def test_current_microsecond_reading_is_accepted_without_truncating_clock(self):
        point = self.point()
        actual_clock = lambda: dt.datetime.now(dt.timezone.utc)
        with patch('services.service_now', side_effect=actual_clock):
            observed = actual_clock()
            record = self.reading(point, observed_at=observed.isoformat())
        self.assertEqual(record['observed_at'], observed.isoformat())

    def test_cleaning_needs_notes_and_inventory_has_no_parallel_readings(self):
        cleaning = self.point('cleaning')
        self.reject(None, 'service_reading.create', **self.reading_payload(cleaning, condition='needs_service'))
        reading = self.reading(cleaning, condition='needs_service', notes='Washroom needs attention')
        self.assertEqual(reading['condition'], 'needs_service')
        self.reject(None, 'service_reading.create', **self.reading_payload(cleaning, value=10))
        inventory = self.point('inventory')
        self.reject('inventory_ledger_only', 'service_reading.create', **self.reading_payload(inventory, value=100))
        self.assertEqual(self.store.state()['stock'], [])

    def test_visitors_completed_hour_and_normalized_duplicate_even_across_phases(self):
        point = self.point('visitors', phase_ids=[])
        reading = self.reading(point, period_start='2026-09-25T21:00:00Z', period_end='2026-09-25T22:00:00Z', value=0)
        self.assertEqual(reading['operational_date'], '2026-09-26')
        self.assertEqual(reading['value'], 0)
        self.reject('duplicate_service_reading', 'service_reading.create',
                    **self.reading_payload(point, phase_id=self.phase2['id'], period_start='2026-09-26T00:00:00+03:00',
                                           period_end='2026-09-26T01:00:00+03:00'))
        for extra in ({'period_start': '2026-09-26T09:01:00+03:00'},
                      {'period_start': '2026-09-26T09:00:00.000001+03:00'},
                      {'period_end': '2026-09-26T11:00:00+03:00'},
                      {'observed_at': '2026-09-26T09:30:00+03:00'}):
            self.reject('invalid_visitor_period', 'service_reading.create', **self.reading_payload(point, **extra))
        for value in (-1, 2.5, True, float('inf'), float('nan')):
            self.reject('invalid_service_number', 'service_reading.create', **self.reading_payload(point, value=value))
        # Missing hours remain missing records. Summing valid movements is a UI task,
        # and state does not claim unique visitors, live occupancy or derived totals.
        self.reading(point, value=7)
        readings = self.store.state()['service_readings']
        self.assertEqual(len(readings), 2)
        self.assertEqual(sum(row['value'] for row in readings), 7)
        self.assertNotIn('visitor_totals', self.store.state())
        self.assertNotIn('occupancy', reading)

    def test_duplicate_visitors_and_days_are_atomic_under_concurrency(self):
        point = self.point('visitors')
        for command, payload, duplicate in [('service_reading.create', self.reading_payload(point), 'duplicate_service_reading'),
                                             ('service_day.open', self.day_payload(), 'service_day_exists')]:
            barrier = threading.Barrier(2)
            results = []
            def run():
                barrier.wait()
                try:
                    self.cmd(command, **payload)
                    results.append('created')
                except DomainError as error:
                    results.append(error.code)
            threads = [threading.Thread(target=run) for _ in range(2)]
            for thread in threads: thread.start()
            for thread in threads: thread.join()
            self.assertCountEqual(results, ['created', duplicate])

    def test_actions_keep_sewage_pumping_separate_from_water_and_diesel_filling(self):
        for category in ('water', 'diesel', 'sewage', 'cleaning', 'inventory', 'visitors'):
            point = self.point(category)
            expected = self.job(point)
            self.assertEqual(expected['status'], 'scheduled')
            self.job(point, action='inspect')
            wrong = 'fill' if category != 'water' and category != 'diesel' else 'pump'
            self.reject('invalid_service_action', 'service_job.create', **self.job_payload(point, action=wrong))
        point = self.point()
        for amount in (0, -1, True, float('nan'), float('inf')):
            self.reject('invalid_service_number', 'service_job.create', **self.job_payload(point, quantity=amount))
        self.assertEqual(self.job(point, quantity=12.5)['quantity'], 12.5)

    def test_job_context_checks_day_phase_and_project_before_creation(self):
        point = self.point(phase_ids=[])
        day = self.day(phase_id=self.phase2['id'])
        self.reject('service_phase_mismatch', 'service_job.create', **self.job_payload(point, day_id=day['id']))
        other = self.other_project()
        foreign_day = self.day(project_id=other['project']['id'], phase_id=other['phase']['id'], responsible_id=other['owner']['id'])
        for extra in ({'day_id': foreign_day['id']}, {'phase_id': other['phase']['id']},
                      {'responsible_id': other['owner']['id']}):
            self.reject('project_mismatch', 'service_job.create', **self.job_payload(point, **extra))
        completed = self.advance(self.handover(day), 'completed')
        self.reject('service_day_completed', 'service_job.create',
                    **self.job_payload(point, phase_id=self.phase2['id'], day_id=completed['id']))

    def test_verification_requires_manager_matching_reading_after_start_and_no_repeat(self):
        point = self.point()
        job = self.job(point)
        self.reject('invalid_transition', 'service_job.transition', id=job['id'], status='completed', evidence='Skip')
        self.start_job(job)
        self.transition(job, 'awaiting_verification', actor=FIELD)
        self.reject('forbidden', 'service_job.transition', actor=FIELD, id=job['id'], status='completed', evidence='Unauthorized')
        self.reject(None, 'service_job.transition', id=job['id'], status='completed', evidence='Missing reading')
        old = self.reading(point, observed_at='2026-09-26T09:59:59Z')
        self.reject('stale_service_verification', 'service_job.transition', id=job['id'], status='completed', reading_id=old['id'], evidence='Old record')
        for observed in ('2026-09-26T10:15:00Z', REQUESTED):
            old = self.reading(point, observed_at=observed)
            self.reject('stale_service_verification', 'service_job.transition', id=job['id'], status='completed', reading_id=old['id'], evidence='Before or at request')
        another = self.point()
        wrong = self.reading(another)
        self.reject('service_context_mismatch', 'service_job.transition', id=job['id'], status='completed', reading_id=wrong['id'], evidence='Wrong point')
        fresh = self.reading(point, value=200)
        closed = self.transition(job, 'completed', reading_id=fresh['id'])
        self.assertEqual(closed['completed_at'], NOW)
        self.assertEqual(closed['completed_by'], MANAGER['id'])
        self.assertEqual(closed['verification_requested_at'], REQUESTED)
        self.assertEqual(closed['verification_reading_id'], fresh['id'])
        self.assertEqual(len(closed['history']), 3)
        self.reject('invalid_transition', 'service_job.transition', id=job['id'], status='completed', reading_id=fresh['id'], evidence='Duplicate')
        self.assertEqual(self.store.state()['service_readings'][-1]['value'], 200)

    def test_cleaning_requires_ready_followup_even_if_inspection_found_an_issue(self):
        point = self.point('cleaning')
        job = self.job(point, action='inspect')
        self.start_job(job)
        self.transition(job, 'awaiting_verification')
        self.reject(None, 'service_job.transition', id=job['id'], status='completed', evidence='No followup')
        followup = self.reading(point, condition='needs_service', notes='Inspection found additional cleaning work')
        self.reject('service_not_ready', 'service_job.transition', id=job['id'], status='completed',
                    reading_id=followup['id'], evidence='Unready inspection')
        ready = self.reading(point, condition='ready')
        closed = self.transition(job, 'completed', reading_id=ready['id'])
        self.assertEqual(closed['status'], 'completed')
        self.assertEqual(self.store.state()['service_readings'][0]['condition'], 'needs_service')

    def test_day_carryover_includes_unlinked_due_work_using_riyadh_date(self):
        point = self.point(phase_ids=[])
        day = self.day()
        overdue = self.job(point, due_at='2026-09-25T23:59:59+03:00')
        due_today = self.job(point, due_at='2026-09-26T23:59:59+03:00')
        explicit_future = self.job(point, day_id=day['id'], due_at='2026-09-30T00:00:00+03:00')
        # This instant is already tomorrow in Riyadh, despite its UTC date.
        future = self.job(point, due_at='2026-09-26T21:00:00Z')
        different_phase = self.job(point, phase_id=self.phase2['id'], due_at='2026-09-24T08:00:00Z')
        cancelled = self.job(point, due_at='2026-09-24T08:00:00Z')
        self.transition(cancelled, 'cancelled', reason='No longer required')
        self.handover(day)
        self.reject('handover_required', 'service_day.advance', id=day['id'], stage='completed', evidence='Missing carryover')
        closed = self.advance(day, 'completed', handover_responsible_id=self.owner['id'],
                              handover_due_at='2026-09-27T09:00:00+03:00', handover_notes='Follow all due work')
        self.assertCountEqual(closed['pending_job_ids'], [overdue['id'], due_today['id'], explicit_future['id']])
        self.assertNotIn(future['id'], closed['pending_job_ids'])
        self.assertNotIn(different_phase['id'], closed['pending_job_ids'])
        self.assertEqual({row['status'] for row in self.store.state()['service_jobs']}, {'scheduled', 'cancelled'})

    def test_cancel_has_reason_and_is_terminal_and_stock_never_moves_implicitly(self):
        point = self.point('inventory')
        job = self.job(point, quantity=12)
        self.reject(None, 'service_job.transition', id=job['id'], status='cancelled', evidence='No reason')
        self.transition(job, 'cancelled', reason='Warehouse request replaced')
        self.reject('invalid_transition', 'service_job.transition', id=job['id'], status='in_progress', evidence='Restart')
        job = self.job(point, quantity=50)
        self.start_job(job)
        self.transition(job, 'awaiting_verification')
        self.transition(job, 'completed')
        state = self.store.state()
        self.assertEqual(state['stock'], [])
        self.assertEqual(state['stock_moves'], [])
        self.assertEqual(state['service_readings'], [])
        self.assertEqual(state['items'][0]['id'], self.item['id'])

    def test_day_requires_real_date_evidence_sequence_and_manager_completion(self):
        for date in ('2026-02-30', '20260926', '26/09/2026'):
            self.reject('invalid_operational_date', 'service_day.open', **self.day_payload(operational_date=date))
        self.reject(None, 'service_day.open', **self.day_payload(evidence=''))
        day = self.cmd('service_day.open', actor=FIELD, **self.day_payload())
        self.assertEqual(day['stage'], 'briefing')
        self.reject('invalid_transition', 'service_day.advance', id=day['id'], stage='active', evidence='Skip readiness')
        self.reject(None, 'service_day.advance', id=day['id'], stage='readiness', evidence='')
        day = self.handover(day)
        self.reject('forbidden', 'service_day.advance', actor=FIELD, id=day['id'], stage='completed', evidence='No authority')
        day = self.advance(day, 'completed')
        self.assertEqual([entry['to'] for entry in day['history']], list(DAY_STAGES))
        self.reject('invalid_transition', 'service_day.advance', id=day['id'], stage='completed', evidence='Again')
        self.reject('service_day_exists', 'service_day.open', **self.day_payload())
        self.day(phase_id=self.phase2['id'])
        self.day(operational_date='2026-09-27')

    def test_day_carries_open_jobs_without_closing_legacy_day_or_phase(self):
        daily = self.cmd('daily.open', project_id=self.project['id'], zone_id=self.zone['id'], phase_id=self.phase['id'],
                         responsible_id=self.owner['id'], operational_date='2026-09-26', evidence='Legacy report',
                         readiness=[{'id': 'basic', 'label': 'Basic check', 'status': 'ready'}])
        point = self.point()
        day = self.day()
        job = self.job(point, day_id=day['id'])
        day = self.handover(day)
        self.reject('handover_required', 'service_day.advance', id=day['id'], stage='completed', evidence='No handover')
        other = self.other_project()
        handover = dict(handover_responsible_id=self.owner['id'], handover_due_at='2026-09-27T08:00:00+03:00',
                        handover_notes='Follow the still scheduled service job')
        self.reject('project_mismatch', 'service_day.advance', id=day['id'], stage='completed', evidence='Wrong owner',
                    **{**handover, 'handover_responsible_id': other['owner']['id']})
        self.reject(None, 'service_day.advance', id=day['id'], stage='completed', evidence='Naive due time',
                    **{**handover, 'handover_due_at': '2026-09-27T08:00:00'})
        before = self.store.state()
        closed = self.advance(day, 'completed', **handover)
        after = self.store.state()
        self.assertEqual(closed['pending_job_ids'], [job['id']])
        self.assertEqual(after['service_jobs'][0]['status'], 'scheduled')
        self.assertEqual(after['daily_reports'], before['daily_reports'])
        self.assertEqual(after['phases'], before['phases'])
        self.assertEqual(after['phase_handoffs'], before['phase_handoffs'])
        self.assertEqual(after['projects'][0]['status'], 'active')
        self.transition(job, 'cancelled', reason='Next shift chose a replacement')
        self.assertEqual(self.store.state()['service_days'][0]['pending_job_ids'], [job['id']])

    def test_closeout_blockers_are_live_and_closed_project_rejects_all_service_commands(self):
        point = self.point('visitors')
        day = self.day()
        job = self.job(point, day_id=day['id'])
        codes = {b['code'] for b in self.store.state()['closeout'][0]['blockers']}
        self.assertIn('open_service_jobs', codes)
        self.assertIn('incomplete_service_days', codes)
        self.reject('closeout_blocked', 'project.close', id=self.project['id'], evidence='Not ready', summary='Pending services')
        self.transition(job, 'cancelled', reason='Service cancelled')
        self.advance(self.handover(day), 'completed')
        self.assertTrue(self.store.state()['closeout'][0]['ready'])
        self.cmd('project.close', id=self.project['id'], evidence='Final record', summary='Services completed')
        commands = [('service_point.create', self.point_payload()),
                    ('service_reading.create', self.reading_payload(point)),
                    ('service_job.create', self.job_payload(point)),
                    ('service_job.transition', dict(id=job['id'], status='in_progress', evidence='Attempt')),
                    ('service_day.open', self.day_payload(operational_date='2026-09-27')),
                    ('service_day.advance', dict(id=day['id'], stage='completed', evidence='Attempt'))]
        for command, payload in commands:
            self.reject('project_closed', command, **payload)

    def test_roles_scope_state_and_revision_audit_use_existing_command_contract(self):
        point = self.point()
        job = self.job(point)
        day = self.day()
        other = self.other_project()
        restricted = {**MANAGER, 'project_ids': [other['project']['id']]}
        commands = [('service_point.create', self.point_payload()),
                    ('service_reading.create', self.reading_payload(point)),
                    ('service_job.create', self.job_payload(point)),
                    ('service_job.transition', dict(id=job['id'], status='in_progress', evidence='Work')),
                    ('service_day.open', self.day_payload(operational_date='2026-09-27')),
                    ('service_day.advance', dict(id=day['id'], stage='readiness', evidence='Ready'))]
        for command, payload in commands:
            self.reject('forbidden', command, actor={'id': 'viewer', 'role': 'viewer'}, **payload)
            self.reject('project_scope_required', command, actor=restricted, **payload)
        for collection in ('service_points', 'service_readings', 'service_jobs', 'service_days'):
            self.assertEqual(self.store.state(restricted)[collection], [])
        self.reject('forbidden', 'service_point.create', actor=FIELD, **self.point_payload())
        self.reject('forbidden', 'service_job.create', actor=SECURITY, **self.job_payload(point))
        self.reject('forbidden', 'service_day.open', actor=WAREHOUSE, **self.day_payload(operational_date='2026-09-27'))
        reading = self.cmd('service_reading.create', actor=SECURITY, **self.reading_payload(point))
        state = self.store.state()
        self.assertEqual(state['audit'][0]['record_id'], reading['id'])
        with self.assertRaises(DomainError) as error:
            self.store.command('service_job.create', self.job_payload(point), MANAGER, expected_revision=state['revision'] - 1)
        self.assertEqual(error.exception.code, 'revision_conflict')
        self.assertEqual(self.store.state()['revision'], state['revision'])
        self.assertIn('service_job.transition', self.store.state(FIELD)['permissions'])
        self.assertNotIn('service_point.create', self.store.state(FIELD)['permissions'])


if __name__ == '__main__':
    unittest.main()

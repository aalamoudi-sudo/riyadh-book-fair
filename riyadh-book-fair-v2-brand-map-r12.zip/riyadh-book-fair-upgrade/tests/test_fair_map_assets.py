"""Check the shipped reference geometry and its safe import boundary offline."""
import json
from pathlib import Path
import unittest

from scripts.import_fair_map import self_test, validate


class FairMapAssetsTests(unittest.TestCase):
    def test_shipped_booths_resolve_to_safe_geometry(self):
        assets = Path(__file__).resolve().parents[1] / 'app' / 'assets'
        metadata = json.loads((assets / 'fair-map-2025.json').read_text())
        result = validate((assets / 'fair-map-2025.svg').read_bytes(), metadata)
        self.assertEqual(result['selectableIds'], len(metadata['booths']))
        first = next(b for b in metadata['booths'] if b['name'] == 'A-1')
        self.assertEqual(first['id'], 'bA-1')
        self.assertIn('دار قصة للنشر والتوزيع', first['exhibitors'])
        self.assertEqual(first['bounds'], [12665, 9660, 30, 60])

    def test_source_parser_geometry_and_sanitizer(self):
        self_test()


if __name__ == '__main__':
    unittest.main()

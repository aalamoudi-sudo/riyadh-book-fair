// Pure data/search checks; browser, pointer, and visual checks are separate.
import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs/promises';
import {parseFairMapData,filterFairBooths,normalizeFairMapSearch} from '../app/fair-map.js';

const raw = JSON.parse(await fs.readFile(new URL('../app/assets/fair-map-2025.json',import.meta.url),'utf8'));

test('reference data has one distinct match for every selectable SVG booth', async () => {
  const data = parseFairMapData(raw);
  const svg = await fs.readFile(new URL('../app/assets/fair-map-2025.svg',import.meta.url),'utf8');
  const ids = new Set([...svg.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]));
  assert.equal(new Set(data.booths.map(booth => booth.id)).size,data.booths.length);
  for (const booth of data.booths) assert.ok(ids.has(booth.id),`Missing SVG booth: ${booth.name}`);
  assert.doesNotMatch(svg,/<(?:script|foreignObject|style)\b|\son\w+=|\bhref\s*=/i);
});

test('Arabic publisher search ignores harakat and common alef forms while booth numbers accept Arabic digits', () => {
  const booths = [{id:'one',name:'A-12',exhibitors:['دار الآفاق للنشر']},{id:'two',name:'B-5',exhibitors:['مكتبة أخرى']}];
  assert.deepEqual(filterFairBooths(booths,'دَار افاق').map(booth => booth.id),['one']);
  assert.deepEqual(filterFairBooths(booths,'A١٢').map(booth => booth.id),['one']);
  assert.deepEqual(filterFairBooths(booths,'B ۵').map(booth => booth.id),['two']);
  assert.deepEqual(filterFairBooths(booths,'غير موجود'),[]);
  assert.equal(normalizeFairMapSearch('إِصْدَار ٢٠٢٥'),'اصدار 2025');
});

test('source, geometry and identity boundaries fail closed before rendering', () => {
  const clone = () => structuredClone(raw);
  const wrongSource=clone(); wrongSource.sourceUrl='https://untrusted.example/';
  assert.throws(() => parseFairMapData(wrongSource));
  const duplicate=clone(); duplicate.booths.push({...duplicate.booths[0]});
  assert.throws(() => parseFairMapData(duplicate));
  const invalidBounds=clone(); invalidBounds.booths[0].bounds[2]=0;
  assert.throws(() => parseFairMapData(invalidBounds));
  const infinite=clone(); infinite.viewBox[0]=Infinity;
  assert.throws(() => parseFairMapData(infinite));
});

import {esc,n,icon} from './ui.js';

const SOURCE_URL = 'https://ribf2025.expofp.com/';
const SVG_NS = 'http://www.w3.org/2000/svg';
const DATA_URL = new URL('./assets/fair-map-2025.json', import.meta.url);
const SVG_URL = new URL('./assets/fair-map-2025.svg', import.meta.url);
const PAGE_SIZE = 20;

export function normalizeFairMapSearch(value) {
  return String(value ?? '').normalize('NFKC').toLowerCase()
    .replace(/[\u064b-\u065f\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
    .replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 0x660))
    .replace(/[۰-۹]/g, digit => String(digit.charCodeAt(0) - 0x6f0))
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, ' ').trim();
}

export function filterFairBooths(booths, query) {
  const normalized = normalizeFairMapSearch(query);
  if (!normalized) return booths;
  const terms = normalized.split(/\s+/);
  const compact = normalized.replace(/\s/g, '');
  return booths.filter(booth => {
    const name = normalizeFairMapSearch(booth.name);
    const haystack = normalizeFairMapSearch([booth.name, ...booth.exhibitors].join(' '));
    return name.replace(/\s/g, '').includes(compact) || terms.every(term => haystack.includes(term));
  });
}

export function parseFairMapData(data) {
  const validBox = box => Array.isArray(box) && box.length === 4 && box.every(Number.isFinite)
    && box[2] > 0 && box[3] > 0 && box.every(value => Math.abs(value) < 1e9);
  if (!data || data.version !== 1 || data.sourceUrl !== SOURCE_URL || !validBox(data.viewBox)
      || !Array.isArray(data.booths) || !data.booths.length || data.booths.length > 10000) {
    throw new Error('ملف مرجع الخريطة غير صالح.');
  }
  const ids = new Set();
  for (const booth of data.booths) {
    if (!booth || typeof booth.id !== 'string' || !booth.id || booth.id.length > 200 || ids.has(booth.id)
        || typeof booth.name !== 'string' || !booth.name.trim() || booth.name.length > 300
        || !Array.isArray(booth.exhibitors) || !booth.exhibitors.every(value => typeof value === 'string' && value.length <= 1000)
        || !validBox(booth.bounds)) throw new Error('فهرس الأجنحة غير صالح.');
    ids.add(booth.id);
  }
  return data;
}

// The initial view is the fair itself, while the reference also includes
// transport and parking locations outside that rectangle.
export function fairMapNavigationBounds(data) {
  const [x,y,w,h] = data.viewBox;
  let minX=x,minY=y,maxX=x+w,maxY=y+h;
  for (const {bounds:[bx,by,bw,bh]} of data.booths) {
    minX=Math.min(minX,bx); minY=Math.min(minY,by);
    maxX=Math.max(maxX,bx+bw); maxY=Math.max(maxY,by+bh);
  }
  return {x:minX,y:minY,w:maxX-minX,h:maxY-minY};
}

function maxViewWidth(home, bounds) {
  return Math.max(home.w*4,bounds.w*1.035,bounds.h*home.w/home.h*1.035);
}

export function constrainFairMapView(next, home, bounds) {
  const w=Math.max(home.w/64,Math.min(maxViewWidth(home,bounds),next.w));
  const h=w*home.h/home.w;
  const cx=Math.max(bounds.x,Math.min(bounds.x+bounds.w,next.x+next.w/2));
  const cy=Math.max(bounds.y,Math.min(bounds.y+bounds.h,next.y+next.h/2));
  return {x:cx-w/2,y:cy-h/2,w,h};
}

export function renderFairMap() {
  return `<section class="fair-map" data-fair-map data-map-state="loading" aria-labelledby="fair-map-title">
    <div class="page-heading fair-map-heading"><div><span class="eyebrow">دليل المعرض · نسخة 2025</span><h1 id="fair-map-title">خريطة المعرض التفاعلية</h1></div><a class="btn secondary fair-map-external" href="${SOURCE_URL}?consent=denied" target="_blank" rel="noopener noreferrer">المصدر في ExpoFP <span aria-hidden="true">↗</span></a></div>
    <p class="fair-map-note">مرجع 2025 من ExpoFP؛ لا يمثل الحالة التشغيلية الحالية.</p>
    <div class="fair-map-status" role="status" aria-live="polite" aria-atomic="true" data-fair-map-status>جارٍ تحميل الخريطة وفهرس الأجنحة…</div>
    <label class="fair-map-search"><span>دار النشر أو رقم الجناح</span><div>${icon('search')}<input type="search" autocomplete="off" enterkeyhint="search" placeholder="مثلًا: دار قصة أو A-1" data-fair-map-search aria-controls="fair-map-results" disabled></div></label>
    <button type="button" class="btn secondary fair-map-results-jump" data-fair-map-results-jump hidden>عرض نتائج البحث</button>
    <div class="fair-map-workspace">
      <aside class="fair-map-directory" aria-label="البحث عن الأجنحة">
        <div class="fair-map-result-heading"><h2>دليل الأجنحة</h2><span data-fair-map-count role="status" aria-live="polite">—</span></div>
        <div id="fair-map-results" class="fair-map-results" data-fair-map-results></div>
        <button type="button" class="btn secondary fair-map-more" data-fair-map-more hidden>عرض المزيد</button>
      </aside>
      <div class="fair-map-sheet">
        <div class="fair-map-toolbar"><span class="fair-map-edition">مخطط المعرض <bdi>2025</bdi></span><div class="fair-map-controls" role="group" aria-label="التحكم في عرض الخريطة"><button type="button" data-fair-map-zoom="in" aria-label="تكبير الخريطة" disabled>+</button><button type="button" data-fair-map-zoom="out" aria-label="تصغير الخريطة" disabled>−</button><button type="button" data-fair-map-reset disabled>عرض المعرض</button></div></div>
        <div class="fair-map-selection" data-fair-map-selection hidden></div>
        <div class="fair-map-stage" data-fair-map-stage tabindex="0" role="region" aria-label="مخطط أجنحة المعرض التفاعلي" aria-describedby="fair-map-help">
          <div class="fair-map-loading" data-fair-map-loading>${icon('spatial')}<p>جارٍ إعداد المخطط…</p><button type="button" class="btn primary" data-fair-map-retry hidden>إعادة المحاولة</button></div>
          <div class="fair-map-art-host" data-fair-map-art-host></div>
        </div>
        <p class="fair-map-help" id="fair-map-help">اسحب للتنقل، وباعد بين إصبعين للتكبير. بلوحة المفاتيح: الأسهم للتحريك، + و− للتكبير والتصغير، وHome لعرض المعرض.</p>
        <div class="fair-map-footer"><span>مخطط الأجنحة ودليل دور النشر</span><a href="#spatial" data-route="spatial">التوأم المكاني ${icon('arrow')}</a></div>
      </div>
    </div>
    <details class="fair-map-edition-notes"><summary>عن نسخة 2025 ومصدر الخريطة</summary><dl><div><dt>موعد المعرض</dt><dd>من 2 إلى 11 أكتوبر 2025</dd></div><div><dt>المكان</dt><dd>جامعة الأميرة نورة بنت عبدالرحمن، الرياض</dd></div><div><dt>شعار النسخة</dt><dd>«الرياض تقرأ»</dd></div><div><dt>ضيف الشرف</dt><dd>أوزبكستان</dd></div></dl><p>معلومات النسخة: التقرير الختامي لمعرض الرياض الدولي للكتاب 2025، ص4. المخطط وأسماء دور النشر مستندان إلى مرجع ExpoFP لعام 2025.</p><p data-fair-map-provenance></p></details>
  </section>`;
}

function parseSafeSvg(text, doc) {
  if (/<!DOCTYPE|<!ENTITY/i.test(text)) throw new Error('يتضمن ملف الخريطة محتوى غير مدعوم.');
  const parsed = new doc.defaultView.DOMParser().parseFromString(text, 'image/svg+xml');
  const source = parsed.documentElement;
  if (source.localName !== 'svg' || source.namespaceURI !== SVG_NS || parsed.querySelector('parsererror')) throw new Error('تعذر قراءة رسم الخريطة.');
  const tags = new Set(['svg','g','rect','path','title','desc','text','tspan','line','polyline','polygon','circle','ellipse']);
  for (const node of [source, ...source.querySelectorAll('*')]) {
    if (node.namespaceURI !== SVG_NS || !tags.has(node.localName)) throw new Error('يتضمن رسم الخريطة عنصرًا غير مدعوم.');
    for (const attr of node.attributes) {
      if (/^on/i.test(attr.name) || /href$/i.test(attr.name) || /url\s*\(|@import|expression\s*\(|javascript:|\\/i.test(attr.value)) throw new Error('يتضمن رسم الخريطة مرجعًا غير مسموح.');
    }
  }
  return doc.importNode(source, true);
}

export function mountFairMap(root = document.querySelector('[data-fair-map]')) {
  if (!root) return () => {};
  const doc = root.ownerDocument, win = doc.defaultView;
  const status = root.querySelector('[data-fair-map-status]');
  const stage = root.querySelector('[data-fair-map-stage]');
  const artHost = root.querySelector('[data-fair-map-art-host]');
  const loading = root.querySelector('[data-fair-map-loading]');
  const retry = root.querySelector('[data-fair-map-retry]');
  const input = root.querySelector('[data-fair-map-search]');
  const results = root.querySelector('[data-fair-map-results]');
  const selection = root.querySelector('[data-fair-map-selection]');
  const count = root.querySelector('[data-fair-map-count]');
  const more = root.querySelector('[data-fair-map-more]');
  const jumpResults = root.querySelector('[data-fair-map-results-jump]');
  const controls = root.querySelectorAll('[data-fair-map-zoom], [data-fair-map-reset]');
  let disposed = false, controller = null, svg = null, model = null, overlay = null;
  let home = null, navigationBounds = null, view = null, selected = null, limit = PAGE_SIZE, gestureMoved = false, suppressClickUntil = 0;
  const booths = new Map(), elements = new Map(), pointers = new Map();
  const listeners = [];
  function listen(target, type, handler, options) { target.addEventListener(type, handler, options); listeners.push(() => target.removeEventListener(type, handler, options)); }
  function announce(state, message) { if (!disposed) { root.dataset.mapState = state; status.textContent = message; } }
  function releasePointers() { for (const id of pointers.keys()) { if (stage.hasPointerCapture?.(id)) stage.releasePointerCapture(id); } pointers.clear(); stage.classList.remove('is-dragging'); }
  function renderResults() {
    if (!model) return;
    const matches = filterFairBooths(model.booths, input.value);
    root.classList.toggle('is-searching', Boolean(input.value.trim()));
    jumpResults.hidden = !input.value.trim(); jumpResults.disabled = matches.length === 0;
    jumpResults.textContent = matches.length ? `عرض نتائج البحث · ${n(matches.length)}` : 'لا توجد نتائج لهذا البحث';
    count.textContent = `${n(matches.length)} موقعًا`;
    results.innerHTML = matches.length ? matches.slice(0, limit).map(booth => `<button type="button" class="fair-map-result${selected?.id === booth.id ? ' is-selected' : ''}" data-fair-map-booth="${esc(booth.id)}"${selected?.id === booth.id ? ' aria-pressed="true"' : ' aria-pressed="false"'}><bdi class="fair-map-booth-number">${esc(booth.name)}</bdi><span>${esc(booth.exhibitors.join(' · ') || 'لا يوجد اسم ناشر في المرجع')}</span></button>`).join('') : '<p class="fair-map-no-results">لا توجد نتائج بهذا الاسم أو الرقم. جرّب جزءًا من اسم دار النشر.</p>';
    more.hidden = matches.length <= limit;
    more.textContent = `عرض المزيد · ${n(Math.min(limit, matches.length))} من ${n(matches.length)}`;
  }
  function getHome() {
    const [x,y,width,height] = model.viewBox;
    const rect = stage.getBoundingClientRect(), ratio = Math.max(rect.width,1) / Math.max(rect.height,1);
    const paddedW = width * 1.035, paddedH = height * 1.035;
    const w = Math.max(paddedW, paddedH * ratio), h = w / ratio;
    return {x:x + width/2 - w/2, y:y + height/2 - h/2, w, h};
  }
  function setView(next) {
    if (!svg || !home) return;
    view = constrainFairMapView(next,home,navigationBounds);
    svg.setAttribute('viewBox', `${view.x} ${view.y} ${view.w} ${view.h}`);
    root.querySelector('[data-fair-map-zoom="out"]').disabled = view.w >= maxViewWidth(home,navigationBounds) * .999;
    root.querySelector('[data-fair-map-zoom="in"]').disabled = view.w <= home.w / 64 * 1.001;
  }
  function worldPoint(point) {
    const matrix = svg?.getScreenCTM();
    if (!matrix) return {x:0,y:0};
    const transformed = new win.DOMPoint(point.x,point.y).matrixTransform(matrix.inverse());
    return {x:transformed.x,y:transformed.y};
  }
  function zoom(factor, point) {
    if (!view) return;
    const anchor = point ? worldPoint(point) : {x:view.x+view.w/2,y:view.y+view.h/2};
    const width = Math.max(home.w/64,Math.min(maxViewWidth(home,navigationBounds),view.w*factor)), scale = width/view.w;
    setView({x:anchor.x-(anchor.x-view.x)*scale,y:anchor.y-(anchor.y-view.y)*scale,w:width,h:view.h*scale});
  }
  function focusBooth(booth) {
    const [x,y,w,h] = booth.bounds;
    const width = Math.max(w*3.2,h*3.2*home.w/home.h,home.w/40);
    const height = width*home.h/home.w;
    setView({x:x+w/2-width/2,y:y+h/2-height/2,w:width,h:height});
  }
  function selectBooth(id, focus = false) {
    const booth = booths.get(id);
    if (!booth) return;
    if (selected) elements.get(selected.id)?.classList.remove('fair-map-booth-selected');
    selected = booth;
    elements.get(id).classList.add('fair-map-booth-selected');
    const [x,y,w,h] = booth.bounds;
    overlay.setAttribute('x',x); overlay.setAttribute('y',y); overlay.setAttribute('width',w); overlay.setAttribute('height',h); overlay.hidden = false; overlay.style.display = '';
    selection.hidden = false;
    selection.innerHTML = `<div class="fair-map-selected-copy"><span class="fair-map-selection-label">الموقع المحدد</span><h2><bdi>${esc(booth.name)}</bdi></h2>${booth.exhibitors.length ? `<ul>${booth.exhibitors.map(name => `<li>${esc(name)}</li>`).join('')}</ul>` : '<p>لا توجد دار نشر مرتبطة بهذا الموقع في المصدر.</p>'}</div><button type="button" class="btn secondary" data-fair-map-focus>توسيط الموقع</button>`;
    renderResults();
    if (focus) { focusBooth(booth); if (win.matchMedia('(max-width: 720px)').matches) selection.scrollIntoView({block:'start'}); }
    announce('ready', `الجناح ${booth.name}${booth.exhibitors.length ? ' · '+booth.exhibitors.join('، ') : ''}`);
  }
  function boothAt(target) {
    for (let node = target; node && node !== svg; node = node.parentElement) if (node.id && booths.has(node.id)) return node.id;
    return null;
  }
  function onClick(event) {
    const action = event.target.closest?.('[data-fair-map-booth], [data-fair-map-zoom], [data-fair-map-reset], [data-fair-map-focus], [data-fair-map-more], [data-fair-map-retry], [data-fair-map-results-jump]');
    if (action && root.contains(action)) {
      if (action.matches('[data-fair-map-retry]')) { load(); return; }
      if (!model || !view) return;
      if (action.matches('[data-fair-map-results-jump]')) { results.scrollIntoView({block:'start'}); results.querySelector('button')?.focus({preventScroll:true}); return; }
      if (action.matches('[data-fair-map-booth]')) { selectBooth(action.dataset.fairMapBooth,true); return; }
      if (action.matches('[data-fair-map-zoom]')) { zoom(action.dataset.fairMapZoom === 'in' ? 1/1.4 : 1.4); return; }
      if (action.matches('[data-fair-map-reset]')) { setView(home); return; }
      if (action.matches('[data-fair-map-focus]')) { if (selected) focusBooth(selected); return; }
      if (action.matches('[data-fair-map-more]')) {
        limit += PAGE_SIZE; renderResults();
        results.querySelectorAll('button')[limit - PAGE_SIZE]?.focus({preventScroll:true});
        return;
      }
    }
    if (!svg || !svg.contains(event.target) || Date.now() < suppressClickUntil) return;
    const id = boothAt(event.target);
    if (id) selectBooth(id);
  }
  function onPointerDown(event) {
    if (!view || (event.pointerType === 'mouse' && event.button !== 0)) return;
    if (!pointers.size) gestureMoved = false;
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY,startX:event.clientX,startY:event.clientY,boothId:boothAt(event.target)});
    if (pointers.size > 1) gestureMoved = true;
    stage.setPointerCapture(event.pointerId);
    stage.classList.add('is-dragging');
  }
  function onPointerMove(event) {
    if (!view || !pointers.has(event.pointerId)) return;
    const previous = [...pointers.values()].map(point => ({...point}));
    const tracked = pointers.get(event.pointerId);
    tracked.x = event.clientX; tracked.y = event.clientY;
    if (Math.hypot(tracked.x-tracked.startX,tracked.y-tracked.startY) > 5) gestureMoved = true;
    const current = [...pointers.values()];
    if (current.length === 1) {
      if (!gestureMoved) return;
      const before = worldPoint(previous[0]), after = worldPoint(current[0]);
      setView({...view,x:view.x-(after.x-before.x),y:view.y-(after.y-before.y)});
    } else {
      const center = list => ({x:(list[0].x+list[1].x)/2,y:(list[0].y+list[1].y)/2});
      const distance = list => Math.hypot(list[0].x-list[1].x,list[0].y-list[1].y);
      const oldDistance = distance(previous), newDistance = distance(current);
      if (oldDistance < 4 || newDistance < 4) return;
      const before = worldPoint(center(previous)), after = worldPoint(center(current));
      const width = Math.max(home.w/64,Math.min(maxViewWidth(home,navigationBounds),view.w*oldDistance/newDistance)), scale = width/view.w;
      setView({x:before.x-(after.x-view.x)*scale,y:before.y-(after.y-view.y)*scale,w:width,h:view.h*scale});
    }
  }
  function onPointerEnd(event) {
    const pointer = pointers.get(event.pointerId);
    if (!gestureMoved && event.type === 'pointerup' && pointers.size === 1 && pointer?.boothId) {
      selectBooth(pointer.boothId);
      suppressClickUntil = Date.now()+350;
    }
    if (gestureMoved) suppressClickUntil = Date.now()+350;
    pointers.delete(event.pointerId);
    if (stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId);
    if (!pointers.size) stage.classList.remove('is-dragging');
  }
  function onKey(event) {
    if (!view || event.target !== stage) return;
    const stepX = view.w*.12, stepY = view.h*.12;
    if (event.key === '+' || event.key === '=') zoom(1/1.4);
    else if (event.key === '-' || event.key === '−') zoom(1.4);
    else if (event.key === 'Home') setView(home);
    else if (event.key === 'ArrowLeft') setView({...view,x:view.x-stepX});
    else if (event.key === 'ArrowRight') setView({...view,x:view.x+stepX});
    else if (event.key === 'ArrowUp') setView({...view,y:view.y-stepY});
    else if (event.key === 'ArrowDown') setView({...view,y:view.y+stepY});
    else return;
    event.preventDefault();
  }
  async function load() {
    controller?.abort();
    controller = new win.AbortController();
    const current = controller;
    releasePointers();
    svg = null; model = null; selected = null; home = null; navigationBounds = null; view = null; booths.clear(); elements.clear(); artHost.replaceChildren();
    results.replaceChildren(); count.textContent='—'; more.hidden=true; limit=PAGE_SIZE;
    selection.replaceChildren(); selection.hidden=true; jumpResults.hidden=true;
    input.disabled = true; controls.forEach(button => {button.disabled=true}); retry.hidden = true; loading.hidden = false;
    loading.querySelector('p').textContent = 'جارٍ إعداد المخطط…';
    announce('loading','جارٍ تحميل الخريطة وفهرس الأجنحة…');
    try {
      const [dataResponse,svgResponse] = await Promise.all([win.fetch(DATA_URL,{signal:current.signal}),win.fetch(SVG_URL,{signal:current.signal})]);
      if (!dataResponse.ok || !svgResponse.ok) throw new Error('تعذر تحميل ملفات الخريطة.');
      const [raw,text] = await Promise.all([dataResponse.json(),svgResponse.text()]);
      if (disposed || current.signal.aborted) return;
      const data = parseFairMapData(raw), drawing = parseSafeSvg(text,doc);
      const indexed = new Map();
      for (const node of drawing.querySelectorAll('[id]')) {
        if (indexed.has(node.id)) throw new Error('توجد معرفات مكررة في رسم الخريطة.');
        indexed.set(node.id,node);
      }
      for (const booth of data.booths) {
        const element = indexed.get(booth.id);
        if (!element) throw new Error('فهرس الأجنحة لا يطابق المخطط.');
        booths.set(booth.id,booth); elements.set(booth.id,element); element.classList.add('fair-map-booth');
      }
      model = data; navigationBounds = fairMapNavigationBounds(data); svg = drawing;
      svg.removeAttribute('width'); svg.removeAttribute('height');
      svg.classList.add('fair-map-art'); svg.setAttribute('preserveAspectRatio','xMidYMid meet');
      svg.setAttribute('role','img'); svg.setAttribute('aria-label','المخطط المرجعي لمعرض الرياض الدولي للكتاب 2025 ومواقع الوصول إليه');
      overlay = doc.createElementNS(SVG_NS,'rect'); overlay.classList.add('fair-map-highlight'); overlay.style.display='none'; overlay.setAttribute('aria-hidden','true'); svg.append(overlay);
      artHost.append(svg); loading.hidden = true; input.disabled = false; controls.forEach(button => {button.disabled=false});
      home = getHome(); setView(home); renderResults();
      const sourceVersion = typeof data.sourceVersion === 'string' ? data.sourceVersion : '';
      const importedAt = typeof data.importedAt === 'string' && Number.isFinite(Date.parse(data.importedAt)) ? new Intl.DateTimeFormat('ar-SA',{calendar:'gregory',dateStyle:'medium'}).format(new Date(data.importedAt)) : '';
      root.querySelector('[data-fair-map-provenance]').textContent = [sourceVersion ? `نسخة المصدر: ${sourceVersion}` : '', importedAt ? `تاريخ حفظ المرجع: ${importedAt}` : ''].filter(Boolean).join(' · ');
      announce('ready',`${n(model.booths.length)} موقعًا في مرجع 2025. ابحث أو حدد موقعًا من المخطط.`);
    } catch (error) {
      if (disposed || current.signal.aborted) return;
      announce('error','تعذر عرض نسخة الخريطة. أعد المحاولة أو افتح المصدر في ExpoFP.');
      loading.hidden = false; loading.querySelector('p').textContent = 'لم تكتمل قراءة ملفات الخريطة.'; retry.hidden = false;
    }
  }
  listen(root,'click',onClick);
  listen(input,'input',() => {limit=PAGE_SIZE; renderResults(); results.scrollTop=0});
  listen(input,'keydown',event => {if (event.key === 'Enter' && model) {const first=filterFairBooths(model.booths,input.value)[0];if (first) {event.preventDefault();selectBooth(first.id,true);stage.focus({preventScroll:true})}}});
  listen(stage,'pointerdown',onPointerDown);
  listen(stage,'pointermove',onPointerMove);
  listen(stage,'pointerup',onPointerEnd);
  listen(stage,'pointercancel',onPointerEnd);
  listen(stage,'keydown',onKey);
  listen(stage,'dblclick',event => {if (view) {event.preventDefault();zoom(1/1.7,{x:event.clientX,y:event.clientY})}});
  listen(stage,'wheel',event => {if (view && (event.ctrlKey || event.metaKey)) {event.preventDefault();zoom(event.deltaY < 0 ? 1/1.12 : 1.12,{x:event.clientX,y:event.clientY})}}, {passive:false});
  const resize = new win.ResizeObserver(() => {
    if (!model || !home) return;
    const epsilon=home.w*1e-5;
    const atHome = Math.abs(view.w-home.w)<epsilon && Math.abs(view.x-home.x)<epsilon && Math.abs(view.y-home.y)<epsilon;
    const previous = view, scale = view.w/home.w;
    home = getHome();
    if (atHome) setView(home);
    else {const width=home.w*scale,height=width*home.h/home.w;setView({x:previous.x+previous.w/2-width/2,y:previous.y+previous.h/2-height/2,w:width,h:height})}
  });
  resize.observe(stage);
  load();
  return () => {
    if (disposed) return;
    disposed = true; controller?.abort(); resize.disconnect(); releasePointers(); listeners.forEach(remove => remove());
    artHost.replaceChildren(); booths.clear(); elements.clear(); svg = null; model = null; selected = null; view = null; home = null; navigationBounds = null;
  };
}

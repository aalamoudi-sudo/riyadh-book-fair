#!/usr/bin/env python3
"""Import the public 2025 ExpoFP reference map, without executing its JavaScript.

Only the observed data.js, fp.svg.js and version.json URLs are fetched. The
outputs contain display names and source geometry, never contact/editor data.
This is a reference drawing, not a surveyed or live operational spatial model.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET


SOURCE_URL = "https://ribf2025.expofp.com/"
SOURCE_FILES = ("data.js", "fp.svg.js", "version.json")
ASSETS = Path(__file__).resolve().parents[1] / "app" / "assets"
NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", NS)
NUMBER = r"[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?"
STYLE_KEYS = {
    "fill", "stroke", "fill-opacity", "stroke-opacity", "opacity",
    "stroke-width", "stroke-linejoin", "stroke-linecap", "fill-rule", "clip-rule", "background-color",
}
ATTRS = STYLE_KEYS | {
    "id", "x", "y", "width", "height", "rx", "ry", "transform",
}
TAGS = {"svg", "g", "rect", "path"}
IDENTITY = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def fail(condition, message):
    if not condition:
        raise ValueError(message)


def number(value):
    result = float(value)
    fail(math.isfinite(result), "Non-finite geometry")
    return result


def fmt(value):
    return format(number(value), ".9g")


def assignment(text, name):
    """Read just the JSON value following an exact public variable assignment."""
    patterns = (
        r"\bvar\s+" + re.escape(name) + r"\s*=\s*",
        r"window\[(['\"])" + re.escape(name) + r"\1\]\s*=\s*",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return json.JSONDecoder().raw_decode(text[match.end():])[0]
    raise ValueError("Missing source assignment: " + name)


def multiply(a, b):
    return (
        a[0]*b[0]+a[2]*b[1], a[1]*b[0]+a[3]*b[1],
        a[0]*b[2]+a[2]*b[3], a[1]*b[2]+a[3]*b[3],
        a[0]*b[4]+a[2]*b[5]+a[4], a[1]*b[4]+a[3]*b[5]+a[5],
    )


def transform_matrix(value):
    if not value:
        return IDENTITY
    result = IDENTITY
    matches = list(re.finditer(r"(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)", value))
    residue = re.sub(r"(matrix|translate|scale|rotate|skewX|skewY)\s*\([^)]*\)", "", value)
    fail(not residue.strip(" ,\t\n"), "Unsupported transform")
    for match in matches:
        kind, raw = match.groups()
        fail(not re.sub(NUMBER, "", raw).strip(" ,\t\n"), "Invalid transform arguments")
        v = [number(n) for n in re.findall(NUMBER, raw)]
        if kind == "matrix" and len(v) == 6:
            m = tuple(v)
        elif kind == "translate" and len(v) in (1, 2):
            m = (1, 0, 0, 1, v[0], v[1] if len(v) == 2 else 0)
        elif kind == "scale" and len(v) in (1, 2):
            m = (v[0], 0, 0, v[-1], 0, 0)
        elif kind == "rotate" and len(v) in (1, 3):
            c, s = math.cos(math.radians(v[0])), math.sin(math.radians(v[0]))
            m = (c, s, -s, c, 0, 0)
            if len(v) == 3:
                m = multiply(multiply((1, 0, 0, 1, v[1], v[2]), m), (1, 0, 0, 1, -v[1], -v[2]))
        elif kind in ("skewX", "skewY") and len(v) == 1:
            tangent = math.tan(math.radians(v[0]))
            m = (1, 0, tangent, 1, 0, 0) if kind == "skewX" else (1, tangent, 0, 1, 0, 0)
        else:
            raise ValueError("Unsupported transform argument count")
        result = multiply(result, m)
    return result


def point(matrix, p):
    x, y = p
    return (matrix[0]*x+matrix[2]*y+matrix[4], matrix[1]*x+matrix[3]*y+matrix[5])


def points(mesh):
    result = [tuple(number(n) for n in p) for p in mesh["positions"]]
    fail(all(len(p) == 2 for p in result), "Invalid mesh vertex")
    return result


def path_line(vertices, close=False):
    if not vertices:
        return ""
    return "M" + " L".join(fmt(x)+","+fmt(y) for x, y in vertices) + (" Z" if close else "")


def mesh_paths(mesh):
    """Return clean outline paths, or separate fill/stroke for a complex mesh.

    Triangulated cells store filled geometry, not the original SVG commands.
    Internal mesh edges must not become visible SVG strokes. Most boundaries
    form rings; a non-manifold mesh uses triangle fill plus boundary-only stroke.
    """
    vertices = points(mesh)
    cells = mesh.get("cells", [])
    if not cells:
        closed = len(vertices) > 1 and vertices[0] == vertices[-1]
        return path_line(vertices[:-1] if closed else vertices, closed), None
    edges = collections.Counter()
    triangles = []
    for cell in cells:
        fail(len(cell) == 3 and all(isinstance(i, int) and 0 <= i < len(vertices) for i in cell), "Invalid mesh cell")
        triangle = [vertices[i] for i in cell]
        if len(set(triangle)) < 3:
            continue
        triangles.append(triangle)
        for a, b in zip(triangle, triangle[1:]+triangle[:1]):
            edges[tuple(sorted((a, b)))] += 1
    boundary = {e for e, count in edges.items() if count % 2}
    neighbors = collections.defaultdict(set)
    for a, b in boundary:
        neighbors[a].add(b)
        neighbors[b].add(a)
    if any(n > 2 for n in edges.values()) or any(len(v) != 2 for v in neighbors.values()):
        fill = " ".join(path_line(t, True) for t in triangles)
        stroke = " ".join(path_line(e) for e in sorted(boundary))
        return fill, stroke
    rings = []
    remaining = set(boundary)
    while remaining:
        start, current = min(remaining)
        remaining.remove(tuple(sorted((start, current))))
        ring = [start, current]
        previous = start
        while current != start:
            candidates = neighbors[current] - {previous}
            fail(len(candidates) == 1, "Ambiguous boundary ring")
            following = next(iter(candidates))
            edge = tuple(sorted((current, following)))
            fail(edge in remaining, "Broken boundary ring")
            remaining.remove(edge)
            previous, current = current, following
            ring.append(current)
        rings.append(path_line(ring[:-1], True))
    return " ".join(rings), None


def clean_style(value):
    result = []
    for declaration in value.split(";"):
        if not declaration.strip():
            continue
        key, separator, content = declaration.partition(":")
        key, content = key.strip(), content.strip()
        if separator and key in STYLE_KEYS:
            fail(bool(re.fullmatch(r"[\w\s.,%#()+-]+", content)), "Unsafe style value")
            fail(not re.search(r"url|expression|var\s*\(", content, re.I), "Style reference forbidden")
            result.append(key+":"+content)
    return ";".join(result)


def clean_attributes(element):
    result = {}
    for key, value in element.attrib.items():
        if key in ATTRS:
            fail(not any(c in value for c in ("@", "<", ">", "\x00")), "Unsafe attribute value")
            fail(not re.search(r"url\s*\(|javascript:|https?:", value, re.I), "Attribute reference forbidden")
            if key == "transform":
                transform_matrix(value)
            result[key] = value
        elif key == "style":
            style = clean_style(value)
            if style:
                result[key] = style
    return result


def source_points(element, meshes, parent=IDENTITY):
    matrix = multiply(parent, transform_matrix(element.attrib.get("transform", "")))
    tag = element.tag.rsplit("}", 1)[-1]
    own = []
    if tag == "rect":
        x, y = number(element.attrib.get("x", 0)), number(element.attrib.get("y", 0))
        w, h = number(element.attrib["width"]), number(element.attrib["height"])
        own = [(x, y), (x+w, y), (x+w, y+h), (x, y+h)]
    elif tag == "path":
        index = int(element.attrib["data-index"])
        own = points(meshes[index])
    result = [point(matrix, p) for p in own]
    for child in element:
        result.extend(source_points(child, meshes, matrix))
    return result


def sanitize(element, meshes, stats):
    tag = element.tag.rsplit("}", 1)[-1]
    fail(tag in TAGS, "Unexpected source element: " + tag)
    attrs = clean_attributes(element)
    if tag == "path":
        index = int(element.attrib["data-index"])
        fail(0 <= index < len(meshes), "Missing path geometry")
        data, outline = mesh_paths(meshes[index])
        stats["paths"] += 1
        if outline is not None:
            stats["complexPaths"] += 1
            output = ET.Element("{"+NS+"}g", attrs)
            ET.SubElement(output, "{"+NS+"}path", {"d": data, "style": "stroke:none"})
            ET.SubElement(output, "{"+NS+"}path", {"d": outline, "style": "fill:none"})
            return output
        attrs["d"] = data
        if meshes[index].get("cells"):
            attrs["fill-rule"] = "evenodd"
    output = ET.Element("{"+NS+"}"+tag, attrs)
    for child in element:
        # The green authoring view-box rectangle is not exhibition geometry.
        if child.attrib.get("id") == "Viewbox":
            continue
        output.append(sanitize(child, meshes, stats))
    return output


def validate(svg_bytes, metadata):
    fail(metadata["version"] == 1, "Unexpected export schema")
    fail(len(metadata["booths"]) == 825, "Source booth count changed; review required")
    fail(len({b["name"] for b in metadata["booths"]}) == 825, "Duplicate booth names")
    root = ET.fromstring(svg_bytes)
    ids = [e.attrib["id"] for e in root.iter() if "id" in e.attrib]
    fail(len(ids) == len(set(ids)), "Duplicate SVG IDs")
    fail(all(b["id"] in ids for b in metadata["booths"]), "Missing selectable booth ID")
    fail([number(x) for x in root.attrib["viewBox"].split()] == metadata["viewBox"], "View-box mismatch")
    for booth in metadata["booths"]:
        fail(len(booth["bounds"]) == 4 and all(math.isfinite(v) for v in booth["bounds"]), "Invalid booth bounds")
        fail(booth["bounds"][2] > 0 and booth["bounds"][3] > 0, "Empty booth bounds")
        fail(set(booth) == {"id", "name", "exhibitors", "bounds"}, "Unexpected booth fields")
    for element in root.iter():
        fail(element.tag.rsplit("}", 1)[-1] in TAGS | {"title", "desc"}, "Unexpected output element")
        for key, value in element.attrib.items():
            fail(not key.startswith(("on", "data-", "fp-")) and not key.endswith("href"), "Forbidden output metadata")
            fail(not re.search(r"url\s*\(|javascript:|https?:|data:", value, re.I), "External/active SVG reference")
    combined = svg_bytes.decode()+json.dumps(metadata, ensure_ascii=False)
    fail(not re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", combined), "Contact data in export")
    return {"booths": len(metadata["booths"]), "selectableIds": 825, "svgBytes": len(svg_bytes)}


def build(raw, imported_at):
    texts = {name: value.decode("utf-8-sig") for name, value in raw.items()}
    data = assignment(texts["data.js"], "__data")
    meshes = assignment(texts["fp.svg.js"], "__fpPaths")
    original = ET.fromstring(assignment(texts["fp.svg.js"], "__fp"))
    fail(len(data["booths"]) == 825, "Source changed; inspect before importing")
    layers = {e.attrib.get("id"): e for e in original}
    source_box = next(e for e in layers["Viewbox"] if e.attrib.get("id") == "VIEWBOX")
    box = [number(source_box.attrib[k]) for k in ("x", "y", "width", "height")]
    margin = 100.0
    view_box = [box[0]-margin, box[1]-margin, box[2]+margin*2, box[3]+margin*2]
    geometry = {e.attrib["id"]: e for e in layers["Booths"]}
    exhibitors = {e["id"]: e["name"] for e in data["exhibitors"]}
    booths = []
    ancestor = multiply(transform_matrix(original.attrib.get("transform", "")), transform_matrix(layers["Booths"].attrib.get("transform", "")))
    for booth in data["booths"]:
        svg_id = "b" + booth["name"]
        fail(svg_id in geometry, "Unmatched booth geometry")
        vertices = source_points(geometry[svg_id], meshes, ancestor)
        fail(bool(vertices), "Booth has no geometry")
        xs, ys = zip(*vertices)
        bounds = [min(xs), min(ys), max(xs)-min(xs), max(ys)-min(ys)]
        names = [exhibitors[i] for i in booth.get("exhibitors", []) if i in exhibitors]
        booths.append({"id": svg_id, "name": booth["name"], "exhibitors": names, "bounds": [round(v, 6) for v in bounds]})
    stats = collections.Counter()
    clean = sanitize(original, meshes, stats)
    clean.set("viewBox", " ".join(fmt(n) for n in view_box))
    clean.set("preserveAspectRatio", "xMidYMid meet")
    clean.set("role", "img")
    title = ET.Element("{"+NS+"}title")
    title.text = "Riyadh International Book Fair 2025 — reference floor plan"
    clean.insert(0, title)
    description = ET.Element("{"+NS+"}desc")
    description.text = "Reference geometry derived from the public ExpoFP map. Drawing coordinates are not surveyed measurements or live operational data."
    clean.insert(1, description)
    svg_bytes = ET.tostring(clean, encoding="utf-8", xml_declaration=True)
    metadata = {
        "version": 1, "sourceUrl": SOURCE_URL,
        "sourceVersion": json.loads(texts["version.json"])["version"],
        "importedAt": imported_at, "viewBox": view_box,
        "sourceHashes": {name: hashlib.sha256(raw[name]).hexdigest() for name in SOURCE_FILES},
        "coordinateSystem": "source drawing units; not surveyed metres",
        "booths": booths,
    }
    result = validate(svg_bytes, metadata)
    result.update(stats)
    return svg_bytes, metadata, result


def self_test():
    fail(assignment('var __data = {"safe":1}; throw new Error();', "__data") == {"safe": 1}, "Assignment parser failed")
    square = {"positions": [[0, 0], [10, 0], [10, 10], [0, 10]], "cells": [[0, 1, 2], [2, 3, 0]]}
    data, outline = mesh_paths(square)
    fail(outline is None and data.count("M") == 1 and data.count("Z") == 1, "Square boundary reconstruction failed")
    fail("0,0 L10,10" not in data, "Internal mesh edge leaked into outline")
    ring = {
        "positions": [[0, 0], [10, 0], [10, 10], [0, 10], [3, 3], [7, 3], [7, 7], [3, 7]],
        "cells": [[0, 1, 5], [0, 5, 4], [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]],
    }
    ring_data, ring_outline = mesh_paths(ring)
    fail(ring_outline is None and ring_data.count("M") == 2 and ring_data.count("Z") == 2, "Hole boundary was lost")
    fail(mesh_paths({"positions": [[0, 0], [1, 0], [2, 1]], "cells": []})[0].endswith("2,1"), "Open path incorrectly closed")
    m = transform_matrix("translate(10,20) scale(2) rotate(90)")
    x, y = point(m, (1, 0))
    fail(abs(x-10) < 1e-8 and abs(y-22) < 1e-8, "Transform-aware geometry failed")
    nested = ET.fromstring('<g transform="translate(10,20)"><rect transform="scale(2)" x="1" y="2" width="3" height="4"/></g>')
    transformed = source_points(nested, [])
    fail(transformed == [(12, 24), (18, 24), (18, 32), (12, 32)], "Nested bounds transform applied incorrectly")
    malicious = ET.fromstring('<g onclick="x" data-history="private" fp-user="private" style="fill:#fff"/>')
    fail(clean_attributes(malicious) == {"style": "fill:#fff"}, "Metadata sanitizer failed")
    try:
        clean_style("fill:url(https://example.invalid/a)")
    except ValueError:
        pass
    else:
        raise ValueError("External style reference was accepted")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Validate existing local outputs without network access")
    parser.add_argument("--self-test", action="store_true", help="Run parser, geometry and sanitizer tests without network access")
    parser.add_argument("--imported-at", help="Fixed ISO timestamp for reproducible imports")
    args = parser.parse_args()
    self_test()
    if args.self_test:
        print("PASS: parser, boundary reconstruction, transforms, sanitization")
        return
    if args.check:
        result = validate((ASSETS/"fair-map-2025.svg").read_bytes(), json.loads((ASSETS/"fair-map-2025.json").read_text()))
        print(json.dumps({"status": "PASS", **result}))
        return
    raw = {}
    for filename in SOURCE_FILES:
        request = urllib.request.Request(SOURCE_URL+"data/"+filename, headers={"User-Agent": "Mayadeen-Reference-Map-Importer/1.0"})
        with urllib.request.urlopen(request, timeout=30) as response:
            fail(response.url == SOURCE_URL+"data/"+filename, "Unexpected source redirect")
            raw[filename] = response.read(8_000_001)
            fail(len(raw[filename]) <= 8_000_000, "Source exceeds import limit")
    imported_at = args.imported_at or dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    svg, metadata, result = build(raw, imported_at)
    # Repeat the pure conversion: equal inputs must produce byte-identical SVG.
    repeat_svg, repeat_metadata, _ = build(raw, imported_at)
    fail(svg == repeat_svg and metadata == repeat_metadata, "Non-deterministic conversion")
    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS/"fair-map-2025.svg").write_bytes(svg)
    (ASSETS/"fair-map-2025.json").write_text(json.dumps(metadata, ensure_ascii=False, separators=(",", ":"))+"\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "sourceVersion": metadata["sourceVersion"], "deterministic": True, **result}))


if __name__ == "__main__":
    main()

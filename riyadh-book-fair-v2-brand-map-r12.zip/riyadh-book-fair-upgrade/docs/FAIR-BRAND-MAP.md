# Riyadh 2025 identity and map

The mobile web interface uses the original Riyadh International Book Fair wordmark from the user-supplied ExpoFP source and the original Mayadeen logo from the supplied branding folder. Marks retain their original appearance. The navy, blue and gold palette is sampled from the supplied 2025 closing report (pages 1, 4 and 8); these are application design choices, not a claim of official brand-guideline values. IBM Plex Arabic remains the interface font for continuity and readable operational tables.

The single visual signature is a restrained book-spine treatment: a gold edge identifies event context while blue identifies interactive controls. Green and red retain their existing operational status meanings. Real source logos replace the generic book symbol on login and primary navigation. Mayadeen is presented as the project platform, not as a claim of event ownership or endorsement.

## Source boundaries

- The supplied 2025 closing report, page 4: 2–11 October 2025; Princess Nourah bint Abdulrahman University, Riyadh; “Riyadh Reads”; Uzbekistan as guest of honour.
- The 333-page original report stays in the local private review directory and is excluded from release archives. Financial, personal and internal report content is not copied into the product.
- Public map and wordmark: https://ribf2025.expofp.com/ and https://ribf2025.expofp.com/data/ribf2025.webp?v=32808 .
- Local reference geometry: public ExpoFP `data/data.js`, `data/fp.svg.js` and `data/version.json`, imported selectively by `scripts/import_fair_map.py`. Only booth identifiers, display names, publisher names and drawing geometry are retained; editor metadata and contact fields are excluded.
- The full ExpoFP guide remains accessible through an explicit external link using `consent=denied`. Opening the local guide makes no third-party request.

The 2025 guide is separate from project spatial plans, reviewed geometry, operational zones and manual crowd records. Drawing coordinates are not treated as metres or survey geometry. There is always an external-map link. The local map is a reference snapshot, not a live feed. The public source contains 825 selectable locations, including booths, parking and transport stops. The initial view centers on the fair; search can locate sites outside that initial viewport.

## Architecture and validation

The map has its own hash route, `#fair-map`, and a mobile navigation entry. The current twin remains available from the map footer and full navigation. Rendering disposes the map and its listeners before rebuilding the page or logging out. SVG and JSON are same-origin static assets, so the existing CSP remains unchanged. The initial iframe approach was abandoned after it stayed blank inside the test browser while the direct source worked; a sandbox-free diagnostic showed the same issue. No broader frame permission is shipped.

The native iPhone icon is a separate signed bundle resource. A web branding update does not replace that icon. The local map avoids cross-origin frame navigation. Actual touch gestures and the external link must still be checked on the phone; desktop responsive testing does not prove native-device behavior.

Execution and verification results are recorded in TASKS.md and the private review evidence. The development copy was extracted from the exact deployed r10.1 release because the original working directory contained iCloud-offloaded Git and source files. Existing local native work has not been overwritten.

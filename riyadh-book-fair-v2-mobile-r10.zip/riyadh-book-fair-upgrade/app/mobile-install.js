let pendingInstall = null;

const installed = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
if (installed()) document.documentElement.classList.add('installed-app');

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  pendingInstall = event;
});
window.addEventListener('appinstalled', () => {
  pendingInstall = null;
  document.documentElement.classList.add('installed-app');
});

if ('serviceWorker' in navigator && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname))) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js', {scope: '/'}).catch(error => {
      console.warn('تعذر تفعيل شاشة انقطاع الاتصال:', error);
    });
  }, {once: true});
}

export function setConnectionStatus(connected) {
  let notice = document.getElementById('connection-warning');
  if (connected) {
    notice?.remove();
    return;
  }
  if (!notice) {
    notice = document.createElement('div');
    notice.id = 'connection-warning';
    notice.setAttribute('role', 'alert');
    notice.textContent = 'الاتصال بالخادم متوقف. السجلات المعروضة آخر تحميل؛ لن تُحفظ تغييراتك حتى يعود الاتصال.';
    document.body.prepend(notice);
  }
}

window.addEventListener('offline', () => setConnectionStatus(false));
window.addEventListener('online', async () => {
  try {
    const response = await fetch('/api/health', {cache: 'no-store'});
    if (response.ok) setConnectionStatus(true);
  } catch { /* keep the warning until the server responds */ }
});

function guide(title, steps) {
  document.getElementById('install-guide')?.remove();
  const dialog = document.createElement('dialog');
  dialog.id = 'install-guide';
  dialog.className = 'install-guide';
  const heading = document.createElement('h2');
  heading.textContent = title;
  dialog.setAttribute('aria-labelledby', 'install-guide-title');
  heading.id = 'install-guide-title';
  const list = document.createElement('ol');
  for (const text of steps) {
    const item = document.createElement('li');
    item.textContent = text;
    list.append(item);
  }
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn primary';
  close.textContent = 'فهمت';
  close.addEventListener('click', () => dialog.close());
  dialog.append(heading, list, close);
  dialog.addEventListener('close', () => dialog.remove(), {once: true});
  document.body.append(dialog);
  dialog.showModal();
  close.focus();
}

export async function requestInstall() {
  if (installed()) {
    guide('التطبيق على الشاشة الرئيسية', ['المنصة مفتوحة الآن بوضع التطبيق. احتفظ باتصال الإنترنت لقراءة السجلات وحفظها.']);
    return;
  }
  if (pendingInstall) {
    const event = pendingInstall;
    pendingInstall = null;
    await event.prompt();
    await event.userChoice;
    return;
  }
  const ios = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  if (ios) {
    guide('تثبيت التطبيق على iPhone', [
      'افتح هذا الرابط في Safari على هاتفك.',
      'اضغط زر المشاركة، ثم اختر «إضافة إلى الشاشة الرئيسية».',
      'اختر فتحه كتطبيق. ستحتاج إلى الإنترنت عند قراءة السجلات أو تعديلها.'
    ]);
  } else if (/Android/.test(navigator.userAgent)) {
    guide('تثبيت التطبيق على Android', [
      'افتح الرابط في Chrome على هاتفك.',
      'من قائمة المتصفح اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».',
      'افتح الأيقونة الجديدة. ستحتاج إلى الإنترنت عند قراءة السجلات أو تعديلها.'
    ]);
  } else {
    guide('تثبيت التطبيق على الجوال', [
      'على iPhone افتح الرابط في Safari، ثم اختر «إضافة إلى الشاشة الرئيسية» من قائمة المشاركة.',
      'على Android افتح الرابط في Chrome، ثم اختر «تثبيت التطبيق» من قائمة المتصفح.',
      'يتطلب عرض سجلات المشروع وحفظها اتصالًا بالخادم.'
    ]);
  }
}

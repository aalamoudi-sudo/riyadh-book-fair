from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainError, DomainStore
from server import Application, hash_password


class AccountDirectoryTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        store = DomainStore(Path(self.folder.name) / 'operations.sqlite')
        self.store = store
        password_hash = hash_password('long-test-password-only')
        accounts = {
            'site': {'id': 'site-security', 'name': 'أمن الموقع', 'role': 'security', 'password_hash': password_hash},
            'other': {'id': 'other-manager', 'name': 'مشروع آخر', 'role': 'manager', 'project_ids': ['PRJ-OTHER'], 'password_hash': password_hash},
            'none': {'id': 'no-project', 'name': 'بلا نطاق', 'role': 'security', 'project_ids': [], 'password_hash': password_hash},
        }
        self.app = Application(store, accounts)

    def tearDown(self):
        self.folder.cleanup()

    def test_directory_is_role_and_project_scoped_without_password_hashes(self):
        manager = {'id': 'project-manager', 'role': 'manager', 'project_ids': ['PRJ-ONE']}
        self.assertEqual([row['id'] for row in self.app.account_directory(manager)], ['site-security'])
        self.assertTrue(all('password_hash' not in row for row in self.app.account_directory({'id':'root','role':'admin'})))
        with self.assertRaises(DomainError):
            self.app.account_directory({'id': 'reader', 'role': 'viewer'})

    def test_stakeholder_link_rejects_unknown_and_out_of_scope_accounts(self):
        actor = {'id': 'root', 'role': 'admin'}
        envelope = {'type': 'shared.create', 'payload': {'collection': 'stakeholders', 'project_id': 'PRJ-ONE', 'account_id': 'site-security'}}
        self.app.validate_stakeholder_account(envelope, actor)
        for account_id in ('missing-account', 'other-manager', 'no-project'):
            envelope['payload']['account_id'] = account_id
            with self.subTest(account_id=account_id), self.assertRaises(DomainError):
                self.app.validate_stakeholder_account(envelope, actor)

    def test_scoped_manager_cannot_enumerate_hidden_account_ids(self):
        manager = {'id': 'project-manager', 'role': 'manager', 'project_ids': ['PRJ-ONE']}
        envelope = {'type': 'shared.create', 'payload': {
            'collection': 'stakeholders', 'project_id': 'PRJ-ONE', 'account_id': ''}}
        codes = []
        for account_id in ('other-manager', 'missing-account', 'no-project'):
            envelope['payload']['account_id'] = account_id
            with self.subTest(account_id=account_id), self.assertRaises(DomainError) as failure:
                self.app.validate_stakeholder_account(envelope, manager)
            codes.append(failure.exception.code)
        self.assertEqual(codes, ['account_unavailable'] * 3)
        envelope['payload']['project_id'] = 'PRJ-OTHER'
        for account_id in ('other-manager', 'missing-account'):
            envelope['payload']['account_id'] = account_id
            with self.subTest(project='hidden', account_id=account_id), self.assertRaises(DomainError) as failure:
                self.app.validate_stakeholder_account(envelope, manager)
            self.assertEqual(failure.exception.code, 'project_scope_required')

    def test_permit_approval_account_must_exist_and_have_required_role(self):
        actor = {'id': 'root', 'role': 'admin'}
        project = self.store.command('shared.create', {'collection': 'projects', 'name': 'اختبار'}, actor)['result']
        stakeholder = self.store.command('shared.create', {'collection': 'stakeholders',
            'project_id': project['id'], 'name': 'أمن الموقع', 'role': 'authority', 'account_id': 'site-security'}, actor)['result']
        envelope = {'type': 'permit.create', 'payload': {'approval_steps': [
            {'stakeholder_id': stakeholder['id'], 'role': 'security'}]}}
        self.app.validate_permit_accounts(envelope)
        envelope['payload']['approval_steps'][0]['role'] = 'manager'
        with self.assertRaises(DomainError):
            self.app.validate_permit_accounts(envelope)

    def test_existing_stakeholder_account_binding_is_checked_and_audited(self):
        actor = {'id': 'root', 'role': 'admin'}
        project = self.store.command('shared.create', {'collection':'projects', 'name':'Project'}, actor)['result']
        stakeholder = self.store.command('shared.create', {'collection':'stakeholders',
            'project_id':project['id'], 'name':'Receiving authority'}, actor)['result']
        envelope = {'type':'stakeholder.bind_account', 'payload':{
            'id':stakeholder['id'], 'account_id':'site-security', 'reason':'Authority appointed representative'}}
        self.app.validate_stakeholder_account(envelope, actor)
        updated = self.store.command('stakeholder.bind_account', envelope['payload'], actor)['result']
        self.assertEqual(updated['account_id'], 'site-security')
        self.assertEqual(updated['account_history'][-1]['actor_id'], 'root')
        self.assertEqual(updated['account_history'][-1]['reason'], 'Authority appointed representative')
        with self.assertRaises(DomainError):
            self.store.command('stakeholder.bind_account', {'id':stakeholder['id'],
                'account_id':'other-manager', 'reason':'Unauthorized'}, {'id':'manager','role':'manager'})
        envelope['payload']['account_id'] = 'other-manager'
        with self.assertRaises(DomainError):
            self.app.validate_stakeholder_account(envelope, actor)


if __name__ == '__main__':
    unittest.main()

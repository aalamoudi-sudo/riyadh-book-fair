import importlib.util
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
spec = importlib.util.spec_from_file_location('database_backup', Path(__file__).resolve().parents[1] / 'scripts/database_backup.py')
backup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backup)


class BackupTests(unittest.TestCase):
    def test_snapshot_and_restore_preserve_records_and_clear_sessions(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'source.sqlite'
            store = DomainStore(source)
            actor = {'id': 'qa', 'role': 'admin'}
            store.command('shared.create', {'collection': 'projects', 'name': 'اختبار نسخة'}, actor)
            with store.connect() as db:
                db.execute('INSERT INTO sessions VALUES(?,?,?)', ('test-token', 'qa', 9999999999))
            snapshot = Path(folder) / 'backup.sqlite'
            backup.copy_database(source, snapshot)
            restored = Path(folder) / 'restored.sqlite'
            backup.copy_database(snapshot, restored, restore=True)
            self.assertEqual(backup.verify(restored)['revision'], 1)
            with sqlite3.connect(restored) as db:
                self.assertEqual(db.execute('SELECT count(*) FROM records').fetchone()[0], 1)
                self.assertEqual(db.execute('SELECT count(*) FROM audit').fetchone()[0], 1)
                self.assertEqual(db.execute('SELECT count(*) FROM sessions').fetchone()[0], 0)
            with self.assertRaises(ValueError):
                backup.copy_database(source, restored)

    def test_rejects_non_project_database(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / 'unrelated.sqlite'
            with sqlite3.connect(file) as db:
                db.execute('CREATE TABLE unrelated(id INT)')
            with self.assertRaises(ValueError):
                backup.verify(file)

    def test_automatic_snapshots_rotate_after_verified_commits(self):
        from backup_service import BackupService
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'source.sqlite'
            store = DomainStore(source)
            actor = {'id': 'qa', 'role': 'admin'}
            service = BackupService(source, Path(folder) / 'backups', interval_seconds=3600, keep=2)
            for index in range(3):
                store.command('shared.create', {'collection': 'projects', 'name': f'مشروع {index}'}, actor)
                status = service.snapshot()
                self.assertEqual(status['latest_revision'], index + 1)
                self.assertIsNone(status['last_error'])
            files = list((Path(folder) / 'backups').glob('rbf-*.sqlite'))
            self.assertEqual(len(files), 2)
            self.assertEqual(status['retained'], 2)
            self.assertEqual(status['location'], 'same_disk')
            self.assertFalse(status['offsite_configured'])
            self.assertEqual(backup.verify(files[0])['integrity'], 'ok')

    def test_snapshot_does_not_duplicate_unchanged_revision(self):
        from backup_service import BackupService
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'source.sqlite'
            DomainStore(source)
            service = BackupService(source, Path(folder) / 'backups', interval_seconds=3600, keep=2)
            first = service.snapshot()
            second = service.snapshot()
            self.assertEqual(first['retained'], 1)
            self.assertEqual(second['retained'], 1)


if __name__ == '__main__':
    unittest.main()

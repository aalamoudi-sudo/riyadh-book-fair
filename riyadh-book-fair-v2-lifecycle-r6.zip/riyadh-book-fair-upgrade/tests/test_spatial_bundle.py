from pathlib import Path
import sys
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.spatial.package_converter import FILES, HERE, TARGET


class SpatialBundleTests(unittest.TestCase):
    def test_downloadable_bundle_contains_current_converter_and_guide(self):
        self.assertTrue(TARGET.is_file(), 'رابط التنزيل يتطلب حزمة منشورة')
        with zipfile.ZipFile(TARGET) as archive:
            self.assertEqual(tuple(archive.namelist()), FILES)
            for name in FILES:
                self.assertEqual(archive.read(name), (HERE / name).read_bytes(), name)
            self.assertIsNone(archive.testzip())


if __name__ == '__main__':
    unittest.main()

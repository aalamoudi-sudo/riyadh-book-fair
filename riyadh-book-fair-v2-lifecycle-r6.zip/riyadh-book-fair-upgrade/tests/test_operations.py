import base64
import tempfile
import threading
from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore, DomainError

ADMIN = {'id': 'operations-manager', 'role': 'manager'}
FIELD = {'id': 'operations-field', 'role': 'field'}


class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = DomainStore(Path(self.temp.name) / 'operations.sqlite')
        self.project = self.cmd('shared.create', collection='projects', name='Daily operations')
        self.phase = self.cmd('shared.create', collection='phases', name='Operations', kind='operations', project_id=self.project['id'])
        self.zone = self.cmd('shared.create', collection='zones', name='Hall A', project_id=self.project['id'])
        self.other_zone = self.cmd('shared.create', collection='zones', name='Hall B', project_id=self.project['id'])
        self.owner = self.cmd('shared.create', collection='stakeholders', name='Zone manager', project_id=self.project['id'])

    def tearDown(self):
        self.temp.cleanup()

    def cmd(self, command_type, actor=ADMIN, **payload):
        return self.store.command(command_type, payload, actor)['result']

    def opening(self, **extra):
        result = {'project_id': self.project['id'], 'phase_id': self.phase['id'], 'zone_id': self.zone['id'],
                  'responsible_id': self.owner['id'], 'operational_date': '2026-09-23',
                  'readiness': [{'id': 'doors', 'label': 'Doors clear', 'status': 'ready'}], 'evidence': 'Opening signed record'}
        result.update(extra)
        return result

    def open_report(self, **extra):
        return self.cmd('daily.open', **self.opening(**extra))

    def close_report(self, report, **extra):
        return self.cmd('daily.close', id=report['id'], evidence='End of day record', summary='Day summary', **extra)

    def handover(self, **extra):
        result = {'handover_responsible_id': self.owner['id'], 'handover_due_at': '2026-09-24T10:00:00+03:00',
                  'handover_notes': 'Follow up the listed work on the next shift'}
        result.update(extra)
        return result

    def assert_code(self, code, callback):
        with self.assertRaises(DomainError) as caught:
            callback()
        self.assertEqual(caught.exception.code, code)

    def incident(self, priority='medium', zone_id=None):
        return self.cmd('incident.create', title='Outstanding incident', description='Requires action',
                        project_id=self.project['id'], zone_id=zone_id or self.zone['id'], priority=priority)

    def test_open_requires_structured_readiness_notes_and_valid_date(self):
        for readiness in [[], [{'id': 'x', 'label': 'Missing', 'status': 'issue'}],
                          [{'id': 'x', 'label': 'One', 'status': 'ready'}, {'id': 'x', 'label': 'Two', 'status': 'ready'}],
                          [{'id': 'x', 'label': 'Invalid', 'status': 'unknown'}]]:
            with self.assertRaises(DomainError): self.open_report(readiness=readiness)
        for date in ['2026-02-30', '20260923', '23/09/2026']:
            self.assert_code('invalid_operational_date', lambda: self.open_report(operational_date=date))
        for missing in ['phase_id', 'zone_id', 'responsible_id', 'evidence']:
            with self.assertRaises(DomainError): self.open_report(**{missing: ''})
        report = self.open_report(readiness=[{'id': 'lighting', 'label': 'Lighting', 'status': 'issue', 'notes': 'Repair request is being recorded'}])
        self.assertEqual(report['status'], 'open')
        self.assertEqual(report['readiness'][0]['notes'], 'Repair request is being recorded')
        self.assertEqual(report['opening_evidence'], 'Opening signed record')

    def test_duplicate_open_is_atomic_even_with_concurrent_requests(self):
        barrier = threading.Barrier(2)
        outcomes = []
        def run():
            barrier.wait()
            try: outcomes.append(self.open_report()['status'])
            except DomainError as error: outcomes.append(error.code)
        threads = [threading.Thread(target=run) for _ in range(2)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertCountEqual(outcomes, ['open', 'daily_already_open'])
        self.assertEqual(len(self.store.state()['daily_reports']), 1)
        self.open_report(zone_id=self.other_zone['id'])
        self.open_report(operational_date='2026-09-24')

    def test_only_manager_closes_and_terminal_close_cannot_repeat(self):
        report = self.cmd('daily.open', actor=FIELD, **self.opening())
        self.assert_code('forbidden', lambda: self.cmd('daily.close', actor=FIELD, id=report['id'], evidence='Attempt', summary='No authority'))
        closed = self.close_report(report)
        self.assertEqual(closed['status'], 'closed')
        self.assertEqual(closed['closed_by'], ADMIN['id'])
        self.assertEqual(closed['closure_snapshot']['counts']['total'], 0)
        self.assert_code('invalid_transition', lambda: self.close_report(report))
        # A second shift for the same operational day is allowed once the first is closed.
        next_report = self.open_report()
        self.assertNotEqual(next_report['id'], report['id'])

    def test_critical_incident_blocks_daily_close_without_partial_changes(self):
        report = self.open_report()
        self.incident(priority='critical')
        revision = self.store.state()['revision']
        self.assert_code('critical_incident_open', lambda: self.close_report(report, **self.handover()))
        state = self.store.state()
        self.assertEqual(state['daily_reports'][0]['status'], 'open')
        self.assertIsNone(state['daily_reports'][0]['closure_snapshot'])
        self.assertEqual(state['revision'], revision)

    def test_snapshot_handover_preserves_open_work_and_is_immutable_after_changes(self):
        report = self.open_report()
        task = self.cmd('task.create', title='Remaining setup', project_id=self.project['id'], zone_id=self.zone['id'], inspection_required=False)
        incident = self.incident()
        support = self.cmd('support.create', project_id=self.project['id'], title='Outgoing support', from_zone_id=self.zone['id'],
                           to_zone_id=self.other_zone['id'], responsible_id=self.owner['id'], needed_by='2026-09-24T12:00:00+03:00', reason='Next hall needs a team')
        self.assert_code('handover_required', lambda: self.close_report(report))
        self.assert_code('handover_required', lambda: self.close_report(report, handover_responsible_id=self.owner['id']))
        closed = self.close_report(report, **self.handover())
        self.assertEqual(closed['closure_snapshot']['counts'], {'tasks': 1, 'incidents': 1, 'support_requests': 1, 'total': 3, 'critical_incidents': 0, 'readiness_issues': 0})
        state = self.store.state()
        self.assertEqual(state['tasks'][0]['status'], 'planned')
        self.assertEqual(state['incidents'][0]['status'], 'open')
        self.assertEqual(state['support_requests'][0]['status'], 'requested')
        self.assertEqual(closed['closure_snapshot']['support_requests'][0]['id'], support['id'])
        self.cmd('task.transition', id=task['id'], status='active')
        self.assertEqual(self.store.state()['daily_reports'][0]['closure_snapshot']['tasks'][0]['status'], 'planned')

    def test_other_zone_critical_incident_is_not_in_this_zone_snapshot(self):
        report = self.open_report()
        self.incident(priority='critical', zone_id=self.other_zone['id'])
        closed = self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['incidents'], [])

    def test_handover_person_must_share_project_and_date_have_timezone(self):
        report = self.open_report()
        self.incident()
        other = self.cmd('shared.create', collection='projects', name='Other project')
        outsider = self.cmd('shared.create', collection='stakeholders', project_id=other['id'], name='Unrelated owner')
        self.assert_code('project_mismatch', lambda: self.close_report(report, **self.handover(handover_responsible_id=outsider['id'])))
        with self.assertRaises(DomainError): self.close_report(report, **self.handover(handover_due_at='2026-09-24T10:00:00'))
        self.assertEqual(self.store.state()['daily_reports'][0]['status'], 'open')

    def test_project_close_requires_daily_closure_and_closed_project_rejects_open(self):
        report = self.open_report()
        blockers = self.store.state()['closeout'][0]['blockers']
        self.assertIn('open_daily_reports', [x['code'] for x in blockers])
        self.assert_code('closeout_blocked', lambda: self.cmd('project.close', id=self.project['id'], evidence='Premature', summary='Not ready'))
        self.close_report(report)
        self.cmd('project.close', id=self.project['id'], evidence='Accepted', summary='Daily report closed')
        self.assert_code('project_closed', lambda: self.open_report(operational_date='2026-09-24'))

    def test_project_scopes_cover_state_open_and_close(self):
        report = self.open_report()
        other = self.cmd('shared.create', collection='projects', name='Other')
        restricted = {**ADMIN, 'project_ids': [other['id']]}
        self.assertEqual(self.store.state(restricted)['daily_reports'], [])
        self.assert_code('project_scope_required', lambda: self.cmd('daily.open', actor=restricted, **self.opening(operational_date='2026-09-24')))
        self.assert_code('project_scope_required', lambda: self.cmd('daily.close', actor=restricted, id=report['id'], evidence='Unallowed', summary='No access'))

    def issue_report(self):
        return self.open_report(readiness=[{'id':'lighting','label':'Lighting check','status':'issue','notes':'One circuit requires repair'}])

    def test_opening_issues_require_exactly_one_followup_each(self):
        report=self.issue_report();revision=self.store.state()['revision']
        self.assert_code('readiness_followup_required',lambda:self.close_report(report))
        self.assertEqual(self.store.state()['revision'],revision)
        for values in [[{'id':'unknown','status':'resolved','notes':'Wrong item'}],
                       [{'id':'lighting','status':'resolved','notes':'Fixed'},{'id':'lighting','status':'resolved','notes':'Duplicate'}],
                       [{'id':'lighting','status':'resolved','notes':''}]]:
            with self.assertRaises(DomainError): self.close_report(report,readiness_followup=values)
        self.assertEqual(self.store.state()['daily_reports'][0]['status'],'open')

    def test_resolved_opening_issue_records_closing_evidence_without_handover(self):
        report=self.issue_report()
        closed=self.close_report(report,readiness_followup=[{'id':'lighting','status':'resolved','notes':'Circuit repaired and retested'}])
        self.assertEqual(closed['readiness_followup'][0]['evidence'],'End of day record')
        self.assertEqual(closed['readiness_followup'][0]['notes'],'Circuit repaired and retested')
        self.assertEqual(closed['closure_snapshot']['readiness_issues'],[])
        self.assertEqual(closed['closure_snapshot']['counts']['total'],0)

    def test_carried_opening_issue_requires_handover_and_appears_in_snapshot(self):
        report=self.issue_report()
        followup=[{'id':'lighting','status':'carryover','notes':'Waiting for a spare circuit'}]
        self.assert_code('handover_required',lambda:self.close_report(report,readiness_followup=followup))
        closed=self.close_report(report,readiness_followup=followup,**self.handover())
        self.assertEqual(closed['closure_snapshot']['counts']['readiness_issues'],1)
        self.assertEqual(closed['closure_snapshot']['counts']['total'],1)
        self.assertEqual(closed['closure_snapshot']['readiness_issues'][0]['id'],'lighting')
        self.assertEqual(closed['handover_responsible_id'],self.owner['id'])

    def test_other_project_critical_incident_does_not_block_zone_closure(self):
        report=self.open_report()
        other=self.cmd('shared.create',collection='projects',name='Other project')
        other_zone=self.cmd('shared.create',collection='zones',project_id=other['id'],name='Other hall')
        self.cmd('incident.create',title='Other project critical',description='Different operational scope',project_id=other['id'],zone_id=other_zone['id'],priority='critical')
        closed=self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['counts']['critical_incidents'],0)
        self.assertEqual(closed['closure_snapshot']['incidents'],[])

    def test_older_open_critical_incident_remains_blocking(self):
        report=self.open_report()
        self.cmd('incident.create',title='Unresolved old danger',description='Age does not resolve a risk',project_id=self.project['id'],zone_id=self.zone['id'],priority='critical',observed_at='2020-01-01T08:00:00+03:00')
        self.assert_code('critical_incident_open',lambda:self.close_report(report,**self.handover()))

    def resolve_incident(self,incident):
        self.cmd('incident.transition',id=incident['id'],status='assigned',responsible_id=self.owner['id'])
        self.cmd('incident.decision',incident_id=incident['id'],decision='Secure the area',action='Remove the danger',impact='Area checked',impact_type='observed',evidence='Safety inspection')
        self.cmd('incident.transition',id=incident['id'],status='resolved',evidence='Resolved risk')

    def test_closed_critical_incident_does_not_block_daily_close(self):
        report=self.open_report();incident=self.incident(priority='critical')
        self.resolve_incident(incident)
        self.cmd('incident.transition',id=incident['id'],status='closed',evidence='Final acceptance')
        closed=self.close_report(report)
        self.assertEqual(closed['closure_snapshot']['counts']['total'],0)
        self.assertEqual(self.store.state()['incidents'][0]['status'],'closed')

    def test_resolved_critical_incident_requires_handover_but_is_not_reclosed(self):
        report=self.open_report();incident=self.incident(priority='critical')
        self.resolve_incident(incident)
        self.assert_code('handover_required',lambda:self.close_report(report))
        closed=self.close_report(report,**self.handover())
        self.assertEqual(closed['closure_snapshot']['counts']['critical_incidents'],0)
        self.assertEqual(closed['closure_snapshot']['counts']['incidents'],1)
        self.assertEqual(self.store.state()['incidents'][0]['status'],'resolved')

    def test_attachment_can_link_to_daily_report(self):
        report = self.open_report()
        attachment = self.cmd('attachment.create', project_id=self.project['id'], record_collection='daily_reports', record_id=report['id'],
                              filename='daily.pdf', content_type='application/pdf', data_base64=base64.b64encode(b'%PDF-1.4\n%%EOF').decode())
        self.assertEqual(attachment['record_id'], report['id'])
        self.assertEqual(self.store.attachment_read(ADMIN, attachment['id'])['content'], b'%PDF-1.4\n%%EOF')

    def test_phase_handoff_requires_clear_source_and_independent_acceptance(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        receiver = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'],
                            name='Operations receiver', account_id='second-manager')
        task = self.cmd('task.create', title='Complete hall build', project_id=self.project['id'],
                        phase_id=build['id'], zone_id=self.zone['id'], inspection_required=False)
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': build['id'], 'to_phase_id': self.phase['id'],
                   'recipient_id': receiver['id'],
                   'evidence': 'Build completion dossier'}
        revision = self.store.state()['revision']
        self.assert_code('phase_handoff_blocked', lambda: self.cmd('phase_handoff.create', **payload))
        self.assertEqual(self.store.state()['revision'], revision)
        self.cmd('task.transition', id=task['id'], status='active')
        self.cmd('task.transition', id=task['id'], status='completed', evidence='Hall accepted')
        handoff = self.cmd('phase_handoff.create', **payload)
        self.assertEqual(handoff['status'], 'pending')
        self.assertEqual(handoff['request_snapshot']['tasks'], [])
        self.assert_code('duplicate_handoff', lambda: self.cmd('phase_handoff.create', **payload))
        self.assert_code('second_approver_required', lambda: self.cmd('phase_handoff.accept', id=handoff['id'], evidence='Self acceptance'))
        late_task = self.cmd('task.create', title='Late build fix', project_id=self.project['id'],
                             phase_id=build['id'], zone_id=self.zone['id'], inspection_required=False)
        other_manager = {'id': 'second-manager', 'role': 'manager'}
        self.assert_code('phase_handoff_blocked', lambda: self.cmd('phase_handoff.accept', actor=other_manager, id=handoff['id'], evidence='Premature'))
        self.cmd('task.transition', id=late_task['id'], status='active')
        self.cmd('task.transition', id=late_task['id'], status='completed', evidence='Fixed')
        accepted = self.cmd('phase_handoff.accept', actor=other_manager, id=handoff['id'], evidence='Operations acceptance record')
        self.assertEqual(accepted['status'], 'accepted')
        self.assertEqual(accepted['accepted_by'], other_manager['id'])
        self.assertEqual(accepted['acceptance_snapshot']['tasks'], [])
        self.assert_code('invalid_transition', lambda: self.cmd('phase_handoff.accept', actor=other_manager, id=handoff['id'], evidence='Again'))
        self.assert_code('phase_already_handed_over', lambda: self.cmd('task.create', title='Late build task',
                         project_id=self.project['id'], phase_id=build['id'], zone_id=self.zone['id']))
        self.assert_code('phase_required_after_handoff', lambda: self.cmd('task.create', title='Unphased task',
                         project_id=self.project['id'], zone_id=self.zone['id']))

    def test_phase_handoff_blocks_open_daily_report_and_critical_incident(self):
        dismantling = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Dismantling', kind='dismantling')
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': self.phase['id'], 'to_phase_id': dismantling['id'],
                   'recipient_id': self.owner['id'], 'evidence': 'Operations handover'}
        report = self.open_report()
        self.assert_code('phase_handoff_blocked', lambda: self.cmd('phase_handoff.create', **payload))
        self.close_report(report)
        incident = self.incident(priority='critical')
        self.assert_code('phase_handoff_blocked', lambda: self.cmd('phase_handoff.create', **payload))
        self.resolve_incident(incident)
        self.assert_code('phase_handoff_blocked', lambda: self.cmd('phase_handoff.create', **payload))
        self.cmd('incident.transition', id=incident['id'], status='closed', evidence='Final safety acceptance')
        self.assertEqual(self.cmd('phase_handoff.create', **payload)['status'], 'pending')

    def test_phase_handoff_uses_linked_stakeholder_account(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        receiver = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'],
                            name='Operations receiving team', account_id='warehouse-receiver')
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': build['id'], 'to_phase_id': self.phase['id'],
                   'recipient_id': receiver['id'], 'evidence': 'Prepared handover'}
        self.assert_code('recipient_account_mismatch', lambda: self.cmd('phase_handoff.create',
            **{**payload, 'recipient_account_id': 'wrong-account'}))
        record = self.cmd('phase_handoff.create', **payload)
        self.assertEqual(record['recipient_account_id'], 'warehouse-receiver')
        self.assert_code('recipient_account_required', lambda: self.cmd('phase_handoff.accept',
            actor={'id': 'another-warehouse', 'role': 'warehouse'}, id=record['id'], evidence='Not authorized'))
        accepted = self.cmd('phase_handoff.accept', actor={'id': 'warehouse-receiver', 'role': 'warehouse'},
                            id=record['id'], evidence='Signed warehouse receiving record')
        self.assertEqual(accepted['acceptance_mode'], 'recipient_account')
        self.assertEqual(accepted['accepted_by'], 'warehouse-receiver')

    def test_rebinding_receiver_revokes_old_handoff_signature(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        receiver = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'],
                            name='Operations receiving team', account_id='old-receiver')
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': build['id'], 'to_phase_id': self.phase['id'],
                   'recipient_id': receiver['id'], 'evidence': 'Prepared handover'}
        handoff = self.cmd('phase_handoff.create', **payload)
        self.cmd('stakeholder.bind_account', actor={'id': 'root-admin', 'role': 'admin'},
                 id=receiver['id'], account_id='new-receiver', reason='Replace receiving representative')
        self.assert_code('recipient_account_required', lambda: self.cmd('phase_handoff.accept',
            actor={'id': 'old-receiver', 'role': 'warehouse'}, id=handoff['id'], evidence='Former receiver'))
        accepted = self.cmd('phase_handoff.accept', actor={'id': 'new-receiver', 'role': 'warehouse'},
                            id=handoff['id'], evidence='Current receiver signed')
        self.assertEqual(accepted['accepted_by'], 'new-receiver')
        self.assertEqual(accepted['recipient_account_id'], 'new-receiver')
        self.assertEqual(accepted['requested_recipient_account_id'], 'old-receiver')

    def test_rebound_handoff_admin_override_requires_reason(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        receiver = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'],
                            name='Operations receiving team', account_id='old-receiver')
        handoff = self.cmd('phase_handoff.create', project_id=self.project['id'], zone_id=self.zone['id'],
                           from_phase_id=build['id'], to_phase_id=self.phase['id'],
                           recipient_id=receiver['id'], evidence='Prepared handover')
        self.cmd('stakeholder.bind_account', actor={'id': 'root-admin', 'role': 'admin'},
                 id=receiver['id'], account_id='new-receiver', reason='Replace receiving representative')
        override = {'id': 'other-admin', 'role': 'admin'}
        with self.assertRaises(DomainError):
            self.cmd('phase_handoff.accept', actor=override, id=handoff['id'], evidence='Override')
        accepted = self.cmd('phase_handoff.accept', actor=override, id=handoff['id'], evidence='Override',
                            override_reason='Current receiver unavailable')
        self.assertEqual(accepted['acceptance_mode'], 'admin_override')
        self.assertEqual(accepted['recipient_account_id'], 'new-receiver')
        self.assertEqual(accepted['requested_recipient_account_id'], 'old-receiver')

    def test_unbound_handoff_cannot_assign_an_arbitrary_receiver_account(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': build['id'], 'to_phase_id': self.phase['id'],
                   'recipient_id': self.owner['id'], 'evidence': 'Build completion memo'}
        self.assert_code('recipient_account_mismatch', lambda: self.cmd('phase_handoff.create',
            **{**payload, 'recipient_account_id': 'unrelated-account'}))
        handoff = self.cmd('phase_handoff.create', **payload)
        self.assertFalse(handoff['recipient_account_id'])
        self.assert_code('recipient_account_required', lambda: self.cmd('phase_handoff.accept',
            actor={'id':'unrelated-account','role':'field'}, id=handoff['id'], evidence='False signature'))

    def test_closeout_requires_each_used_dismantling_phase_to_handoff(self):
        first = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Dismantle A', kind='dismantling')
        second = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Dismantle B', kind='dismantling')
        closeout = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Closeout', kind='closeout')
        base = {'project_id':self.project['id'], 'zone_id':self.zone['id'], 'recipient_id':self.owner['id'], 'evidence':'Handover memo'}
        other = {'id':'other-admin','role':'admin'}
        for phase in (first, second):
            entering = self.cmd('phase_handoff.create', **base, from_phase_id=self.phase['id'], to_phase_id=phase['id'])
            self.cmd('phase_handoff.accept', actor=other, id=entering['id'], evidence='Accepted', override_reason='No account linked')
        task = self.cmd('task.create', title='Remove equipment B', project_id=self.project['id'],
                        phase_id=second['id'], zone_id=self.zone['id'], inspection_required=False)
        self.cmd('task.transition', id=task['id'], status='active')
        self.cmd('task.transition', id=task['id'], status='completed', evidence='Finished')
        handoff = self.cmd('phase_handoff.create', **base, from_phase_id=first['id'], to_phase_id=closeout['id'])
        self.cmd('phase_handoff.accept', actor=other, id=handoff['id'], evidence='Accepted', override_reason='No account linked')
        blocker = next(row for row in self.store.state()['closeout'][0]['blockers'] if row['code']=='final_phase_handoff_required')
        self.assertIn(self.zone['id']+':'+second['id'], blocker['ids'])
        self.assert_code('closeout_blocked', lambda: self.cmd('project.close', id=self.project['id'], evidence='Closeout', summary='Complete'))
        last = self.cmd('phase_handoff.create', **base, from_phase_id=second['id'], to_phase_id=closeout['id'])
        self.cmd('phase_handoff.accept', actor=other, id=last['id'], evidence='Accepted', override_reason='No account linked')
        self.assertNotIn('final_phase_handoff_required', [row['code'] for row in self.store.state()['closeout'][0]['blockers']])

    def test_phase_handoff_chain_and_admin_proxy_reason(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        teardown = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Teardown', kind='dismantling')
        closeout = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Closeout', kind='closeout')
        base = {'project_id': self.project['id'], 'zone_id': self.zone['id'], 'recipient_id': self.owner['id'], 'evidence': 'Stage readiness'}
        self.assert_code('prior_handoff_required', lambda: self.cmd('phase_handoff.create', **base,
            from_phase_id=self.phase['id'], to_phase_id=teardown['id']))
        first = self.cmd('phase_handoff.create', **base, from_phase_id=build['id'], to_phase_id=self.phase['id'])
        self.assert_code('recipient_account_required', lambda: self.cmd('phase_handoff.accept', actor={'id':'other-manager','role':'manager'},
            id=first['id'], evidence='Attempt without linked account'))
        self.assert_code('validation', lambda: self.cmd('phase_handoff.accept', actor={'id':'other-admin','role':'admin'},
            id=first['id'], evidence='Proxy without reason'))
        accepted = self.cmd('phase_handoff.accept', actor={'id':'other-admin','role':'admin'}, id=first['id'],
                            evidence='Proxy acceptance', override_reason='Recipient has no platform account')
        self.assertEqual(accepted['acceptance_mode'], 'admin_override')
        self.assertEqual(accepted['override_reason'], 'Recipient has no platform account')
        second = self.cmd('phase_handoff.create', **base, from_phase_id=self.phase['id'], to_phase_id=teardown['id'])
        self.assertEqual(second['status'], 'pending')
        self.assert_code('prior_handoff_required', lambda: self.cmd('phase_handoff.create', **base,
            from_phase_id=teardown['id'], to_phase_id=closeout['id']))
        self.cmd('phase_handoff.accept', actor={'id':'other-admin','role':'admin'}, id=second['id'],
                 evidence='Proxy acceptance', override_reason='Recipient has no platform account')
        self.assertEqual(self.cmd('phase_handoff.create', **base, from_phase_id=teardown['id'],
                                  to_phase_id=closeout['id'])['status'], 'pending')

    def test_active_zone_project_close_requires_accepted_final_handoff(self):
        teardown = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Teardown', kind='dismantling')
        closeout = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Closeout', kind='closeout')
        task = self.cmd('task.create', title='Remove hall equipment', project_id=self.project['id'],
                        phase_id=teardown['id'], zone_id=self.zone['id'], inspection_required=False)
        self.cmd('task.transition', id=task['id'], status='active')
        self.cmd('task.transition', id=task['id'], status='completed', evidence='Teardown accepted')
        blockers = [row['code'] for row in self.store.state()['closeout'][0]['blockers']]
        self.assertIn('final_phase_handoff_required', blockers)
        self.assert_code('closeout_blocked', lambda: self.cmd('project.close', id=self.project['id'],
                                                            evidence='Premature', summary='No final acceptance'))
        base = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                'recipient_id': self.owner['id'], 'evidence': 'Stage handover'}
        operations_handoff = self.cmd('phase_handoff.create', **base, from_phase_id=self.phase['id'],
                                       to_phase_id=teardown['id'])
        proxy = {'id': 'second-admin', 'role': 'admin'}
        self.cmd('phase_handoff.accept', actor=proxy, id=operations_handoff['id'],
                 evidence='Received teardown area', override_reason='No linked recipient account')
        final = self.cmd('phase_handoff.create', **base, from_phase_id=teardown['id'], to_phase_id=closeout['id'])
        self.assertIn('pending_phase_handoffs', [row['code'] for row in self.store.state()['closeout'][0]['blockers']])
        self.cmd('phase_handoff.accept', actor=proxy, id=final['id'], evidence='Final zone acceptance',
                 override_reason='No linked recipient account')
        self.assertNotIn('final_phase_handoff_required', [row['code'] for row in self.store.state()['closeout'][0]['blockers']])
        self.assertEqual(self.cmd('project.close', id=self.project['id'],
                                  evidence='Final acceptance dossier', summary='Teardown and closeout signed')['status'], 'closed')

    def test_withdrawn_handoff_can_be_replaced_and_manifest_cancelled(self):
        build = self.cmd('shared.create', collection='phases', project_id=self.project['id'], name='Build', kind='build')
        payload = {'project_id': self.project['id'], 'zone_id': self.zone['id'],
                   'from_phase_id': build['id'], 'to_phase_id': self.phase['id'],
                   'recipient_id': self.owner['id'], 'evidence': 'First readiness record'}
        first = self.cmd('phase_handoff.create', **payload)
        self.assert_code('forbidden', lambda: self.cmd('phase_handoff.withdraw', actor={'id':'other-manager','role':'manager'},
            id=first['id'], reason='Not my request', evidence='Attempt'))
        self.assertEqual(self.cmd('phase_handoff.withdraw', id=first['id'], reason='Scope changed',
                                  evidence='Withdrawal memo')['status'], 'withdrawn')
        self.assertNotEqual(self.cmd('phase_handoff.create', **payload)['id'], first['id'])
        publisher = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Publisher')
        item = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book', owner_id=publisher['id'])
        manifest = {'project_id': self.project['id'], 'zone_id': self.zone['id'], 'publisher_id': publisher['id'],
                    'direction': 'inbound', 'document_reference': 'MANIFEST-1', 'evidence': 'Packing list',
                    'lines': [{'item_id': item['id'], 'qty': 3}]}
        first_manifest = self.cmd('book_shipment.create', **manifest)
        self.assertEqual(self.cmd('book_shipment.cancel', id=first_manifest['id'], reason='Wrong date',
                                  evidence='Cancellation memo')['status'], 'cancelled')
        self.assertEqual(self.store.state()['stock'], [])

    def test_book_shipment_receipts_and_return_change_stock_once(self):
        publisher = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Publisher')
        other_publisher = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Other publisher')
        first = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book One', owner_id=publisher['id'])
        second = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book Two', owner_id=publisher['id'])
        wrong = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Wrong publisher book', owner_id=other_publisher['id'])
        manifest = {'project_id': self.project['id'], 'zone_id': self.zone['id'], 'publisher_id': publisher['id'],
                    'direction': 'inbound', 'document_reference': 'PUBLISHER-2026-001',
                    'evidence': 'Publisher packing list',
                    'lines': [{'item_id': first['id'], 'qty': 10}, {'item_id': second['id'], 'qty': 5}]}
        self.assert_code('shipment_item_mismatch', lambda: self.cmd('book_shipment.create', **{**manifest, 'lines': [{'item_id': wrong['id'], 'qty': 1}]}))
        incoming = self.cmd('book_shipment.create', **manifest)
        self.assertEqual(self.store.state()['stock'], [])
        self.assert_code('duplicate_shipment_reference', lambda: self.cmd('book_shipment.create', **manifest))
        self.assert_code('receipt_exceeds_manifest', lambda: self.cmd('book_shipment.receive', id=incoming['id'],
            receiver_name='Warehouse team', evidence='Bad receipt', actual_lines=[{'item_id': first['id'], 'received_qty': 11}, {'item_id': second['id'], 'received_qty': 5}]))
        receipt = self.cmd('book_shipment.receive', id=incoming['id'], receiver_name='Warehouse team',
            evidence='Signed receiving record', difference_reason='Three copies missing and five damaged',
            actual_lines=[{'item_id': first['id'], 'received_qty': 7}, {'item_id': second['id'], 'received_qty': 0}])
        self.assertEqual(receipt['status'], 'discrepancy')
        self.assertEqual(next(s['on_hand'] for s in self.store.state()['stock'] if s['item_id']==first['id']), 7)
        self.assertFalse(any(s['item_id']==second['id'] for s in self.store.state()['stock']))
        self.assert_code('invalid_transition', lambda: self.cmd('book_shipment.receive', id=incoming['id'], receiver_name='Warehouse team',
            evidence='Again', actual_lines=[{'item_id': first['id'], 'received_qty': 7}, {'item_id': second['id'], 'received_qty': 0}]))
        resolved = self.cmd('book_shipment.resolve', id=incoming['id'], reason='Publisher accepted shortage', evidence='Discrepancy closure memo')
        self.assertEqual(resolved['status'], 'resolved')
        outgoing = self.cmd('book_shipment.create', **{**manifest, 'direction': 'publisher_return',
            'document_reference': 'RETURN-001', 'lines': [{'item_id': first['id'], 'qty': 4}]})
        self.assertEqual(next(s['on_hand'] for s in self.store.state()['stock'] if s['item_id']==first['id']), 7)
        dispatched = self.cmd('book_shipment.dispatch', id=outgoing['id'], carrier='Local carrier',
                              tracking_number='TRACK-001', evidence='Carrier handover record')
        self.assertEqual(dispatched['status'], 'shipped')
        self.assertEqual(next(s['on_hand'] for s in self.store.state()['stock'] if s['item_id']==first['id']), 3)
        self.assert_code('invalid_transition', lambda: self.cmd('book_shipment.dispatch', id=outgoing['id'], carrier='Local carrier',
                              tracking_number='TRACK-001', evidence='Again'))
        delivered = self.cmd('book_shipment.receive', id=outgoing['id'], receiver_name='Publisher receiver',
            evidence='Publisher receipt', actual_lines=[{'item_id': first['id'], 'received_qty': 4}])
        self.assertEqual(delivered['status'], 'received')
        self.assertEqual(next(s['on_hand'] for s in self.store.state()['stock'] if s['item_id']==first['id']), 3)

    def test_book_inbound_and_return_cannot_bypass_manifest(self):
        publisher = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Publisher')
        item = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book', owner_id=publisher['id'])
        self.assert_code('book_shipment_required', lambda: self.cmd('stock.move', action='receipt',
            item_id=item['id'], zone_id=self.zone['id'], qty=3, evidence='Unlinked receipt'))
        self.assert_code('book_shipment_required', lambda: self.cmd('stock.move', action='ship',
            item_id=item['id'], zone_id=self.zone['id'], qty=1, evidence='Unlinked return'))
        self.assert_code('book_shipment_required', lambda: self.cmd('procurement.create', project_id=self.project['id'],
            item_id=item['id'], supplier_id=publisher['id'], zone_id=self.zone['id'], qty=3))
        self.assertEqual(self.store.state()['book_shipments'], [])

    def test_book_shipment_dispatch_rolls_back_all_lines_on_shortfall(self):
        publisher = self.cmd('shared.create', collection='stakeholders', project_id=self.project['id'], name='Publisher')
        first = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book One', owner_id=publisher['id'])
        second = self.cmd('item.create', project_id=self.project['id'], kind='book', name='Book Two', owner_id=publisher['id'])
        incoming = self.cmd('book_shipment.create', project_id=self.project['id'], zone_id=self.zone['id'],
            publisher_id=publisher['id'], direction='inbound', document_reference='IN-ROLLBACK', evidence='Publisher manifest',
            lines=[{'item_id':first['id'],'qty':5},{'item_id':second['id'],'qty':5}])
        self.cmd('book_shipment.receive', id=incoming['id'], receiver_name='Warehouse', evidence='Signed receipt',
            actual_lines=[{'item_id':first['id'],'received_qty':5},{'item_id':second['id'],'received_qty':5}])
        outgoing = self.cmd('book_shipment.create', project_id=self.project['id'], zone_id=self.zone['id'],
            publisher_id=publisher['id'], direction='publisher_return', document_reference='RETURN-ROLLBACK', evidence='Manifest',
            lines=[{'item_id': first['id'], 'qty': 4}, {'item_id': second['id'], 'qty': 4}])
        competing = self.cmd('book_shipment.create', project_id=self.project['id'], zone_id=self.zone['id'],
            publisher_id=publisher['id'], direction='publisher_return', document_reference='RETURN-OTHER', evidence='Second manifest',
            lines=[{'item_id':second['id'],'qty':3}])
        self.cmd('book_shipment.dispatch', id=competing['id'], carrier='Carrier', tracking_number='OTHER-3', evidence='Dispatch')
        revision = self.store.state()['revision']
        self.assert_code('insufficient_stock', lambda: self.cmd('book_shipment.dispatch', id=outgoing['id'], carrier='Carrier',
                                                               tracking_number='TRACK', evidence='Delivery note'))
        state = self.store.state()
        self.assertEqual(state['revision'], revision)
        self.assertEqual(next(s['on_hand'] for s in state['stock'] if s['item_id']==first['id']), 5)
        self.assertEqual(next(s['on_hand'] for s in state['stock'] if s['item_id']==second['id']), 2)
        self.assertEqual(next(s for s in state['book_shipments'] if s['id']==outgoing['id'])['status'], 'prepared')
        self.assertFalse(any(m['reference']=='book_shipment:'+outgoing['id'] for m in state['stock_moves']))


if __name__ == '__main__':
    unittest.main()

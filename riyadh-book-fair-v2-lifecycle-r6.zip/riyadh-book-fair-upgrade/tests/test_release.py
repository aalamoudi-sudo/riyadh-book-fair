from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.package_release import release_files


class ReleaseContentsTests(unittest.TestCase):
    def test_release_contains_new_runtime_and_converter_without_private_files(self):
        names = {name for _, name in release_files()}
        self.assertIn('backup_service.py', names)
        self.assertIn('app/assets/spatial-converter.zip', names)
        self.assertIn('scripts/spatial/CONVERTER-AR.md', names)
        self.assertNotIn('review/private/production-accounts.json', names)
        self.assertFalse(any(name.startswith('review/private/') or name.endswith(('.sqlite', '.pyc')) for name in names))

"""A synthetic, authenticated pilot of one project from setup to closeout.

The test uses a fresh database and local HTTP server. It never contacts Render,
GitHub, a carrier, a payment provider, or a real authority.
"""
import base64
import datetime as dt
import http.client
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from domain import DomainStore
from server import Application, Handler, Server, hash_password


class ProjectLifecyclePilot(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = DomainStore(Path(self.temp.name) / 'pilot.sqlite')
        self.password = 'synthetic-pilot-password'
        password_hash = hash_password(self.password)
        self.accounts = {
            role: {'id': role, 'name': role, 'username': role, 'role': role,
                   'password_hash': password_hash}
            for role in ('admin', 'manager', 'warehouse', 'security', 'field', 'viewer')
        }
        self.accounts['security_alt'] = {'id': 'security_alt', 'name': 'Unassigned guard',
            'username': 'security_alt', 'role': 'security', 'password_hash': password_hash}
        self.server = Server(('127.0.0.1', 0), Handler)
        self.port = self.server.server_address[1]
        self.origin = f'http://127.0.0.1:{self.port}'
        self.server.app = Application(self.store, self.accounts, host='127.0.0.1',
                                      port=self.port, static_root=self.temp.name)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.cookies = {}
        self.revision = 0

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        self.temp.cleanup()

    def request(self, path, method='GET', data=None, actor=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        headers = {}
        if data is not None:
            headers['Content-Type'] = 'application/json'
        if method == 'POST':
            headers['Origin'] = self.origin
        if actor:
            headers['Cookie'] = self.cookies[actor]
        connection.request(method, path,
                           body=json.dumps(data) if data is not None else None,
                           headers=headers)
        response = connection.getresponse()
        raw = response.read()
        result = response.status, json.loads(raw), dict(response.getheaders())
        connection.close()
        return result

    def login(self, actor):
        status, body, headers = self.request('/api/session/login', 'POST',
            {'username': actor, 'password': self.password})
        self.assertEqual((status, body['authenticated']), (200, True))
        self.cookies[actor] = headers['Set-Cookie'].split(';')[0]

    def command(self, actor, command_type, **payload):
        status, body, _ = self.request('/api/commands', 'POST',
            {'type': command_type, 'payload': payload, 'expected_revision': self.revision}, actor)
        self.assertEqual(status, 200, f'{actor} {command_type}: {body}')
        self.revision = body['revision']
        return body['result']

    def rejected(self, actor, command_type, code, **payload):
        status, body, _ = self.request('/api/commands', 'POST',
            {'type': command_type, 'payload': payload, 'expected_revision': self.revision}, actor)
        self.assertGreaterEqual(status, 400, f'{actor} {command_type} unexpectedly succeeded')
        self.assertEqual(body['code'], code, f'{actor} {command_type}: {body}')
        self.assertEqual(self.store.state()['revision'], self.revision,
                         f'{actor} {command_type} changed data despite rejection')

    def state(self):
        status, body, _ = self.request('/api/state', actor='admin')
        self.assertEqual(status, 200)
        self.assertEqual(body['revision'], self.revision)
        return body

    def test_authenticated_project_lifecycle(self):
        for role in self.accounts:
            self.login(role)
        project = self.command('admin', 'shared.create', collection='projects', name='Synthetic book fair pilot')
        phases = {kind: self.command('manager', 'shared.create', collection='phases',
            project_id=project['id'], kind=kind, name=kind)
            for kind in ('build', 'operations', 'dismantling', 'closeout')}
        zone = self.command('manager', 'shared.create', collection='zones',
                            project_id=project['id'], name='Pilot hall', capacity=100)
        publisher = self.command('manager', 'shared.create', collection='stakeholders',
                                 project_id=project['id'], name='Synthetic publisher')
        recipient = {}
        for role in ('manager', 'warehouse', 'security', 'field', 'admin'):
            recipient[role] = self.command('manager', 'shared.create',
                collection='stakeholders', project_id=project['id'],
                name=f'{role} authority', account_id=role)
        self.rejected('manager', 'shared.create', 'account_not_found',
            collection='stakeholders', project_id=project['id'],
            name='Unknown authority', account_id='not-an-account')

        book = self.command('warehouse', 'item.create', kind='book',
            project_id=project['id'], name='Synthetic novel', owner_id=publisher['id'])
        incoming = self.command('warehouse', 'book_shipment.create', project_id=project['id'],
            zone_id=zone['id'], publisher_id=publisher['id'], direction='inbound',
            document_reference='PILOT-IN-1', evidence='Packing list',
            lines=[{'item_id': book['id'], 'qty': 20}])
        self.assertEqual(self.state()['stock'], [])
        received = self.command('warehouse', 'book_shipment.receive', id=incoming['id'],
            receiver_name='Warehouse', evidence='Signed receipt for 18 copies',
            difference_reason='Two copies short',
            actual_lines=[{'item_id': book['id'], 'received_qty': 18}])
        self.assertEqual(received['status'], 'discrepancy')
        self.assertEqual(self.state()['stock'][0]['on_hand'], 18)
        self.rejected('warehouse', 'book_shipment.resolve', 'forbidden', id=incoming['id'],
                      reason='Unilateral settlement', evidence='None')
        self.command('manager', 'book_shipment.resolve', id=incoming['id'],
                     reason='Publisher accepted short delivery', evidence='Settlement memo')

        order = self.command('warehouse', 'order.create', project_id=project['id'],
            customer_name='Synthetic visitor', address='Synthetic delivery address',
            lines=[{'item_id': book['id'], 'zone_id': zone['id'], 'qty': 3}])
        self.assertEqual(self.state()['stock'][0]['reserved'], 3)
        self.command('warehouse', 'order.transition', id=order['id'], status='picking')
        self.command('warehouse', 'order.transition', id=order['id'], status='packed', evidence='Packing scan')
        self.command('warehouse', 'order.transition', id=order['id'], status='shipped',
                     evidence='Courier receipt', carrier='Synthetic carrier', tracking_number='PILOT-ORDER-1')
        self.command('warehouse', 'order.transition', id=order['id'], status='delivered', evidence='Visitor receipt')
        self.assertEqual((self.state()['stock'][0]['on_hand'], self.state()['stock'][0]['reserved']), (15, 0))

        outgoing = self.command('warehouse', 'book_shipment.create', project_id=project['id'],
            zone_id=zone['id'], publisher_id=publisher['id'], direction='publisher_return',
            document_reference='PILOT-OUT-1', evidence='Return manifest',
            lines=[{'item_id': book['id'], 'qty': 5}])
        self.command('warehouse', 'book_shipment.dispatch', id=outgoing['id'],
                     evidence='Carrier handoff', carrier='Synthetic carrier', tracking_number='PILOT-RETURN-1')
        self.assertIn('open_book_shipments',
                      {row['code'] for row in self.state()['closeout'][0]['blockers']})
        self.command('warehouse', 'book_shipment.receive', id=outgoing['id'],
                     receiver_name='Publisher', evidence='Publisher receipt',
                     actual_lines=[{'item_id': book['id'], 'received_qty': 5}])
        self.assertEqual(self.state()['stock'][0]['on_hand'], 10)

        point = dt.datetime.now(dt.timezone.utc)
        permit = self.command('field', 'permit.create', project_id=project['id'],
            zone_id=zone['id'], title='Synthetic supplier entry', holder_name='Synthetic supplier',
            valid_from=(point-dt.timedelta(hours=1)).isoformat(),
            valid_until=(point+dt.timedelta(days=1)).isoformat(),
            approval_steps=[{'id': 'management', 'authority': 'Project management',
                             'role': 'manager', 'stakeholder_id': recipient['manager']['id']},
                            {'id': 'site-security', 'authority': 'Site security',
                             'role': 'security', 'stakeholder_id': recipient['security']['id']}])
        self.command('field', 'permit.transition', id=permit['id'], status='submitted')
        self.rejected('security', 'permit.transition', 'approval_role_required',
                      id=permit['id'], status='approved', evidence='Out of sequence')
        self.rejected('viewer', 'permit.transition', 'forbidden',
                      id=permit['id'], status='approved', evidence='No authority')
        self.command('manager', 'permit.transition', id=permit['id'], status='approved',
                     evidence='Manager signature')
        self.rejected('security_alt', 'permit.transition', 'approval_identity_required',
                      id=permit['id'], status='approved', evidence='Same role, wrong account')
        approved = self.command('security', 'permit.transition', id=permit['id'],
                                status='approved', evidence='Security signature')
        self.assertEqual([step['decision_account_id'] for step in approved['approval_steps']],
                         ['manager', 'security'])
        self.command('security', 'permit.access', id=permit['id'], action='checkin', evidence='Gate scan')
        self.assertIn('active_access', {row['code'] for row in self.state()['closeout'][0]['blockers']})
        self.command('security', 'permit.access', id=permit['id'], action='checkout', evidence='Exit scan')

        build_task = self.command('manager', 'task.create', project_id=project['id'],
            phase_id=phases['build']['id'], zone_id=zone['id'], title='Build pilot hall',
            inspection_required=False)
        base = {'project_id': project['id'], 'zone_id': zone['id'],
                'evidence': 'Signed phase handover'}
        self.rejected('manager', 'phase_handoff.create', 'phase_handoff_blocked',
            **base, from_phase_id=phases['build']['id'], to_phase_id=phases['operations']['id'],
            recipient_id=recipient['warehouse']['id'])
        self.command('field', 'task.transition', id=build_task['id'], status='active')
        self.command('manager', 'task.transition', id=build_task['id'], status='completed',
                     evidence='Build acceptance')
        first = self.command('manager', 'phase_handoff.create', **base,
            from_phase_id=phases['build']['id'], to_phase_id=phases['operations']['id'],
            recipient_id=recipient['warehouse']['id'])
        self.rejected('manager', 'phase_handoff.accept', 'second_approver_required',
                      id=first['id'], evidence='Wrong signer')
        self.rejected('security', 'phase_handoff.accept', 'recipient_account_required',
                      id=first['id'], evidence='Unassigned signer')
        accepted = self.command('warehouse', 'phase_handoff.accept', id=first['id'],
                                evidence='Operations acceptance')
        self.assertEqual(accepted['acceptance_mode'], 'recipient_account')
        self.rejected('manager', 'task.create', 'phase_already_handed_over',
            project_id=project['id'], phase_id=phases['build']['id'], zone_id=zone['id'],
            title='Late build task')

        report = self.command('field', 'daily.open', project_id=project['id'],
            phase_id=phases['operations']['id'], zone_id=zone['id'],
            responsible_id=recipient['field']['id'],
            operational_date=dt.datetime.now(dt.timezone.utc).date().isoformat(),
            readiness=[{'id':'entry', 'label':'Entry gate', 'status':'ready'}],
            evidence='Signed opening record')
        self.rejected('manager', 'phase_handoff.create', 'phase_handoff_blocked',
            **base, from_phase_id=phases['operations']['id'], to_phase_id=phases['dismantling']['id'],
            recipient_id=recipient['field']['id'])
        self.command('manager', 'daily.close', id=report['id'],
                     evidence='Signed close of shift', summary='Operations complete')
        second = self.command('manager', 'phase_handoff.create', **base,
            from_phase_id=phases['operations']['id'], to_phase_id=phases['dismantling']['id'],
            recipient_id=recipient['field']['id'])
        self.command('field', 'phase_handoff.accept', id=second['id'], evidence='Dismantling acceptance')

        final = self.command('manager', 'phase_handoff.create', **base,
            from_phase_id=phases['dismantling']['id'], to_phase_id=phases['closeout']['id'],
            recipient_id=recipient['admin']['id'])
        self.rejected('manager', 'project.close', 'closeout_blocked', id=project['id'],
                      evidence='Premature close', summary='Pending final handover and count')
        self.command('admin', 'phase_handoff.accept', id=final['id'], evidence='Final acceptance')
        self.assertIn('final_count_required',
                      {row['code'] for row in self.state()['closeout'][0]['blockers']})
        count = self.command('warehouse', 'stock.count', item_id=book['id'], zone_id=zone['id'],
                             counted_qty=10, evidence='Signed final count')
        self.assertEqual(count['status'], 'matched')
        self.assertIn('remaining_books',
                      {row['code'] for row in self.state()['closeout'][0]['blockers']})
        self.rejected('manager', 'project.close', 'closeout_blocked', id=project['id'],
                      evidence='Premature close', summary='Ten publisher copies remain')
        final_return = self.command('warehouse', 'book_shipment.create', project_id=project['id'],
            zone_id=zone['id'], publisher_id=publisher['id'], direction='publisher_return',
            document_reference='PILOT-FINAL-RETURN', evidence='Final return manifest',
            lines=[{'item_id': book['id'], 'qty': 10}])
        self.command('warehouse', 'book_shipment.dispatch', id=final_return['id'],
                     evidence='Final carrier handoff', carrier='Synthetic carrier',
                     tracking_number='PILOT-FINAL-RETURN')
        self.command('warehouse', 'book_shipment.receive', id=final_return['id'],
                     receiver_name='Publisher', evidence='Publisher final receipt',
                     actual_lines=[{'item_id': book['id'], 'received_qty': 10}])
        self.assertEqual(self.state()['stock'][0]['on_hand'], 0)
        self.assertIn('final_count_required',
                      {row['code'] for row in self.state()['closeout'][0]['blockers']})
        self.command('warehouse', 'stock.count', item_id=book['id'], zone_id=zone['id'],
                     counted_qty=0, evidence='Signed empty-shelf count')
        self.assertTrue(self.state()['closeout'][0]['ready'])
        attachment = self.command('warehouse', 'attachment.create',
            project_id=project['id'], record_collection='book_shipments',
            record_id=incoming['id'], filename='receipt.pdf', content_type='application/pdf',
            data_base64=base64.b64encode(b'%PDF-1.4\n%%EOF').decode())
        self.assertEqual(attachment['record_id'], incoming['id'])
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=5)
        connection.request('GET', '/api/attachments/' + attachment['id'],
                           headers={'Cookie': self.cookies['warehouse']})
        response = connection.getresponse()
        self.assertEqual(response.status, 200)
        self.assertEqual(response.read(), b'%PDF-1.4\n%%EOF')
        connection.close()
        closed = self.command('manager', 'project.close', id=project['id'],
                              evidence='Signed project closeout', summary='All pilot obligations settled')
        self.assertEqual(closed['status'], 'closed')
        self.rejected('warehouse', 'book_shipment.create', 'project_closed',
            project_id=project['id'], zone_id=zone['id'], publisher_id=publisher['id'],
            direction='inbound', document_reference='LATE', evidence='After close',
            lines=[{'item_id':book['id'], 'qty':1}])
        self.assertEqual(self.state()['integrations']['shipping'], 'not_connected')

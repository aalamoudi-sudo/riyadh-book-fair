"""Daily zone readiness and documented handover; no external integrations.

Both commands run inside DomainStore.command's transaction, revision check and
project authorization. Closing a daily report never closes operational records.
"""
import datetime as dt
import re


class OperationsMixin:
    def phase_handoff_blockers(self, c, project_id, zone_id, from_phase_id):
        """Evaluate the live source-phase work for one zone before either signature."""
        tasks = [row['id'] for row in self.all(c, 'tasks')
                 if row.get('project_id') == project_id and row.get('zone_id') == zone_id
                 and row.get('phase_id') == from_phase_id and row['status'] != 'completed']
        daily = [row['id'] for row in self.all(c, 'daily_reports')
                 if row.get('project_id') == project_id and row.get('zone_id') == zone_id
                 and row.get('phase_id') == from_phase_id and row['status'] == 'open']
        critical = [row['id'] for row in self.all(c, 'incidents')
                    if row.get('project_id') == project_id and row.get('zone_id') == zone_id
                    and row.get('priority') == 'critical' and row['status'] != 'closed']
        return {'tasks': tasks, 'daily_reports': daily, 'critical_incidents': critical}

    def require_prior_phase_handoff(self, c, project_id, zone_id, source):
        from domain import require
        prior_kind = {'operations': 'build', 'dismantling': 'operations',
                      'closeout': 'dismantling'}.get(source['kind'])
        if not prior_kind:
            return
        prior = [phase for phase in self.all(c, 'phases')
                 if phase.get('project_id') == project_id and phase.get('kind') == prior_kind]
        if not prior:
            return
        accepted = [row for row in self.all(c, 'phase_handoffs')
                    if row.get('project_id') == project_id and row.get('zone_id') == zone_id
                    and row.get('to_phase_id') == source['id'] and row.get('status') == 'accepted']
        active_prior = [phase for phase in prior if any(row.get('phase_id') == phase['id']
                        and row.get('zone_id') == zone_id and row.get('project_id') == project_id
                        for col in ('tasks', 'daily_reports') for row in self.all(c, col))]
        required = active_prior or prior
        require(all(any(row.get('from_phase_id') == phase['id'] for row in accepted)
                    for phase in required),
                'اعتمد تسليم المرحلة السابقة لهذه المنطقة أولًا', 'prior_handoff_required', 409)

    def phase_handoff_create(self, c, p, actor):
        from domain import require, text, now
        source = self.get(c, 'phases', p.get('from_phase_id'))
        destination = self.get(c, 'phases', p.get('to_phase_id'))
        zone = self.get(c, 'zones', p.get('zone_id'))
        project_id = zone['project_id']
        require(source['project_id'] == project_id == destination['project_id'],
                'مراحل ومحضر المنطقة يجب أن تتبع المشروع نفسه', 'project_mismatch')
        require(not p.get('project_id') or p['project_id'] == project_id,
                'المشروع لا يطابق المنطقة', 'project_mismatch')
        allowed = {('build', 'operations'), ('operations', 'dismantling'),
                   ('dismantling', 'closeout')}
        require((source['kind'], destination['kind']) in allowed,
                'انتقال المراحل غير مدعوم', 'invalid_phase_handoff')
        require(source['id'] != destination['id'], 'اختر مرحلتين مختلفتين')
        self.require_prior_phase_handoff(c, project_id, zone['id'], source)
        recipient_id = text(p.get('recipient_id'), 'جهة الاستلام', True, 100)
        recipient = self.get(c, 'stakeholders', recipient_id)
        require(recipient['project_id'] == project_id, 'جهة الاستلام من مشروع آخر', 'project_mismatch')
        stored_account_id = text(recipient.get('account_id'), 'حساب الجهة المرتبط', limit=100)
        requested_account_id = text(p.get('recipient_account_id'), 'حساب جهة الاستلام', limit=100)
        require(not requested_account_id or stored_account_id == requested_account_id,
                'حساب الاستلام المدخل يختلف عن حساب الجهة المرتبط', 'recipient_account_mismatch')
        recipient_account_id = stored_account_id
        require(not any(row.get('project_id') == project_id and row.get('zone_id') == zone['id']
                        and row.get('from_phase_id') == source['id'] and row.get('to_phase_id') == destination['id']
                        and row['status'] in {'pending', 'accepted'} for row in self.all(c, 'phase_handoffs')),
                'يوجد محضر تسليم قائم لهذا الانتقال والمنطقة', 'duplicate_handoff', 409)
        blockers = self.phase_handoff_blockers(c, project_id, zone['id'], source['id'])
        require(not any(blockers.values()), 'أكمل مهام المرحلة وأقفل المحاضر والبلاغات الحرجة قبل طلب التسليم',
                'phase_handoff_blocked', 409)
        return self.new(c, 'phase_handoffs', {
            'project_id': project_id, 'zone_id': zone['id'], 'from_phase_id': source['id'],
            'to_phase_id': destination['id'], 'recipient_id': recipient_id,
            'recipient_account_id': recipient_account_id,
            'requested_recipient_account_id': recipient_account_id,
            'status': 'pending', 'requested_at': now(), 'requested_by': actor['id'],
            'request_evidence': text(p.get('evidence'), 'محضر طلب التسليم', True, 4000),
            'notes': text(p.get('notes'), 'ملاحظات التسليم', limit=4000),
            'request_snapshot': blockers, 'acceptance_snapshot': None,
            'accepted_at': '', 'accepted_by': '', 'acceptance_evidence': '',
            'acceptance_mode': '', 'override_reason': ''}, actor)

    def phase_handoff_accept(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'phase_handoffs', p.get('id'))
        require(row['status'] == 'pending', 'محضر التسليم ليس بانتظار الاعتماد', 'invalid_transition', 409)
        require(row['requested_by'] != actor['id'], 'اعتماد التسليم يتطلب حسابًا آخر',
                'second_approver_required', 403)
        recipient = self.get(c, 'stakeholders', row['recipient_id'])
        require(recipient['project_id'] == row['project_id'],
                'جهة الاستلام لم تعد تتبع المشروع', 'project_mismatch', 409)
        recipient_account_id = recipient.get('account_id', '')
        bound_acceptance = bool(recipient_account_id) and recipient_account_id == actor['id']
        override_reason = ''
        if not bound_acceptance:
            require(actor['role'] == 'admin',
                    'قبول التسليم يتطلب حساب المستلم المحدد أو مدير نظام ينوب عنه',
                    'recipient_account_required', 403)
            override_reason = text(p.get('override_reason'), 'سبب قبول مدير النظام نيابة عن الجهة', True, 2000)
        source = self.get(c, 'phases', row['from_phase_id'])
        self.require_prior_phase_handoff(c, row['project_id'], row['zone_id'], source)
        blockers = self.phase_handoff_blockers(c, row['project_id'], row['zone_id'], row['from_phase_id'])
        require(not any(blockers.values()), 'ظهرت أعمال مفتوحة بعد طلب التسليم؛ عالجها قبل الاعتماد',
                'phase_handoff_blocked', 409)
        row.setdefault('requested_recipient_account_id', row.get('recipient_account_id', ''))
        row.update(status='accepted', accepted_at=now(), accepted_by=actor['id'],
                   recipient_account_id=recipient_account_id,
                   acceptance_evidence=text(p.get('evidence'), 'محضر قبول التسليم', True, 4000),
                   acceptance_snapshot=blockers, acceptance_mode='recipient_account' if bound_acceptance else 'admin_override',
                   override_reason=override_reason)
        return self.put(c, 'phase_handoffs', row)

    def phase_handoff_withdraw(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'phase_handoffs', p.get('id'))
        require(row['status'] == 'pending', 'لا يمكن سحب محضر مقبول أو مسحوب', 'invalid_transition', 409)
        require(actor['role'] == 'admin' or row['requested_by'] == actor['id'],
                'سحب الطلب للمنشئ أو مدير النظام', 'forbidden', 403)
        row.update(status='withdrawn', withdrawn_at=now(), withdrawn_by=actor['id'],
                   withdrawal_reason=text(p.get('reason'), 'سبب سحب الطلب', True, 2000),
                   withdrawal_evidence=text(p.get('evidence'), 'مرجع سحب الطلب', True, 4000))
        return self.put(c, 'phase_handoffs', row)

    def book_shipment_create(self, c, p, actor):
        from domain import require, text, quantity, now
        direction = p.get('direction')
        require(isinstance(direction, str) and direction in {'inbound', 'publisher_return'},
                'اتجاه الشحنة غير صالح')
        zone = self.get(c, 'zones', p.get('zone_id'))
        project_id = zone['project_id']
        require(not p.get('project_id') or p['project_id'] == project_id,
                'المشروع لا يطابق موقع الشحنة', 'project_mismatch')
        publisher_id = text(p.get('publisher_id'), 'الناشر', True, 100)
        publisher = self.get(c, 'stakeholders', publisher_id)
        require(publisher['project_id'] == project_id, 'الناشر يتبع مشروعًا آخر', 'project_mismatch')
        raw = p.get('lines')
        require(isinstance(raw, list) and 1 <= len(raw) <= 100,
                'تتطلب الشحنة من عنوان واحد إلى 100 عنوان')
        lines, seen = [], set()
        for entry in raw:
            require(isinstance(entry, dict), 'بند الشحنة غير صالح')
            item = self.get(c, 'items', entry.get('item_id'))
            require(item['kind'] == 'book' and item['project_id'] == project_id
                    and item['owner_id'] == publisher_id,
                    'كل عنوان يجب أن يكون كتابًا مملوكًا للناشر في المشروع', 'shipment_item_mismatch')
            require(item['id'] not in seen, 'ادمج الكميات المتكررة للعنوان نفسه')
            seen.add(item['id'])
            amount = quantity(entry.get('qty'))
            if direction == 'publisher_return':
                require(self.balance(c, item['id'], zone['id'])['available'] >= amount,
                        'رصيد الكتاب المتاح لا يكفي لتجهيز المرتجع', 'insufficient_stock', 409)
            lines.append({'item_id': item['id'], 'title': item['title'], 'qty': amount,
                          'received_qty': None, 'stock_move_id': ''})
        reference = text(p.get('document_reference'), 'مرجع بيان الشحنة', True, 160)
        require(not any(row.get('project_id') == project_id and row.get('direction') == direction
                        and row.get('document_reference') == reference for row in self.all(c, 'book_shipments')),
                'مرجع بيان الشحنة مستخدم في هذا الاتجاه', 'duplicate_shipment_reference', 409)
        return self.new(c, 'book_shipments', {
            'project_id': project_id, 'zone_id': zone['id'], 'publisher_id': publisher_id,
            'direction': direction, 'document_reference': reference,
            'status': 'announced' if direction == 'inbound' else 'prepared',
            'lines': lines, 'notes': text(p.get('notes'), 'ملاحظات الشحنة', limit=4000),
            'created_evidence': text(p.get('evidence'), 'مرجع بيان الشحنة', True, 4000),
            'carrier': '', 'tracking_number': '', 'dispatched_at': '', 'dispatched_by': '',
            'dispatch_evidence': '', 'received_at': '', 'received_by': '', 'receiver_name': '',
            'receipt_evidence': '', 'difference_reason': '', 'resolved_at': '', 'resolved_by': '',
            'resolution_evidence': '', 'resolution_reason': '', 'updated_at': now()}, actor)

    def book_shipment_dispatch(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'book_shipments', p.get('id'))
        require(row['direction'] == 'publisher_return' and row['status'] == 'prepared',
                'الصرف للناشر متاح للمرتجع المجهز فقط', 'invalid_transition', 409)
        evidence = text(p.get('evidence'), 'محضر تسليم الشحنة للناقل', True, 4000)
        carrier = text(p.get('carrier'), 'الناقل', True, 200)
        tracking = text(p.get('tracking_number'), 'رقم التتبع', True, 160)
        for line in row['lines']:
            move = self.stock_move(c, {'action': 'ship', 'item_id': line['item_id'],
                'zone_id': row['zone_id'], 'qty': line['qty'],
                'reference': 'book_shipment:' + row['id'], 'evidence': evidence}, actor, True)
            line['stock_move_id'] = move['id']
        row.update(status='shipped', carrier=carrier, tracking_number=tracking,
                   dispatched_at=now(), dispatched_by=actor['id'], dispatch_evidence=evidence,
                   updated_at=now())
        return self.put(c, 'book_shipments', row)

    def book_shipment_receive(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'book_shipments', p.get('id'))
        expected = 'announced' if row['direction'] == 'inbound' else 'shipped'
        require(row['status'] == expected, 'الشحنة ليست في حالة تسمح بالاستلام', 'invalid_transition', 409)
        raw = p.get('actual_lines')
        require(isinstance(raw, list) and len(raw) == len(row['lines']),
                'سجل الكمية المستلمة لكل عنوان في البيان')
        actual = {}
        for entry in raw:
            require(isinstance(entry, dict), 'سطر الاستلام غير صالح')
            identifier = text(entry.get('item_id'), 'معرف الكتاب', True, 100)
            amount = entry.get('received_qty')
            require(isinstance(amount, int) and not isinstance(amount, bool) and 0 <= amount <= 1000000,
                    'الكمية المستلمة يجب أن تكون عددًا صحيحًا غير سالب')
            require(identifier not in actual, 'تكرر عنوان في محضر الاستلام')
            actual[identifier] = amount
        require(set(actual) == {line['item_id'] for line in row['lines']},
                'محضر الاستلام لا يطابق عناوين البيان')
        difference = any(actual[line['item_id']] != line['qty'] for line in row['lines'])
        require(all(actual[line['item_id']] <= line['qty'] for line in row['lines']),
                'الكمية المستلمة تتجاوز بيان الشحنة؛ أعد إصدار بيان مصحح', 'receipt_exceeds_manifest', 409)
        reason = text(p.get('difference_reason'), 'سبب فرق الاستلام', difference, 2000)
        evidence = text(p.get('evidence'), 'محضر إثبات الاستلام', True, 4000)
        receiver = text(p.get('receiver_name'), 'اسم مستلم الشحنة', True, 200)
        for line in row['lines']:
            amount = actual[line['item_id']]
            line['received_qty'] = amount
            if row['direction'] == 'inbound' and amount:
                move = self.stock_move(c, {'action': 'receipt', 'item_id': line['item_id'],
                    'zone_id': row['zone_id'], 'qty': amount,
                    'reference': 'book_shipment:' + row['id'], 'evidence': evidence}, actor, True)
                line['stock_move_id'] = move['id']
        row.update(status='discrepancy' if difference else 'received', received_at=now(),
                   received_by=actor['id'], receiver_name=receiver, receipt_evidence=evidence,
                   difference_reason=reason, updated_at=now())
        return self.put(c, 'book_shipments', row)

    def book_shipment_resolve(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'book_shipments', p.get('id'))
        require(row['status'] == 'discrepancy', 'لا يوجد فرق استلام ينتظر التسوية',
                'invalid_transition', 409)
        row.update(status='resolved', resolved_at=now(), resolved_by=actor['id'],
                   resolution_reason=text(p.get('reason'), 'قرار معالجة فرق الاستلام', True, 2000),
                   resolution_evidence=text(p.get('evidence'), 'إثبات معالجة فرق الاستلام', True, 4000),
                   updated_at=now())
        return self.put(c, 'book_shipments', row)

    def book_shipment_cancel(self, c, p, actor):
        from domain import require, text, now
        row = self.get(c, 'book_shipments', p.get('id'))
        require(row['status'] in {'announced', 'prepared'},
                'لا يمكن إلغاء شحنة تغير رصيدها أو أرسلت للناقل', 'invalid_transition', 409)
        row.update(status='cancelled', cancelled_at=now(), cancelled_by=actor['id'],
                   cancellation_reason=text(p.get('reason'), 'سبب إلغاء البيان', True, 2000),
                   cancellation_evidence=text(p.get('evidence'), 'مرجع إلغاء البيان', True, 4000),
                   updated_at=now())
        return self.put(c, 'book_shipments', row)

    def daily_open(self, c, p, actor):
        from domain import require, text, now
        fields = self.common(c, p)
        for key, label in [('project_id', 'المشروع'), ('zone_id', 'المنطقة'),
                           ('phase_id', 'المرحلة'), ('responsible_id', 'مسؤول اليوم')]:
            require(bool(fields[key]), f'حدد {label} لافتتاح اليوم')
        require(not any(row.get('project_id') == fields['project_id']
                        and row.get('zone_id') == fields['zone_id']
                        and row.get('from_phase_id') == fields['phase_id']
                        and row['status'] == 'accepted' for row in self.all(c, 'phase_handoffs')),
                'سُلّمت هذه المرحلة في المنطقة؛ افتح محضر التشغيل في المرحلة المستلمة',
                'phase_already_handed_over', 409)
        require(bool(fields['evidence']), 'محضر افتتاح اليوم مطلوب')
        date_value = text(p.get('operational_date'), 'تاريخ التشغيل', True, 10)
        require(bool(re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', date_value)),
                'تاريخ التشغيل يجب أن يكون YYYY-MM-DD', 'invalid_operational_date')
        try:
            dt.date.fromisoformat(date_value)
        except ValueError:
            require(False, 'تاريخ التشغيل غير صالح', 'invalid_operational_date')
        raw = p.get('readiness')
        require(isinstance(raw, list) and 1 <= len(raw) <= 20,
                'سجل من بند واحد إلى 20 بندًا لجاهزية اليوم')
        readiness, seen = [], set()
        for entry in raw:
            require(isinstance(entry, dict), 'بند الجاهزية غير صالح')
            identifier = text(entry.get('id'), 'معرف بند الجاهزية', True, 80)
            require(identifier not in seen, 'معرفات بنود الجاهزية مكررة')
            seen.add(identifier)
            status = entry.get('status')
            require(isinstance(status, str) and status in {'ready', 'issue'},
                    'حالة بند الجاهزية يجب أن تكون ready أو issue')
            readiness.append({'id': identifier,
                              'label': text(entry.get('label'), 'بند الجاهزية', True, 300),
                              'status': status,
                              'notes': text(entry.get('notes'), 'تفاصيل ملاحظة الجاهزية', status == 'issue', 2000)})
        require(not any(row['zone_id'] == fields['zone_id'] and row['operational_date'] == date_value
                        and row['status'] == 'open' for row in self.all(c, 'daily_reports')),
                'يوجد تقرير يومي مفتوح لهذه المنطقة والتاريخ', 'daily_already_open', 409)
        fields.update(operational_date=date_value, readiness=readiness, status='open',
                      opening_evidence=fields['evidence'], opened_at=now(), opened_by=actor['id'],
                      closure_snapshot=None, readiness_followup=[], closed_at='', closed_by='', closing_evidence='', summary='',
                      handover_responsible_id='', handover_due_at='', handover_notes='')
        return self.new(c, 'daily_reports', fields, actor)

    def daily_snapshot(self, c, project_id, zone_id):
        from domain import now
        def in_zone(row):
            return row.get('project_id') == project_id and row.get('zone_id') == zone_id
        def brief(row):
            return {key: row[key] for key in ('id', 'title', 'status', 'priority', 'responsible_id',
                                              'from_zone_id', 'to_zone_id') if key in row}
        tasks = [brief(row) for row in self.all(c, 'tasks') if in_zone(row) and row['status'] != 'completed']
        incidents = [brief(row) for row in self.all(c, 'incidents') if in_zone(row) and row['status'] != 'closed']
        support = [brief(row) for row in self.all(c, 'support_requests')
                   if row.get('project_id') == project_id
                   and zone_id in {row.get('zone_id'), row.get('from_zone_id'), row.get('to_zone_id')}
                   and row['status'] not in {'received', 'cancelled', 'rejected'}]
        critical = [row for row in incidents if row.get('priority') == 'critical' and row['status'] in {'open', 'assigned'}]
        return {'captured_at': now(), 'tasks': tasks, 'incidents': incidents, 'support_requests': support, 'readiness_issues': [],
                'counts': {'tasks': len(tasks), 'incidents': len(incidents), 'support_requests': len(support),
                           'total': len(tasks) + len(incidents) + len(support), 'critical_incidents': len(critical), 'readiness_issues': 0}}

    def daily_close(self, c, p, actor):
        from domain import require, text, timestamp, now
        require(actor.get('role') in {'admin', 'manager'}, 'إقفال اليوم يتطلب مدير المشروع', 'forbidden', 403)
        row = self.get(c, 'daily_reports', p.get('id'))
        require(row['status'] == 'open', 'التقرير اليومي مقفل بالفعل', 'invalid_transition', 409)
        evidence = text(p.get('evidence'), 'محضر إقفال اليوم', True, 4000)
        summary = text(p.get('summary'), 'ملخص اليوم', True, 4000)
        snapshot = self.daily_snapshot(c, row['project_id'], row['zone_id'])
        require(snapshot['counts']['critical_incidents'] == 0,
                'لا يمكن إقفال اليوم مع بلاغ حرج مفتوح أو مسند في المنطقة', 'critical_incident_open', 409)
        opening_issues = {item['id']: item for item in row['readiness'] if item['status'] == 'issue'}
        raw_followup = p.get('readiness_followup', [])
        require(isinstance(raw_followup, list) and len(raw_followup) <= 20, 'متابعة ملاحظات الافتتاح غير صالحة')
        require(not opening_issues or bool(raw_followup),
                'سجل معالجة أو ترحيل كل ملاحظة من محضر افتتاح اليوم', 'readiness_followup_required', 409)
        followup, seen = [], set()
        for entry in raw_followup:
            require(isinstance(entry, dict), 'متابعة بند الجاهزية غير صالحة')
            identifier = text(entry.get('id'), 'معرف ملاحظة الافتتاح', True, 80)
            require(identifier in opening_issues and identifier not in seen,
                    'ملاحظة افتتاح غير معروفة أو مكررة', 'invalid_readiness_followup')
            seen.add(identifier)
            status = entry.get('status')
            require(isinstance(status, str) and status in {'resolved', 'carryover'},
                    'حدد معالجة الملاحظة أو ترحيلها')
            followup.append({'id': identifier, 'label': opening_issues[identifier]['label'], 'status': status,
                             'notes': text(entry.get('notes'), 'نتيجة معالجة أو ترحيل الملاحظة', True, 2000),
                             'evidence': evidence if status == 'resolved' else ''})
        require(seen == set(opening_issues), 'سجل معالجة أو ترحيل كل ملاحظة افتتاح', 'readiness_followup_required', 409)
        snapshot['readiness_issues'] = [dict(entry) for entry in followup if entry['status'] == 'carryover']
        snapshot['counts']['readiness_issues'] = len(snapshot['readiness_issues'])
        snapshot['counts']['total'] += len(snapshot['readiness_issues'])
        outstanding = snapshot['counts']['total'] > 0
        provided = any(p.get(key) for key in ('handover_responsible_id', 'handover_due_at', 'handover_notes'))
        require(not outstanding or all(p.get(key) for key in ('handover_responsible_id', 'handover_due_at', 'handover_notes')),
                'الأعمال المتبقية تحتاج مسؤول تسليم وموعدًا وملاحظات متابعة', 'handover_required', 409)
        responsible_id = due_at = handover_notes = ''
        if outstanding or provided:
            responsible_id = text(p.get('handover_responsible_id'), 'مسؤول متابعة المتبقي', True, 100)
            responsible = self.get(c, 'stakeholders', responsible_id)
            require(responsible['project_id'] == row['project_id'], 'مسؤول التسليم يتبع مشروعًا آخر', 'project_mismatch')
            due_at = timestamp(p.get('handover_due_at'), 'موعد متابعة المتبقي').isoformat()
            handover_notes = text(p.get('handover_notes'), 'ملاحظات تسليم المتبقي', True, 4000)
        row.update(status='closed', closed_at=now(), closed_by=actor['id'], closing_evidence=evidence,
                   summary=summary, closure_snapshot=snapshot, readiness_followup=followup, handover_responsible_id=responsible_id,
                   handover_due_at=due_at, handover_notes=handover_notes)
        return self.put(c, 'daily_reports', row)

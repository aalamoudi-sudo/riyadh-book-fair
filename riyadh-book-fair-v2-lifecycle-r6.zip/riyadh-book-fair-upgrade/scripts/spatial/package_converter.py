"""Build the downloadable, source-matched local Blender converter bundle."""
from hashlib import sha256
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
TARGET = HERE.parents[1] / 'app' / 'assets' / 'spatial-converter.zip'
FILES = ('import_plan.py', 'blender_export.py', 'plan_schema.py', 'check_glb.py', 'CONVERTER-AR.md')


def build(target=TARGET):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in FILES:
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (HERE / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return sha256(target.read_bytes()).hexdigest()


if __name__ == '__main__':
    print(f'{TARGET.name} sha256={build()}')

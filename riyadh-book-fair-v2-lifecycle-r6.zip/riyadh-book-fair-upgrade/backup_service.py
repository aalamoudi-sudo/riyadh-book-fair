"""Verified, rotating SQLite snapshots for one persistent application instance.

Snapshots on the same disk are a recovery aid, not an off-site backup. The
operator must export or mirror them outside the service before relying on them
for disk-loss recovery.
"""
from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
import secrets
import shutil
import threading
import time

from scripts.database_backup import copy_database, verify


class BackupService:
    def __init__(self, source, directory, interval_seconds=24 * 60 * 60, keep=3):
        self.source = Path(source).resolve()
        self.directory = Path(directory).resolve()
        self.interval_seconds = interval_seconds
        self.keep = keep
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._last_error = None
        self._last_success = None
        self._latest_revision = None
        if interval_seconds <= 0 or keep < 2:
            raise ValueError('إعداد النسخ الاحتياطي غير صالح')
        if self.directory == self.source.parent or self.directory == self.source:
            raise ValueError('ضع النسخ في مجلد منفصل عن ملف قاعدة البيانات')

    def _files(self):
        return sorted(self.directory.glob('rbf-*.sqlite'), key=lambda p: p.stat().st_mtime, reverse=True) if self.directory.exists() else []

    def snapshot(self):
        """Create and verify one exclusive snapshot; prune only after success."""
        with self._lock:
            self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            os.chmod(self.directory, 0o700)
            current = verify(self.source)
            latest = self._files()
            if latest and time.time() - latest[0].stat().st_mtime < self.interval_seconds:
                try:
                    previous = verify(latest[0])
                    if previous['revision'] == current['revision']:
                        self._last_success = latest[0].stat().st_mtime
                        self._latest_revision = previous['revision']
                        self._last_error = None
                        return self.status_unlocked()
                except (OSError, ValueError):
                    pass  # A corrupt latest snapshot must be replaced.
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
            destination = self.directory / f'rbf-{stamp}-{secrets.token_hex(4)}.sqlite'
            try:
                required = max(8 * 1024 * 1024, self.source.stat().st_size * 2)
                if shutil.disk_usage(self.directory).free < required:
                    raise OSError('لا توجد مساحة كافية لنسخة احتياطية متحققة')
                result = copy_database(self.source, destination)
                self._last_success = destination.stat().st_mtime
                self._latest_revision = result['revision']
                self._last_error = None
                for old in self._files()[self.keep:]:
                    old.unlink()
                return self.status_unlocked()
            except Exception as error:
                self._last_error = type(error).__name__
                raise

    def status_unlocked(self):
        latest = self._files()
        success = self._last_success or (latest[0].stat().st_mtime if latest else None)
        return {
            'enabled': True,
            'location': 'same_disk',
            'offsite_configured': False,
            'last_success_at': datetime.fromtimestamp(success, timezone.utc).isoformat(timespec='seconds') if success else None,
            'age_seconds': max(0, int(time.time() - success)) if success else None,
            'latest_revision': self._latest_revision,
            'retained': len(latest),
            'retention_limit': self.keep,
            'last_error': self._last_error,
        }

    def status(self):
        with self._lock:
            return self.status_unlocked()

    def start(self):
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run, name='rbf-backup', daemon=True)
        self._thread.start()

    def _run(self):
        delay = 0
        while not self._stop.wait(delay):
            try:
                self.snapshot()
                delay = self.interval_seconds
            except Exception as error:
                # Never log database content, credentials, or paths.
                print('backup failed: ' + type(error).__name__, file=__import__('sys').stderr, flush=True)
                delay = min(self.interval_seconds, 60 * 60)

    def stop(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=10)

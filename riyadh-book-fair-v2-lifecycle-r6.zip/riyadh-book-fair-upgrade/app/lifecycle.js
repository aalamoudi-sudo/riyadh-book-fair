import {esc, n, date, badge, icon, empty, button, field, textarea, select, table, progress, modal, detail, download} from './ui.js';
import {recordEvidence} from './evidence.js';

const phaseKinds = [{id:'foundation',name:'التأسيس'},{id:'planning',name:'التخطيط'},{id:'procurement',name:'المشتريات'},{id:'build',name:'البناء والتجهيز'},{id:'operations',name:'التشغيل اليومي'},{id:'dismantling',name:'الفك والاسترجاع'},{id:'closeout',name:'الإقفال'}];
const taskLabels = {planned:'مخطط',active:'قيد التنفيذ',inspection:'بانتظار الفحص',blocked:'متعثر',completed:'مكتمل'};
const permitLabels = {proposed:'مسودة',submitted:'بانتظار الاعتماد',approved:'معتمد',rejected:'مرفوض',revoked:'ملغى'};
const kinds = [{id:'person',name:'فرد'},{id:'vehicle',name:'مركبة'},{id:'team',name:'فريق'},{id:'supplier',name:'مورد'}];
const roles = [{id:'security',name:'الأمن والتصاريح'},{id:'manager',name:'مدير المشروع'}];
const taskTransitions = {planned:['active','blocked'],active:['inspection','completed','blocked'],inspection:['completed','active','blocked'],blocked:['planned','active'],completed:[]};
const taskActionLabels = {active:'بدء / استئناف التنفيذ',inspection:'إحالة للفحص',completed:'اعتماد التسليم والإكمال',blocked:'تسجيل تعثر',planned:'إعادة إلى التخطيط'};
const permitTransitions = {proposed:['submitted'],submitted:['approved','rejected'],approved:['revoked'],rejected:[],revoked:[]};
const permitActionLabels = {submitted:'تقديم للاعتماد',approved:'اعتماد التصريح',rejected:'رفض التصريح',revoked:'إلغاء التصريح'};
const defaultChecklist=[{id:'scope',label:'مطابقة نطاق العمل المعتمد',required:true},{id:'quality',label:'فحص الجودة والوظيفة',required:true},{id:'handover',label:'تسليم الموقع أو الأصل للمسؤول',required:true}];
const all = (ctx,col) => ctx.state?.[col] || [];
const rows = (ctx,col) => ctx.records(col) || [];
const byId = (ctx,col,id) => all(ctx,col).find(r=>r.id===id);
const relatedName = (ctx,col,id) => id ? ctx.name(col,id) || id : 'غير محدد';
const taskBadge = status => badge(status==='active'?'in_progress':status,taskLabels[status] || status);
const roleName = role => ({admin:'مدير النظام',manager:'مدير المشروع',security:'الأمن والتصاريح',field:'الفريق الميداني',viewer:'اطلاع فقط',warehouse:'أمين المستودع'}[role] || role || 'غير محدد');
const kindName = kind => kinds.find(k=>k.id===kind)?.name || kind;
const safeDate = value => value && Number.isFinite(Date.parse(value)) ? date(value) : 'غير محدد';
const riyadhDate = value => value && Number.isFinite(Date.parse(value)) ? new Intl.DateTimeFormat('ar-SA',{dateStyle:'medium',timeStyle:'short',calendar:'gregory',timeZone:'Asia/Riyadh'}).format(new Date(value)) : 'غير محدد';
const inputRiyadh = value => new Date(value.getTime()+3*3600000).toISOString().slice(0,16);
const requiredText = (value,title) => {if (!String(value || '').trim()) throw new Error(`الحقل مطلوب: ${title}`);return String(value).trim();};
const detailItem = (title,value) => `<div class="detail-item"><span>${esc(title)}</span><strong>${esc(value || 'غير محدد')}</strong></div>`;
const note = text => `<p class="field-help">${esc(text)}</p>`;
const allowed = (ctx,command) => Boolean(ctx.can(command)) && !(byId(ctx,'projects',ctx.projectId)?.status==='closed' && !command.startsWith('project.'));
const attributed = (ctx,row) => `<span>${esc(relatedName(ctx,'zones',row.zone_id))}</span><span>${esc(relatedName(ctx,'stakeholders',row.responsible_id))}</span>`;
const action = (title,name,id,target='',style='small',disabled='',ico='') => button(title,name,style,ico,`data-id="${esc(id)}" data-target="${esc(target)}"${disabled?` disabled title="${esc(disabled)}"`:''}`);

function validity(permit, point=Date.now()) {
  if (!permit) return {valid:false,text:'التصريح المرتبط غير موجود',status:'rejected'};
  const start=Date.parse(permit.valid_from),end=Date.parse(permit.valid_until);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end<=start) return {valid:false,text:'تواريخ غير صالحة',status:'rejected'};
  if (point>end) return {valid:false,text:'منتهي الصلاحية',status:'rejected'};
  if (permit.status!=='approved') return {valid:false,text:'غير معتمد للدخول',status:'pending'};
  if (point<start) return {valid:false,text:'لم تبدأ الصلاحية',status:'pending'};
  return {valid:true,text:'صالح الآن',status:'approved'};
}
const checklist = task => task.inspection_checklist?.length ? task.inspection_checklist : defaultChecklist;
const latestInspection = task => (task.inspections||[]).at(-1);
const inspectionPassed = task => {const report=latestInspection(task);return report?.overall==='passed'&&Number(report.cycle)===Number(task.inspection_cycle||0);};
const permitSteps = permit => permit.approval_steps?.length?permit.approval_steps:[{id:'legacy-step',authority:permit.authority,role:permit.approval_role,status:permit.status==='approved'?'approved':permit.status==='rejected'?'rejected':'pending'}];
const permitStepIndex = permit => Math.min(Number(permit.current_step_index||0),permitSteps(permit).length-1);
const permitStep = permit => permitSteps(permit)[permitStepIndex(permit)];
const permitDecisionAccount = (ctx,step) => step.account_id&&step.stakeholder_id
  ? byId(ctx,'stakeholders',step.stakeholder_id)?.account_id || '' : step.account_id || '';
function approvalRoute(ctx,permit) {
  const steps=permitSteps(permit),index=permitStepIndex(permit);
  return `<h3 class="form-section">مسار الاعتماد · ${n(steps.length)} خطوات</h3>${steps.map((step,i)=>`<div class="record-row"><div class="record-symbol">${n(i+1)}</div><div class="record-main"><h3>${esc(step.authority)} · ${esc(roleName(step.role))}</h3><p>${step.stakeholder_id?`الجهة المسجلة: ${esc(relatedName(ctx,'stakeholders',step.stakeholder_id))} · `:''}حساب القرار: ${esc((step.decided_at?step.account_id:permitDecisionAccount(ctx,step))||'غير مربوط · يلزم تجاوز مدير النظام')} · ${step.decided_at?`${esc(riyadhDate(step.decided_at))} · ${esc(step.decided_by||'')}`:i===index&&permit.status==='submitted'?'تنتظر قرار الحساب المحدد':'لم يُسجل قرار لهذه الخطوة بعد'}</p>${step.admin_override?`<p>تجاوز إداري: ${esc(step.reason||'')}</p>`:''}${step.evidence?`<p>${esc(step.evidence)}</p>`:''}</div>${badge(step.status==='approved'?'approved':step.status==='rejected'?'rejected':i===index&&permit.status==='submitted'?'submitted':'pending',step.status==='approved'?'معتمدة':step.status==='rejected'?'مرفوضة':i===index&&permit.status==='submitted'?'الخطوة الحالية':'بانتظار دورها')}</div>`).join('')}${note('القرار مرتبط بحساب ممثل الجهة المسجلة ودوره. يستطيع مدير النظام التجاوز بسبب موثق. هذا اعتماد داخلي ولا يعني اتصالًا إلكترونيًا بالجهات الخارجية؛ الدخول ينتظر اكتمال جميع الخطوات.')}`;
}
function approvalStepFields(ctx) {
  const people=[{id:'',name:'اختر جهة مرتبطة بحساب دخول'},...rows(ctx,'stakeholders').filter(person=>person.account_id).map(person=>({id:person.id,name:`${person.name} · ${person.account_id}`}))];
  return `${select('approval_step_count','عدد خطوات الاعتماد',[{id:'1',name:'خطوة واحدة'},{id:'2',name:'خطوتان متتاليتان'},{id:'3',name:'ثلاث خطوات متتالية'}],'1','required')}<h3 class="form-section wide">الخطوة الأولى</h3>${field('authority','الجهة المعتمدة · الخطوة الأولى','text','','required maxlength="200"')}${select('approval_role','دور الاعتماد · الخطوة الأولى',roles,'security','required')}${select('approval_stakeholder_1','ممثل الجهة صاحب حساب القرار',people,'','required')}${[2,3].map(index=>`<div class="wide" data-approval-step="${index}" hidden><h3 class="form-section">الخطوة ${index===2?'الثانية':'الثالثة'}</h3><div class="form-grid">${field(`approval_authority_${index}`,'اسم الجهة المعتمدة','text','','maxlength="200" disabled')}${select(`approval_role_${index}`,'الدور المطلوب',roles,index===2?'manager':'security','disabled')}${select(`approval_stakeholder_${index}`,'ممثل الجهة صاحب حساب القرار',people,'','disabled')}</div></div>`).join('')}${note('أضف جهة مع معرّف حساب الاعتماد في شاشة الجهات أولًا، واختر الدور المطابق لصلاحية ذلك الحساب. اسم الجهة وحده لا يجيز القرار.')}`;
}
function inspectionHistory(task) {
  const items=checklist(task),reports=task.inspections||[];
  return `<h3 class="form-section">بنود الفحص والتسليم</h3>${items.map(item=>`<div class="record-row"><div class="record-main"><h3>${esc(item.label)}</h3><p>${item.required===false?'بند إضافي':'بند إلزامي قبل الإكمال'}</p></div>${badge('reference',item.id)}</div>`).join('')}<h3 class="form-section">محاضر الفحص · ${n(reports.length)}</h3>${reports.length?[...reports].reverse().map(report=>`<div class="panel mt"><div class="panel-head"><div><h2>محضر ${esc(report.id)}</h2><p>${esc(riyadhDate(report.at))} · الفاحص ${esc(report.actor_id)} · دورة تنفيذ ${n(report.cycle)}</p></div>${badge(report.overall==='passed'?'completed':'rejected',report.overall==='passed'?'اجتاز الفحص':'إخفاق يحتاج معالجة')}</div>${table(['البند','النتيجة','ملاحظات الفحص'],(report.results||[]).map(result=>`<tr><td>${esc(items.find(item=>item.id===result.item_id)?.label||result.item_id)}</td><td>${badge(result.status==='passed'?'completed':'rejected',result.status==='passed'?'اجتاز':'أخفق')}</td><td>${esc(result.notes||'—')}</td></tr>`))}<div class="panel-body"><p>${esc(report.evidence)}</p>${note(report.attachment_ids?.length?`ملفات الإثبات المرتبطة: ${report.attachment_ids.join('، ')}`:'لا توجد ملفات مرفقة بهذا المحضر.')}${Number(report.cycle)!==Number(task.inspection_cycle||0)?note('هذا محضر دورة سابقة؛ عاد العمل إلى التنفيذ ويلزم فحص جديد.') : ''}</div></div>`).join(''):note('لم يُسجل فحص تفصيلي بعد. عند الإحالة للفحص، سجّل نتيجة كل بند؛ لا يكفي تحديد مربع عام للاجتياز.')}`;
}
function taskBlockers(ctx,task,target) {
  if (!['active','completed'].includes(target)) return [];
  const reasons=[];
  const dependencies=(task.dependencies||[]).map(id=>byId(ctx,'tasks',id));
  if (dependencies.some(d=>!d || d.status!=='completed')) reasons.push('أكمل المهام السابقة أولًا');
  if (task.permit_id) {const permit=byId(ctx,'permits',task.permit_id), valid=validity(permit);if (!valid.valid) reasons.push(valid.text);}
  if (target==='completed' && task.inspection_required) {
    if (task.status!=='inspection') reasons.push('أحِل المهمة للفحص أولًا');
    if (!inspectionPassed(task)) reasons.push('سجّل فحص بنود ناجحًا لدورة التنفيذ الحالية');
    if (!['admin','manager'].includes(ctx.state?.user?.role)) reasons.push('اعتماد الفحص والتسليم يتطلب مديرًا');
  }
  return reasons;
}
function taskActions(ctx,task) {
  if (!allowed(ctx,'task.transition')) return '';
  return `${task.status==='inspection'&&task.inspection_required&&allowed(ctx,'task.inspect')?action('تسجيل فحص البنود','lc-task-inspect',task.id,'','primary','','check'):''}${(taskTransitions[task.status]||[]).filter(s=>!(s==='completed' && task.inspection_required && task.status!=='inspection')).map(target=>action(target==='completed'&&!task.inspection_required?'تسجيل التسليم والإكمال':taskActionLabels[target],'lc-task-transition',task.id,target,target==='blocked'?'danger':'small',taskBlockers(ctx,task,target).join(' · '))).join('')}`;
}
function history(records, labels=taskLabels) {
  if (!records?.length) return empty('لا توجد انتقالات بعد','تظهر الإجراءات والإثباتات هنا بعد تنفيذها.');
  return table(['الانتقال','وقت الإجراء · الرياض','المستخدم','الإثبات / السبب'],[...records].reverse().map(h=>`<tr><td>${esc(labels[h.from]||h.from)} ← ${esc(labels[h.to]||h.to)}</td><td>${esc(riyadhDate(h.at))}</td><td>${esc(h.actor_id)}</td><td><span class="cell-title">${esc(h.evidence||'لم يُرفق إثبات')}</span>${h.reason?`<span class="cell-sub" title="${esc(h.reason)}">${esc(h.reason)}</span>`:''}</td></tr>`));
}
function filters(ctx,statuses,collection) {
  return `<div class="filterbar"><label class="search-field">${icon('search')}<input type="search" data-filter="query" placeholder="بحث بالاسم أو المرجع أو المنطقة" value="${esc(ctx.query||'')}" aria-label="بحث السجلات"></label><select data-filter="status" aria-label="تصفية الحالة"><option value="">كل الحالات</option>${Object.entries(statuses).map(([id,name])=>`<option value="${esc(id)}" ${ctx.status===id?'selected':''}>${esc(name)}</option>`).join('')}</select><select data-filter="phase" aria-label="تصفية المرحلة"><option value="">كل المراحل</option>${rows(ctx,'phases').sort((a,b)=>(a.order||0)-(b.order||0)).map(p=>`<option value="${esc(p.id)}" ${ctx.phaseId===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select><span class="filter-count">${n(rows(ctx,collection).length)} سجل في المشروع</span></div>`;
}
function filtered(ctx,list) {
  const query=String(ctx.query||'').trim().toLocaleLowerCase('ar');
  return list.filter(r=>(!ctx.status||r.status===ctx.status)&&(!ctx.phaseId||r.phase_id===ctx.phaseId)&&(!query||[r.id,r.title,r.holder_name,r.vehicle_plate,r.authority,relatedName(ctx,'zones',r.zone_id),relatedName(ctx,'stakeholders',r.responsible_id)].join(' ').toLocaleLowerCase('ar').includes(query)));
}

function closeoutData(ctx) {
  const itemIds=new Set(rows(ctx,'items').map(i=>i.id)),zoneIds=new Set(rows(ctx,'zones').map(z=>z.id));
  const projectMoves=rows(ctx,'stock_moves');
  const legacyKeys=new Set(projectMoves.filter(m=>m.action==='issue').map(m=>`${m.item_id}@${m.reference}`));
  const custody=all(ctx,'custody').filter(c=>c.kind!=='order' && !String(c.reference||'').startsWith('order:') && Number(c.outstanding)>0 && (!ctx.projectId || c.project_id===ctx.projectId || (!c.project_id && (legacyKeys.has(c.id) || (itemIds.has(c.item_id)&&byId(ctx,'items',c.item_id)?.project_id===ctx.projectId)))));
  const reservations=all(ctx,'reservations').filter(r=>Number(r.qty)>0&&(!ctx.projectId||zoneIds.has(r.zone_id)));
  const stock=all(ctx,'stock').filter(s=>Number(s.maintenance)>0&&(!ctx.projectId||zoneIds.has(s.zone_id)));
  return {custody,reservations,maintenance:stock,books:all(ctx,'stock').filter(b=>itemIds.has(b.item_id)&&byId(ctx,'items',b.item_id)?.kind==='book'&&b.on_hand>0),tasks:rows(ctx,'tasks').filter(t=>t.status!=='completed'),orders:rows(ctx,'orders').filter(o=>!['delivered','cancelled','returned'].includes(o.status)),incidents:rows(ctx,'incidents').filter(i=>i.status!=='closed'),access:rows(ctx,'access_logs').filter(a=>!a.checked_out_at),procurements:rows(ctx,'procurements').filter(p=>p.status!=='received')};
}
function closeoutPanel(ctx) {
  const data=closeoutData(ctx),report=all(ctx,'closeout').find(r=>r.project_id===ctx.projectId),project=byId(ctx,'projects',ctx.projectId),closed=project?.status==='closed';
  const blockers=report?.blockers||[],count=report?blockers.reduce((sum,b)=>sum+b.count,0):Object.values(data).reduce((sum,list)=>sum+list.length,0);
  const summary=[['عهد تشغيلية لم تُسترجع',data.custody.length,`${n(data.custody.reduce((sum,c)=>sum+Number(c.outstanding),0))} وحدة لدى أصحاب العهد`],['طلبات زوار مفتوحة',data.orders.length,'التجميع والشحن والاستثناءات غير المقفلة'],['بلاغات غير مقفلة',data.incidents.length,'تشمل ما عولج وينتظر الإقفال'],['مهام غير مكتملة',data.tasks.length,'تشمل الفحص والتسليم والفك'],['أرصدة كتب متبقية',data.books.length,`${n(data.books.reduce((sum,b)=>sum+b.on_hand,0))} نسخة تحتاج توزيعًا أو مرتجعًا`]];
  return `<section class="panel mt"><div class="panel-head"><div><h2>جاهزية الإقفال</h2><p>سجلات المشروع الفعلية، مستقلة عن مرشحات الجدول. يتحقق الخادم من الالتزامات والجرد الأخير.</p></div>${badge(closed?'closed':count?'blocked':'pending',closed?'المشروع مقفل':count?'توجد متطلبات مفتوحة':report?.ready?'جاهز لمراجعة الإقفال':'بانتظار تحقق الخادم')}</div><div class="panel-body">${closed?`<div class="details-grid">${detailItem('محضر الإقفال',project.closeout_evidence)}${detailItem('تاريخ الإقفال · الرياض',riyadhDate(project.closed_at))}</div><p>${esc(project.closeout_summary||'')}</p>`:''}<div class="kpi-grid">${summary.map(([title,value,help])=>`<div class="kpi"><div class="kpi-top">${esc(title)}</div><div class="kpi-value">${n(value)}</div><div class="kpi-foot">${esc(help)}</div></div>`).join('')}</div><p class="field-help">حجوزات مخزون قائمة: ${n(data.reservations.length)} · سجلات صيانة: ${n(data.maintenance.length)} · حالات دخول بلا خروج: ${n(data.access.length)} · مشتريات غير مستلمة: ${n(data.procurements.length)}.</p>${blockers.length?`<div class="actions mt">${blockers.map(b=>badge('blocked',`${b.label}: ${n(b.count)}`)).join('')}</div>`:''}<p class="field-help">يتطلب الإقفال جردًا مطابقًا أو معتمدًا بعد آخر حركة لكل موقع مخزون، وإغلاق جميع الالتزامات، ثم محضر إقفال وملخص تسليم من المدير.</p><div class="actions mt">${button('عرض متطلبات الإقفال','lc-closeout','secondary','reports')}${button('تنزيل قائمة المراجعة','lc-export-closeout','secondary','download')}${ctx.state?.capabilities?.backup || ['admin','manager'].includes(ctx.state?.user?.role)?button('نسخة كاملة تشمل التدقيق','lc-export-audit','secondary','download'):''}${!closed&&allowed(ctx,'project.close')?action('اعتماد إقفال المشروع','lc-project-close',ctx.projectId,'','primary',!report?.ready?'أكمل متطلبات الإقفال أولًا':'','check'):''}${closed&&allowed(ctx,'project.reopen')?action('إعادة فتح المشروع','lc-project-reopen',ctx.projectId,'','secondary','','refresh'):''}</div><p class="field-help">يعرض التطبيق أحدث 200 إجراء تدقيق فقط. غياب إجراء من هذه العينة لا يعني فقدانه؛ النسخة الكاملة تتضمن السجل الكامل وجميع المشاريع المصرح بها.</p></div></section>`;
}

export function renderLifecycle(ctx) {
  const tasks=rows(ctx,'tasks'),visible=filtered(ctx,tasks),phases=rows(ctx,'phases').sort((a,b)=>(a.order||0)-(b.order||0));
  const complete=tasks.filter(t=>t.status==='completed').length;
  const heading=`<div class="page-heading"><div><span class="eyebrow">إدارة دورة المشروع</span><h1>من التأسيس إلى الإقفال</h1><p>جدولة البناء والتشغيل والفك، وربط الاعتماديات والتصاريح والفحص بمحضر تسليم واضح.</p></div><div class="actions">${allowed(ctx,'shared.create')?button('إضافة مرحلة','lc-new-phase','secondary'):''}${allowed(ctx,'task.create')?button('مهمة جديدة','lc-new-task'):''}</div></div>`;
  const strip=`<div class="phase-strip"><button class="phase-step ${!ctx.phaseId?'current':''}" type="button" data-action="lc-filter-phase" data-id=""><span class="phase-dot">${n(tasks.length)}</span>كل المراحل</button>${phases.map((p,i)=>{const list=tasks.filter(t=>t.phase_id===p.id),done=list.length>0&&list.every(t=>t.status==='completed');return `<button type="button" class="phase-step ${ctx.phaseId===p.id?'current':done?'done':''}" data-action="lc-filter-phase" data-id="${esc(p.id)}"><span class="phase-dot">${done?'✓':n(i+1)}</span>${esc(p.name)}</button>`;}).join('')}</div>`;
  const cards=visible.map(task=>{
    const dependencies=(task.dependencies||[]).map(id=>byId(ctx,'tasks',id)),open=dependencies.filter(d=>!d||d.status!=='completed');
    const overdue=task.due_date&&task.status!=='completed'&&Date.now()>Date.parse(task.due_date+'T23:59:59+03:00');
    const permit=task.permit_id?byId(ctx,'permits',task.permit_id):null;
    return `<article class="task-card"><div class="task-head"><div><h3>${esc(task.title)}</h3><div class="record-meta"><span>${esc(task.id)}</span><span>${esc(relatedName(ctx,'phases',task.phase_id))}</span>${attributed(ctx,task)}</div></div>${taskBadge(task.status)}</div><div class="task-tail"><div class="task-links"><span>من ${esc(safeDate(task.start_date))} إلى ${esc(safeDate(task.due_date))}</span>${overdue?badge('high','متأخر'):''}<span>${n(dependencies.length)} اعتماديات ${open.length?`· ${n(open.length)} لم تكتمل`:''}</span>${task.inspection_required?badge(inspectionPassed(task)?'completed':task.inspection_result==='failed'?'rejected':'inspection',inspectionPassed(task)?'فحص مجتاز':task.inspection_result==='failed'?'فحص غير مجتاز':'فحص مطلوب'):badge('reference','تسليم بإثبات')}${task.permit_id?badge(validity(permit).status,`تصريح: ${validity(permit).text}`):''}</div><div class="actions">${action('التفاصيل','lc-task-detail',task.id,'','ghost')}${taskActions(ctx,task)}</div></div></article>`;
  }).join('');
  return `${heading}${strip}<div class="phase-summary"><div class="phase-number">${n(complete)}</div><div><h2>مهمة مكتملة من ${n(tasks.length)}</h2><p>التنفيذ ثم الفحص ثم التسليم؛ أي تصريح مرتبط يجب أن يكون صالحًا.</p></div>${progress(tasks.length?Math.round(100*complete/tasks.length):0,'اكتمال مهام المشروع')}</div><section class="panel"><div class="panel-head"><div><h2>حزم العمل والمهام</h2><p>تتحقق قواعد المشروع في الخادم عند كل إجراء.</p></div>${badge('reference',`${n(visible.length)} نتيجة`)}</div>${filters(ctx,taskLabels,'tasks')}${cards||empty('لا توجد مهام مطابقة',tasks.length?'عدّل مرشحات البحث أو المرحلة.':'أضف مراحل المشروع، ثم المهام ومسؤوليها.')}</section>${closeoutPanel(ctx)}`;
}

function permitActions(ctx,permit) {
  const commands=[];
  if (allowed(ctx,'permit.transition')) for (const target of permitTransitions[permit.status]||[]) {
    const decision=['approved','rejected','revoked'].includes(target);
    const step=permitStep(permit),user=ctx.state?.user;
    const accountId=permitDecisionAccount(ctx,step);
    const assigned=user?.role===step.role&&user?.id===accountId;
    const roleAllowed=!decision||assigned||user?.role==='admin';
    const reason=!roleAllowed?`القرار مخصص لحساب ${accountId||'غير مربوط'} بدور ${roleName(step.role)}`:target==='approved'&&Date.parse(permit.valid_until)<=Date.now()?'انتهت الصلاحية؛ أنشئ تصريحًا جديدًا':'';
    const title=target==='approved'&&permitSteps(permit).length>1?`اعتماد الخطوة ${n(permitStepIndex(permit)+1)} من ${n(permitSteps(permit).length)}`:permitActionLabels[target];
    commands.push(action(title,'permit-transition',permit.id,target,['rejected','revoked'].includes(target)?'danger':'small',reason));
  }
  if (allowed(ctx,'permit.access')) {
    const inside=rows(ctx,'access_logs').some(a=>a.permit_id===permit.id&&!a.checked_out_at),valid=validity(permit);
    commands.push(action('تسجيل دخول','permit-access',permit.id,'checkin','small',inside?'للتصريح دخول قائم':!valid.valid?valid.text:''));
    commands.push(action('تسجيل خروج','permit-access',permit.id,'checkout','small',!inside?'لا يوجد دخول قائم':''));
  }
  return commands.join('');
}
export function renderPermits(ctx) {
  const permits=rows(ctx,'permits'),visible=filtered(ctx,permits),access=rows(ctx,'access_logs'),inside=access.filter(a=>!a.checked_out_at);
  const stats=[['تصاريح صالحة الآن',permits.filter(p=>validity(p).valid).length,'الفترة الحالية والاعتماد'],['بانتظار الاعتماد',permits.filter(p=>p.status==='submitted').length,'حسب دور الاعتماد المحدد'],['داخل الموقع',inside.length,'حركات دخول لم تسجل خروجًا'],['منتهية الصلاحية',permits.filter(p=>Date.parse(p.valid_until)<Date.now()).length,'يلزم تصريح جديد للدخول']];
  const permitRows=visible.map(p=>`<tr><td><span class="cell-title">${esc(p.title)}</span><span class="cell-sub">${esc(p.id)}</span>${badge(p.status,permitLabels[p.status])}</td><td>${esc(p.holder_name)}<span class="cell-sub">${esc(kindName(p.kind))}${p.vehicle_plate?` · ${esc(p.vehicle_plate)}`:''}${p.holder_id?` · ${esc(p.holder_id)}`:''}</span></td><td>${esc(relatedName(ctx,'zones',p.zone_id))}<span class="cell-sub">${esc(relatedName(ctx,'phases',p.phase_id))}</span></td><td>${esc(permitStep(p).authority)}<span class="cell-sub">${esc(roleName(permitStep(p).role))} · الخطوة ${n(permitStepIndex(p)+1)} / ${n(permitSteps(p).length)}</span></td><td>${esc(riyadhDate(p.valid_from))}<span class="cell-sub">حتى ${esc(riyadhDate(p.valid_until))}</span>${badge(validity(p).status,validity(p).text)}</td><td><div class="actions">${action('التفاصيل','permit-detail',p.id,'','ghost')}${permitActions(ctx,p)}</div></td></tr>`);
  const logRows=[...access].sort((a,b)=>String(b.checked_in_at).localeCompare(String(a.checked_in_at))).slice(0,30).map(a=>`<tr><td>${esc(a.holder_name)}<span class="cell-sub">${esc(a.permit_id)}</span></td><td>${esc(relatedName(ctx,'zones',a.zone_id))}</td><td>${esc(riyadhDate(a.checked_in_at))}<span class="cell-sub">${esc(a.checkin_evidence)}</span></td><td>${a.checked_out_at?`${esc(riyadhDate(a.checked_out_at))}<span class="cell-sub">${esc(a.checkout_evidence)}</span>`:badge('in_progress','داخل الموقع')}</td></tr>`);
  return `<div class="page-heading"><div><span class="eyebrow">التصاريح والتحكم بالدخول</span><h1>بوابات منظّمة وصلاحيات واضحة</h1><p>تصاريح الأفراد والمركبات والفرق والموردين، مرتبطة بالمنطقة والفترة والجهة ومسار اعتمادها. جميع الأوقات بتوقيت الرياض (UTC+03:00).</p></div><div class="actions">${allowed(ctx,'permit.create')?button('تصريح جديد','permit-new'):''}</div></div><div class="kpi-grid">${stats.map(([title,value,help])=>`<div class="kpi"><div class="kpi-top">${esc(title)}<span class="kpi-icon">${icon('permits')}</span></div><div class="kpi-value">${n(value)}</div><div class="kpi-foot">${esc(help)}</div></div>`).join('')}</div><section class="panel"><div class="panel-head"><div><h2>سجل التصاريح</h2><p>الدخول يتطلب تصريحًا معتمدًا وساريًا. الخروج يُسجل للدخول القائم حتى بعد انتهاء الصلاحية.</p></div>${badge('reference',`${n(visible.length)} نتيجة`)}</div>${filters(ctx,permitLabels,'permits')}${permitRows.length?table(['التصريح','الحامل / النوع','النطاق','الجهة والاعتماد','الصلاحية · الرياض','الإجراءات'],permitRows):empty('لا توجد تصاريح مطابقة',permits.length?'عدّل مرشحات العرض.':'أضف تصريحًا بجهة ومسؤول وفترة ومنطقة محددة.')}</section><section class="panel mt"><div class="panel-head"><div><h2>سجل الدخول والخروج</h2><p>أحدث ${n(Math.min(30,access.length))} حركة في المشروع، مع إثبات البوابة.</p></div>${badge(inside.length?'in_progress':'reference',`${n(inside.length)} داخل الموقع`)}</div>${logRows.length?table(['الحامل','المنطقة','الدخول · الرياض','الخروج · الرياض'],logRows):empty('لم تُسجل حركة بوابة','اعتمد تصريحًا ثم سجّل الدخول بإثبات من البوابة.')}</section>`;
}

function validateCommon(data) {
  for (const [key,title] of [['project_id','المشروع'],['phase_id','المرحلة'],['zone_id','المنطقة'],['responsible_id','المسؤول']]) requiredText(data[key],title);
}
function taskDetail(ctx,id) {
  const task=byId(ctx,'tasks',id);if(!task)throw new Error('المهمة غير موجودة؛ حدّث الصفحة.');
  const deps=(task.dependencies||[]).map(id=>byId(ctx,'tasks',id));
  detail(task.title,`<div class="details-grid">${detailItem('المرحلة',relatedName(ctx,'phases',task.phase_id))}${detailItem('المنطقة',relatedName(ctx,'zones',task.zone_id))}${detailItem('المسؤول',relatedName(ctx,'stakeholders',task.responsible_id))}${detailItem('الجدول',`${safeDate(task.start_date)} — ${safeDate(task.due_date)}`)}${detailItem('متطلب الفحص',task.inspection_required?'فحص واعتماد مدير قبل التسليم':'إثبات تسليم مطلوب')}${detailItem('التصريح المرتبط',task.permit_id?`${byId(ctx,'permits',task.permit_id)?.title||task.permit_id} · ${validity(byId(ctx,'permits',task.permit_id)).text}`:'لا يوجد تصريح مرتبط')}</div><div class="actions">${taskBadge(task.status)}${taskActions(ctx,task)}</div><h3 class="form-section">المهام السابقة</h3>${deps.length?deps.map(d=>`<div class="record-row"><div class="record-main"><h3>${esc(d?.title||'مهمة مفقودة')}</h3><p>${esc(d?.id||'راجع المرجع')}</p></div>${d?taskBadge(d.status):badge('rejected','غير موجودة')}</div>`).join(''):note('لا توجد اعتماديات مسجلة.')}<h3 class="form-section">الإثبات والملاحظات</h3><p>${esc(task.evidence||'لا يوجد إثبات عند الإنشاء.')}</p>${note(task.notes||'لا توجد ملاحظات إضافية.')}${task.inspection_required?inspectionHistory(task):''}${recordEvidence(ctx,'tasks',task.id)}<h3 class="form-section">سجل التنفيذ والفحص والتسليم</h3>${history(task.history)}`);
}
function permitDetail(ctx,id) {
  const permit=byId(ctx,'permits',id);if(!permit)throw new Error('التصريح غير موجود؛ حدّث الصفحة.');
  detail(permit.title,`<div class="details-grid">${detailItem('الحامل والنوع',`${permit.holder_name} · ${kindName(permit.kind)}`)}${detailItem('معرف الحامل / لوحة المركبة',[permit.holder_id,permit.vehicle_plate].filter(Boolean).join(' / '))}${detailItem('المنطقة',relatedName(ctx,'zones',permit.zone_id))}${detailItem('المرحلة',relatedName(ctx,'phases',permit.phase_id))}${detailItem('الجهة المعتمدة',permit.authority)}${detailItem('دور الاعتماد',roleName(permit.approval_role))}${detailItem('بداية الصلاحية · الرياض',riyadhDate(permit.valid_from))}${detailItem('نهاية الصلاحية · الرياض',riyadhDate(permit.valid_until))}${detailItem('المسؤول',relatedName(ctx,'stakeholders',permit.responsible_id))}${detailItem('ملاحظات',permit.notes)}</div><div class="actions">${badge(permit.status,permitLabels[permit.status])}${badge(validity(permit).status,validity(permit).text)}</div>${approvalRoute(ctx,permit)}<div class="actions mt">${permitActions(ctx,permit)}</div><h3 class="form-section">إثبات الطلب</h3><p>${esc(permit.evidence||'لا يوجد إثبات عند الإنشاء.')}</p>${recordEvidence(ctx,'permits',permit.id)}<h3 class="form-section">سجل القرارات</h3>${history(permit.history,permitLabels)}`);
}

export function lifecycleActions(ctx) {
  return {
    'lc-filter-phase':async element=>{ctx.phaseId=element.dataset.id||'';ctx.refresh();},
    'lc-new-phase':async ()=>{
      if (!allowed(ctx,'shared.create')) throw new Error('إضافة مرحلة تتطلب مديرًا.');
      modal('إضافة مرحلة للمشروع',`<div class="form-grid">${select('project_id','المشروع',all(ctx,'projects'),ctx.projectId,'required')}${field('name','اسم المرحلة','text','','required maxlength="200"')}${select('kind','نوع المرحلة',phaseKinds,'planning','required')}${field('order','الترتيب','number',rows(ctx,'phases').length,'required min="0" step="1" max="1000"')}${textarea('notes','نطاق المرحلة','','maxlength="2000"')}</div>`,async data=>{const order=Number(data.order);if(!Number.isInteger(order)||order<0)throw new Error('ترتيب المرحلة يجب أن يكون عددًا صحيحًا غير سالب.');await ctx.command('shared.create',{...data,collection:'phases',order});});
    },
    'lc-new-task':async ()=>{
      if(!allowed(ctx,'task.create'))throw new Error('إنشاء المهام يتطلب مديرًا.');
      const tasks=rows(ctx,'tasks'),permits=rows(ctx,'permits');
      modal('مهمة جديدة وحزمة تسليم',`<div class="form-grid">${field('title','عنوان المهمة / حزمة العمل','text','','required maxlength="240"')}${ctx.commonFields({phase_id:ctx.phaseId||''})}${field('start_date','تاريخ البدء','date','','required')}${field('due_date','موعد التسليم','date','','required')}${select('permit_id','التصريح المرتبط',[{id:'',name:'لا يلزم تصريح مرتبط'},...permits.map(p=>({id:p.id,name:`${p.title} · ${permitLabels[p.status]} · ${relatedName(ctx,'zones',p.zone_id)}`}))])}<label class="checkbox-field wide"><input type="checkbox" name="inspection_required" checked><span>تتطلب المهمة فحصًا واعتماد مدير قبل التسليم والإكمال.</span></label>${textarea('inspection_checklist_lines','بنود الفحص · بند واحد في كل سطر',defaultChecklist.map(item=>item.label).join('\n'),'maxlength="4200"')}${note('هذه بنود أولية قابلة لإعادة التسمية. حدّد من 1 إلى 20 بندًا يناسب نطاق المهمة؛ جميع البنود المدخلة إلزامية.')} ${textarea('evidence','مرجع مستند التخطيط / التكليف','','maxlength="4000" placeholder="رقم محضر أو مرجع ملف محفوظ"')}${textarea('notes','معايير القبول والملاحظات','','maxlength="4000"')}</div><h3 class="form-section">الاعتماديات · المهام التي يجب أن تكتمل أولًا</h3>${tasks.length?tasks.map(t=>`<label class="checkbox-field"><input type="checkbox" name="dependencies" value="${esc(t.id)}"><span>${esc(t.title)} — ${esc(taskLabels[t.status]||t.status)}</span></label>`).join(''):note('لا توجد مهام سابقة في هذا المشروع.')}<p class="field-help">المشروع والمرحلة والمنطقة والمسؤول مطلوبة. لا يبدأ التنفيذ ولا يعتمد الإكمال قبل اكتمال الاعتماديات وصلاحية التصريح المرتبط.</p>`,async(data,form)=>{
        validateCommon(data);if(data.start_date>data.due_date)throw new Error('موعد التسليم يسبق تاريخ البدء.');
        const dependencies=new FormData(form).getAll('dependencies');if(dependencies.length>100)throw new Error('الحد الأقصى 100 اعتمادية.');
        if(dependencies.some(id=>byId(ctx,'tasks',id)?.project_id!==data.project_id))throw new Error('كل الاعتماديات يجب أن تتبع المشروع المحدد.');
        if(data.permit_id){const p=byId(ctx,'permits',data.permit_id);if(!p||p.project_id!==data.project_id||p.zone_id!==data.zone_id)throw new Error('التصريح يجب أن يتبع المشروع والمنطقة المحددين.');}
        const inspectionRequired=form.elements.inspection_required.checked;const inspectionChecklist=data.inspection_checklist_lines.split(/\r?\n/).map(line=>line.trim()).filter(Boolean).map((label,index)=>({id:`check-${index+1}`,label,required:true}));if(inspectionRequired&&(inspectionChecklist.length<1||inspectionChecklist.length>20||inspectionChecklist.some(item=>item.label.length>200)))throw new Error('أدخل من 1 إلى 20 بند فحص، بطول لا يتجاوز 200 حرف لكل بند.');delete data.inspection_checklist_lines;await ctx.command('task.create',{...data,dependencies,inspection_required:inspectionRequired,...(inspectionRequired?{inspection_checklist:inspectionChecklist}:{})});
      },'إنشاء المهمة',true);
    },
    'lc-task-detail':async element=>taskDetail(ctx,element.dataset.id),
    'task-detail':async element=>taskDetail(ctx,element.dataset.id),
    'lc-task-inspect':async element=>{
      if(!allowed(ctx,'task.inspect'))throw new Error('تسجيل واعتماد فحص البنود يتطلب مديرًا.');
      const task=byId(ctx,'tasks',element.dataset.id);if(!task||task.status!=='inspection'||!task.inspection_required)throw new Error('الفحص متاح للمهام المحالة للفحص فقط.');
      const items=checklist(task),attachments=rows(ctx,'attachments').filter(a=>a.record_collection==='tasks'&&a.record_id===task.id);
      modal('فحص البنود وتوثيق النتيجة',`<p>${esc(task.title)}</p>${note(`دورة التنفيذ الحالية: ${n(task.inspection_cycle||0)}. اختر نتيجة كل بند. الإخفاق يحتاج ملاحظات، ويُحفظ في السجل دون حذف المحاضر السابقة.`)}${items.map((item,index)=>`<h3 class="form-section">${n(index+1)}. ${esc(item.label)} ${item.required===false?'(إضافي)':'(إلزامي)'}</h3><div class="form-grid">${select(`inspection_status_${index}`,'نتيجة الفحص',[{id:'',name:'اختر نتيجة الفحص'},{id:'passed',name:'اجتاز الفحص'},{id:'failed',name:'أخفق — يحتاج معالجة'}],'','required')}${textarea(`inspection_notes_${index}`,'ملاحظات البند · مطلوبة عند الإخفاق','','maxlength="2000"')}</div>`).join('')}<h3 class="form-section">إثبات ومحضر الفحص</h3><div class="form-grid">${textarea('evidence','مرجع محضر الفحص (مطلوب)','','required maxlength="4000"')}</div>${attachments.length?`<h3 class="form-section">ربط ملفات محفوظة بالمحضر</h3>${attachments.map(a=>`<label class="checkbox-field"><input name="attachment_ids" type="checkbox" value="${esc(a.id)}"><span>${esc(a.label||a.filename)} · ${esc(a.id)}</span></label>`).join('')}`:note('لا توجد ملفات محفوظة لهذه المهمة. يمكنك إرفاق ملف من تفاصيل المهمة قبل بدء هذا النموذج؛ مرجع المحضر النصي مطلوب في جميع الحالات.')}`,async(data,form)=>{
        const results=items.map((item,index)=>({item_id:item.id,status:data[`inspection_status_${index}`],notes:data[`inspection_notes_${index}`]?.trim()||''}));
        for(const result of results){if(!['passed','failed'].includes(result.status))throw new Error('اختر نتيجة لجميع البنود.');if(result.status==='failed'&&!result.notes)throw new Error('اكتب ملاحظات توضّح كل بند أخفق في الفحص.');}
        await ctx.command('task.inspect',{id:task.id,results,evidence:data.evidence,attachment_ids:new FormData(form).getAll('attachment_ids')});
      },'حفظ محضر الفحص',true);
    },
    'lc-task-transition':async element=>{
      if(!allowed(ctx,'task.transition'))throw new Error('لا تملك صلاحية تغيير حالة المهمة.');
      const task=byId(ctx,'tasks',element.dataset.id),target=element.dataset.target;if(!task||(taskTransitions[task.status]||[]).indexOf(target)<0)throw new Error('انتقال غير صالح؛ حدّث البيانات.');
      const blockers=taskBlockers(ctx,task,target);if(blockers.length)throw new Error(blockers.join(' · '));
      modal(taskActionLabels[target],`<p>${esc(task.title)}</p><div class="actions mt">${taskBadge(task.status)}${icon('arrow')}${taskBadge(target)}</div><div class="form-grid mt">${textarea('evidence',target==='completed'?'إثبات الفحص / محضر التسليم (مطلوب)':'إثبات الإجراء أو مرجع الملف','',`${target==='completed'?'required ':''}maxlength="4000"`)}${textarea('reason',target==='blocked'?'سبب التعثر (مطلوب)':'ملاحظات الإجراء','',`${target==='blocked'?'required ':''}maxlength="2000"`)}${target==='completed'&&task.inspection_required?note(`سيُعتمد التسليم على محضر الفحص الناجح ${latestInspection(task)?.id||''} لدورة التنفيذ الحالية.`):''}</div>${note(target==='completed'?'يعاد التحقق من الاعتماديات والتصريح في الخادم لحظة الحفظ.':'يسجل الإجراء باسم المستخدم الحالي وفي سجل التدقيق.')}`,async data=>{await ctx.command('task.transition',{id:task.id,status:target,...data});},'تسجيل الإجراء');
    },
    'lc-closeout':async ()=>{
      const data=closeoutData(ctx),report=all(ctx,'closeout').find(r=>r.project_id===ctx.projectId),categories=[['العهد التشغيلية',data.custody,c=>`${relatedName(ctx,'items',c.item_id)} · ${c.reference}`,c=>`${n(c.outstanding)} وحدة · ${relatedName(ctx,'stakeholders',c.custodian_id)}`],['طلبات الزوار المفتوحة',data.orders,o=>o.id,o=>o.status],['البلاغات غير المقفلة',data.incidents,i=>i.title,i=>i.status],['المهام غير المكتملة',data.tasks,t=>t.title,t=>taskLabels[t.status]||t.status],['حجوزات المخزون',data.reservations,r=>`${relatedName(ctx,'items',r.item_id)} · ${r.reference}`,r=>`${n(r.qty)} وحدة · ${relatedName(ctx,'zones',r.zone_id)}`],['مواد في الصيانة',data.maintenance,s=>relatedName(ctx,'items',s.item_id),s=>`${n(s.maintenance)} وحدة`],['دخول بلا خروج',data.access,a=>a.holder_name,a=>a.permit_id],['مشتريات غير مستلمة',data.procurements,p=>p.title,p=>p.status]];
      detail('قائمة مراجعة الإقفال',`${note('هذه قائمة من السجلات الحالية وليست محضر إقفال معتمدًا. تشمل المشروع المحدد كاملًا، بغض النظر عن مرشحات الصفحة.')}<h3 class="form-section">نتيجة تحقق الخادم</h3>${report?.blockers?.length?table(['المتطلب','العدد','مراجع السجلات'],report.blockers.map(b=>`<tr><td>${esc(b.label)}</td><td>${n(b.count)}</td><td>${esc(b.ids.join('، '))}</td></tr>`)):note(report?.ready?'اكتملت الشروط الآلية؛ يلزم اعتماد محضر الإقفال.':'نتيجة الخادم غير متاحة؛ حدّث الصفحة.')}${categories.map(([name,list,title,state])=>`<h3 class="form-section">${esc(name)} · ${n(list.length)}</h3>${list.length?table(['السجل','المتبقي / الحالة'],list.map(row=>`<tr><td>${esc(title(row))}</td><td>${esc(state(row))}</td></tr>`)):note('لا توجد سجلات مفتوحة في هذا البند.')}`).join('')}<h3 class="form-section">التدقيق والإثباتات</h3>${note('واجهة الحالة تعرض آخر 200 إجراء فقط. استخدم النسخة الكاملة لفحص سجل التدقيق ومحاضر الجرد والتسليم قبل اعتماد الإقفال.')}`);
    },
    'lc-export-closeout':async ()=>download(`closeout-${ctx.projectId||'all'}-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify({type:'closeout-review-checklist',project_id:ctx.projectId||'',generated_at:new Date().toISOString(),revision:ctx.state.revision,provenance:ctx.state.data_mode||ctx.state.mode,approved:false,server_report:all(ctx,'closeout').find(r=>r.project_id===ctx.projectId)||null,records:closeoutData(ctx),audit_coverage:'latest 200 commands visible in state; full audit requires backup'},null,2)),
    'lc-project-close':async element=>{
      if(!allowed(ctx,'project.close'))throw new Error('اعتماد إقفال المشروع يتطلب مديرًا.');
      const project=byId(ctx,'projects',element.dataset.id),report=all(ctx,'closeout').find(r=>r.project_id===project?.id);
      if(!project||!report?.ready)throw new Error('أكمل متطلبات الإقفال والجرد النهائي أولًا.');
      modal('اعتماد إقفال المشروع',`<p>${esc(project.name)}</p>${note('يوقف الإقفال معاملات المشروع الجديدة. يتحقق الخادم مجددًا من المهام والبلاغات والطلبات والمشتريات والعهد والدخول والجرد النهائي قبل الحفظ.')}<div class="form-grid mt">${textarea('evidence','مرجع محضر الإقفال والجرد النهائي','','required maxlength="4000"')}${textarea('summary','ملخص التسليم والإقفال','','required maxlength="4000"')}<label class="checkbox-field wide"><input type="checkbox" name="confirmed" required><span>راجعت محاضر التسليم والجرد وأعتمد إقفال هذا المشروع.</span></label></div>`,async(data,form)=>{if(!form.elements.confirmed.checked)throw new Error('المراجعة والاعتماد مطلوبان.');await ctx.command('project.close',{id:project.id,evidence:data.evidence,summary:data.summary});},'اعتماد الإقفال');
    },
    'lc-project-reopen':async element=>{
      if(!allowed(ctx,'project.reopen'))throw new Error('إعادة فتح المشروع تتطلب مديرًا.');
      const project=byId(ctx,'projects',element.dataset.id);if(!project||project.status!=='closed')throw new Error('المشروع غير مقفل.');
      modal('إعادة فتح المشروع',`<p>${esc(project.name)}</p><div class="form-grid mt">${textarea('reason','سبب إعادة الفتح','','required maxlength="2000"')}${textarea('evidence','مرجع اعتماد إعادة الفتح','','required maxlength="4000"')}</div>`,async data=>ctx.command('project.reopen',{id:project.id,reason:data.reason,evidence:data.evidence}),'إعادة فتح موثقة');
    },
    'lc-export-audit':async ()=>{const response=await fetch('/api/backup',{credentials:'same-origin'});const body=await response.json();if(!response.ok)throw new Error(body.error||'تعذر تصدير نسخة التدقيق.');download(`riyadh-book-fair-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(body,null,2));},
    'permit-new':async ()=>{
      if(!allowed(ctx,'permit.create'))throw new Error('لا تملك صلاحية إنشاء تصريح.');
      const from=inputRiyadh(new Date()),until=inputRiyadh(new Date(Date.now()+8*3600000));
      const d=modal('طلب تصريح جديد',`<div class="form-grid">${field('title','عنوان التصريح','text','','required maxlength="240"')}${select('kind','نوع التصريح',kinds,'person','required')}${field('holder_name','اسم الفرد أو الفريق أو المورد','text','','required maxlength="200"')}${field('holder_id','معرّف الحامل الداخلي / مرجع الجهة','text','','maxlength="120"')}${field('vehicle_plate','لوحة المركبة · مطلوبة للمركبات','text','','maxlength="60"')}${ctx.commonFields({phase_id:ctx.phaseId||''})}${approvalStepFields(ctx)}${field('valid_from','بداية الصلاحية · توقيت الرياض','datetime-local',from,'required')}${field('valid_until','نهاية الصلاحية · توقيت الرياض','datetime-local',until,'required')}${textarea('evidence','مرجع خطاب الطلب أو مستند التصريح','','maxlength="4000"')}${textarea('notes','المهمة ونطاق الدخول وتعليمات البوابة','','maxlength="4000"')}</div><p class="field-help">تُحفظ الأوقات مع المنطقة الزمنية UTC+03:00 مهما كانت منطقة جهازك. الطلب يبدأ مسودة، ثم يقدم للاعتماد لدى الدور المحدد. إثبات القرار إلزامي عند الاعتماد أو الرفض أو الإلغاء.</p>`,async data=>{
        validateCommon(data);if(data.kind==='vehicle')requiredText(data.vehicle_plate,'لوحة المركبة');
        const start=new Date(data.valid_from+':00+03:00'),end=new Date(data.valid_until+':00+03:00');if(!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||end<=start)throw new Error('حدد فترة صحيحة تنتهي بعد البداية.');
        const count=Number(data.approval_step_count);if(!Number.isInteger(count)||count<1||count>3)throw new Error('اختر من خطوة إلى ثلاث خطوات اعتماد.');const approval_steps=Array.from({length:count},(_,index)=>({id:'step-'+(index+1),authority:requiredText(index===0?data.authority:data['approval_authority_'+(index+1)],'جهة الخطوة '+(index+1)),role:index===0?data.approval_role:data['approval_role_'+(index+1)],stakeholder_id:requiredText(data['approval_stakeholder_'+(index+1)],'ممثل الجهة للخطوة '+(index+1))}));for(const step of approval_steps){const person=byId(ctx,'stakeholders',step.stakeholder_id);if(!person||person.project_id!==data.project_id||!person.account_id)throw new Error('اختر جهة من المشروع مرتبطة بحساب دخول لكل خطوة.');}await ctx.command('permit.create',{...data,approval_steps,valid_from:start.toISOString(),valid_until:end.toISOString()});
      },'حفظ مسودة التصريح',true);
      const update=()=>{d.querySelector('[name=vehicle_plate]').required=d.querySelector('[name=kind]').value==='vehicle';};d.querySelector('[name=kind]').addEventListener('change',update);update();const updateSteps=()=>{const count=Number(d.querySelector('[name=approval_step_count]').value);d.querySelectorAll('[data-approval-step]').forEach(group=>{const active=Number(group.dataset.approvalStep)<=count;group.hidden=!active;group.querySelectorAll('input,select').forEach(input=>{input.disabled=!active;input.required=active&&(input.name.startsWith('approval_authority_')||input.name.startsWith('approval_stakeholder_'));});});};d.querySelector('[name=approval_step_count]').addEventListener('change',updateSteps);updateSteps();
    },
    'permit-detail':async element=>permitDetail(ctx,element.dataset.id),
    'permit-transition':async element=>{
      if(!allowed(ctx,'permit.transition'))throw new Error('لا تملك صلاحية تحديث التصريح.');
      const permit=byId(ctx,'permits',element.dataset.id),target=element.dataset.target;if(!permit||!(permitTransitions[permit.status]||[]).includes(target))throw new Error('انتقال غير صالح؛ حدّث البيانات.');
      const decision=['approved','rejected','revoked'].includes(target),step=permitStep(permit),accountId=permitDecisionAccount(ctx,step),user=ctx.state?.user,adminOverride=decision&&user?.role==='admin';if(decision&&!adminOverride&&!(user?.role===step.role&&user?.id===accountId))throw new Error(`القرار مخصص لحساب ${accountId||'غير مربوط'} بدور ${roleName(step.role)}.`);
      modal(permitActionLabels[target],`<p>${esc(permit.title)} · ${esc(permit.holder_name)}</p>${note(`الخطوة ${permitStepIndex(permit)+1} من ${permitSteps(permit).length} · ${step.authority} · الحساب ${accountId||'غير مربوط'} · الدور ${roleName(step.role)}`)}${adminOverride?note('سيُسجل القرار كتجاوز إداري، ويلزم ذكر سببه صراحة.'):''}${target==='approved'&&permitStepIndex(permit)<permitSteps(permit).length-1?note('اعتماد هذه الخطوة ينقل الطلب إلى الخطوة التالية؛ لا يفتح صلاحية الدخول بعد.'):''}<div class="form-grid mt">${textarea('evidence',decision?'إثبات القرار (مطلوب)':'مرجع تقديم الطلب','',`${decision?'required ':''}maxlength="4000"`)}${textarea('reason',adminOverride?'سبب التجاوز الإداري (مطلوب)':['rejected','revoked'].includes(target)?'سبب الرفض أو الإلغاء (مطلوب)':'ملاحظات القرار','',`${adminOverride||['rejected','revoked'].includes(target)?'required ':''}maxlength="2000"`)}</div>`,async data=>ctx.command('permit.transition',{id:permit.id,status:target,...data}),'تسجيل القرار');
    },
    'permit-access':async element=>{
      if(!allowed(ctx,'permit.access'))throw new Error('تسجيل البوابة متاح للأمن ومدير النظام.');
      const permit=byId(ctx,'permits',element.dataset.id),target=element.dataset.target;if(!permit||!['checkin','checkout'].includes(target))throw new Error('حركة غير صالحة.');
      const inside=rows(ctx,'access_logs').some(a=>a.permit_id===permit.id&&!a.checked_out_at);
      if(target==='checkin'&&(!validity(permit).valid||inside))throw new Error(inside?'للتصريح دخول قائم.':validity(permit).text);
      if(target==='checkout'&&!inside)throw new Error('لا يوجد دخول قائم لتسجيل الخروج.');
      modal(target==='checkin'?'تسجيل الدخول من البوابة':'تسجيل الخروج من البوابة',`<div class="details-grid">${detailItem('الحامل',permit.holder_name)}${detailItem('المنطقة المصرح بها',relatedName(ctx,'zones',permit.zone_id))}${detailItem('النوع / اللوحة',`${kindName(permit.kind)} ${permit.vehicle_plate||''}`)}${detailItem('الصلاحية',validity(permit).text)}</div><div class="form-grid">${textarea('evidence','إثبات البوابة (مطلوب)','','required maxlength="4000" placeholder="مرجع مسح البوابة أو سجل الحارس أو محضر الدخول / الخروج"')}</div>${note(target==='checkout'?'الخروج يغلق حركة الدخول القائمة، ويظل متاحًا حتى عند انتهاء التصريح أو إلغائه.':'يتحقق الخادم من صلاحية التصريح ومنع تكرار الدخول لحظة الحفظ.')}`,async data=>ctx.command('permit.access',{id:permit.id,action:target,zone_id:permit.zone_id,evidence:data.evidence}),target==='checkin'?'تأكيد الدخول':'تأكيد الخروج');
    }
  };
}

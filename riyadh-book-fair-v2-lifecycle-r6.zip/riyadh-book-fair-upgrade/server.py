#!/usr/bin/env python3
"""Local review and authenticated deployment server for the Riyadh Book Fair app.

Review: python3 server.py --review --demo --port 8765
Production: RBF_ACCOUNTS_FILE=/private/accounts.json python3 server.py \
    --host 0.0.0.0 --origin https://example.com --db /persistent/app.sqlite
Put a TLS reverse proxy in front of public deployments. Public mode refuses to
start without accounts and explicit HTTPS origin. No credentials are bundled.
"""
from __future__ import annotations
import argparse
import base64
import collections
import getpass
import hashlib
import hmac
import ipaddress
import json
import mimetypes
import math
import os
from pathlib import Path
import secrets
import sqlite3
import sys
import tempfile
import threading
import time
from http.cookies import SimpleCookie, CookieError
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote, quote
from domain import DomainStore, DomainError, ROLES, COMMAND_ROLES, require
from backup_service import BackupService

ROOT = Path(__file__).resolve().parent
MAX_BODY = 1024 * 1024
MAX_ATTACHMENT_BODY = 8 * 1024 * 1024
SESSION_SECONDS = 8 * 60 * 60
ROLE_LABELS = {'admin':'مدير النظام','manager':'مدير المشروع','warehouse':'أمين المستودع',
               'security':'الأمن والتصاريح','field':'الفريق الميداني','viewer':'مشاهد'}

def hash_password(password):
    if len(password)<12: raise ValueError('كلمة المرور يجب أن تكون 12 حرفًا على الأقل')
    if len(password)>1024: raise ValueError('كلمة المرور طويلة جدًا')
    if not hasattr(hashlib,'scrypt'): raise ValueError('Python مع OpenSSL وhashlib.scrypt مطلوب؛ استخدم Python 3.11 أو أحدث')
    salt=secrets.token_bytes(16)
    key=hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1,dklen=32)
    return 'scrypt$16384$8$1$'+base64.urlsafe_b64encode(salt).decode()+'$'+base64.urlsafe_b64encode(key).decode()

def verify_password(password,encoded):
    try:
        kind,n,r,p,salt,key=encoded.split('$')
        if (kind,n,r,p)!=('scrypt','16384','8','1') or len(password)>1024: return False
        salt=base64.urlsafe_b64decode(salt); key=base64.urlsafe_b64decode(key)
        if len(salt)!=16 or len(key)!=32: return False
        calculated=hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1,dklen=32)
        return hmac.compare_digest(key,calculated)
    except (ValueError,TypeError,AttributeError): return False

def loopback(host):
    if host=='localhost': return True
    try: return ipaddress.ip_address(host).is_loopback
    except ValueError: return False

def load_accounts(path=None,encoded=None):
    if path:
        with open(path,encoding='utf-8') as f: data=json.load(f)
    elif encoded: data=json.loads(encoded)
    else: return {}
    rows=data.get('accounts') if isinstance(data,dict) and 'accounts' in data else data
    if not isinstance(rows,list): raise ValueError('ملف الحسابات يجب أن يحتوي قائمة accounts')
    result={}
    for row in rows:
        if not isinstance(row,dict): raise ValueError('سجل حساب غير صالح')
        name=row.get('username','')
        if not isinstance(name,str) or not name.strip() or len(name)>100 or name in result: raise ValueError('اسم حساب غير صالح أو مكرر')
        role=row.get('role'); encoded_hash=row.get('password_hash','')
        if role not in ROLES: raise ValueError('دور حساب غير صالح')
        # Parse parameters without exposing hash values in startup errors.
        try:
            parts=encoded_hash.split('$')
            if len(parts)!=6 or parts[:4]!=['scrypt','16384','8','1'] or len(base64.urlsafe_b64decode(parts[4]))!=16 or len(base64.urlsafe_b64decode(parts[5]))!=32: raise ValueError()
        except (ValueError,TypeError,AttributeError): raise ValueError('تجزئة كلمة مرور غير صالحة؛ استخدم --hash-password')
        scope=row.get('project_ids')
        if scope is not None and (not isinstance(scope,list) or not all(isinstance(x,str) and x for x in scope)): raise ValueError('نطاق مشاريع الحساب غير صالح')
        result[name]={'id':str(row.get('id') or name),'name':str(row.get('name') or name),
                      'role':role,'username':name,'password_hash':encoded_hash}
        if scope is not None: result[name]['project_ids']=list(dict.fromkeys(scope))
    if len({x['id'] for x in result.values()}) != len(result): raise ValueError('معرفات الحسابات مكررة')
    return result

def create_account_file(path,username,name,role,password,project_ids=None):
    """Append one account atomically; never print the password or resulting hash."""
    target=Path(path).expanduser().resolve()
    if not username or len(username)>100: raise ValueError('اسم الحساب غير صالح')
    accounts=load_accounts(str(target)) if target.exists() else {}
    if username in accounts: raise ValueError('الحساب موجود؛ لا يتم استبداله تلقائيًا')
    row={'id':username,'username':username,'name':name or username,'role':role,'password_hash':hash_password(password)}
    if project_ids is not None: row['project_ids']=list(dict.fromkeys(project_ids))
    accounts[username]=row
    target.parent.mkdir(parents=True,exist_ok=True)
    temp_name=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=target.parent,prefix='.accounts-',delete=False) as handle:
            temp_name=handle.name
            os.chmod(temp_name,0o600)
            json.dump({'accounts':list(accounts.values())},handle,ensure_ascii=False,indent=2)
            handle.write('\n');handle.flush();os.fsync(handle.fileno())
        os.replace(temp_name,target)
    finally:
        if temp_name and os.path.exists(temp_name): os.unlink(temp_name)
    return target

class Application:
    def __init__(self,store,accounts,review=False,host='127.0.0.1',port=8765,origins=(),static_root=None,backups=None):
        self.store,self.accounts,self.review=store,accounts,review
        self.backups=backups
        self.mode='demo' if store.mode=='demo' else ('review' if review else 'production')
        self.host,self.port=host,port
        self.static_root=Path(static_root or ROOT/'app').resolve()
        self.origins=set(origins)
        self.cookie_secure=not review and any(x.startswith('https://') for x in self.origins)
        self.throttle=collections.defaultdict(collections.deque)
        self.lock=threading.Lock()
        self.dummy_hash=hash_password(secrets.token_urlsafe(24))
        if loopback(host):
            self.origins.update({f'http://127.0.0.1:{port}',f'http://localhost:{port}',f'http://[::1]:{port}'})
        self.allowed_hosts={urlsplit(x).netloc.lower() for x in self.origins}

    def public_user(self,account): return {k:account[k] for k in ('id','name','role','project_ids') if k in account}

    def account_directory(self,actor):
        require(actor['role'] in {'admin','manager'},'صلاحية عرض دليل الحسابات مطلوبة','forbidden',403)
        allowed=set(actor.get('project_ids',[])) if 'project_ids' in actor else None
        return sorted((self.public_user(account) for account in self.accounts.values()
                       if allowed is None or 'project_ids' not in account or allowed.intersection(account['project_ids'])),
                      key=lambda row:(row['name'],row['id']))

    def validate_stakeholder_account(self,data,actor):
        command=data.get('type')
        if command not in {'shared.create','stakeholder.bind_account'} or not isinstance(data.get('payload'),dict):
            return
        payload=data['payload']
        if command=='shared.create' and payload.get('collection')!='stakeholders':
            return
        if not payload.get('account_id'):
            return
        account_id=payload['account_id']
        require(isinstance(account_id,str) and len(account_id)<=100,'معرف حساب الجهة غير صالح')
        if command=='stakeholder.bind_account':
            with self.store.connect() as db:
                stakeholder=self.store.get(db,'stakeholders',payload.get('id'))
            project_id=stakeholder['project_id']
        else:
            project_id=payload.get('project_id')
        require('project_ids' not in actor or project_id in actor['project_ids'],
                'الجهة خارج نطاق الحساب','project_scope_required',403)
        account=next((row for row in self.accounts.values() if row['id']==account_id),None)
        if self.review and account_id=='review-admin':
            return
        if 'project_ids' in actor:
            require(account is not None and
                    ('project_ids' not in account or project_id in account['project_ids']),
                    'حساب الجهة غير متاح لهذا المشروع','account_unavailable',400)
            return
        require(account is not None,'اربط الجهة بحساب دخول موجود في دليل الحسابات','account_not_found',400)
        require('project_ids' not in account or project_id in account['project_ids'],
                'حساب الجهة لا يشمل هذا المشروع','account_scope_mismatch',400)

    def validate_permit_accounts(self,data):
        if data.get('type')!='permit.create' or not isinstance(data.get('payload'),dict):
            return
        payload=data['payload']
        steps=payload.get('approval_steps')
        if steps is None:
            steps=[{'stakeholder_id':payload.get('approval_stakeholder_id'),'role':payload.get('approval_role','security')}]
        if not isinstance(steps,list):
            return  # Domain validation supplies the precise structural error.
        with self.store.connect() as db:
            for step in steps:
                if not isinstance(step,dict) or not step.get('stakeholder_id'):
                    continue
                stakeholder=self.store.get(db,'stakeholders',step['stakeholder_id'])
                account=next((row for row in self.accounts.values() if row['id']==stakeholder.get('account_id')),None)
                if self.review and stakeholder.get('account_id')=='review-admin':
                    continue
                require(account is not None,'حساب جهة الاعتماد غير موجود؛ حدّث ارتباط الجهة','approval_account_not_found',400)
                require(account['role'] in {step.get('role'),'admin'},
                        'دور حساب الجهة لا يطابق دور خطوة الاعتماد','approval_account_role_mismatch',400)
                require('project_ids' not in account or stakeholder.get('project_id') in account['project_ids'],
                        'حساب جهة الاعتماد لا يشمل هذا المشروع','approval_account_scope_mismatch',400)

    def actor(self,handler):
        if self.review:
            if not loopback(handler.client_address[0]): return None
            return {'id':'review-admin','name':'مدير المراجعة المحلية','role':'admin'}
        try:
            cookie=SimpleCookie(); cookie.load(handler.headers.get('Cookie',''))
            token=cookie['rbf_session'].value if 'rbf_session' in cookie else ''
        except CookieError: return None
        if not token or len(token)>200: return None
        digest=hashlib.sha256(token.encode()).hexdigest()
        with self.store.connect() as c:
            row=c.execute('SELECT user_id,expires_at FROM sessions WHERE token_hash=?',(digest,)).fetchone()
        if not row or row['expires_at']<int(time.time()): return None
        account=next((x for x in self.accounts.values() if x['id']==row['user_id']),None)
        return self.public_user(account) if account else None

    def login(self,username,password,ip):
        require(isinstance(username,str) and isinstance(password,str),'بيانات الدخول غير صالحة')
        point=time.monotonic()
        with self.lock:
            queue=self.throttle[ip]
            while queue and queue[0]<point-300: queue.popleft()
            require(len(queue)<10,'محاولات كثيرة؛ أعد المحاولة بعد خمس دقائق','rate_limited',429)
            queue.append(point)
        account=self.accounts.get(username)
        valid=verify_password(password,account['password_hash'] if account else self.dummy_hash)
        require(account is not None and valid,'اسم الحساب أو كلمة المرور غير صحيحة','invalid_credentials',401)
        token=secrets.token_urlsafe(32)
        with self.store.connect() as c:
            c.execute('DELETE FROM sessions WHERE expires_at<?',(int(time.time()),))
            c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),account['id'],int(time.time())+SESSION_SECONDS))
        return token,self.public_user(account)

    def session_cookie(self,token,clear=False):
        return 'rbf_session='+token+'; Path=/; HttpOnly; SameSite=Strict; Max-Age='+('0' if clear else str(SESSION_SECONDS))+('; Secure' if self.cookie_secure else '')

class Handler(BaseHTTPRequestHandler):
    server_version='RBF'
    sys_version=''
    protocol_version='HTTP/1.1'

    @property
    def app(self): return self.server.app

    def log_message(self,fmt,*args):
        # Never log bodies, cookies, query strings or user input.
        sys.stderr.write('%s %s %s\n'%(self.log_date_time_string(),self.command,getattr(self,'response_status','-')))

    def security_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
        if self.app.cookie_secure: self.send_header('Strict-Transport-Security','max-age=31536000')

    def respond(self,status,data,headers=None,content_type='application/json; charset=utf-8'):
        self.response_status=status
        if not isinstance(data,bytes): data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status)
        self.security_headers()
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        for key,value in (headers or {}).items(): self.send_header(key,value)
        self.end_headers()
        if self.command!='HEAD': self.wfile.write(data)

    def host_check(self):
        require(len(self.headers.get_all('Host',[]))==1,'ترويسة المضيف غير صالحة','invalid_host',403)
        require(self.headers.get('Host','').lower() in self.app.allowed_hosts,'مضيف الطلب غير مسموح','invalid_host',403)

    def csrf_check(self):
        require(len(self.headers.get_all('Origin',[]))==1,'مصدر الطلب مطلوب ووحيد','invalid_origin',403)
        require(self.headers.get('Origin','') in self.app.origins,'مصدر الطلب غير مسموح؛ افتح المنصة من رابطها المعتمد','invalid_origin',403)
        require(self.headers.get('Sec-Fetch-Site','same-origin') not in {'cross-site'},'طلب من موقع خارجي غير مسموح','invalid_origin',403)

    def body(self):
        require(self.headers.get('Content-Type','').split(';')[0].strip()=='application/json','يجب إرسال JSON','unsupported_media_type',415)
        require(len(self.headers.get_all('Content-Length',[]))==1,'ترويسة طول الطلب غير صالحة','bad_request',400)
        require(not self.headers.get('Transfer-Encoding'),'ترميز الطلب غير مدعوم','bad_request',400)
        try: size=int(self.headers.get('Content-Length','0'))
        except ValueError: raise DomainError('حجم الطلب غير صالح')
        body_limit=MAX_ATTACHMENT_BODY if urlsplit(self.path).path=='/api/commands' else MAX_BODY
        require(0<size<=body_limit,'حجم الطلب يتجاوز المسموح أو فارغ','payload_too_large',413)
        raw=self.rfile.read(size)
        def finite_float(value):
            parsed=float(value)
            if not math.isfinite(parsed): raise ValueError('nonfinite')
            return parsed
        try: result=json.loads(raw,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite')),parse_float=finite_float)
        except (ValueError,UnicodeDecodeError): raise DomainError('صيغة JSON غير صالحة','invalid_json')
        require(isinstance(result,dict),'محتوى الطلب يجب أن يكون كائنًا')
        require(size<=MAX_BODY or result.get('type')=='attachment.create','حجم الطلب يتجاوز المسموح لهذا الإجراء','payload_too_large',413)
        return result

    def authenticated(self):
        actor=self.app.actor(self)
        require(actor is not None,'سجّل الدخول للمتابعة','unauthenticated',401)
        return actor

    def guarded(self,method):
        try:
            self.connection.settimeout(15)
            self.host_check()
            method()
        except DomainError as e:
            self.close_connection=True
            self.respond(e.status,{'error':e.message,'code':e.code})
        except (BrokenPipeError,ConnectionResetError,TimeoutError): self.close_connection=True
        except Exception as e:
            self.close_connection=True
            sys.stderr.write('request failed: '+type(e).__name__+'\n')
            self.respond(500,{'error':'تعذر إكمال الطلب؛ لم تُحفظ معاملة غير مكتملة','code':'internal_error'})

    def do_GET(self): self.guarded(self.get)
    def do_HEAD(self): self.guarded(self.get)
    def do_POST(self): self.guarded(self.post)

    def get(self):
        path=urlsplit(self.path).path
        if path in {'/api/session','/api/session/me'}:
            actor=self.app.actor(self)
            return self.respond(200,{'authenticated':bool(actor),'user':actor,'mode':self.app.mode,'data_mode':self.app.store.mode,'review':self.app.review,'roles':ROLE_LABELS})
        if path=='/api/health':
            return self.respond(200,{'ok':True,'service':'riyadh-book-fair','version':'2.0.0','mode':self.app.mode})
        if path=='/api/accounts':
            actor=self.authenticated()
            return self.respond(200,{'accounts':self.app.account_directory(actor)})
        if path=='/api/state':
            actor=self.authenticated()
            state=self.app.store.state(actor)
            state.update(data_mode=self.app.store.mode,mode=self.app.mode,
                         capabilities={'roles':ROLE_LABELS,'review':self.app.review,'backup':actor['role'] in {'admin','manager'} and 'project_ids' not in actor,
                          'live_sources':False,'shipping_integration':False,'payment_integration':False})
            return self.respond(200,state,{'ETag':'"'+str(state['revision'])+'"'})
        if path=='/api/backup/status':
            actor=self.authenticated()
            require(actor['role'] in {'admin','manager'} and 'project_ids' not in actor,
                    'صلاحية النسخ الاحتياطي مطلوبة','forbidden',403)
            return self.respond(200,self.app.backups.status() if self.app.backups else {'enabled':False})
        if path.startswith('/api/attachments/'):
            actor=self.authenticated()
            identifier=unquote(path[len('/api/attachments/'):])
            attachment=self.app.store.attachment_read(actor,identifier)
            metadata=attachment['metadata']
            safe_name=quote(metadata['filename'],safe='')
            headers={'Content-Disposition':f"attachment; filename=\"evidence-{metadata['id']}\"; filename*=UTF-8''{safe_name}",
                     'ETag':'"'+metadata['sha256']+'"','Cross-Origin-Resource-Policy':'same-origin'}
            return self.respond(200,attachment['content'],headers,content_type='application/octet-stream')
        if path in {'/api/backup','/api/export'}:
            actor=self.authenticated()
            return self.respond(200,self.app.store.export(actor),{'Content-Disposition':'attachment; filename="riyadh-book-fair-backup.json"'})
        if path.startswith('/api/'):
            raise DomainError('المسار غير موجود','not_found',404)
        clean=unquote(path).lstrip('/')
        file=(self.app.static_root/(clean or 'index.html')).resolve()
        require(file.is_relative_to(self.app.static_root) and file.is_file(),'الملف غير موجود','not_found',404)
        require(file.suffix.lower() in {'.html','.css','.js','.json','.svg','.png','.jpg','.jpeg','.webp','.ico','.woff','.woff2','.ttf','.glb','.gltf','.bin','.zip'},'نوع الملف غير مسموح','not_found',404)
        content_type=mimetypes.guess_type(str(file))[0] or 'application/octet-stream'
        if file.suffix=='.js': content_type='text/javascript'
        if content_type.startswith('text/'): content_type+='; charset=utf-8'
        return self.respond(200,file.read_bytes(),content_type=content_type)

    def post(self):
        self.csrf_check()
        data=self.body(); path=urlsplit(self.path).path
        if path in {'/api/session','/api/session/login','/api/session/logout'}:
            action=data.get('action') or ('logout' if path.endswith('/logout') else 'login')
            if action=='login':
                require(not self.app.review,'المراجعة المحلية تستخدم هوية مدير المراجعة','review_mode',409)
                token,user=self.app.login(data.get('username'),data.get('password'),self.client_address[0])
                return self.respond(200,{'ok':True,'authenticated':True,'user':user,'mode':self.app.mode},{'Set-Cookie':self.app.session_cookie(token)})
            if action=='logout':
                try:
                    cookie=SimpleCookie(); cookie.load(self.headers.get('Cookie',''))
                    token=cookie['rbf_session'].value if 'rbf_session' in cookie else ''
                    with self.app.store.connect() as c: c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
                except CookieError: pass
                return self.respond(200,{'ok':True},{'Set-Cookie':self.app.session_cookie('',True)})
            raise DomainError('إجراء الجلسة غير معروف')
        if path=='/api/commands':
            actor=self.authenticated()
            require('expected_revision' in data,'أرسل رقم النسخة الحالية لحماية التعديلات المتزامنة','revision_required',428)
            require(isinstance(data['expected_revision'],int) and not isinstance(data['expected_revision'],bool),'رقم النسخة يجب أن يكون عددًا صحيحًا','invalid_revision')
            command_type=data.get('type')
            if isinstance(command_type,str) and command_type in COMMAND_ROLES:
                require(actor['role'] in COMMAND_ROLES[command_type],
                        'لا تملك صلاحية هذا الإجراء','forbidden',403)
            self.app.validate_stakeholder_account(data,actor)
            self.app.validate_permit_accounts(data)
            result=self.app.store.command(data.get('type'),data.get('payload'),actor,data['expected_revision'])
            return self.respond(200,result)
        raise DomainError('المسار غير موجود','not_found',404)

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--host',default=os.environ.get('RBF_HOST','127.0.0.1'))
    parser.add_argument('--port',type=int,default=int(os.environ.get('PORT',os.environ.get('RBF_PORT','8765'))))
    parser.add_argument('--db',default=os.environ.get('RBF_DB'))
    parser.add_argument('--review',action='store_true',help='Explicit local-only review identity; never bind publicly')
    parser.add_argument('--demo',action='store_true',help='Seed isolated demonstration database')
    parser.add_argument('--accounts-file',default=os.environ.get('RBF_ACCOUNTS_FILE'))
    parser.add_argument('--origin',action='append',default=[x.strip() for x in os.environ.get('RBF_ALLOWED_ORIGINS','').split(',') if x.strip()])
    parser.add_argument('--hash-password',action='store_true')
    parser.add_argument('--create-account',metavar='USERNAME',help='Create one account interactively in --accounts-file, then exit')
    parser.add_argument('--role',choices=sorted(ROLES),default='viewer')
    parser.add_argument('--name',help='Display name for --create-account')
    parser.add_argument('--project-id',action='append',help='Optional project scope; repeat for multiple projects')
    args=parser.parse_args(argv)
    if not hasattr(hashlib,'scrypt'): parser.error('This Python build lacks hashlib.scrypt. Use Python 3.11+ with OpenSSL; no weaker password fallback is used.')
    if args.create_account:
        if not args.accounts_file: parser.error('--create-account requires --accounts-file')
        first=getpass.getpass('New password (12+ characters): ')
        if first!=getpass.getpass('Confirm password: '): parser.error('Passwords do not match')
        try:
            target=create_account_file(args.accounts_file,args.create_account,args.name,args.role,first,args.project_id)
        except (ValueError,OSError): parser.error('Account creation failed: invalid input, existing username, or unwritable configuration')
        print(f'Account created in {target}; role={args.role}; password and hash are not displayed')
        return
    if args.hash_password:
        first=getpass.getpass('Password (12+ characters): ')
        if first!=getpass.getpass('Confirm password: '): parser.error('Passwords do not match')
        print(hash_password(first)); return
    if not 1<=args.port<=65535: parser.error('Invalid port')
    if args.review and not loopback(args.host): parser.error('--review is only allowed on loopback')
    try: accounts=load_accounts(args.accounts_file,os.environ.get('RBF_ACCOUNTS_JSON'))
    except (ValueError,OSError,json.JSONDecodeError): parser.error('Invalid accounts configuration; use valid scrypt hashes; no account values were logged')
    if not args.review and not accounts: parser.error('Authentication required: configure RBF_ACCOUNTS_FILE or use explicit loopback --review')
    if not loopback(args.host):
        if not args.origin or any(urlsplit(x).scheme!='https' or not urlsplit(x).netloc or urlsplit(x).path not in {'','/'} or urlsplit(x).query or urlsplit(x).fragment or urlsplit(x).username for x in args.origin):
            parser.error('Public deployment requires explicit HTTPS --origin and a TLS reverse proxy')
    origins=[x.rstrip('/') for x in args.origin]
    db=args.db or str(ROOT/'data'/('demo.sqlite' if args.demo else 'operations.sqlite'))
    try:
        store=DomainStore(db,demo=args.demo)
        backups=None
        if not args.review and not args.demo and db!=':memory:':
            backup_dir=os.environ.get('RBF_BACKUP_DIR') or str(Path(db).resolve().parent/'backups')
            backups=BackupService(db,backup_dir)
        app=Application(store,accounts,args.review,args.host,args.port,origins,backups=backups)
        server=Server((args.host,args.port),Handler); server.app=app
    except (DomainError,OSError) as e:
        parser.error(str(e))
    print(f'Riyadh Book Fair | mode={app.mode} | http://{args.host}:{args.port} | persistence={Path(db).resolve()}',flush=True)
    if backups: backups.start()
    try: server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt: pass
    finally:
        server.server_close()
        if backups: backups.stop()

if __name__=='__main__': main()

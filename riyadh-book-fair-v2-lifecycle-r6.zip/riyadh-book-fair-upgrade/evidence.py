"""Private evidence attachments stored atomically as SQLite BLOBs, never paths.

DomainStore supplies common/get/new/put/all/connect and transaction boundaries.
Imports of domain validation helpers are local to avoid a mixin import cycle.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import re
import secrets
import struct
import unicodedata

MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024
MAX_BASE64_CHARS = ((MAX_ATTACHMENT_BYTES + 2) // 3) * 4
WRITE_ROLES = frozenset({'admin', 'manager', 'warehouse', 'field', 'security'})
ORDER_FILE_ROLES = frozenset({'admin', 'manager', 'warehouse'})
CONTENT_TYPES = {
    'image/png': frozenset({'.png'}),
    'image/jpeg': frozenset({'.jpg', '.jpeg'}),
    'image/webp': frozenset({'.webp'}),
    'application/pdf': frozenset({'.pdf'}),
}
RECORD_COLLECTIONS = frozenset({
    'projects', 'phases', 'zones', 'stakeholders', 'items', 'stock_moves',
    'stock_counts', 'orders', 'tasks', 'permits', 'access_logs', 'incidents',
    'decisions', 'procurements', 'spatial_jobs', 'observations', 'support_requests', 'daily_reports',
    'phase_handoffs', 'book_shipments',
})


def validate_file(filename, content_type, encoded):
    """Validate an allowed filename, bounded canonical base64 and file signature."""
    from domain import require, text
    filename = text(filename, 'اسم الملف', True, 160)
    require(not filename.startswith('.') and not any(ch in filename for ch in '/\\:')
            and not any(unicodedata.category(ch).startswith('C') for ch in filename),
            'اسم الملف غير صالح؛ استخدم اسمًا دون مسار أو محارف تحكم', 'invalid_filename')
    require(isinstance(content_type, str) and content_type in CONTENT_TYPES,
            'الأنواع المسموحة PNG وJPEG وWebP وPDF فقط', 'unsupported_attachment_type', 415)
    extension = '.' + filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    require(extension in CONTENT_TYPES[content_type], 'امتداد الملف لا يطابق نوعه', 'attachment_type_mismatch', 415)
    require(isinstance(encoded, str) and bool(encoded), 'محتوى الملف مطلوب', 'invalid_attachment_encoding')
    require(len(encoded) <= MAX_BASE64_CHARS, 'حجم المرفق يتجاوز 5 MB', 'attachment_too_large', 413)
    try:
        content = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError):
        require(False, 'ترميز الملف غير صالح', 'invalid_attachment_encoding')
    require(0 < len(content) <= MAX_ATTACHMENT_BYTES, 'حجم المرفق يجب أن يكون بين بايت واحد و5 MB', 'attachment_too_large', 413)
    require(base64.b64encode(content).decode('ascii') == encoded,
            'ترميز الملف غير صالح', 'invalid_attachment_encoding')
    valid = False
    if content_type == 'image/png':
        valid = (len(content) >= 45 and content.startswith(b'\x89PNG\r\n\x1a\n')
                 and content[8:16] == b'\x00\x00\x00\rIHDR'
                 and content.endswith(b'\x00\x00\x00\x00IEND\xaeB`\x82'))
        if valid:
            width, height = struct.unpack('>II', content[16:24])
            valid = 0 < width <= 20000 and 0 < height <= 20000 and width * height <= 64_000_000
    elif content_type == 'image/jpeg':
        valid = len(content) >= 12 and content.startswith(b'\xff\xd8\xff') and content.endswith(b'\xff\xd9')
    elif content_type == 'image/webp':
        valid = (len(content) >= 20 and content[:4] == b'RIFF' and content[8:12] == b'WEBP'
                 and content[12:16] in {b'VP8 ', b'VP8L', b'VP8X'}
                 and int.from_bytes(content[4:8], 'little') == len(content) - 8)
    elif content_type == 'application/pdf':
        valid = bool(re.match(rb'%PDF-(?:1\.[0-7]|2\.0)(?:\r|\n|\s)', content)) and content.rstrip().endswith(b'%%EOF')
    require(valid, 'توقيع الملف أو بنيته الأساسية لا يطابق النوع المحدد', 'attachment_magic_mismatch', 415)
    return filename, content_type, content


class EvidenceMixin:
    def attachment_create(self, c, p, actor):
        from domain import require, text
        require(actor.get('role') in WRITE_ROLES, 'لا تملك صلاحية رفع مرفق', 'forbidden', 403)
        fields = self.common(c, p)
        require(bool(fields['project_id']), 'حدد مشروع المرفق', 'attachment_project_required')
        self.get(c, 'projects', fields['project_id'])
        if 'project_ids' in actor:
            require(fields['project_id'] in actor['project_ids'], 'المشروع خارج نطاق الحساب', 'project_scope_required', 403)
        collection = text(p.get('record_collection'), 'نوع السجل المرتبط', limit=80)
        record_id = text(p.get('record_id'), 'معرف السجل المرتبط', limit=500)
        require(bool(collection) == bool(record_id), 'اختر نوع السجل ومعرفه معًا', 'attachment_reference_required')
        if collection:
            require(collection in RECORD_COLLECTIONS, 'نوع السجل غير متاح للمرفقات', 'attachment_record_type')
            record = self.get(c, collection, record_id)
            linked_project = record['id'] if collection == 'projects' else record.get('project_id')
            require(linked_project == fields['project_id'], 'السجل المرتبط يتبع مشروعًا آخر', 'project_mismatch')
            if collection == 'orders':
                require(actor.get('role') in ORDER_FILE_ROLES, 'مرفقات طلبات الزوار تتطلب مسؤول طلبات', 'attachment_order_restricted', 403)
        filename, content_type, content = validate_file(p.get('filename'), p.get('content_type'), p.get('data_base64'))
        label = text(p.get('label') or filename, 'عنوان الإثبات', True, 200)
        digest = hashlib.sha256(content).hexdigest()
        # A random identifier owns both rows. No uploaded filename is ever a path.
        identifier = 'ATT-' + secrets.token_hex(16).upper()
        while c.execute("SELECT 1 FROM records WHERE collection='attachments' AND id=?", (identifier,)).fetchone():
            identifier = 'ATT-' + secrets.token_hex(16).upper()
        fields.update(id=identifier, label=label, filename=filename, content_type=content_type,
                      size_bytes=len(content), sha256=digest, record_collection=collection, record_id=record_id)
        c.execute('CREATE TABLE IF NOT EXISTS attachment_blobs(id TEXT PRIMARY KEY,content BLOB NOT NULL)')
        metadata = self.new(c, 'attachments', fields, actor)
        c.execute('INSERT INTO attachment_blobs(id,content) VALUES(?,?)', (metadata['id'], content))
        return metadata

    def _attachment_content(self, c, metadata):
        from domain import require
        table = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attachment_blobs'").fetchone()
        require(table is not None, 'ملف الإثبات غير متاح؛ تحقق من النسخة الاحتياطية', 'attachment_content_missing', 500)
        row = c.execute('SELECT content FROM attachment_blobs WHERE id=?', (metadata['id'],)).fetchone()
        require(row is not None, 'ملف الإثبات غير متاح؛ تحقق من النسخة الاحتياطية', 'attachment_content_missing', 500)
        content = bytes(row['content'])
        require(len(content) == metadata['size_bytes'] and hashlib.sha256(content).hexdigest() == metadata['sha256'],
                'تعذر التحقق من سلامة ملف الإثبات', 'attachment_integrity_error', 500)
        return content

    def attachment_read(self, actor, attachment_id):
        from domain import require
        require(isinstance(actor, dict) and actor.get('role') in WRITE_ROLES,
                'دور الاطلاع يتيح بيانات المرفق فقط؛ تنزيل الملف يتطلب صلاحية تشغيل', 'forbidden', 403)
        with self.connect() as c:
            c.execute('BEGIN')
            metadata = self.get(c, 'attachments', attachment_id)
            if 'project_ids' in actor:
                require(metadata['project_id'] in actor['project_ids'], 'المشروع خارج نطاق الحساب', 'project_scope_required', 403)
            if metadata['record_collection'] == 'orders':
                require(actor.get('role') in ORDER_FILE_ROLES, 'مرفقات طلبات الزوار تتطلب مسؤول طلبات', 'attachment_order_restricted', 403)
            content = self._attachment_content(c, metadata)
            return {'metadata': metadata, 'content': content}

    def attachment_backup(self, c):
        """Called in the same snapshot transaction as metadata and audit export."""
        result = []
        for metadata in self.all(c, 'attachments'):
            content = self._attachment_content(c, metadata)
            result.append({'id': metadata['id'], 'sha256': metadata['sha256'], 'size_bytes': len(content),
                           'data_base64': base64.b64encode(content).decode('ascii')})
        return result

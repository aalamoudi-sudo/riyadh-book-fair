/* Local-only spatial authoring. Images never leave this browser. */
const EPS = 1e-8;
let session = null;
const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
const onSegment = (a, b, p) => Math.abs(cross(a, b, p)) < EPS && [0, 1].every(i => p[i] >= Math.min(a[i], b[i]) - EPS && p[i] <= Math.max(a[i], b[i]) + EPS);
const intersects = (a, b, c, d) => (cross(a, b, c) * cross(a, b, d) < -EPS && cross(c, d, a) * cross(c, d, b) < -EPS) || onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b);

export function calibrationScale(a, b, distanceM) {
  if (![...a, ...b, distanceM].every(Number.isFinite) || distanceM <= 0) throw new Error('أدخل مسافة مرجعية صحيحة أكبر من صفر.');
  const units = Math.hypot(b[0] - a[0], b[1] - a[1]);
  if (units < EPS) throw new Error('اختر نقطتين مختلفتين للمعايرة.');
  return distanceM / units;
}

export function validatePolygon(points) {
  if (!Array.isArray(points) || points.length < 3 || points.length > 500) throw new Error('الحدود تحتاج من 3 إلى 500 نقطة.');
  if (points.some(p => !Array.isArray(p) || p.length !== 2 || p.some(n => !Number.isFinite(n) || Math.abs(n) > 100000))) throw new Error('إحداثيات المضلع غير صالحة.');
  const n = points.length;
  let area = 0;
  for (let i = 0; i < n; i++) {
    const a = points[i], b = points[(i + 1) % n];
    if (Math.hypot(a[0] - b[0], a[1] - b[1]) < EPS) throw new Error('توجد نقطة مكررة أو ضلع صفري.');
    area += a[0] * b[1] - b[0] * a[1];
    for (let j = i + 1; j < n; j++) {
      if (j === i + 1 || (i === 0 && j === n - 1)) continue;
      if (intersects(a, b, points[j], points[(j + 1) % n])) throw new Error('حدود المضلع تتقاطع؛ تراجع عن النقطة وأعد الرسم.');
    }
  }
  if (Math.abs(area / 2) < EPS) throw new Error('مساحة المضلع صفر.');
  return Math.abs(area / 2);
}

export function validateSpatialPlan(plan, requireReview = false) {
  if (!plan || plan.schema_version !== 1 || plan.units !== 'm' || plan.coordinate_system !== 'right-handed-z-up') throw new Error('المطلوب مخطط إصدار 1، بوحدة المتر وإحداثيات right-handed-z-up.');
  if (!['manual', 'expected', 'demo'].includes(plan.provenance?.data_class) || typeof plan.provenance?.source_file !== 'string' || !plan.provenance.source_file.trim()) throw new Error('اسم المصدر وتصنيف البيانات مطلوبان.');
  const calibration = plan.calibration;
  if (!calibration || !Number.isFinite(calibration.meters_per_unit) || calibration.meters_per_unit <= 0 || !['known-distance', 'declared-unit-scale'].includes(calibration.method)) throw new Error('المعايرة غير صالحة.');
  if (calibration.method === 'known-distance') {
    if (!Array.isArray(calibration.points) || calibration.points.length !== 2 || calibration.points.some(p => !Array.isArray(p) || p.length !== 2)) throw new Error('نقطتا المعايرة مطلوبتان.');
    const expected = calibrationScale(...calibration.points, calibration.distance_m);
    if (Math.abs(expected - calibration.meters_per_unit) > expected * 1e-6) throw new Error('المقياس لا يطابق نقطتي المعايرة.');
  }
  if (!Array.isArray(plan.elements) || !plan.elements.length || plan.elements.length > 2000) throw new Error('المخطط يحتاج من 1 إلى 2000 عنصر.');
  const ids = new Set();
  plan.elements.forEach(e => {
    for (const key of ['id', 'name', 'zone_id']) {
      if (typeof e?.[key] !== 'string' || !e[key].trim() || e[key].length > 200) throw new Error('كل عنصر يحتاج معرفًا واسمًا ومنطقة صالحة.');
    }
    if (ids.has(e.id)) throw new Error('معرف عنصر مكرر.');
    ids.add(e.id);
    if (e.asset_id !== undefined && typeof e.asset_id !== 'string') throw new Error('معرف الأصل يجب أن يكون نصًا.');
    validatePolygon(e.polygon);
    if (!Number.isFinite(e.height_m) || e.height_m <= 0 || e.height_m > 200 || !Number.isFinite(e.base_m ?? 0) || Math.abs(e.base_m ?? 0) > 1000) throw new Error('ارتفاع العنصر أو مستوى القاعدة غير صالح.');
  });
  if (requireReview && (plan.review?.approved !== true || typeof plan.review.reviewer !== 'string' || !plan.review.reviewer.trim() || !Number.isFinite(Date.parse(plan.review.reviewed_at)))) throw new Error('أكمل المراجعة البشرية واكتب اسم المراجع.');
  return plan;
}

function emptyState() {
  return {image: null, source: null, plan: null, calibrationPoints: [], draft: [], mode: 'calibrate', dataClass: 'manual'};
}

function clone(value) { return JSON.parse(JSON.stringify(value)); }

/** context: zones[{id,name}], actor{name,id}, initialPlan?, onExport(plan)?, onPlanExport(plan)? */
export function renderSpatial(container, context = {}) {
  if (!session) session = emptyState();
  const state = session;
  if (context.initialPlan && !state.plan) {
    try { state.plan = clone(validateSpatialPlan(context.initialPlan)); state.dataClass = state.plan.provenance.data_class; } catch (_) { /* Invalid external plans are not used. */ }
  }
  let alive = true;
  let generation = 0;
  let view = {scale: 1, x: 0, y: 0};
  container.innerHTML = `
  <section class="spatial-tool" dir="rtl" aria-labelledby="sp-title">
    <style>
      .spatial-tool{--sp-accent:#137467;--sp-line:#d9e4df;color:inherit;max-width:1450px;margin:auto}.spatial-tool *{box-sizing:border-box}.spatial-tool h2{margin:0 0 8px}.spatial-tool h3{margin:0 0 12px;font-size:1.1rem}.spatial-tool p{line-height:1.8;margin:6px 0 15px}.spatial-tool small{line-height:1.7;display:block}.spatial-tool .sp-notice{padding:14px 18px;border:1px solid #d9bb7d;background:#fffbef;color:#5d4925;border-radius:12px;margin:14px 0}.spatial-tool .sp-layout{display:grid;grid-template-columns:minmax(230px,320px) minmax(0,1fr);gap:18px;align-items:start}.spatial-tool .sp-layout>div{min-width:0}.spatial-tool .sp-card{border:1px solid var(--sp-line);border-radius:14px;padding:18px;background:var(--surface,#fff);margin-bottom:16px;color:#163e39}.spatial-tool label{display:block;margin:10px 0 4px;font-size:.9rem}.spatial-tool input:not([type=checkbox]),.spatial-tool select{width:100%;padding:10px;border:1px solid #bbcfc5;border-radius:8px;background:#fff;color:#153c36;font:inherit;min-width:0}.spatial-tool input[type=file]{font-size:.83rem}.spatial-tool button{font:inherit;padding:9px 13px;border:1px solid #b9cec5;background:#f2f7f4;color:#16473c;border-radius:8px;cursor:pointer}.spatial-tool button.sp-primary{background:var(--sp-accent);color:#fff;border-color:var(--sp-accent)}.spatial-tool button:disabled{opacity:.45;cursor:not-allowed}.spatial-tool button:focus-visible,.spatial-tool input:focus-visible,.spatial-tool select:focus-visible{outline:3px solid #d3a44c;outline-offset:2px}.spatial-tool .sp-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.spatial-tool .sp-pair{display:grid;grid-template-columns:1fr 1fr;gap:10px}.spatial-tool .sp-canvas-wrap{border:1px solid var(--sp-line);background:repeating-linear-gradient(0deg,#fafcfb 0px,#fafcfb 19px,#eaf0eb 20px);border-radius:10px;overflow:hidden;min-height:280px}.spatial-tool canvas{display:block;width:100%;height:auto;touch-action:manipulation;cursor:crosshair;direction:ltr}.spatial-tool .sp-status{border-radius:8px;padding:10px 12px;background:#e8f5ef;color:#155845;min-height:40px;margin:10px 0;line-height:1.6}.spatial-tool .sp-status[data-error=true]{background:#fff0ed;color:#982f20}.spatial-tool .sp-tag{display:inline-block;padding:4px 10px;border-radius:30px;background:#e9f3ef;font-size:.8rem}.spatial-tool .sp-table-wrap{overflow:auto}.spatial-tool table{width:100%;border-collapse:collapse;font-size:.85rem}.spatial-tool th,.spatial-tool td{padding:10px 8px;border-bottom:1px solid var(--sp-line);text-align:right;white-space:nowrap}.spatial-tool .sp-check{display:flex;gap:10px;align-items:flex-start;line-height:1.8}.spatial-tool .sp-check input{margin-top:7px;flex:none}.spatial-tool .sp-review{border-right:4px solid #d3a44c}.spatial-tool .sp-muted{color:#547169}.spatial-tool .sp-empty{padding:24px;text-align:center;color:#62786f}.spatial-tool code{direction:ltr;display:inline-block;font-size:.85em;overflow-wrap:anywhere}.spatial-tool details{margin-top:12px;line-height:1.8}.spatial-tool summary{cursor:pointer}.spatial-tool .sp-info{white-space:pre-wrap;overflow-wrap:anywhere}@media(max-width:900px){.spatial-tool .sp-layout{grid-template-columns:1fr}.spatial-tool .sp-card{padding:14px}.spatial-tool .sp-pair{gap:8px}}
    </style>
    <h2 id="sp-title">المخطط المكاني · من 2D إلى Blender</h2>
    <p class="sp-muted">جهّز حدود منطقة واحدة، اربطها بالمنطقة والأصول، ثم راجع القياسات والارتفاعات قبل إنتاج المجسم.</p>
    <div class="sp-notice"><strong>مصدر محلي ومعايرة بشرية</strong> — الصور لا تتحول تلقائيًا إلى نموذج موثوق. هذه أداة إعداد ومراجعة، وليست بيانات حية أو اعتمادًا هندسيًا. ملفات الصور تُقرأ داخل متصفحك دون رفع خارجي.</div>
    <div class="sp-layout">
      <div>
        <section class="sp-card"><h3>1. المصدر</h3>
          <label for="sp-image">صورة مخطط PNG / JPEG / WebP</label><input id="sp-image" type="file" accept="image/png,image/jpeg,image/webp">
          <small class="sp-muted">حتى 20 MB. اختيار مصدر جديد يبدأ مسودة جديدة؛ صدّر عملك أولًا.</small>
          <label for="sp-json">أو مخطط JSON من مسار SVG / DXF</label><input id="sp-json" type="file" accept="application/json,.json">
          <label for="sp-class">نوع البيانات</label><select id="sp-class"><option value="manual">إدخال يدوي / مرجع يحتاج التحقق</option><option value="expected">مقترح تخطيطي / متوقع</option><option value="demo">تجريبي للتدريب فقط</option></select>
          <p id="sp-source" class="sp-info sp-muted"></p>
          <details><summary>استيراد SVG / DXF</summary><small>توجد أداة الاستيراد في حزمة المشروع: <code>scripts/spatial/import_plan.py</code>. تقبل SVG مبسطًا من rect / polygon / line، وDXF اختياريًا عبر ezdxf. يلزم تحديد المتر لكل وحدة والارتفاع ومعرّف المنطقة. بعدها افتح plan.json هنا للمراجعة. الملفات ذات الأقواس أو التحويلات غير المدعومة تُرفض برسالة واضحة.</small></details>
        </section>
        <section class="sp-card"><h3>2. المعايرة</h3><p class="sp-muted">اختر نقطتين على الصورة لمسافة معلومة. الاتجاه الأفقي إلى اليمين، والمحور Y إلى أعلى في النموذج.</p>
          <label for="sp-distance">المسافة الفعلية بين النقطتين (متر)</label><input id="sp-distance" type="number" min="0.001" step="any" placeholder="مثلًا: 10">
          <div class="sp-actions"><button type="button" id="sp-calibrate" class="sp-primary">اعتماد المقياس</button><button type="button" id="sp-recalibrate">إعادة المعايرة</button></div>
          <p id="sp-scale" class="sp-info"></p><small class="sp-muted">بعد إضافة عنصر، احذف العناصر قبل إعادة المعايرة حتى لا تتغير أبعاد نموذج قائم دون مراجعة.</small>
        </section>
        <section class="sp-card"><h3>3. تتبع الحدود</h3>
          <label for="sp-name">اسم العنصر</label><input id="sp-name" maxlength="200" placeholder="مثلًا: جناح الناشر أو مستودع الكتب">
          <label for="sp-zone">معرّف المنطقة</label><input id="sp-zone" list="sp-zones" maxlength="200" placeholder="مثلًا: Z-A"><datalist id="sp-zones"></datalist>
          <label for="sp-asset">معرّف الأصل (اختياري)</label><input id="sp-asset" maxlength="200" placeholder="يربط المجسم بسجل المعدات">
          <div class="sp-pair"><div><label for="sp-height">الارتفاع (متر)</label><input id="sp-height" type="number" min="0.001" max="200" step="any" placeholder="أدخل القياس"></div><div><label for="sp-base">مستوى القاعدة (متر)</label><input id="sp-base" type="number" min="-1000" max="1000" step="any" value="0"></div></div>
          <label for="sp-type">نوع العنصر</label><select id="sp-type"><option value="space">منطقة / جناح</option><option value="wall">جدار / حاجز</option><option value="asset">أصل / تجهيز</option></select>
          <div class="sp-actions"><button type="button" id="sp-add" class="sp-primary">إغلاق الحدود وإضافة العنصر</button><button type="button" id="sp-undo">تراجع عن نقطة</button></div>
          <small class="sp-muted">ابدأ بثلاث نقاط أو أكثر. لا تكرر النقطة الأولى، ولا ترسم مضلعًا يتقاطع مع نفسه.</small>
        </section>
      </div>
      <div>
        <section class="sp-card"><h3>لوحة المعاينة <span id="sp-count" class="sp-tag">لا عناصر</span></h3>
          <div id="sp-status" class="sp-status" role="status" aria-live="polite">افتح صورة محلية أو مخطط JSON للبدء.</div>
          <div class="sp-canvas-wrap"><canvas id="sp-canvas" width="1200" height="650" role="img" aria-label="معاينة المخطط وحدوده ونقطتي المعايرة"></canvas></div>
          <p id="sp-points" class="sp-muted"></p>
          <details><summary>إضافة نقطة بالإحداثيات بدل النقر</summary><small>إحداثيات الصورة الأصلية بالبكسل، تبدأ من أعلى اليسار.</small><div class="sp-pair"><div><label for="sp-x">X</label><input id="sp-x" type="number" min="0" step="any"></div><div><label for="sp-y">Y</label><input id="sp-y" type="number" min="0" step="any"></div></div><div class="sp-actions"><button type="button" id="sp-point">إضافة النقطة</button></div></details>
        </section>
        <section class="sp-card"><h3>العناصر المرتبطة</h3><div class="sp-table-wrap"><table><thead><tr><th>العنصر</th><th>المنطقة / الأصل</th><th>المساحة م²</th><th>الارتفاع م</th><th>إجراء</th></tr></thead><tbody id="sp-elements"></tbody></table></div></section>
        <section class="sp-card sp-review"><h3>4. مراجعة وتصدير</h3>
          <p>تحقق من مقياس المخطط، وحدود كل عنصر وارتفاعه، وربطه بالمنطقة الصحيحة. يمثل المجسم أحجامًا مبسطة، ولا يثبت السلامة أو قابلية البناء.</p>
          <label for="sp-reviewer">اسم المراجع</label><input id="sp-reviewer" maxlength="160" autocomplete="name" placeholder="اسم الشخص الذي راجع المخطط">
          <label class="sp-check"><input id="sp-review" type="checkbox"><span>راجعت المقياس والحدود والارتفاعات ومعرّفات المناطق والأصول، وأعتمد هذه النسخة للتحويل إلى مجسم.</span></label>
          <p id="sp-review-state" class="sp-muted"></p>
          <div class="sp-actions"><button type="button" id="sp-draft">تنزيل مسودة JSON</button><button type="button" id="sp-export" class="sp-primary">اعتماد وتنزيل المخطط</button></div>
          <small class="sp-muted">الملف يتضمن البيانات والمعايرة وسجل المراجعة فقط؛ لا يتضمن الصورة الأصلية. احتفظ بالصورة ومرجع القياس لديك. التعديلات تلغي الاعتماد السابق.</small>
          <details><summary>الخطوة التالية: Blender ثم GLB</summary><p>شغّل Blender محليًا باستخدام <code>scripts/spatial/blender_export.py</code> وفق دليل <code>docs/SPATIAL.md</code>. لا يُشغَّل Blender من هذه الصفحة. المصدر غير المعتمد يُرفض، وتنتقل معرّفات <code>zone_id</code> و<code>asset_id</code> إلى GLB لاستخدامها في العارض. يلزم Blender مثبتًا على جهاز التصدير.</p></details>
        </section>
      </div>
    </div>
  </section>`;
  const $ = id => container.querySelector(`#sp-${id}`);
  const canvas = $('canvas'), ctx = canvas.getContext('2d');
  for (const zone of context.zones || []) {
    const option = document.createElement('option'); option.value = String(zone.id); option.label = String(zone.name || zone.id); $('zones').append(option);
  }
  $('class').value = state.dataClass;
  $('reviewer').value = state.plan?.review?.reviewer || context.actor?.name || '';
  $('review').checked = false;
  if (state.plan?.calibration?.distance_m) $('distance').value = state.plan.calibration.distance_m;
  function status(message, error = false) { $('status').textContent = message; $('status').dataset.error = String(error); }
  function invalidate() {
    if (state.plan) state.plan.review = {approved: false, reviewer: '', reviewed_at: null};
    $('review').checked = false;
    $('review-state').textContent = 'المسودة تحتاج مراجعة قبل التصدير المعتمد.';
  }
  function sourcePoint(modelPoint) {
    const calibration = state.plan.calibration, origin = calibration.origin || calibration.points?.[0] || [0, 0];
    return [modelPoint[0] / calibration.meters_per_unit + origin[0], origin[1] - modelPoint[1] / calibration.meters_per_unit];
  }
  function project(point, model = false) {
    if (state.image) {
      const p = model ? sourcePoint(point) : point;
      return [p[0] * view.scale + view.x, p[1] * view.scale + view.y];
    }
    return [point[0] * view.scale + view.x, -point[1] * view.scale + view.y];
  }
  function path(points, color, fill = null, model = false, close = true) {
    if (!points.length) return;
    ctx.beginPath(); points.forEach((point, i) => {const p = project(point, model); i ? ctx.lineTo(...p) : ctx.moveTo(...p);});
    if (close && points.length > 2) ctx.closePath();
    if (fill) {ctx.fillStyle = fill; ctx.fill();}
    ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.stroke();
    points.forEach((point, i) => {const p = project(point, model); ctx.beginPath();ctx.arc(...p, 5, 0, Math.PI * 2);ctx.fillStyle = color;ctx.fill();ctx.fillStyle = '#173e35';ctx.font = '15px sans-serif';ctx.fillText(String(i + 1), p[0] + 9, p[1] - 7);});
  }
  function draw() {
    canvas.width = 1200;
    canvas.height = state.image ? Math.max(220, Math.min(1400, 1200 * state.image.height / state.image.width)) : 650;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (state.image) {
      view.scale = Math.min(canvas.width / state.image.width, canvas.height / state.image.height);
      view.x = (canvas.width - state.image.width * view.scale) / 2; view.y = (canvas.height - state.image.height * view.scale) / 2;
      ctx.drawImage(state.image, view.x, view.y, state.image.width * view.scale, state.image.height * view.scale);
    } else if (state.plan?.elements?.length) {
      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      for (const element of state.plan.elements) for (const [x,y] of element.polygon) {minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
      view.scale = Math.min((canvas.width - 90) / Math.max(maxX - minX, .01), (canvas.height - 90) / Math.max(maxY - minY, .01));
      view.x = (canvas.width - (maxX - minX) * view.scale) / 2 - minX * view.scale;
      view.y = (canvas.height - (maxY - minY) * view.scale) / 2 + maxY * view.scale;
    } else {ctx.fillStyle = '#688076';ctx.font = '24px sans-serif';ctx.textAlign = 'center';ctx.fillText('افتح مخططًا لعرضه هنا', 600, 300);ctx.textAlign = 'start';}
    for (const element of state.plan?.elements || []) {
      path(element.polygon, '#117765', '#2ba48735', true);
      const p = project(element.polygon[0], true);ctx.font = '17px sans-serif';ctx.fillStyle = '#075648';ctx.fillText(element.name, p[0] + 10, p[1] + 24);
    }
    if (state.image) {path(state.calibrationPoints, '#c4801d', null, false, false);path(state.draft, '#7c45c8', '#b288e52f', false, false);}
  }
  function refresh() {
    const elements = state.plan?.elements || [], cal = state.plan?.calibration;
    $('source').textContent = state.source ? `${state.source.name} · ${state.image?.width || ''} × ${state.image?.height || ''} بكسل` : state.plan ? `المصدر: ${state.plan.provenance.source_file} · ${state.plan.provenance.source_type || 'JSON'}` : 'لم يُحمّل مصدر بعد.';
    $('scale').textContent = cal ? `${cal.meters_per_unit.toPrecision(6)} متر لكل وحدة مصدر${cal.distance_m ? ` · المسافة المرجعية ${cal.distance_m} م` : ' · مقياس مدخل يدويًا'}` : `${state.calibrationPoints.length} / 2 نقطتي معايرة`;
    $('count').textContent = `${elements.length} عنصر`;
    $('points').textContent = state.image ? (state.mode === 'calibrate' ? `وضع المعايرة: ${state.calibrationPoints.length} / 2 نقطة.` : `وضع التتبع: ${state.draft.length} نقطة في الحدود الحالية.`) : 'تُعرض حدود مخطط JSON بالمتر. لتحرير الحدود استخدم نسخة المصدر وأعد الاستيراد.';
    $('calibrate').disabled = !state.image || state.calibrationPoints.length !== 2 || elements.length > 0;
    $('distance').disabled = !state.image || elements.length > 0;
    $('recalibrate').disabled = !state.image || elements.length > 0;
    $('add').disabled = !state.image || !cal || state.draft.length < 3;
    $('undo').disabled = !(state.mode === 'calibrate' ? state.calibrationPoints.length : state.draft.length);
    $('point').disabled = !state.image;
    $('draft').disabled = !elements.length; $('export').disabled = !elements.length;
    $('review-state').textContent = state.plan?.review?.approved ? `اعتماد مسجل: ${state.plan.review.reviewer} · ${state.plan.review.reviewed_at}` : 'المسودة تحتاج مراجعة قبل التصدير المعتمد.';
    $('elements').replaceChildren();
    if (!elements.length) {const row = document.createElement('tr'), cell = document.createElement('td');cell.colSpan = 5;cell.className = 'sp-empty';cell.textContent = 'لا توجد عناصر. أكمل المعايرة ثم تتبع حدود أول منطقة.';row.append(cell);$('elements').append(row);}
    for (const element of elements) {
      const row = document.createElement('tr');
      for (const text of [element.name, `${element.zone_id}${element.asset_id ? ` / ${element.asset_id}` : ''}`, validatePolygon(element.polygon).toFixed(2), element.height_m]) {const cell = document.createElement('td');cell.textContent = String(text);row.append(cell);}
      const cell = document.createElement('td'), button = document.createElement('button');button.type = 'button';button.textContent = 'حذف';button.setAttribute('aria-label', `حذف ${element.name}`);button.onclick = () => {state.plan.elements = state.plan.elements.filter(e => e.id !== element.id);invalidate();refresh();};cell.append(button);row.append(cell);$('elements').append(row);
    }
    draw();
  }
  function addPoint(point) {
    if (!state.image) throw new Error('افتح صورة أولًا.');
    if (point.some(n => !Number.isFinite(n)) || point[0] < 0 || point[1] < 0 || point[0] > state.image.width || point[1] > state.image.height) throw new Error('النقطة خارج حدود الصورة.');
    if (state.mode === 'calibrate') {
      if (state.calibrationPoints.length >= 2) throw new Error('اعتمد المقياس أو تراجع عن نقطة لتعديلها.');
      state.calibrationPoints.push(point);
    } else {
      if (state.draft.length >= 500) throw new Error('وصلت إلى حد 500 نقطة للعنصر.');
      state.draft.push(point);
    }
    invalidate();refresh();
  }
  function safely(fn) {return async event => {try {await fn(event);} catch(error) {status(error.message || 'تعذر تنفيذ العملية.', true);}};}
  canvas.onclick = safely(event => {const box = canvas.getBoundingClientRect();addPoint([((event.clientX - box.left) * canvas.width / box.width - view.x) / view.scale, ((event.clientY - box.top) * canvas.height / box.height - view.y) / view.scale]);});
  $('point').onclick = safely(() => {if (!$('x').value || !$('y').value) throw new Error('أدخل X وY.');addPoint([Number($('x').value), Number($('y').value)]);});
  $('undo').onclick = () => {(state.mode === 'calibrate' ? state.calibrationPoints : state.draft).pop();invalidate();refresh();};
  $('image').onchange = safely(async event => {
    const file = event.target.files?.[0];if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 20 * 1024 * 1024) throw new Error('اختر PNG أو JPEG أو WebP حتى 20 MB.');
    const current = ++generation, image = new Image(), url = URL.createObjectURL(file);
    try {image.src = url;await image.decode();} finally {URL.revokeObjectURL(url);}
    if (!alive || current !== generation) return;
    if (image.width > 16000 || image.height > 16000) throw new Error('أبعاد الصورة تتجاوز 16000 بكسل. اقتطع منطقة العمل أولًا.');
    let hash = '';
    if (globalThis.crypto?.subtle) {const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2,'0')).join('');}
    if (!alive || current !== generation) return;
    Object.assign(state, emptyState(), {image, source: {name:file.name, sha256:hash}, dataClass:$('class').value});
    $('json').value = '';$('distance').value = '';invalidate();refresh();status('اختر نقطتين لمسافة معلومة ثم أدخل المسافة بالمتر.');
  });
  $('json').onchange = safely(async event => {
    const file = event.target.files?.[0];if (!file) return;
    if (file.size > 20 * 1024 * 1024) throw new Error('ملف JSON أكبر من 20 MB.');
    const current = ++generation, plan = validateSpatialPlan(JSON.parse(await file.text()));
    if (!alive || current !== generation) return;
    Object.assign(state, emptyState(), {plan:clone(plan), dataClass:plan.provenance.data_class});
    $('image').value = '';$('distance').value = plan.calibration.distance_m || '';$('class').value = state.dataClass;invalidate();refresh();status('تم تحميل المخطط. راجع الحدود والمقياس والارتفاعات ثم سجل اعتمادك.');
  });
  $('class').onchange = () => {state.dataClass = $('class').value;if (state.plan) state.plan.provenance.data_class = state.dataClass;invalidate();refresh();};
  $('calibrate').onclick = safely(() => {
    if (state.plan?.elements?.length) throw new Error('احذف العناصر قبل إعادة المعايرة.');
    if (state.calibrationPoints.length !== 2) throw new Error('اختر نقطتين للمعايرة.');
    const distance = Number($('distance').value), scale = calibrationScale(...state.calibrationPoints, distance);
    state.plan = {schema_version:1, units:'m', coordinate_system:'right-handed-z-up', created_at:new Date().toISOString(), provenance:{data_class:state.dataClass, source_type:'image', source_file:state.source.name, source_sha256:state.source.sha256, method:'manual-tracing', notes:'تتبع يدوي ومعايرة لمسافة معروفة. الارتفاعات مدخلة يدويًا. الصورة الأصلية غير مضمنة.'}, calibration:{method:'known-distance', meters_per_unit:scale, points:clone(state.calibrationPoints), distance_m:distance, origin:clone(state.calibrationPoints[0]), source_y_down:true}, review:{approved:false, reviewer:'', reviewed_at:null}, elements:[]};
    state.mode = 'trace';state.draft = [];invalidate();refresh();status('تمت المعايرة. تتبع حدود العنصر ثم أدخل الاسم والمنطقة والارتفاع.');
  });
  $('recalibrate').onclick = () => {if (state.plan?.elements?.length) return;state.plan = null;state.calibrationPoints = [];state.draft = [];state.mode = 'calibrate';invalidate();refresh();status('اختر نقطتي معايرة جديدتين.');};
  $('add').onclick = safely(() => {
    if (!state.plan || !state.image) throw new Error('أكمل المعايرة أولًا.');
    const cal = state.plan.calibration, origin = cal.origin;
    const element = {id:globalThis.crypto?.randomUUID?.() || `element-${Date.now()}-${Math.random().toString(16).slice(2)}`, name:$('name').value.trim(), zone_id:$('zone').value.trim(), asset_id:$('asset').value.trim(), type:$('type').value, polygon:state.draft.map(p => [(p[0]-origin[0])*cal.meters_per_unit, (origin[1]-p[1])*cal.meters_per_unit]), height_m:Number($('height').value), base_m:Number($('base').value)};
    validateSpatialPlan({...state.plan,elements:[...state.plan.elements,element]});state.plan.elements.push(element);state.draft = [];invalidate();refresh();status(`أُضيف «${element.name}». يمكنك تتبع عنصر آخر أو مراجعة المخطط.`);
  });
  function download(plan, name) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(plan,null,2)],{type:'application/json'})), anchor = document.createElement('a');
    anchor.href = url;anchor.download = name;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  $('draft').onclick = safely(() => {const plan = clone(validateSpatialPlan(state.plan));plan.review = {approved:false,reviewer:'',reviewed_at:null};download(plan,'spatial-plan-draft.json');status('تم تنزيل المسودة. Blender يرفضها حتى تسجيل المراجعة.');});
  $('export').onclick = safely(async () => {
    if (!$('review').checked || !$('reviewer').value.trim()) throw new Error('اكتب اسم المراجع وحدد مربع الاعتماد الصريح.');
    if (state.draft.length) throw new Error('توجد حدود غير محفوظة. أضف العنصر أو تراجع عن نقاطه قبل الاعتماد.');
    const plan = clone(state.plan);plan.review = {approved:true, reviewer:$('reviewer').value.trim(), reviewed_at:new Date().toISOString()};validateSpatialPlan(plan,true);
    download(plan,'spatial-plan-reviewed.json');state.plan = plan;refresh();
    status('تم تنزيل المخطط المعتمد. يمكنك تحويله محليًا إلى GLB باستخدام Blender.');
    const callback = context.onExport || context.onPlanExport;
    if (callback) {try {await callback(clone(plan));} catch (_) {status('تم تنزيل المخطط محليًا، لكن تعذر تسجيله في التطبيق. احتفظ بملف JSON.',true);}}
  });
  refresh();
  return () => {alive = false;generation++;};
}

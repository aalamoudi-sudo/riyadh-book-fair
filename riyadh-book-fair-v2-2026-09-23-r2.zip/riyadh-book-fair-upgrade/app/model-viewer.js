import * as THREE from './vendor/three-0.186.0/build/three.module.js';
import {GLTFLoader} from './vendor/three-0.186.0/examples/jsm/loaders/GLTFLoader.js';
import {OrbitControls} from './vendor/three-0.186.0/examples/jsm/controls/OrbitControls.js';
import {esc, n, icon} from './ui.js';

const LIMIT=50*1024*1024;
const classes={demo:'مجسم تجريبي فقط',manual:'مرجع أُدخل يدويًا',expected:'مقترح تخطيطي'};
const text=value=>typeof value==='string'?value.slice(0,500):typeof value==='number'?String(value):'';

/** Inspect binary GLB before any loader can request resources. No external URI is accepted. */
export function inspectGLB(buffer) {
  if(!(buffer instanceof ArrayBuffer)||buffer.byteLength<20||buffer.byteLength>LIMIT)throw new Error('يلزم ملف GLB صالح حتى 50 MB.');
  const view=new DataView(buffer);
  if(view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==buffer.byteLength)throw new Error('صيغة الملف ليست GLB 2.0 أو أن حجمه لا يطابق الرأس.');
  const size=view.getUint32(12,true),kind=view.getUint32(16,true);
  if(kind!==0x4e4f534a||size>8*1024*1024||size%4!==0||size+20>buffer.byteLength)throw new Error('بيانات GLB الوصفية غير صالحة.');
  let json;try{json=JSON.parse(new TextDecoder().decode(new Uint8Array(buffer,20,size)).trim());}catch{throw new Error('تعذر قراءة بيانات GLB الوصفية.');}
  if(json?.asset?.version!=='2.0')throw new Error('يدعم العارض glTF 2.0 فقط.');
  function scan(value,depth=0){if(depth>100)throw new Error('بنية النموذج متداخلة أكثر من الحد المسموح.');if(value&&typeof value==='object')for(const [key,item]of Object.entries(value)){if(key==='uri'&&item)throw new Error('هذا GLB يطلب موردًا منفصلًا. صدّره بموارد مضمنة؛ لا تُحمّل روابط خارجية هنا.');scan(item,depth+1);}}
  scan(json);
  const unsupported=['KHR_draco_mesh_compression','EXT_meshopt_compression','KHR_texture_basisu'];
  if((json.extensionsUsed||[]).some(e=>unsupported.includes(e)))throw new Error('النموذج مضغوط بترميز غير مضمّن في هذا العارض. أعد تصديره دون Draco أو Meshopt أو KTX2.');
  if(!Array.isArray(json.nodes)||json.nodes.length>10000||(json.accessors||[]).some(a=>!Number.isSafeInteger(a.count)||a.count<0||a.count>3000000))throw new Error('حجم هندسة النموذج يتجاوز حدود العارض.');
  const visiting=new Set(),done=new Set();
  function visit(index,depth=0){if(!Number.isInteger(index)||index<0||index>=json.nodes.length||depth>100||visiting.has(index))throw new Error('شجرة عناصر GLB غير صالحة.');if(done.has(index))return;visiting.add(index);for(const child of json.nodes[index].children||[])visit(child,depth+1);visiting.delete(index);done.add(index);}
  json.nodes.forEach((_,i)=>visit(i));
  return json;
}

/** Local GLB viewer. Returns dispose(); optional onSelect({id,name,zone_id,asset_id,data_class}). */
export function renderModelViewer(container, context={}) {
  let alive=true,generation=0,frame=0,model=null,grid=null,selectionBox=null,selected=null,modelMetadata={},fileName='';
  const selectable=[],meshes=[];
  container.innerHTML=`<section class="panel model-viewer" dir="rtl"><div class="panel-head"><div><h2>معاينة المجسم وربطه بالمناطق</h2><p>عرض GLB محلي بعد التصدير من Blender؛ الملف يبقى في جهازك.</p></div><span class="badge reference" data-mv="source">لم يُحمّل نموذج</span></div><div class="panel-body"><div class="form-grid"><label class="field"><span>ملف GLB محلي · حتى 50 MB</span><input data-mv="file" type="file" accept=".glb,model/gltf-binary"></label><label class="field"><span>اختيار عنصر أو منطقة</span><select data-mv="select" disabled><option value="">حمّل نموذجًا أولًا</option></select></label></div><div class="actions mt"><button type="button" class="btn secondary" data-mv="demo">${icon('spatial')}فتح مثال تجريبي</button><button type="button" class="btn secondary" data-mv="fit" disabled>${icon('refresh')}إظهار النموذج كاملًا</button><button type="button" class="btn secondary" data-mv="top" disabled>مسقط علوي</button><button type="button" class="btn secondary" data-mv="clear" disabled>إغلاق النموذج</button></div><p class="field-help" data-mv="status" role="status" aria-live="polite">اسحب للتدوير، واستخدم عجلة الفأرة للتقريب. اختر عنصرًا بالنقر أو من القائمة.</p><div data-mv="viewport" class="mt" style="width:100%;height:440px;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#edf1f7;position:relative"></div><div data-mv="dimensions" class="field-help"></div><div data-mv="metadata" class="details-grid mt"><div class="detail-item"><span>لا توجد بيانات محددة</span><strong>حمّل ملف GLB واختر عنصرًا.</strong></div></div><p class="field-help">القياسات من إحداثيات الملف بالمتر وفق glTF، ومحور الارتفاع Y. وجود بيانات مراجعة داخل الملف لا يثبت هوية المراجع أو اعتماد المشروع. الملفات التي تشير إلى صور أو موارد خارجية تُرفض، ولا تُرفع الملفات إلى أي خدمة.</p></div></section>`;
  const $=name=>container.querySelector(`[data-mv="${name}"]`);
  const status=(message,error=false)=>{if(!alive)return;$('status').textContent=message;$('status').style.color=error?'var(--red)':'var(--muted)';};
  let renderer;
  try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});}catch{status('تعذر بدء WebGL في هذا المتصفح. جرّب متصفحًا يدعم العرض ثلاثي الأبعاد.',true);$('file').disabled=true;$('demo').disabled=true;return()=>{alive=false;};}
  renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor(0xedf1f7);renderer.domElement.setAttribute('aria-label','نموذج ثلاثي الأبعاد؛ استخدم قائمة العناصر لاختيار المنطقة');renderer.domElement.style.display='block';renderer.domElement.style.width='100%';renderer.domElement.style.height='100%';$('viewport').append(renderer.domElement);
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(45,1,.01,100000),controls=new OrbitControls(camera,renderer.domElement);
  controls.enableDamping=true;controls.dampingFactor=.09;controls.screenSpacePanning=true;camera.position.set(10,12,14);
  scene.add(new THREE.HemisphereLight(0xffffff,0x8b94a8,2.2));const light=new THREE.DirectionalLight(0xffffff,3);light.position.set(10,20,10);scene.add(light);
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  function invalidate(){if(alive&&!frame)frame=requestAnimationFrame(()=>{frame=0;if(!alive)return;controls.update();renderer.render(scene,camera);});}
  controls.addEventListener('change',invalidate);
  const observer=new ResizeObserver(()=>{if(!alive)return;const width=$('viewport').clientWidth,height=$('viewport').clientHeight;if(width&&height){renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();invalidate();}});observer.observe($('viewport'));
  const cleanupObject=object=>{const geometries=new Set(),materials=new Set(),textures=new Set();object?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const m of(Array.isArray(o.material)?o.material:o.material?[o.material]:[])){materials.add(m);for(const value of Object.values(m))if(value?.isTexture)textures.add(value);}});for(const t of textures){t.dispose();t.source?.data?.close?.();}for(const m of materials)m.dispose();for(const g of geometries)g.dispose();};
  function clear(){
    if(selectionBox){scene.remove(selectionBox);cleanupObject(selectionBox);selectionBox=null;}
    if(model){scene.remove(model);cleanupObject(model);model=null;}
    if(grid){scene.remove(grid);cleanupObject(grid);grid=null;}
    selected=null;modelMetadata={};selectable.length=0;meshes.length=0;$('select').innerHTML='<option value="">حمّل نموذجًا أولًا</option>';$('select').disabled=true;$('source').textContent='لم يُحمّل نموذج';$('source').className='badge reference';$('dimensions').textContent='';$('metadata').innerHTML='<div class="detail-item"><span>لا توجد بيانات محددة</span><strong>حمّل ملف GLB واختر عنصرًا.</strong></div>';for(const name of['fit','top','clear'])$(name).disabled=true;invalidate();
  }
  function fit(top=false){if(!model)return;const box=new THREE.Box3().setFromObject(model),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());const radius=Math.max(size.length()/2,.1);const distance=radius/Math.sin(THREE.MathUtils.degToRad(camera.fov)/2)*1.2;camera.near=Math.max(distance/10000,.001);camera.far=Math.max(distance*100,100);controls.minDistance=radius*.02;controls.maxDistance=distance*20;controls.target.copy(center);camera.position.copy(center).add(top?new THREE.Vector3(0,distance,.0001):new THREE.Vector3(distance*.65,distance*.65,distance*.8));camera.updateProjectionMatrix();controls.update();invalidate();}
  async function choose(object){
    if(!object)return;selected=object;$('select').value=object.uuid;
    if(selectionBox){scene.remove(selectionBox);cleanupObject(selectionBox);}
    selectionBox=new THREE.BoxHelper(object,0xd28b24);scene.add(selectionBox);
    const meta=object.userData||{},dataClass=text(meta.data_class||modelMetadata.data_class),data={id:text(meta.id),name:text(meta.source_name||object.name),zone_id:text(meta.zone_id),asset_id:text(meta.asset_id),data_class:dataClass,source_file:text(modelMetadata.source_file)||fileName};
    const pairs=[['العنصر',data.name||data.id||'عنصر غير مسمى'],['المنطقة',data.zone_id||'لا يوجد zone_id'],['الأصل',data.asset_id||'لا يوجد asset_id'],['نوع المصدر',classes[data.data_class]||'المصدر غير موثق'],['ارتفاع مسجل في المصدر',meta.height_m!==undefined?`${text(meta.height_m)} م`:'غير مسجل'],['مراجع الملف',text(modelMetadata.reviewer)||'لا توجد بيانات مراجعة']];
    $('metadata').innerHTML=pairs.map(([name,value])=>`<div class="detail-item"><span>${esc(name)}</span><strong>${esc(value)}</strong></div>`).join('');invalidate();
    if(context.onSelect){try{await context.onSelect(data);}catch{status('عُرض العنصر، لكن تعذر ربطه بسجل المنطقة في التطبيق.',true);}}
  }
  async function load(buffer,name,own=++generation){
    status('جارٍ التحقق من ملف GLB…');const json=inspectGLB(buffer);
    const manager=new THREE.LoadingManager();manager.setURLModifier(url=>{if(!url.startsWith('blob:'))throw new Error('رُفض مورد خارج ملف GLB.');return url;});
    const loader=new GLTFLoader(manager);let loaded;
    try{loaded=await loader.parseAsync(buffer,'');}catch(error){throw new Error(`تعذر تحميل المجسم: ${error.message||'صيغة غير مدعومة'}`);}
    if(!alive||own!==generation){cleanupObject(loaded.scene);return;}
    const box=new THREE.Box3().setFromObject(loaded.scene),size=box.getSize(new THREE.Vector3());
    if(box.isEmpty()||![...box.min.toArray(),...box.max.toArray()].every(Number.isFinite)||Math.max(...size.toArray())>100000){cleanupObject(loaded.scene);throw new Error('حدود المجسم فارغة أو غير صالحة أو خارج نطاق المشروع المحلي.');}
    clear();model=loaded.scene;fileName=name;modelMetadata={...(json.scenes?.[json.scene||0]?.extras||{}),...(model.userData||{})};scene.add(model);
    const sourceNames=new Map(json.nodes.filter(node=>node.extras?.id).map(node=>[node.extras.id,node.name]));
    model.traverse(object=>{if(sourceNames.has(object.userData?.id))object.userData.source_name=sourceNames.get(object.userData.id);if(object.isMesh)meshes.push(object);if(object.userData?.zone_id||object.userData?.asset_id||object.userData?.id)selectable.push(object);});
    if(!selectable.length)selectable.push(...meshes);
    const gridSize=Math.max(Math.ceil(Math.max(size.x,size.z)*1.3),2),center=box.getCenter(new THREE.Vector3());grid=new THREE.GridHelper(gridSize,20,0xa5b0c2,0xd2d9e5);grid.position.set(center.x,box.min.y-.02,center.z);scene.add(grid);
    $('select').replaceChildren();const blank=document.createElement('option');blank.value='';blank.textContent='اختر عنصرًا لعرض المنطقة والأصل';$('select').append(blank);
    for(const object of selectable){const option=document.createElement('option');option.value=object.uuid;option.textContent=`${text(object.userData?.source_name||object.name)||'عنصر'}${object.userData?.zone_id?' · '+text(object.userData.zone_id):''}`;$('select').append(option);}
    $('select').disabled=!selectable.length;for(const name of['fit','top','clear'])$(name).disabled=false;
    const dataClass=text(modelMetadata.data_class);$('source').textContent=classes[dataClass]||'مصدر غير موثق';$('source').className=`badge ${dataClass==='demo'?'demo':dataClass==='expected'?'forecast':'reference'}`;
    $('dimensions').textContent=`${name} · ${n(meshes.length)} مجسم · X ${size.x.toFixed(2)} م × ارتفاع Y ${size.y.toFixed(2)} م × Z ${size.z.toFixed(2)} م. ${dataClass==='demo'?'المثال للتدريب، ولا يمثل موقع معرض الرياض.':''}`;
    status(`تم تحميل ${n(selectable.length)} عنصر. اختر عنصرًا من النموذج أو القائمة.`);fit();
    if(context.onLoad)await context.onLoad({file_name:name,meshes:meshes.length,elements:selectable.length,dimensions_m:{x:size.x,y:size.y,z:size.z},metadata:{...modelMetadata}});
  }
  async function loadFile(file){if(!file)return;if(!/\.glb$/i.test(file.name)||file.size>LIMIT)throw new Error('اختر ملفًا بامتداد GLB وحجم حتى 50 MB.');const own=++generation,buffer=await file.arrayBuffer();if(!alive||own!==generation)return;return load(buffer,file.name,own);}
  $('file').onchange=async event=>{try{await loadFile(event.target.files?.[0]);}catch(error){status(error.message,true);}};
  $('demo').onclick=async()=>{try{const own=++generation,url=new URL(context.demoUrl||'./assets/spatial-demo.glb',import.meta.url);if(url.origin!==location.origin)throw new Error('المثال يجب أن يكون من نفس خادم التطبيق.');status('جارٍ فتح المثال التجريبي المحلي…');const response=await fetch(url,{credentials:'same-origin'});if(!response.ok)throw new Error('المثال التجريبي غير متوفر على هذا الخادم.');const buffer=await response.arrayBuffer();if(!alive||own!==generation)return;await load(buffer,'spatial-demo.glb',own);}catch(error){status(error.message,true);}};
  $('select').onchange=()=>choose(selectable.find(o=>o.uuid===$('select').value));$('fit').onclick=()=>fit();$('top').onclick=()=>fit(true);$('clear').onclick=()=>{generation++;clear();$('file').value='';status('أُغلق النموذج. يمكنك فتح ملف آخر.');};
  let down=null;renderer.domElement.addEventListener('pointerdown',event=>{down=[event.clientX,event.clientY];});renderer.domElement.addEventListener('pointerup',event=>{if(!down||Math.hypot(event.clientX-down[0],event.clientY-down[1])>5)return;down=null;const box=renderer.domElement.getBoundingClientRect();pointer.set((event.clientX-box.left)/box.width*2-1,-(event.clientY-box.top)/box.height*2+1);raycaster.setFromCamera(pointer,camera);let object=raycaster.intersectObjects(meshes,false)[0]?.object;while(object&&!selectable.includes(object))object=object.parent;if(object)choose(object);});
  renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();status('فقد المتصفح سياق العرض. أغلق هذه الصفحة وأعد فتح العارض.',true);});
  invalidate();
  const dispose=()=>{if(!alive)return;generation++;clear();alive=false;cancelAnimationFrame(frame);observer.disconnect();controls.dispose();renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
  dispose.loadFile=loadFile;
  return dispose;
}

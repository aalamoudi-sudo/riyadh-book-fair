"""Transactional project operations. Python stdlib only; all quantities are whole units.

Every command is one SQLite transaction, including inventory and append-only audit.
The JSON record store keeps the public API simple while invariants live here, never
in the browser. Demo provenance is immutable and isolated from operational data.
"""
from __future__ import annotations
import datetime as dt
from contextlib import contextmanager
import json
import os
import secrets
import sqlite3
from pathlib import Path
from coordination import CoordinationMixin
from evidence import EvidenceMixin
from operations import OperationsMixin

COLLECTIONS = ('projects','phases','zones','stakeholders','items','stock','stock_moves',
               'reservations','custody','orders','tasks','permits','access_logs',
               'incidents','decisions','procurements','spatial_jobs','observations','stock_counts','support_requests','attachments','daily_reports')
ROLES = {'admin','manager','warehouse','security','field','viewer'}
COMMAND_ROLES = {
    'daily.open': {'admin','manager','warehouse','field','security'},
    'daily.close': {'admin','manager'},
    'attachment.create': {'admin','manager','warehouse','field','security'},
    'project.close': {'admin','manager'}, 'project.reopen': {'admin','manager'},
    'support.create': {'admin','manager','field','warehouse','security'},
    'support.transition': {'admin','manager','warehouse','field','security'},
    'incident.escalate': {'admin','manager','security','field'},
    'stock.settle': {'admin','manager'},
    'stock.count': {'admin','manager','warehouse'}, 'stock.count.review': {'admin','manager'},
    'shared.create': {'admin','manager'}, 'item.create': {'admin','manager','warehouse'},
    'stock.move': {'admin','manager','warehouse'}, 'order.create': {'admin','manager','warehouse'},
    'order.transition': {'admin','manager','warehouse'}, 'task.create': {'admin','manager'},
    'task.inspect': {'admin','manager'},
    'task.transition': {'admin','manager','field'}, 'permit.create': {'admin','manager','security','field'},
    'permit.transition': {'admin','manager','security'}, 'permit.access': {'admin','security'},
    'incident.create': {'admin','manager','security','field'},
    'incident.transition': {'admin','manager','security','field'},
    'incident.decision': {'admin','manager','security'},
    'procurement.create': {'admin','manager','warehouse'},
    'procurement.transition': {'admin','manager','warehouse'},
    'observation.create': {'admin','manager','security','field'},
    'spatial.create': {'admin','manager','field'}, 'spatial.transition': {'admin','manager'},
}
PREFIXES = {'projects':'PRJ','phases':'PHS','zones':'ZON','stakeholders':'STK','items':'ITM',
            'stock_moves':'MOV','orders':'ORD','tasks':'TSK','permits':'PER','access_logs':'ACC',
            'incidents':'INC','decisions':'DEC','procurements':'PUR','spatial_jobs':'SPT','observations':'OBS','stock_counts':'CNT','support_requests':'SUP','attachments':'ATT','daily_reports':'DAY'}

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')

class DomainError(Exception):
    def __init__(self, message, code='validation', status=400):
        super().__init__(message)
        self.message, self.code, self.status = message, code, status

def require(condition, message, code='validation', status=400):
    if not condition: raise DomainError(message, code, status)

def text(value, name, required=False, limit=2000):
    require(isinstance(value if value is not None else '', str), f'{name}: يجب إدخال نص')
    value = (value or '').strip()
    require(not required or bool(value), f'الحقل مطلوب: {name}')
    require(len(value) <= limit, f'الحقل طويل جدًا: {name}')
    return value

def quantity(value):
    require(isinstance(value, int) and not isinstance(value, bool) and 0 < value <= 1000000,
            'الكمية يجب أن تكون عددًا صحيحًا موجبًا لا يزيد على مليون', 'invalid_quantity')
    return value

def timestamp(value, label):
    value = text(value, label, True, 80)
    try:
        parsed = dt.datetime.fromisoformat(value.replace('Z','+00:00'))
        require(parsed.tzinfo is not None, f'{label}: أضف المنطقة الزمنية')
        return parsed.astimezone(dt.timezone.utc)
    except ValueError: raise DomainError(f'{label}: تاريخ غير صالح')

class DomainStore(CoordinationMixin, EvidenceMixin, OperationsMixin):
    def __init__(self, path, demo=False):
        self.path = str(path)
        if self.path != ':memory:':
            Path(self.path).parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            try:
                descriptor=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                os.close(descriptor)
            except FileExistsError: pass
        with self.connect() as c:
            c.executescript('''
              PRAGMA journal_mode=WAL;
              CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS records(collection TEXT NOT NULL,id TEXT NOT NULL,data TEXT NOT NULL,
                PRIMARY KEY(collection,id));
              CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT,
                at TEXT NOT NULL,actor_id TEXT NOT NULL,actor_role TEXT NOT NULL,command TEXT NOT NULL,
                record_id TEXT NOT NULL,payload TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS attachment_blobs(id TEXT PRIMARY KEY,content BLOB NOT NULL);
              CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,
                expires_at INTEGER NOT NULL);
              CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit
                BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
              CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit
                BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
            ''')
            c.execute("INSERT OR IGNORE INTO metadata VALUES('revision','0')")
            c.execute("INSERT OR IGNORE INTO metadata VALUES('mode',?)", ('demo' if demo else 'manual',))
            mode = c.execute("SELECT value FROM metadata WHERE key='mode'").fetchone()[0]
            require(mode == ('demo' if demo else 'manual'),
                    'قاعدة البيانات التجريبية منفصلة: اختر ملف قاعدة مناسبًا للوضع المطلوب', 'mode_mismatch')
        self.mode = mode
        if demo: self.seed_demo()

    @contextmanager
    def connect(self):
        c = sqlite3.connect(self.path, timeout=15)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON')
        c.execute('PRAGMA busy_timeout=15000')
        try:
            with c: yield c
        finally: c.close()

    def get(self, c, collection, record_id, required=True):
        require(isinstance(record_id,str) and 0<len(record_id)<=500,'معرف السجل غير صالح')
        row = c.execute('SELECT data FROM records WHERE collection=? AND id=?', (collection,record_id)).fetchone()
        require(row is not None or not required, 'السجل غير موجود', 'not_found', 404)
        return json.loads(row[0]) if row else None

    def all(self, c, collection):
        return [json.loads(r[0]) for r in c.execute('SELECT data FROM records WHERE collection=? ORDER BY rowid', (collection,))]

    def put(self, c, collection, record):
        c.execute('INSERT INTO records(collection,id,data) VALUES(?,?,?) ON CONFLICT(collection,id) DO UPDATE SET data=excluded.data',
                  (collection, record['id'], json.dumps(record,ensure_ascii=False,separators=(',',':'))))
        return record

    def new(self, c, collection, fields, actor):
        # Creation must never call the upsert used by state transitions: an ID
        # collision must retry, not silently replace an existing operational row.
        explicit_id=fields.get('id')
        for attempt in range(8):
            identifier=explicit_id or PREFIXES.get(collection,'REC')+'-'+secrets.token_hex(4).upper()
            record={**fields,'id':identifier,'provenance':self.mode,'created_at':now(),'created_by':actor['id']}
            try:
                c.execute('INSERT INTO records(collection,id,data) VALUES(?,?,?)',
                          (collection,identifier,json.dumps(record,ensure_ascii=False,separators=(',',':'))))
                return record
            except sqlite3.IntegrityError:
                if explicit_id: raise DomainError('معرف السجل موجود مسبقًا؛ لم يُستبدل السجل','duplicate_id',409)
        raise DomainError('تعذر توليد معرف فريد؛ أعد المحاولة','identifier_collision',409)

    def common(self, c, p):
        fields = {}
        project_ids=set()
        for key,col in (('project_id','projects'),('phase_id','phases'),('zone_id','zones'),('responsible_id','stakeholders')):
            value = text(p.get(key),key,limit=100)
            if value:
                ref = self.get(c,col,value)
                project_id=value if key=='project_id' else ref.get('project_id')
                if project_id: project_ids.add(project_id)
            fields[key] = value
        require(len(project_ids)<=1,'السجلات المرتبطة تتبع مشاريع مختلفة','project_mismatch')
        if project_ids: fields['project_id']=next(iter(project_ids))
        fields['evidence'] = text(p.get('evidence'),'الإثبات',limit=4000)
        fields['notes'] = text(p.get('notes'),'ملاحظات',limit=4000)
        return fields

    def revision(self,c): return int(c.execute("SELECT value FROM metadata WHERE key='revision'").fetchone()[0])

    def state(self, actor=None):
        with self.connect() as c:
            c.execute('BEGIN')
            result = {'revision':self.revision(c), 'mode':self.mode,
                      'provenance_notice': 'بيانات تجريبية معزولة' if self.mode=='demo' else 'إدخال يدوي؛ لا توجد مصادر حية متصلة',
                      'integrations': {'shipping':'not_connected','payment':'not_connected','crowds':'not_connected','notifications':'in_app_only'}}
            for col in COLLECTIONS: result[col] = self.all(c,col)
            result['audit'] = [dict(r) for r in c.execute('SELECT seq,at,actor_id,actor_role,command,record_id FROM audit ORDER BY seq DESC LIMIT 200')]
            if actor and 'project_ids' in actor:
                allowed=set(actor['project_ids'])
                allowed_zones={x['id'] for x in result['zones'] if x.get('project_id') in allowed}
                allowed_items={x['id'] for x in result['items'] if x.get('project_id') in allowed}
                for col in COLLECTIONS:
                    result[col]=[r for r in result[col] if (r['id'] in allowed if col=='projects' else r.get('project_id') in allowed or (col in {'stock','reservations','custody'} and (r.get('zone_id') in allowed_zones or r.get('item_id') in allowed_items)))]
                allowed_records={r['id'] for col in COLLECTIONS for r in result[col]}
                result['audit']=[r for r in result['audit'] if r['record_id'] in allowed_records]
            if actor and actor.get('role') not in {'admin','manager','warehouse'}:
                for order in result['orders']:
                    order['customer_name']='زائر — بيانات محجوبة'
                    order.pop('customer_phone',None)
                    order.pop('address',None)
                    order['personal_data_redacted']=True
                for attachment in result['attachments']:
                    if attachment.get('record_collection')=='orders':
                        attachment['label']='إثبات طلب زائر — بيانات محجوبة'
                        attachment.pop('filename',None)
                        attachment.pop('notes',None)
                        attachment.pop('evidence',None)
            result['closeout'] = [self.closeout_report(c,p['id']) for p in result['projects']]
            result['user'] = actor
            result['permissions'] = sorted(k for k,v in COMMAND_ROLES.items() if actor and actor.get('role') in v)
            return result

    def export(self, actor):
        require(actor.get('role') in {'admin','manager'},'صلاحية تصدير النسخة الاحتياطية مطلوبة','forbidden',403)
        require('project_ids' not in actor,'تصدير نسخة كاملة يتطلب حسابًا مخولًا لجميع المشاريع','full_backup_scope_required',403)
        with self.connect() as c:
            c.execute('BEGIN')
            return {'format':'riyadh-book-fair-backup','schema_version':1,'exported_at':now(),
                    'mode':self.mode,'revision':self.revision(c),
                    'records':{col:self.all(c,col) for col in COLLECTIONS},'attachment_contents':self.attachment_backup(c),
                    'audit':[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY seq')]}

    def command(self, command_type, payload, actor, expected_revision=None):
        require(isinstance(payload,dict),'محتوى الطلب غير صالح')
        for key in ('collection','kind','action','status','priority','source','approval_role','impact_type','input_type','disposition'):
            require(key not in payload or isinstance(payload[key],str),f'الحقل يجب أن يكون نصًا: {key}')
        require(isinstance(command_type,str) and command_type in COMMAND_ROLES,'الأمر غير معروف','unknown_command',404)
        require(actor.get('role') in COMMAND_ROLES[command_type],'لا تملك صلاحية هذا الإجراء','forbidden',403)
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            current = self.revision(c)
            if expected_revision is not None:
                require(isinstance(expected_revision,int) and not isinstance(expected_revision,bool),'رقم النسخة غير صالح')
                require(expected_revision == current,'تغيرت البيانات؛ حدّث الصفحة ثم أعد المحاولة','revision_conflict',409)
            if 'project_ids' in actor and command_type=='shared.create' and payload.get('collection')=='projects':
                raise DomainError('إنشاء مشروع جديد يتطلب إدارة غير مقيّدة بمشاريع محددة','project_scope_required',403)
            self.ensure_project_open(c,command_type,payload,actor)
            result = getattr(self,command_type.replace('.','_'))(c,payload,actor)
            result_project=result['id'] if command_type in {'project.close','project.reopen'} or (command_type=='shared.create' and payload.get('collection')=='projects') else result.get('project_id')
            if 'project_ids' in actor:
                require(result_project in actor['project_ids'],'المشروع خارج نطاق الحساب','project_scope_required',403)
            if result_project and command_type not in {'project.close','project.reopen'}:
                require(self.get(c,'projects',result_project).get('status','active')!='closed','المشروع مقفل؛ أعد فتحه بسبب موثق أولًا','project_closed',409)
            c.execute("UPDATE metadata SET value=? WHERE key='revision'",(str(current+1),))
            # Order addresses and contact details are deliberately not copied into audit.
            safe = {k:payload[k] for k in ('id','action','status','item_id','zone_id','to_zone_id','qty','reference','reason') if k in payload}
            c.execute('INSERT INTO audit(at,actor_id,actor_role,command,record_id,payload) VALUES(?,?,?,?,?,?)',
                      (now(),actor['id'],actor['role'],command_type,result.get('id',''),json.dumps(safe,ensure_ascii=False)))
            return {'ok':True,'revision':current+1,'result':result}

    def ensure_project_open(self,c,command_type,p,actor=None):
        project_ids=set()
        if p.get('project_id'): project_ids.add(text(p['project_id'],'المشروع',True,100))
        references=[('zone_id','zones'),('to_zone_id','zones'),('from_zone_id','zones'),('item_id','items'),('incident_id','incidents'),('phase_id','phases'),('responsible_id','stakeholders'),('to_responsible_id','stakeholders'),('handover_responsible_id','stakeholders'),('owner_id','stakeholders'),('supplier_id','stakeholders'),('permit_id','permits')]
        target_collection={'project':'projects','task':'tasks','permit':'permits','incident':'incidents','procurement':'procurements','order':'orders','spatial':'spatial_jobs','support':'support_requests','daily':'daily_reports'}.get(command_type.split('.')[0])
        if command_type=='stock.count.review': target_collection='stock_counts'
        if target_collection and p.get('id'): references.append(('id',target_collection))
        for key,col in references:
            if p.get(key):
                row=self.get(c,col,p[key]); pid=row['id'] if col=='projects' else row.get('project_id')
                if pid: project_ids.add(pid)
        if isinstance(p.get('dependencies'),list):
            for dep in p['dependencies']:
                row=self.get(c,'tasks',dep)
                if row.get('project_id'): project_ids.add(row['project_id'])
        if isinstance(p.get('lines'),list):
            for line in p['lines']:
                if isinstance(line,dict):
                    for key,col in [('item_id','items'),('zone_id','zones')]:
                        if line.get(key):
                            row=self.get(c,col,line[key])
                            if row.get('project_id'): project_ids.add(row['project_id'])
        for pid in project_ids:
            if actor and 'project_ids' in actor:
                require(pid in actor['project_ids'],'المشروع خارج نطاق الحساب','project_scope_required',403)
            project=self.get(c,'projects',pid)
            if command_type=='project.reopen': continue
            require(project.get('status','active')!='closed','المشروع مقفل؛ أعد فتحه بسبب موثق قبل إضافة معاملات','project_closed',409)

    def stock_marker(self,c,item_id,zone_id):
        moves=[m for m in self.all(c,'stock_moves') if m['item_id']==item_id and (m['zone_id']==zone_id or m.get('to_zone_id')==zone_id)]
        return moves[-1]['id'] if moves else ''

    def stock_count(self,c,p,a):
        item=self.get(c,'items',p.get('item_id')); zone=self.get(c,'zones',p.get('zone_id'))
        fields=self.common(c,{**p,'project_id':zone['project_id']})
        require(not item.get('project_id') or item['project_id']==zone['project_id'],'الصنف والمنطقة يتبعان مشروعين مختلفين','project_mismatch')
        qty=p.get('counted_qty')
        require(isinstance(qty,int) and not isinstance(qty,bool) and 0<=qty<=1000000,'كمية الجرد يجب أن تكون عددًا صحيحًا غير سالب')
        require(bool(fields['evidence']),'محضر الجرد مطلوب')
        b=self.balance(c,item['id'],zone['id'])
        fields.update(item_id=item['id'],counted_qty=qty,expected_qty=b['on_hand'],variance=qty-b['on_hand'],
                      status='matched' if qty==b['on_hand'] else 'pending',movement_marker=self.stock_marker(c,item['id'],zone['id']))
        return self.new(c,'stock_counts',fields,a)

    def stock_count_review(self,c,p,a):
        row=self.get(c,'stock_counts',p.get('id')); target=p.get('status')
        require(row['status']=='pending' and target in {'approved','rejected'},'الجرد لا ينتظر اعتماد فرق','invalid_transition',409)
        evidence=text(p.get('evidence'),'محضر معالجة الفرق',True,4000)
        reason=text(p.get('reason'),'سبب اعتماد أو رفض الفرق',True,2000)
        if target=='approved':
            related=[count for count in self.all(c,'stock_counts') if count['item_id']==row['item_id'] and count['zone_id']==row['zone_id']]
            require(related and related[-1]['id']==row['id'],'يوجد جرد أحدث لهذا الموقع؛ لا يمكن اعتماد الجرد السابق','superseded_count',409)
            require(self.stock_marker(c,row['item_id'],row['zone_id'])==row['movement_marker'],'تحرك المخزون بعد الجرد؛ سجّل جردًا جديدًا','stale_count',409)
            b=self.balance(c,row['item_id'],row['zone_id'])
            require(row['counted_qty']>=b['reserved'],'نتيجة الجرد تقل عن الرصيد المحجوز؛ عالج الحجوزات أولًا','reserved_stock_conflict',409)
            b['on_hand']=row['counted_qty']; self.save_balance(c,b)
            move=self.new(c,'stock_moves',{'action':'adjustment','item_id':row['item_id'],'zone_id':row['zone_id'],
              'project_id':row['project_id'],'phase_id':row['phase_id'],'qty':abs(row['variance']),'signed_qty':row['variance'],
              'to_zone_id':'','reference':'count:'+row['id'],'custodian_id':'','evidence':evidence,'reason':reason,
              'responsible_id':row['responsible_id'],'balance_after':b['on_hand']},a)
            row['movement_marker']=move['id']
        row.update(status=target,reviewed_by=a['id'],reviewed_at=now(),review_evidence=evidence,reason=reason)
        return self.put(c,'stock_counts',row)

    def closeout_report(self,c,project_id):
        project=self.get(c,'projects',project_id)
        belongs=lambda row: row.get('project_id')==project_id
        zones={z['id'] for z in self.all(c,'zones') if belongs(z)}
        items={i['id'] for i in self.all(c,'items') if belongs(i)}
        blockers=[]
        def add(code,label,rows):
            if rows: blockers.append({'code':code,'label':label,'count':len(rows),'ids':[r['id'] for r in rows]})
        add('unfinished_tasks','مهام غير مكتملة',[r for r in self.all(c,'tasks') if belongs(r) and r['status']!='completed'])
        add('open_incidents','بلاغات غير مقفلة',[r for r in self.all(c,'incidents') if belongs(r) and r['status']!='closed'])
        add('outstanding_support','طلبات دعم بين المناطق لم تُنهَ',[r for r in self.all(c,'support_requests') if belongs(r) and r['status'] not in {'received','cancelled','rejected'}])
        add('open_orders','طلبات زوار لم تُنهَ',[r for r in self.all(c,'orders') if belongs(r) and r['status'] not in {'delivered','returned','cancelled'}])
        add('open_daily_reports','تقارير تشغيل يومي لم تُقفل',[r for r in self.all(c,'daily_reports') if belongs(r) and r['status']=='open'])
        add('open_procurements','مشتريات غير مستلمة',[r for r in self.all(c,'procurements') if belongs(r) and r['status']!='received'])
        add('active_access','أفراد أو مركبات لم يسجل خروجها',[r for r in self.all(c,'access_logs') if r['zone_id'] in zones and not r.get('checked_out_at')])
        add('outstanding_custody','عهد تشغيلية لم تُسترجع',[r for r in self.all(c,'custody') if (belongs(r) or r['item_id'] in items) and r.get('kind')!='order' and r['outstanding']>0])
        balances=[r for r in self.all(c,'stock') if r['zone_id'] in zones]
        add('reserved_stock','حجوزات مخزون لم تُنهَ',[r for r in balances if r['reserved']>0])
        add('maintenance_stock','معدات ما زالت في الصيانة',[r for r in balances if r['maintenance']>0])
        counts=self.all(c,'stock_counts')
        pending=[]
        for b in balances:
            marker=self.stock_marker(c,b['item_id'],b['zone_id'])
            related=[r for r in counts if r['item_id']==b['item_id'] and r['zone_id']==b['zone_id']]
            latest=related[-1] if related else None
            if not latest or latest['status'] not in {'matched','approved'} or latest['movement_marker']!=marker: pending.append(b)
        add('final_count_required','مواقع مخزون تحتاج جردًا نهائيًا محدثًا',pending)
        return {'project_id':project_id,'status':project.get('status','active'),'ready':not blockers,'blockers':blockers}

    def project_close(self,c,p,a):
        project=self.get(c,'projects',p.get('id'))
        evidence=text(p.get('evidence'),'محضر الإقفال',True,4000)
        summary=text(p.get('summary'),'ملخص التسليم والإقفال',True,4000)
        report=self.closeout_report(c,project['id'])
        require(report['ready'],'الإقفال غير جاهز: '+ '، '.join(b['label'] for b in report['blockers']),'closeout_blocked',409)
        project.update(status='closed',closed_at=now(),closed_by=a['id'],closeout_evidence=evidence,closeout_summary=summary)
        project.setdefault('history',[]).append({'status':'closed','at':now(),'actor_id':a['id'],'evidence':evidence,'summary':summary})
        return self.put(c,'projects',project)

    def project_reopen(self,c,p,a):
        project=self.get(c,'projects',p.get('id'))
        require(project.get('status')=='closed','المشروع غير مقفل','invalid_transition',409)
        reason=text(p.get('reason'),'سبب إعادة الفتح',True,2000); evidence=text(p.get('evidence'),'مرجع الاعتماد',True,4000)
        project.update(status='active',reopened_at=now(),reopened_by=a['id'])
        project.setdefault('history',[]).append({'status':'active','at':now(),'actor_id':a['id'],'evidence':evidence,'reason':reason})
        return self.put(c,'projects',project)

    def shared_create(self,c,p,a):
        col = p.get('collection')
        require(col in {'projects','phases','zones','stakeholders'},'نوع السجل المشترك غير صالح')
        fields = {'name':text(p.get('name'),'الاسم',True,200),'notes':text(p.get('notes'),'ملاحظات')}
        if col == 'projects': fields['status']='active'
        if col != 'projects':
            fields['project_id'] = text(p.get('project_id'),'المشروع',True,100)
            self.get(c,'projects',fields['project_id'])
        if col == 'phases':
            fields['kind'] = p.get('kind','planning')
            require(fields['kind'] in {'foundation','planning','procurement','build','operations','dismantling','closeout'},'المرحلة غير صالحة')
            fields['order'] = p.get('order',0)
            require(isinstance(fields['order'],int) and not isinstance(fields['order'],bool),'ترتيب المرحلة غير صالح')
        if col == 'zones':
            capacity=p.get('capacity',0)
            require(isinstance(capacity,int) and not isinstance(capacity,bool) and 0<=capacity<=1000000,'سعة المنطقة يجب أن تكون عددًا صحيحًا من صفر إلى مليون')
            fields['capacity']=capacity
        if col == 'stakeholders':
            fields.update({'role':text(p.get('role'),'الدور',limit=100),'organization':text(p.get('organization'),'الجهة',limit=200),
                           'contact':text(p.get('contact'),'التواصل',limit=200)})
        return self.new(c,col,fields,a)

    def item_create(self,c,p,a):
        fields = self.common(c,p)
        kind = p.get('kind')
        require(kind in {'equipment','book','consumable'},'نوع الصنف غير صالح')
        fields.update({'kind':kind, 'name':text(p.get('name') or p.get('title'),'اسم الصنف',True,240),
                       'title':text(p.get('title') or p.get('name'),'العنوان',kind=='book',240),
                       'edition':text(p.get('edition'),'الطبعة',limit=120),'isbn':text(p.get('isbn'),'ISBN',limit=40),
                       'unit':text(p.get('unit') or ('نسخة' if kind=='book' else 'قطعة'),'الوحدة',True,40),
                       'owner_id':text(p.get('owner_id'),'المالك أو الناشر',kind=='book',100)})
        if fields['owner_id']:
            owner=self.get(c,'stakeholders',fields['owner_id'])
            require(not fields['project_id'] or fields['project_id']==owner['project_id'],'المالك يتبع مشروعًا آخر','project_mismatch')
            if not fields['project_id']: fields['project_id']=owner['project_id']
        require(bool(fields['project_id']),'حدد مشروع الصنف أو جهة مالكة مرتبطة بمشروع')
        return self.new(c,'items',fields,a)

    def balance(self,c,item_id,zone_id):
        key = item_id+'@'+zone_id
        return self.get(c,'stock',key,False) or {'id':key,'item_id':item_id,'zone_id':zone_id,
          'on_hand':0,'reserved':0,'available':0,'maintenance':0,'provenance':self.mode}

    def save_balance(self,c,b):
        b['available'] = b['on_hand']-b['reserved']
        require(all(isinstance(b[k],int) and b[k]>=0 for k in ('on_hand','reserved','available','maintenance')),
                'الحركة تتجاوز الرصيد المتاح','insufficient_stock',409)
        b['updated_at'] = now()
        return self.put(c,'stock',b)

    def stock_move(self,c,p,a,internal=False):
        action = p.get('action')
        require(action in {'receipt','reserve','release','issue','return','transfer','maintenance','restore','ship','consume'},'نوع الحركة غير صالح')
        item = self.get(c,'items',p.get('item_id'))
        zone = self.get(c,'zones',p.get('zone_id'))
        require(item.get('project_id')==zone.get('project_id'),'الصنف والمنطقة يتبعان مشروعين مختلفين أو الصنف بلا مشروع','project_mismatch')
        common=self.common(c,{**p,'project_id':zone['project_id']})
        q = quantity(p.get('qty'))
        ref = text(p.get('reference'),'مرجع الحركة',action in {'reserve','release','issue','return','consume'},160)
        require(internal or not ref.startswith(('order:','procurement:','support:')), 'هذا المرجع تديره دورة الطلب أو الشراء','protected_reference',409)
        evidence = text(p.get('evidence'),'الإثبات',action in {'receipt','issue','return','transfer','maintenance','restore','ship','consume'},4000)
        reason = text(p.get('reason'),'سبب الحركة',False,2000)
        custodian = text(p.get('custodian_id'),'صاحب العهدة',action=='issue',100)
        if custodian and not internal:
            owner=self.get(c,'stakeholders',custodian)
            require(owner['project_id']==zone['project_id'],'صاحب العهدة يتبع مشروعًا آخر','project_mismatch')
        b = self.balance(c,item['id'],zone['id'])
        hold_id = f"{item['id']}@{zone['id']}@{ref}"
        hold = self.get(c,'reservations',hold_id,False) or {'id':hold_id,'item_id':item['id'],'zone_id':zone['id'],'reference':ref,'qty':0,'provenance':self.mode}
        custody_id = f"{item['id']}@{ref}"
        custody = self.get(c,'custody',custody_id,False) or {'id':custody_id,'item_id':item['id'],'reference':ref,'outstanding':0,'issued':0,'returned':0,'settled':0,'custodian_id':custodian,'kind':'order' if ref.startswith('order:') else 'operational','project_id':zone['project_id'],'provenance':self.mode}
        custody.setdefault('project_id',zone['project_id'])
        if action=='receipt': b['on_hand'] += q
        elif action=='consume':
            require(item['kind']=='consumable','الاستهلاك المباشر متاح للمواد الاستهلاكية فقط')
            require(bool(common['responsible_id']),'مسؤول الاستهلاك مطلوب')
            require(b['available']>=q,'لا يمكن استهلاك مخزون محجوز أو غير متاح','insufficient_stock',409)
            b['on_hand'] -= q
        elif action=='reserve':
            require(b['available']>=q,'الرصيد المتاح لا يكفي للحجز','insufficient_stock',409)
            b['reserved'] += q; hold['qty'] += q
            self.put(c,'reservations',hold)
        elif action=='release':
            require(hold['qty']>=q,'الكمية تتجاوز الحجز المرتبط بهذا المرجع','reservation_exceeded',409)
            hold['qty'] -= q; b['reserved'] -= q
            self.put(c,'reservations',hold)
        elif action in {'issue','ship'}:
            own = min(q,hold['qty'])
            require(b['available'] >= q-own,'الحركة تتجاوز المتاح أو حجز مرجع آخر','insufficient_stock',409)
            b['on_hand'] -= q; b['reserved'] -= own; hold['qty'] -= own
            if own: self.put(c,'reservations',hold)
            if action=='issue':
                require(not custody['outstanding'] or custody['custodian_id']==custodian,'مرجع العهدة مسند إلى مسؤول آخر','custodian_mismatch',409)
                custody.update(custodian_id=custodian,outstanding=custody['outstanding']+q,issued=custody['issued']+q)
                self.put(c,'custody',custody)
        elif action=='return':
            require(custody['outstanding']>=q,'لا يمكن إرجاع كمية أكبر من العهدة المصروفة','return_exceeded',409)
            custody['outstanding'] -= q; custody['returned'] += q; b['on_hand'] += q
            self.put(c,'custody',custody)
        elif action=='transfer':
            target = self.get(c,'zones',p.get('to_zone_id'))
            require(target['id']!=zone['id'],'اختر منطقة وجهة مختلفة')
            require(target['project_id']==zone['project_id'],'النقل بين مشروعين غير مدعوم','project_mismatch')
            require(b['available']>=q,'لا يمكن نقل مخزون محجوز أو غير متاح','insufficient_stock',409)
            b['on_hand'] -= q
            dest = self.balance(c,item['id'],target['id']); dest['on_hand'] += q
            self.save_balance(c,dest)
        elif action=='maintenance':
            require(item['kind']=='equipment','الصيانة متاحة للمعدات فقط')
            require(b['available']>=q,'لا يتوفر رصيد كافٍ للصيانة','insufficient_stock',409)
            b['on_hand'] -= q; b['maintenance'] += q
        elif action=='restore':
            require(b['maintenance']>=q,'الكمية تتجاوز الموجود في الصيانة','maintenance_exceeded',409)
            b['maintenance'] -= q; b['on_hand'] += q
        self.save_balance(c,b)
        return self.new(c,'stock_moves',{'action':action,'item_id':item['id'],'zone_id':zone['id'],
          'project_id':zone['project_id'],'phase_id':text(p.get('phase_id'),'المرحلة',limit=100),'qty':q,
          'to_zone_id':p.get('to_zone_id',''),'reference':ref,'custodian_id':custodian,'evidence':evidence,
          'reason':reason,'responsible_id':text(p.get('responsible_id'),'المسؤول',limit=100),'balance_after':b['on_hand']},a)

    def stock_settle(self,c,p,a):
        item=self.get(c,'items',p.get('item_id'))
        ref=text(p.get('reference'),'مرجع العهدة',True,160)
        require(not ref.startswith(('order:','support:')),'التسوية لهذا المرجع تديرها دورة الطلب أو الدعم','protected_reference',409)
        q=quantity(p.get('qty')); disposition=p.get('disposition')
        allowed={'consumable':{'consumed','final_delivery','loss_damage'},'book':{'publisher_sold','final_delivery','loss_damage'},'equipment':{'final_delivery','loss_damage'}}
        require(disposition in allowed[item['kind']],'نوع التسوية غير مسموح لهذا الصنف','invalid_disposition')
        reason=text(p.get('reason'),'سبب التسوية',True,2000); evidence=text(p.get('evidence'),'محضر اعتماد التسوية',True,4000)
        custody=self.get(c,'custody',item['id']+'@'+ref)
        require(custody.get('kind')!='order','تسوية طلبات الزوار تتم من دورة الطلب','protected_reference',409)
        require(custody['outstanding']>=q,'التسوية تتجاوز العهدة القائمة','settlement_exceeded',409)
        custody['outstanding']-=q;custody['settled']=custody.get('settled',0)+q
        self.put(c,'custody',custody)
        return self.new(c,'stock_moves',{'action':'settlement','item_id':item['id'],'zone_id':'','project_id':custody.get('project_id') or item.get('project_id',''),
           'phase_id':'','qty':q,'to_zone_id':'','reference':ref,'custodian_id':custody['custodian_id'],
           'evidence':evidence,'reason':reason,'disposition':disposition,'responsible_id':custody['custodian_id'],
           'balance_after':None,'custody_outstanding_after':custody['outstanding']},a)

    def order_create(self,c,p,a):
        fields = self.common(c,p)
        raw = p.get('lines')
        require(isinstance(raw,list) and 0<len(raw)<=100,'أضف من 1 إلى 100 بند في الطلب')
        lines = []
        seen = set()
        for line in raw:
            require(isinstance(line,dict),'بند غير صالح')
            item = self.get(c,'items',line.get('item_id'))
            require(item['kind']=='book','مشتريات الزوار مخصصة للكتب')
            zone = self.get(c,'zones',line.get('zone_id'))
            require(not fields['project_id'] or fields['project_id']==zone['project_id'],'البند يتبع مشروعًا آخر','project_mismatch')
            if not fields['project_id']: fields['project_id']=zone['project_id']
            key = (item['id'],zone['id'])
            require(key not in seen,'ادمج البنود المتكررة للصنف والموقع')
            seen.add(key)
            lines.append({'item_id':item['id'],'zone_id':zone['id'],'qty':quantity(line.get('qty')),
                          'owner_id':item['owner_id'],'title':item['title']})
        fields.update({'customer_name':text(p.get('customer_name'),'اسم المستلم',True,200),
                       'customer_phone':text(p.get('customer_phone'),'هاتف المستلم',limit=60),
                       'address':text(p.get('address'),'عنوان التسليم',limit=1000),'lines':lines,
                       'status':'ordered','tracking_number':'','carrier':'','history':[],
                       'payment_status':'not_integrated','shipping_source':'manual'})
        order = self.new(c,'orders',fields,a)
        for line in lines:
            self.stock_move(c,{**line,'action':'reserve','reference':'order:'+order['id']},a,True)
        return order

    def order_transition(self,c,p,a):
        order = self.get(c,'orders',p.get('id'))
        target = p.get('status')
        current = order['status']
        transitions = {'ordered':{'picking','cancelled','exception'}, 'picking':{'packed','cancelled','exception'},
          'packed':{'shipped','cancelled','exception'}, 'shipped':{'delivered','returned','exception'},
          'delivered':{'returned'}, 'exception':{'cancelled','returned'}, 'cancelled':set(),'returned':set()}
        if current=='exception':
            transitions['exception'].add(order.get('previous_status','ordered'))
        require(target in transitions.get(current,set()),'انتقال حالة الطلب غير مسموح','invalid_transition',409)
        evidence = text(p.get('evidence'),'إثبات الإجراء',target not in {'picking','exception'},4000)
        reason = text(p.get('reason'),'سبب الاستثناء أو الإلغاء',target in {'exception','cancelled','returned'},2000)
        dispatched = order.get('dispatched',False)
        if target=='exception': order['previous_status'] = current
        elif current=='exception' and target==order.get('previous_status'):
            require(bool(evidence),'إثبات معالجة الاستثناء مطلوب')
        elif target=='shipped':
            require(not dispatched,'الطلب مشحون بالفعل','already_dispatched',409)
            order['tracking_number'] = text(p.get('tracking_number'),'رقم التتبع',True,160)
            order['carrier'] = text(p.get('carrier'),'شركة الشحن',True,200)
            require(bool(order['address']),'عنوان التسليم مطلوب للشحن')
            for line in order['lines']:
                self.stock_move(c,{**line,'action':'issue','reference':'order:'+order['id'],
                   'custodian_id':'customer:'+order['id'],'evidence':evidence},a,True)
            order['dispatched'] = True
        elif target=='cancelled':
            require(not dispatched,'لا يمكن إلغاء طلب مشحون؛ سجّل مرتجعًا','already_dispatched',409)
            for line in order['lines']:
                self.stock_move(c,{**line,'action':'release','reference':'order:'+order['id']},a,True)
        elif target=='returned':
            require(dispatched,'الطلب غير مشحون؛ استخدم إلغاء الطلب','not_dispatched',409)
            for line in order['lines']:
                self.stock_move(c,{**line,'action':'return','reference':'order:'+order['id'],'evidence':evidence},a,True)
        order['history'].append({'from':current,'to':target,'at':now(),'actor_id':a['id'],'evidence':evidence,'reason':reason})
        order.update(status=target,updated_at=now())
        return self.put(c,'orders',order)

    def normalize_checklist(self,value=None):
        if value is None:
            value=[{'id':'scope','label':'مطابقة نطاق العمل المعتمد','required':True},
                   {'id':'quality','label':'فحص الجودة والوظيفة','required':True},
                   {'id':'handover','label':'تسليم الموقع أو الأصل للمسؤول','required':True}]
        require(isinstance(value,list) and 1<=len(value)<=20,'قائمة الفحص يجب أن تحتوي من بند واحد إلى 20 بندًا')
        seen=set();result=[]
        for entry in value:
            require(isinstance(entry,dict),'بند الفحص غير صالح')
            identifier=text(entry.get('id'),'معرف بند الفحص',True,80)
            require(identifier not in seen,'معرفات بنود الفحص مكررة');seen.add(identifier)
            mandatory=entry.get('required',True)
            require(isinstance(mandatory,bool),'متطلب بند الفحص يجب أن يكون منطقيًا')
            result.append({'id':identifier,'label':text(entry.get('label'),'بند الفحص',True,300),'required':mandatory})
        require(any(x['required'] for x in result),'يجب أن تتضمن قائمة الفحص بندًا إلزاميًا على الأقل')
        return result

    def task_inspect(self,c,p,a):
        task=self.get(c,'tasks',p.get('id'))
        require(task['status']=='inspection','انقل المهمة إلى الفحص قبل تسجيل التقرير','invalid_transition',409)
        checklist=self.normalize_checklist(task.get('inspection_checklist'))
        expected={x['id']:x for x in checklist}
        raw=p.get('results')
        require(isinstance(raw,list) and 1<=len(raw)<=20,'سجل نتائج بنود الفحص')
        evidence=text(p.get('evidence'),'محضر الفحص',True,4000)
        results=[];seen=set()
        for entry in raw:
            require(isinstance(entry,dict),'نتيجة بند غير صالحة')
            identifier=text(entry.get('item_id'),'معرف بند الفحص',True,80)
            require(identifier in expected and identifier not in seen,'بند فحص غير معروف أو مكرر');seen.add(identifier)
            status=entry.get('status');require(isinstance(status,str) and status in {'passed','failed'},'نتيجة الفحص غير صالحة')
            results.append({'item_id':identifier,'label':expected[identifier]['label'],'status':status,
                            'notes':text(entry.get('notes'),'ملاحظات البند',status=='failed',2000)})
        require(all(not item['required'] or item['id'] in seen for item in checklist),'سجل نتيجة كل بند إلزامي','inspection_incomplete',409)
        attachment_ids=p.get('attachment_ids',[])
        require(isinstance(attachment_ids,list) and len(attachment_ids)<=20 and all(isinstance(x,str) for x in attachment_ids),'مراجع المرفقات غير صالحة')
        for identifier in attachment_ids:
            attachment=self.get(c,'attachments',identifier)
            require(attachment['project_id']==task['project_id'],'مرفق الفحص يتبع مشروعًا آخر','project_mismatch')
        overall='failed' if any(x['status']=='failed' for x in results) else 'passed'
        report={'id':'INS-'+secrets.token_hex(4).upper(),'results':results,'overall':overall,'cycle':task.get('inspection_cycle',0),
                'at':now(),'actor_id':a['id'],'evidence':evidence,'attachment_ids':list(dict.fromkeys(attachment_ids))}
        task.setdefault('inspections',[]).append(report)
        task.update(inspection_checklist=checklist,inspection_result=overall,inspected_by=a['id'],inspected_at=report['at'],updated_at=now())
        return self.put(c,'tasks',task)

    def task_create(self,c,p,a):
        fields = self.common(c,p)
        dependency_projects={fields['project_id']} if fields['project_id'] else set()
        deps = p.get('dependencies',[])
        require(isinstance(deps,list) and len(deps)<=100 and all(isinstance(x,str) for x in deps),'الاعتماديات غير صالحة')
        for dep in deps:
            task = self.get(c,'tasks',dep)
            if task.get('project_id'): dependency_projects.add(task['project_id'])
        if p.get('permit_id'):
            linked_permit=self.get(c,'permits',p['permit_id'])
            if linked_permit.get('project_id'): dependency_projects.add(linked_permit['project_id'])
            if not fields['zone_id']: fields['zone_id']=linked_permit['zone_id']
        require(len(dependency_projects)<=1,'اعتماديات المهمة أو التصريح تتبع مشاريع مختلفة','project_mismatch')
        require(bool(dependency_projects),'حدد مشروع المهمة أو مراجع مرتبطة بمشروع')
        fields['project_id']=next(iter(dependency_projects))
        start = text(p.get('start_date'),'بداية المهمة',limit=40)
        due = text(p.get('due_date'),'نهاية المهمة',limit=40)
        for value in [start,due]:
            if value:
                try: dt.date.fromisoformat(value)
                except ValueError: raise DomainError('تاريخ المهمة يجب أن يكون YYYY-MM-DD')
        require(not (start and due) or start<=due,'نهاية المهمة تسبق بدايتها')
        require(isinstance(p.get('inspection_required',True),bool),'متطلب الفحص يجب أن يكون منطقيًا')
        checklist=self.normalize_checklist(p.get('inspection_checklist'))
        fields.update({'title':text(p.get('title'),'عنوان المهمة',True,240),'status':'planned','dependencies':list(dict.fromkeys(deps)),
           'start_date':start,'due_date':due,'inspection_required':p.get('inspection_required',True),'inspection_result':'pending','inspection_checklist':checklist,'inspections':[],'inspection_cycle':0,
           'permit_id':text(p.get('permit_id'),'التصريح',limit=100),'history':[]})
        if fields['permit_id']:
            permit=self.get(c,'permits',fields['permit_id'])
            require(not fields['project_id'] or permit.get('project_id')==fields['project_id'],'التصريح يتبع مشروعًا آخر','project_mismatch')
            require(not fields['zone_id'] or permit['zone_id']==fields['zone_id'],'التصريح لا يشمل منطقة المهمة','zone_not_permitted')
        return self.new(c,'tasks',fields,a)

    def task_transition(self,c,p,a):
        task = self.get(c,'tasks',p.get('id')); target = p.get('status'); current=task['status']
        require(target in {'planned':{'active','blocked'},'active':{'inspection','completed','blocked'},
                          'inspection':{'completed','active','blocked'},'blocked':{'planned','active'},'completed':set()}.get(current,set()),
                'انتقال حالة المهمة غير مسموح','invalid_transition',409)
        if target in {'active','completed'}:
            require(all(self.get(c,'tasks',dep)['status']=='completed' for dep in task['dependencies']),
                    'أكمل المهام السابقة أولًا','dependencies_incomplete',409)
        if target in {'active','completed'} and task.get('permit_id'):
            self.valid_permit(self.get(c,'permits',task['permit_id']))
        evidence = text(p.get('evidence'),'إثبات الفحص أو التسليم',target=='completed',4000)
        if target=='completed' and task['inspection_required']:
            require(a['role'] in {'admin','manager'},'اعتماد الفحص والتسليم يتطلب مديرًا','forbidden',403)
            reports=task.get('inspections',[])
            require(current=='inspection' and reports and reports[-1]['overall']=='passed' and reports[-1]['cycle']==task.get('inspection_cycle',0),'يجب اجتياز تقرير فحص البنود للدورة الحالية قبل الإكمال','inspection_required',409)
        if target=='active':
            task['inspection_cycle']=task.get('inspection_cycle',0)+1
            task['inspection_result']='pending'
        reason = text(p.get('reason'),'سبب التعليق',target=='blocked')
        task['history'].append({'from':current,'to':target,'at':now(),'actor_id':a['id'],'evidence':evidence,'reason':reason})
        task.update(status=target,updated_at=now())
        return self.put(c,'tasks',task)

    def permit_create(self,c,p,a):
        fields = self.common(c,p)
        require(bool(fields['zone_id']),'حدد منطقة التصريح')
        valid_from=timestamp(p.get('valid_from'),'بداية الصلاحية'); valid_until=timestamp(p.get('valid_until'),'نهاية الصلاحية')
        require(valid_until>valid_from,'نهاية الصلاحية يجب أن تكون بعد البداية')
        kind=p.get('kind','person'); require(kind in {'person','vehicle','team','supplier'},'نوع التصريح غير صالح')
        raw_steps=p.get('approval_steps')
        if raw_steps is None:
            raw_steps=[{'id':'approval-1','authority':p.get('authority'),'role':p.get('approval_role','security')}]
        require(isinstance(raw_steps,list) and 1<=len(raw_steps)<=3,'مسار التصريح يتطلب من خطوة إلى ثلاث خطوات اعتماد')
        steps=[];seen=set()
        for entry in raw_steps:
            require(isinstance(entry,dict),'خطوة الاعتماد غير صالحة')
            identifier=text(entry.get('id'),'معرف خطوة الاعتماد',True,80)
            require(identifier not in seen,'معرفات خطوات الاعتماد مكررة');seen.add(identifier)
            role=entry.get('role');require(isinstance(role,str) and role in {'security','manager'},'دور الاعتماد غير صالح')
            stakeholder_id=text(entry.get('stakeholder_id'),'الجهة المرتبطة بالاعتماد',limit=100)
            if stakeholder_id:
                stakeholder=self.get(c,'stakeholders',stakeholder_id)
                require(stakeholder['project_id']==fields['project_id'],'جهة الاعتماد تتبع مشروعًا آخر','project_mismatch')
            steps.append({'id':identifier,'authority':text(entry.get('authority'),'الجهة المعتمدة',True,200),
                          'role':role,'stakeholder_id':stakeholder_id,'status':'pending'})
        fields.update({'title':text(p.get('title'),'عنوان التصريح',True,240),'holder_name':text(p.get('holder_name'),'حامل التصريح',True,200),
          'holder_id':text(p.get('holder_id'),'معرف الحامل',limit=120),'vehicle_plate':text(p.get('vehicle_plate'),'لوحة المركبة',kind=='vehicle',60),
          'kind':kind,'approval_role':steps[0]['role'],'valid_from':valid_from.isoformat(),'valid_until':valid_until.isoformat(),
          'authority':steps[0]['authority'],'status':'proposed','history':[],'approval_steps':steps,'current_step_index':0})
        return self.new(c,'permits',fields,a)

    def permit_transition(self,c,p,a):
        permit=self.get(c,'permits',p.get('id')); target=p.get('status'); current=permit['status']
        require(target in {'proposed':{'submitted'},'submitted':{'approved','rejected'},'approved':{'revoked'},'rejected':set(),'revoked':set()}.get(current,set()),
                'انتقال حالة التصريح غير مسموح','invalid_transition',409)
        steps=permit.get('approval_steps') or [{'id':'approval-1','authority':permit['authority'],'role':permit['approval_role'],'stakeholder_id':'','status':'approved' if current=='approved' else 'pending'}]
        index=permit.get('current_step_index',len(steps) if current=='approved' else 0)
        active_step=steps[min(index,len(steps)-1)]
        if target in {'approved','rejected','revoked'}:
            require(a['role'] in {'admin',active_step['role']},'الاعتماد يتطلب دور الخطوة الحالية في مسار التصريح','approval_role_required',403)
        evidence=text(p.get('evidence'),'إثبات القرار',target in {'approved','rejected','revoked'},4000)
        reason=text(p.get('reason'),'سبب الرفض أو الإلغاء',target in {'rejected','revoked'})
        actual_target=target
        if target=='approved':
            require(timestamp(permit['valid_until'],'نهاية الصلاحية')>dt.datetime.now(dt.timezone.utc),'لا يمكن اعتماد تصريح منتهي','permit_expired',409)
            require(index<len(steps) and active_step['status']=='pending','خطوة الاعتماد غير متاحة','invalid_transition',409)
            active_step.update(status='approved',decided_at=now(),decided_by=a['id'],evidence=evidence)
            index+=1
            if index<len(steps): actual_target='submitted'
        elif target=='rejected':
            active_step.update(status='rejected',decided_at=now(),decided_by=a['id'],evidence=evidence,reason=reason)
        permit['history'].append({'from':current,'to':actual_target,'event':'approval_step_approved' if target=='approved' else 'transition',
          'step_id':active_step['id'] if target in {'approved','rejected'} else '',
          'at':now(),'actor_id':a['id'],'evidence':evidence,'reason':reason})
        next_step=steps[min(index,len(steps)-1)]
        permit.update(status=actual_target,updated_at=now(),approval_steps=steps,current_step_index=index,
                      authority=next_step['authority'],approval_role=next_step['role'])
        return self.put(c,'permits',permit)

    def valid_permit(self,permit):
        require(permit['status']=='approved' and all(step['status']=='approved' for step in permit.get('approval_steps',[])),'التصريح غير معتمد بالكامل','permit_not_approved',409)
        point=dt.datetime.now(dt.timezone.utc)
        require(timestamp(permit['valid_from'],'بداية الصلاحية')<=point<=timestamp(permit['valid_until'],'نهاية الصلاحية'),
                'التصريح خارج فترة الصلاحية','permit_expired',409)

    def permit_access(self,c,p,a):
        permit=self.get(c,'permits',p.get('id')); action=p.get('action')
        require(action in {'checkin','checkout'},'نوع حركة الدخول غير صالح')
        active=[x for x in self.all(c,'access_logs') if x['permit_id']==permit['id'] and not x.get('checked_out_at')]
        evidence=text(p.get('evidence'),'إثبات البوابة',True,4000)
        if action=='checkin':
            self.valid_permit(permit)
            require(not active,'للتصريح دخول قائم بالفعل','already_checked_in',409)
            require(not p.get('zone_id') or p['zone_id']==permit['zone_id'],'التصريح لا يشمل هذه المنطقة','zone_not_permitted',403)
            return self.new(c,'access_logs',{'permit_id':permit['id'],'zone_id':permit['zone_id'],'project_id':permit.get('project_id',''),
              'checked_in_at':now(),'checked_in_by':a['id'],'checkin_evidence':evidence,'checked_out_at':'','holder_name':permit['holder_name']},a)
        require(bool(active),'لا يوجد دخول قائم لتسجيل الخروج','not_checked_in',409)
        row=active[0]; row.update(checked_out_at=now(),checked_out_by=a['id'],checkout_evidence=evidence)
        return self.put(c,'access_logs',row)

    def incident_create(self,c,p,a):
        fields=self.common(c,p)
        require(bool(fields['project_id']),'حدد مشروع البلاغ أو المنطقة')
        priority=p.get('priority','medium'); require(priority in {'critical','high','medium','low'},'الأولوية غير صالحة')
        source=p.get('source','manual'); require(source in {'manual','field','prediction'},'اختر مصدرًا يدويًا أو ميدانيًا أو تنبؤيًا')
        observed=timestamp(p.get('observed_at') or now(),'وقت الرصد')
        require(source=='prediction' or observed<=dt.datetime.now(dt.timezone.utc)+dt.timedelta(minutes=5),'البلاغ الميداني لا يكون في المستقبل')
        fields.update({'title':text(p.get('title'),'عنوان البلاغ',True,240),'description':text(p.get('description'),'تفاصيل البلاغ',True,4000),
           'priority':priority,'source':source,'status':'open','category':text(p.get('category') or 'operations','التصنيف',True,100),
           'observed_at':observed.isoformat(),'history':[]})
        return self.new(c,'incidents',fields,a)

    def incident_decision(self,c,p,a):
        incident=self.get(c,'incidents',p.get('incident_id'))
        require(p.get('impact_type','expected') in {'expected','observed'},'نوع الأثر غير صالح')
        require(incident['status']!='closed','البلاغ مقفل','invalid_transition',409)
        responsible=text(p.get('responsible_id') or incident.get('responsible_id'),'مسؤول الإجراء',True,100)
        owner=self.get(c,'stakeholders',responsible)
        require(not incident.get('project_id') or owner['project_id']==incident['project_id'],'مسؤول القرار يتبع مشروعًا آخر','project_mismatch')
        return self.new(c,'decisions',{'incident_id':incident['id'],'project_id':incident.get('project_id',''),'zone_id':incident.get('zone_id',''),
          'decision':text(p.get('decision'),'القرار',True,4000),'action':text(p.get('action'),'الإجراء',True,4000),
          'impact':text(p.get('impact'),'الأثر المرصود أو المتوقع',True,4000),'impact_type':p.get('impact_type','expected'),
          'responsible_id':responsible,'evidence':text(p.get('evidence'),'الإثبات',True,4000)},a)

    def incident_transition(self,c,p,a):
        row=self.get(c,'incidents',p.get('id')); target=p.get('status'); current=row['status']
        require(target in {'open':{'assigned'},'assigned':{'resolved'},'resolved':{'closed','assigned'},'closed':set()}.get(current,set()),
                'انتقال حالة البلاغ غير مسموح','invalid_transition',409)
        evidence=text(p.get('evidence'),'إثبات الإجراء',target in {'resolved','closed'},4000)
        if target=='assigned':
            responsible=text(p.get('responsible_id') or row.get('responsible_id'),'المسؤول',True,100)
            owner=self.get(c,'stakeholders',responsible)
            require(owner['project_id']==row['project_id'],'مسؤول البلاغ يتبع مشروعًا آخر','project_mismatch')
            row['responsible_id']=responsible
        if target=='resolved':
            require(any(d['incident_id']==row['id'] for d in self.all(c,'decisions')),'سجّل قرارًا وإجراءً وأثرًا قبل الحل','decision_required',409)
        if target=='closed': require(a['role'] in {'admin','manager','security'},'إقفال البلاغ يتطلب مسؤول قيادة','forbidden',403)
        row['history'].append({'from':current,'to':target,'at':now(),'actor_id':a['id'],'evidence':evidence})
        row.update(status=target,updated_at=now())
        return self.put(c,'incidents',row)

    def procurement_create(self,c,p,a):
        fields=self.common(c,p)
        item=self.get(c,'items',p.get('item_id')); require(bool(fields['zone_id']),'حدد منطقة الاستلام')
        supplier=text(p.get('supplier_id'),'المورد',True,100); supplier_record=self.get(c,'stakeholders',supplier)
        require(not item.get('project_id') or item['project_id']==fields['project_id'],'الصنف يتبع مشروعًا آخر','project_mismatch')
        require(supplier_record['project_id']==fields['project_id'],'المورد يتبع مشروعًا آخر','project_mismatch')
        fields.update({'title':text(p.get('title') or item['name'],'عنوان الشراء',True,240),'item_id':item['id'],
          'qty':quantity(p.get('qty')),'supplier_id':supplier,'status':'planned','history':[]})
        return self.new(c,'procurements',fields,a)

    def procurement_transition(self,c,p,a):
        row=self.get(c,'procurements',p.get('id')); target=p.get('status'); current=row['status']
        require(target in {'planned':{'approved'},'approved':{'ordered'},'ordered':{'received'},'received':set()}.get(current,set()),
                'انتقال حالة الشراء غير مسموح','invalid_transition',409)
        if target in {'approved','ordered'}: require(a['role'] in {'admin','manager'},'اعتماد وإصدار الشراء يتطلب مديرًا','forbidden',403)
        evidence=text(p.get('evidence'),'مستند الإجراء',True,4000)
        if target=='received':
            move=self.stock_move(c,{'item_id':row['item_id'],'zone_id':row['zone_id'],'qty':row['qty'],
               'action':'receipt','reference':'procurement:'+row['id'],'evidence':evidence,'phase_id':row['phase_id']},a,True)
            row['stock_move_id']=move['id']
        row['history'].append({'from':current,'to':target,'at':now(),'actor_id':a['id'],'evidence':evidence})
        row.update(status=target,updated_at=now())
        return self.put(c,'procurements',row)

    def spatial_create(self,c,p,a):
        fields=self.common(c,p)
        require(bool(fields['project_id']),'حدد مشروع المخطط أو المنطقة')
        kind=p.get('input_type'); require(kind in {'svg','dxf','image'},'المدخل يجب أن يكون SVG أو DXF أو صورة')
        fields.update({'title':text(p.get('title'),'اسم المخطط',True,240),'input_type':kind,
          'source_file':text(p.get('source_file'),'مرجع ملف المخطط',True,1000),'status':'draft',
          'scale_meters':None,'reference_pixels':None,'height_meters':None,'output_file':'','history':[]})
        return self.new(c,'spatial_jobs',fields,a)

    def spatial_transition(self,c,p,a):
        row=self.get(c,'spatial_jobs',p.get('id')); target=p.get('status'); current=row['status']
        require(target in {'draft':{'calibrated'},'calibrated':{'reviewed'},'reviewed':{'exported'},'exported':set()}.get(current,set()),
                'انتقال حالة المخطط غير مسموح','invalid_transition',409)
        evidence=text(p.get('evidence'),'إثبات المراجعة',True,4000)
        if target=='calibrated':
            for key in ('scale_meters','reference_pixels','height_meters'):
                val=p.get(key)
                require(isinstance(val,(int,float)) and not isinstance(val,bool) and 0<val<=100000, 'أدخل قياسات معايرة موجبة ومحدودة')
                row[key]=val
        if target=='reviewed': row['reviewed_by']=a['id']
        if target=='exported':
            output=text(p.get('output_file'),'ملف GLB أو glTF',True,1000)
            require(output.lower().endswith(('.glb','.gltf')),'مرجع التصدير يجب أن ينتهي بـ .glb أو .gltf')
            row['output_file']=output
        row['history'].append({'from':current,'to':target,'at':now(),'actor_id':a['id'],'evidence':evidence})
        row.update(status=target,updated_at=now())
        return self.put(c,'spatial_jobs',row)

    def observation_create(self,c,p,a):
        fields=self.common(c,p)
        require(bool(fields['zone_id']),'حدد منطقة الرصد')
        require(bool(fields['responsible_id']),'حدد مسؤول الرصد')
        observed=timestamp(p.get('observed_at') or now(),'وقت الرصد')
        require(observed<=dt.datetime.now(dt.timezone.utc)+dt.timedelta(minutes=5),'الرصد الميداني لا يكون في المستقبل')
        require(p.get('source','manual') in {'manual','field'},'لا يوجد مصدر حي متصل؛ سجل رصدًا ميدانيًا')
        count=p.get('people_count'); capacity=p.get('capacity')
        require(isinstance(count,int) and not isinstance(count,bool) and 0<=count<=1000000,'عدد الحضور غير صالح')
        quantity(capacity)
        require(bool(fields['evidence']),'إثبات الرصد مطلوب')
        fields.update(observed_at=observed.isoformat(),people_count=count,capacity=capacity,source='manual')
        for key,high in [('wait_minutes',1440),('satisfaction_score',5),('sample_size',1000000)]:
            value=p.get(key)
            if value is not None and value!='':
                require(isinstance(value,(int,float)) and not isinstance(value,bool) and 0<=value<=high,f'القيمة غير صالحة: {key}')
                if key=='sample_size': require(isinstance(value,int),'حجم العينة يجب أن يكون عددًا صحيحًا')
                fields[key]=value
        if fields.get('satisfaction_score') is not None:
            require(fields.get('sample_size',0)>0,'أدخل حجم عينة الرضا')
        return self.new(c,'observations',fields,a)

    def seed_demo(self):
        with self.connect() as c:
            if c.execute("SELECT 1 FROM metadata WHERE key='demo_seeded'").fetchone(): return
            require(not c.execute('SELECT 1 FROM records LIMIT 1').fetchone(),'قاعدة العرض ليست فارغة؛ لن تُستبدل بياناتها')
        a={'id':'demo-seed','name':'تهيئة العرض','role':'admin'}
        project=self.command('shared.create',{'collection':'projects','name':'معرض الرياض الدولي للكتاب — تجربة تشغيلية','notes':'بيانات للعرض فقط؛ لا تمثل المعرض الفعلي'},a)['result']
        pid=project['id']
        phases=[]
        for i,(kind,name) in enumerate([('foundation','التأسيس'),('planning','التخطيط'),('procurement','المشتريات'),('build','البناء والتجهيز'),('operations','التشغيل اليومي'),('dismantling','الفك والاسترجاع'),('closeout','الإقفال')]):
            phases.append(self.command('shared.create',{'collection':'phases','project_id':pid,'name':name,'kind':kind,'order':i},a)['result'])
        zones=[]
        for name in ('المستودع المركزي','القاعة أ','القاعة ب','منطقة التحميل','مركز خدمة الزائر'):
            zones.append(self.command('shared.create',{'collection':'zones','project_id':pid,'name':name,'capacity':500},a)['result'])
        stakeholders=[]
        for name,role,org in [('إدارة المشروع','manager','فريق التنظيم'),('مسؤول المستودع','warehouse','التشغيل'),('فريق السلامة','security','الأمن والسلامة'),('دار الأفق — نموذج','publisher','دار الأفق'),('دار المدار — نموذج','publisher','دار المدار'),('مورد التجهيز — نموذج','supplier','التجهيزات')]:
            stakeholders.append(self.command('shared.create',{'collection':'stakeholders','project_id':pid,'name':name,'role':role,'organization':org},a)['result'])
        items=[]
        for kind,name,qty,owner in [('equipment','جهاز اتصال لاسلكي',48,1),('equipment','كرسي استقبال',120,1),('consumable','صندوق تغليف',240,1),('book','رحلات في المعرفة',90,3),('book','ذاكرة المدن',65,4)]:
            item=self.command('item.create',{'project_id':pid,'kind':kind,'name':name,'owner_id':stakeholders[owner]['id'],'edition':'الأولى' if kind=='book' else ''},a)['result']; items.append(item)
            self.command('stock.move',{'action':'receipt','item_id':item['id'],'zone_id':zones[0]['id'],'qty':qty,'evidence':'محضر استلام تجريبي','reference':'DEMO-OPENING'},a)
        task=self.command('task.create',{'title':'فحص جاهزية القاعة أ وتسليمها للتشغيل','project_id':pid,'phase_id':phases[3]['id'],'zone_id':zones[1]['id'],'responsible_id':stakeholders[0]['id'],'inspection_required':True},a)['result']
        self.command('task.transition',{'id':task['id'],'status':'active'},a)
        self.command('incident.create',{'title':'تكدس افتراضي عند مدخل القاعة أ','description':'بلاغ تدريبي لا يستند إلى حساس أو مصدر حي.','project_id':pid,'phase_id':phases[4]['id'],'zone_id':zones[1]['id'],'priority':'high','source':'prediction','category':'crowds'},a)
        self.command('procurement.create',{'title':'تجهيز دفعة صناديق التغليف','item_id':items[2]['id'],'qty':50,'project_id':pid,'phase_id':phases[2]['id'],'zone_id':zones[0]['id'],'supplier_id':stakeholders[5]['id']},a)
        self.command('stock.move',{'action':'issue','item_id':items[0]['id'],'zone_id':zones[0]['id'],'qty':6,'reference':'DEMO-CUSTODY-01','custodian_id':stakeholders[2]['id'],'evidence':'محضر عهدة تجريبي لفريق السلامة'},a)
        self.command('order.create',{'customer_name':'زائر تجريبي','customer_phone':'رقم تجريبي غير فعلي','address':'عنوان تجريبي غير صالح للشحن','project_id':pid,'phase_id':phases[4]['id'],'responsible_id':stakeholders[1]['id'],'lines':[{'item_id':items[3]['id'],'zone_id':zones[0]['id'],'qty':2},{'item_id':items[4]['id'],'zone_id':zones[0]['id'],'qty':1}]},a)
        point=dt.datetime.now(dt.timezone.utc)
        permit=self.command('permit.create',{'title':'دخول مورد تجهيز — مثال مراجعة','holder_name':'سائق تجريبي','kind':'vehicle','vehicle_plate':'DEMO-001','authority':'فريق أمن الموقع — نموذج','project_id':pid,'phase_id':phases[3]['id'],'zone_id':zones[3]['id'],'approval_role':'security','valid_from':(point-dt.timedelta(hours=1)).isoformat(),'valid_until':(point+dt.timedelta(days=7)).isoformat()},a)['result']
        self.command('permit.transition',{'id':permit['id'],'status':'submitted'},a)
        self.command('observation.create',{'project_id':pid,'phase_id':phases[4]['id'],'zone_id':zones[1]['id'],'responsible_id':stakeholders[2]['id'],'observed_at':now(),'people_count':320,'capacity':500,'wait_minutes':8,'satisfaction_score':4.2,'sample_size':30,'evidence':'عدّ تجريبي معزول لأغراض المراجعة فقط'},a)
        with self.connect() as c: c.execute("INSERT INTO metadata VALUES('demo_seeded','1')")
